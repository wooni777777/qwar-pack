clear @s *[minecraft:custom_data~{rpg_crystal:10}] 10
data modify storage rpg:main cry.n set value 1
function rpg:crystal/give11 with storage rpg:main cry
scoreboard players set #ok rpg.sys 1
execute at @s run playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 1 1.3
tellraw @s ["", {"text": "[크리스탈] ", "color": "aqua", "bold": true}, {"text": "10월 크리스탈 10개 \u2192 11월 크리스탈 1개", "color": "white"}]

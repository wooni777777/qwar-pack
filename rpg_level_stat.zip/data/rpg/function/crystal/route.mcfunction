scoreboard players set #ok rpg.sys 0
execute if score @s rpg.cry matches 1 run function rpg:crystal/ex1
execute if score @s rpg.cry matches 2 run function rpg:crystal/ex2
execute if score @s rpg.cry matches 3 run function rpg:crystal/ex3
execute if score @s rpg.cry matches 4 run function rpg:crystal/ex4
execute if score @s rpg.cry matches 5 run function rpg:crystal/ex5
execute if score @s rpg.cry matches 6 run function rpg:crystal/ex6
execute if score @s rpg.cry matches 7 run function rpg:crystal/ex7
execute if score @s rpg.cry matches 8 run function rpg:crystal/ex8
execute if score @s rpg.cry matches 9 run function rpg:crystal/ex9
execute if score @s rpg.cry matches 10 run function rpg:crystal/ex10
execute if score @s rpg.cry matches 11 run function rpg:crystal/ex11
execute if score #ok rpg.sys matches 0 run tellraw @s ["", {"text": "[크리스탈] ", "color": "aqua", "bold": true}, {"text": "크리스탈이 10개 이상 있어야 교환할 수 있습니다.", "color": "red"}]
execute if score #ok rpg.sys matches 0 at @s run playsound minecraft:entity.villager.no player @s ~ ~ ~ 1 1
scoreboard players set @s rpg.cry 0
scoreboard players enable @s rpg.cry

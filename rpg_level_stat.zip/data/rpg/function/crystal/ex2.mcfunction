scoreboard players set #cn rpg.sys 0
execute store result score #cn rpg.sys run clear @s *[minecraft:custom_data~{rpg_crystal:2}] 0
execute if score #cn rpg.sys matches 10.. run function rpg:crystal/ex2_go

# 매 틱 : 착용자 머리에 3D 투구를 붙인다
execute as @a[tag=kw_wh] at @s run function rpg:kawa/fit

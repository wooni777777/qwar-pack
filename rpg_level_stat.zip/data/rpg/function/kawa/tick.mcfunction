# v48 : 카와 투구는 이제 리소스팩 장비 텍스처로만 보입니다 (3D 표시 엔티티 없음)
#   예전에 만들어진 3D 투구가 남아 있으면 치움
execute if entity @e[type=minecraft:item_display,tag=rpg_kwd,limit=1] run kill @e[type=minecraft:item_display,tag=rpg_kwd]

# 투구 착용 여부를 갱신하고 3D 모델을 만들거나 치운다 (0.5초마다)
tag @a remove kw_wh
execute as @a if data entity @s equipment.head.components."minecraft:custom_data".rpg_kawa run tag @s add kw_wh
execute unless entity @a[tag=kw_wh] run kill @e[tag=rpg_kwd]
execute as @a[tag=kw_wh,limit=1] at @s unless entity @e[tag=kw_dh] run function rpg:kawa/mk_h
# 주인이 사라진 모델은 정리
execute as @e[tag=rpg_kwd] at @s unless entity @a[distance=..8] run kill @s

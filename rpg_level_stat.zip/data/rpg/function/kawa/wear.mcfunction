# v48 : 3D 투구를 만들지 않습니다 (리소스팩 장비 텍스처) — 예전 태그만 정리
tag @a remove kw_wh

# 5초마다 : 부위당 1개만 남기고 복제본을 정리한다
function rpg:kawa/sweep_h
function rpg:kawa/sweep_c
function rpg:kawa/sweep_l
function rpg:kawa/sweep_b

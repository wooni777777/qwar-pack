# 4부위 전부 회수
function rpg:kawa/take_h
function rpg:kawa/take_c
function rpg:kawa/take_l
function rpg:kawa/take_b

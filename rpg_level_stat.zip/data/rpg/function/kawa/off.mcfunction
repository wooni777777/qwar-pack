# 3D 투구 모델을 치운다 (꼬였을 때 · 0.5초 뒤 다시 붙습니다)
kill @e[tag=rpg_kwd]
tag @a remove kw_wh
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"3D 투구를 다시 붙입니다.","color":"white"}]

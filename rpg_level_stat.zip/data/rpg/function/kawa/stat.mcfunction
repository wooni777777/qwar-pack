# 카와의 명작 세트 : 4부위를 모두 입으면 공격력 +200 / 최대체력 +150
scoreboard players set #kws rpg.sys 0
execute if data entity @s equipment.head.components."minecraft:custom_data".rpg_kawa run scoreboard players add #kws rpg.sys 1
execute if data entity @s equipment.chest.components."minecraft:custom_data".rpg_kawa run scoreboard players add #kws rpg.sys 1
execute if data entity @s equipment.legs.components."minecraft:custom_data".rpg_kawa run scoreboard players add #kws rpg.sys 1
execute if data entity @s equipment.feet.components."minecraft:custom_data".rpg_kawa run scoreboard players add #kws rpg.sys 1
execute if score #kws rpg.sys matches 4 run scoreboard players add @s rpg.t_atk 200
execute if score #kws rpg.sys matches 4 run scoreboard players add @s rpg.t_hp 150

$clear @s *[minecraft:custom_data~{rpg_kawa:1,kw:"c"}] $(n)

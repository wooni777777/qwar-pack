# [카와의 명작] 클릭 처리
execute unless entity @s[tag=op] run function rpg:menu/noperm
execute unless entity @s[tag=op] run scoreboard players set @s rpg.kw 0
execute unless entity @s[tag=op] run return 0
execute if score @s rpg.kw matches 1 run function rpg:kawa/menu
execute if score @s rpg.kw matches 2 run function rpg:kawa/give_all
execute if score @s rpg.kw matches 3 run function rpg:kawa/take_all
execute if score @s rpg.kw matches 11 run function rpg:kawa/give_h
execute if score @s rpg.kw matches 31 run function rpg:kawa/take_h
execute if score @s rpg.kw matches 12 run function rpg:kawa/give_c
execute if score @s rpg.kw matches 32 run function rpg:kawa/take_c
execute if score @s rpg.kw matches 13 run function rpg:kawa/give_l
execute if score @s rpg.kw matches 33 run function rpg:kawa/take_l
execute if score @s rpg.kw matches 14 run function rpg:kawa/give_b
execute if score @s rpg.kw matches 34 run function rpg:kawa/take_b
execute if score @s rpg.kw matches 2..99 run function rpg:kawa/menu
scoreboard players set @s rpg.kw 0
scoreboard players enable @s rpg.kw

scoreboard players set #kwk rpg.sys 1
execute if score #kwn rpg.sys matches 2.. run function rpg:kawa/cut_l

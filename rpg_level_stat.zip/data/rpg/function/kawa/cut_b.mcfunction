scoreboard players remove #kwn rpg.sys 1
execute store result storage rpg:kawa d.n int 1 run scoreboard players get #kwn rpg.sys
function rpg:kawa/cut2_b with storage rpg:kawa d
tellraw @a[tag=op] [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"카와의 명작 [알보르즈] 복제본을 정리했습니다.","color":"red"}]

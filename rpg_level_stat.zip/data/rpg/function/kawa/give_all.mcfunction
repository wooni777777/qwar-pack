# 4부위 전부 발행 (v57 : 몇 번이든)
function rpg:kawa/give_h
function rpg:kawa/give_c
function rpg:kawa/give_l
function rpg:kawa/give_b

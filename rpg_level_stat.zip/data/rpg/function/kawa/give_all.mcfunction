# 4부위 전부 발행 (아직 발행 안 된 것만)
function rpg:kawa/give_h
function rpg:kawa/give_c
function rpg:kawa/give_l
function rpg:kawa/give_b

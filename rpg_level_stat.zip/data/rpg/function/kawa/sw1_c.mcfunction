scoreboard players set #kwn rpg.sys 0
execute store result score #kwn rpg.sys run clear @s *[minecraft:custom_data~{rpg_kawa:1,kw:"c"}] 0
execute if score #kwn rpg.sys matches ..0 run return 0
# 이미 다른 사람이 갖고 있으면 여기 있는 건 전부 복제본
execute if score #kwk rpg.sys matches 1 run clear @s *[minecraft:custom_data~{rpg_kawa:1,kw:"c"}]
execute if score #kwk rpg.sys matches 1 run tellraw @a[tag=op] [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"카와의 명작 [아한가르] 복제본을 정리했습니다.","color":"red"}]
execute if score #kwk rpg.sys matches 0 run function rpg:kawa/keep_c

scoreboard players set #kwk rpg.sys 0
execute as @a run function rpg:kawa/sw1_l

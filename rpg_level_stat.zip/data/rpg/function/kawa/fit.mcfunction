# 3D 투구를 머리에 맞춘다 (매 틱 · as/at 착용자)
# 머리 좌우(yaw) · 위아래(pitch) 를 그대로 따라갑니다
data modify storage rpg:kawa f set value {oh:1.406}
execute if predicate rpg:sneaking run data modify storage rpg:kawa f set value {oh:1.176}
execute store result storage rpg:kawa f.hy double 0.01 run data get entity @s Rotation[0] 100
execute store result storage rpg:kawa f.hp double 0.01 run data get entity @s Rotation[1] 100
function rpg:kawa/tp_h with storage rpg:kawa f

# 카와의 명작 [디라프시] 을 전부 회수하고 다시 발행할 수 있게 한다
clear @a *[minecraft:custom_data~{rpg_kawa:1,kw:"h"}]
kill @e[type=minecraft:item,nbt={Item:{components:{"minecraft:custom_data":{rpg_kawa:1,kw:"h"}}}}]
scoreboard players set #kw_h rpg.sys 0
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"카와의 명작 [디라프시]","color":"light_purple","bold":true},{"text":" 을(를) 회수했습니다.","color":"white"}]

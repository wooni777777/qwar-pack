# 초 -> 틱 (v44 · 내부용 · 매크로 k v) -> #bf<k>
$data modify storage rpg:bf n set value {v:$(v)}
$execute store result score #bf$(k) rpg.sys run data get storage rpg:bf n.v 20
$execute if score #bf$(k) rpg.sys matches ..0 run scoreboard players set #bf$(k) rpg.sys 1

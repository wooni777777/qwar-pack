# 절대방어 켜기 (v44 · 내부용) — 저항 V (피해 100% 막음) · 이미 있으면 더 긴 쪽
scoreboard players add @s rpg.bgd 0
execute if score #bfg rpg.sys > @s rpg.bgd run scoreboard players operation @s rpg.bgd = #bfg rpg.sys
effect give @s minecraft:resistance infinite 4 true
particle minecraft:end_rod ~ ~1 ~ 0.4 0.6 0.4 0.05 20 normal @a
playsound minecraft:block.beacon.power_select player @a ~ ~ ~ 0.8 1.6

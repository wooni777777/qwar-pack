# 절대방어 켜기 (v44 · 내부용) — 저항 V (피해 100% 막음) · 이미 있으면 더 긴 쪽
scoreboard players add @s rpg.bgd 0
execute if score #bfg rpg.sys > @s rpg.bgd run scoreboard players operation @s rpg.bgd = #bfg rpg.sys
effect give @s minecraft:resistance infinite 4 true
particle minecraft:end_rod ~ ~1 ~ 0.4 0.6 0.4 0.05 20 normal @a
playsound minecraft:block.beacon.power_select player @a ~ ~ ~ 0.8 1.6
scoreboard players operation #bfs rpg.sys = @s rpg.bgd
scoreboard players operation #bfs rpg.sys /= #c20 rpg.sys
scoreboard players operation #bfs2 rpg.sys = @s rpg.bgd
scoreboard players operation #bfs2 rpg.sys %= #c20 rpg.sys
scoreboard players operation #bfs2 rpg.sys /= #c2 rpg.sys
execute if entity @s[type=minecraft:player] run tellraw @s ["", {"text": "[버프] ", "color": "gold", "bold": true}, {"text": "절대방어 ", "color": "yellow", "bold": true}, {"score": {"name": "#bfs", "objective": "rpg.sys"}, "color": "white"}, {"text": ".", "color": "white"}, {"score": {"name": "#bfs2", "objective": "rpg.sys"}, "color": "white"}, {"text": "초 — 받는 피해 0", "color": "gray"}]

# % (v44 · 내부용 · 매크로 v) -> #bfp (0 ~ 100)
$data modify storage rpg:bf n set value {v:$(v)}
execute store result score #bfp rpg.sys run data get storage rpg:bf n.v
execute if score #bfp rpg.sys matches 101.. run scoreboard players set #bfp rpg.sys 100
execute if score #bfp rpg.sys matches ..-1 run scoreboard players set #bfp rpg.sys 0

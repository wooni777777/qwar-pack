# CC 면역 1틱 (v44 · 내부용)
scoreboard players remove @s rpg.bcc 1
execute if score @s rpg.bcc matches ..0 run return run attribute @s minecraft:knockback_resistance modifier remove rpg:ccimm
function rpg:buff/cc_clean

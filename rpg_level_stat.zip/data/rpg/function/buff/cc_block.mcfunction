# 기절을 걸려는 대상이 CC 면역 (v44 · 내부용 · as 때린 사람)
execute at @e[tag=rpg.tgt,limit=1] run particle minecraft:totem_of_undying ~ ~1 ~ 0.3 0.5 0.3 0.1 10 normal @a
tellraw @s [{"text":"[패시브] ","color":"red","bold":true},{"text":"대상이 CC 면역이라 기절하지 않습니다","color":"gray"}]

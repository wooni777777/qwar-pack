# 걸린 CC 풀기 (v44 · 내부용 · CC 면역 동안 매 틱)
execute if entity @s[tag=rpg_stunned] run function rpg:passive/stun_end
execute if entity @s[tag=rpg_stn] run function rpg:stun/end
effect clear @s minecraft:slowness
effect clear @s minecraft:weakness
effect clear @s minecraft:mining_fatigue
effect clear @s minecraft:blindness
effect clear @s minecraft:darkness
effect clear @s minecraft:nausea
effect clear @s minecraft:levitation
execute if entity @s[tag=rpg_lft] run function rpg:lift/end
# v58 : 둔화 · 침묵 · 화면 흔들림 · 방어력 깎기 · 치감 · 시야 차단 · 소리 차단 · 끌기 · 불
function rpg:cc/clear

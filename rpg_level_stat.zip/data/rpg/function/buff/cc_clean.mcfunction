# 걸린 CC 풀기 (v44 · 내부용 · CC 면역 동안 매 틱)
execute if entity @s[tag=rpg_stunned] run function rpg:passive/stun_end
execute if entity @s[tag=rpg_stn] run function rpg:stun/end
effect clear @s minecraft:slowness
effect clear @s minecraft:weakness
effect clear @s minecraft:mining_fatigue
effect clear @s minecraft:blindness
effect clear @s minecraft:darkness
effect clear @s minecraft:nausea
effect clear @s minecraft:levitation

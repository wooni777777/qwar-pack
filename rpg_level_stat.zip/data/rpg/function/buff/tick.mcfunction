# 버프 시간 (v44 · 매 틱)
execute as @e[tag=rpg_bf] run function rpg:buff/tick1

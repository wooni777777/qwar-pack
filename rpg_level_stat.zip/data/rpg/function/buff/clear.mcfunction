# 버프 전부 지우기 (v44 · as 대상) — function rpg:buff/clear  (예 : execute as @p run function rpg:buff/clear)
scoreboard players set @s rpg.bgd 0
scoreboard players set @s rpg.bdt 0
scoreboard players set @s rpg.bdp 0
scoreboard players set @s rpg.bcc 0
execute if predicate rpg:res5 run effect clear @s minecraft:resistance
attribute @s minecraft:knockback_resistance modifier remove rpg:ccimm
tag @s remove rpg_bf

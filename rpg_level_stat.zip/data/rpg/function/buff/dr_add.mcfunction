# 받는 피해 감소 버프를 경감 %(#red) 에 곱으로 더함 (v44 · 내부용 · 100% 를 넘지 않음)
#   예 : 방어력 40% + 버프 30% -> 40 + 30 x 60/100 = 58%
scoreboard players set #rr rpg.sys 100
scoreboard players operation #rr rpg.sys -= #red rpg.sys
scoreboard players operation #rr rpg.sys *= @s rpg.bdp
scoreboard players operation #rr rpg.sys /= #c100 rpg.sys
scoreboard players operation #red rpg.sys += #rr rpg.sys

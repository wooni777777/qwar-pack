# 몬스터 받는 피해 감소 (v44 · 내부용 · 이번 틱 피해 #fd 를 줄임)
scoreboard players set #rr rpg.sys 100
scoreboard players operation #rr rpg.sys -= @s rpg.bdp
scoreboard players operation #fd rpg.sys *= #rr rpg.sys
scoreboard players operation #fd rpg.sys /= #c100 rpg.sys

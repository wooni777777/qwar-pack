# 절대방어 끝 (v44 · 내부용)
scoreboard players set @s rpg.bgd 0
execute if predicate rpg:res5 run effect clear @s minecraft:resistance
execute if entity @s[type=minecraft:player] run tellraw @s ["", {"text": "[버프] ", "color": "gold", "bold": true}, {"text": "절대방어가 끝났습니다", "color": "gray"}]

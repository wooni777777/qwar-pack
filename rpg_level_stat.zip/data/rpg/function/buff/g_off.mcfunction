# 절대방어 끝 (v44 · 내부용)
scoreboard players set @s rpg.bgd 0
execute if predicate rpg:res5 run effect clear @s minecraft:resistance

# (v44 · 내부용 · as 버프 받은 대상)
execute if score @s rpg.bgd matches 1.. run function rpg:buff/g_tick
execute if score @s rpg.bdt matches 1.. run scoreboard players remove @s rpg.bdt 1
execute if score @s rpg.bcc matches 1.. run function rpg:buff/cc_tick
execute unless score @s rpg.bgd matches 1.. unless score @s rpg.bdt matches 1.. unless score @s rpg.bcc matches 1.. run tag @s remove rpg_bf

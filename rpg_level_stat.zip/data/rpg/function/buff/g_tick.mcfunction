# 절대방어 1틱 (v44 · 내부용) — 우유 · 사망 등으로 저항이 풀리면 다시 검
scoreboard players remove @s rpg.bgd 1
execute if score @s rpg.bgd matches ..0 run return run function rpg:buff/g_off
execute unless predicate rpg:res5 run effect give @s minecraft:resistance infinite 4 true

# 받는 피해 감소 켜기 (v44 · 내부용) — 이미 걸려 있으면 % 와 시간 모두 더 큰 쪽
scoreboard players add @s rpg.bdt 0
execute if score @s rpg.bdt matches ..0 run scoreboard players set @s rpg.bdp 0
execute if score #bfp rpg.sys > @s rpg.bdp run scoreboard players operation @s rpg.bdp = #bfp rpg.sys
execute if score #bft rpg.sys > @s rpg.bdt run scoreboard players operation @s rpg.bdt = #bft rpg.sys
particle minecraft:dust_color_transition{from_color:[0.3,0.6,1.0],to_color:[0.8,0.9,1.0],scale:1.4} ~ ~1 ~ 0.4 0.6 0.4 0 16 normal @a
scoreboard players operation #bfs rpg.sys = @s rpg.bdt
scoreboard players operation #bfs rpg.sys /= #c20 rpg.sys
scoreboard players operation #bfs2 rpg.sys = @s rpg.bdt
scoreboard players operation #bfs2 rpg.sys %= #c20 rpg.sys
scoreboard players operation #bfs2 rpg.sys /= #c2 rpg.sys
execute if entity @s[type=minecraft:player] run tellraw @s ["", {"text": "[버프] ", "color": "gold", "bold": true}, {"text": "받는 피해 ", "color": "aqua", "bold": true}, {"score": {"name": "@s", "objective": "rpg.bdp"}, "color": "white"}, {"text": "% 감소 ", "color": "aqua"}, {"score": {"name": "#bfs", "objective": "rpg.sys"}, "color": "white"}, {"text": ".", "color": "white"}, {"score": {"name": "#bfs2", "objective": "rpg.sys"}, "color": "white"}, {"text": "초", "color": "gray"}]

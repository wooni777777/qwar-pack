# 받는 피해 감소 켜기 (v44 · 내부용) — 이미 걸려 있으면 % 와 시간 모두 더 큰 쪽
scoreboard players add @s rpg.bdt 0
execute if score @s rpg.bdt matches ..0 run scoreboard players set @s rpg.bdp 0
execute if score #bfp rpg.sys > @s rpg.bdp run scoreboard players operation @s rpg.bdp = #bfp rpg.sys
execute if score #bft rpg.sys > @s rpg.bdt run scoreboard players operation @s rpg.bdt = #bft rpg.sys

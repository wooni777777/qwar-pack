# 버프 받는 대상 하나 (v44 · 내부용 · as 대상 at 대상)
scoreboard players add #bfn rpg.sys 1
tag @s add rpg_bf
# 받는 피해 감소 100% 는 절대방어로 (맞기 전에 막아야 한 방에 죽지 않음)
execute if score #bfp rpg.sys matches 100.. if score #bft rpg.sys > #bfg rpg.sys run scoreboard players operation #bfg rpg.sys = #bft rpg.sys
execute if score #bfg rpg.sys matches 1.. run function rpg:buff/g_on
execute if score #bft rpg.sys matches 1.. if score #bfp rpg.sys matches 1.. run function rpg:buff/dr_on
execute if score #bfc rpg.sys matches 1.. run function rpg:buff/cc_on

# CC 면역 켜기 (v44 · 내부용) — 걸려 있던 CC 도 바로 풀림 · 밀려남 없음
scoreboard players add @s rpg.bcc 0
execute if score #bfc rpg.sys > @s rpg.bcc run scoreboard players operation @s rpg.bcc = #bfc rpg.sys
attribute @s minecraft:knockback_resistance modifier remove rpg:ccimm
attribute @s minecraft:knockback_resistance modifier add rpg:ccimm 1 add_value
function rpg:buff/cc_clean
particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.6 0.4 0.1 14 normal @a

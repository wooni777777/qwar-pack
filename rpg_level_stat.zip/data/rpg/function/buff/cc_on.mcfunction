# CC 면역 켜기 (v44 · 내부용) — 걸려 있던 CC 도 바로 풀림 · 밀려남 없음
scoreboard players add @s rpg.bcc 0
execute if score #bfc rpg.sys > @s rpg.bcc run scoreboard players operation @s rpg.bcc = #bfc rpg.sys
attribute @s minecraft:knockback_resistance modifier remove rpg:ccimm
attribute @s minecraft:knockback_resistance modifier add rpg:ccimm 1 add_value
function rpg:buff/cc_clean
particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.6 0.4 0.1 14 normal @a
scoreboard players operation #bfs rpg.sys = @s rpg.bcc
scoreboard players operation #bfs rpg.sys /= #c20 rpg.sys
scoreboard players operation #bfs2 rpg.sys = @s rpg.bcc
scoreboard players operation #bfs2 rpg.sys %= #c20 rpg.sys
scoreboard players operation #bfs2 rpg.sys /= #c2 rpg.sys
execute if entity @s[type=minecraft:player] run tellraw @s ["", {"text": "[버프] ", "color": "gold", "bold": true}, {"text": "CC 면역 ", "color": "green", "bold": true}, {"score": {"name": "#bfs", "objective": "rpg.sys"}, "color": "white"}, {"text": ".", "color": "white"}, {"score": {"name": "#bfs2", "objective": "rpg.sys"}, "color": "white"}, {"text": "초 — 기절 · 느려짐 · 밀려남 없음", "color": "gray"}]

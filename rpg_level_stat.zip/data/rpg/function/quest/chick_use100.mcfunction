advancement revoke @s only rpg:quest/chick100
execute at @s rotated ~ 0 run function rpg:quest/sum_chick100

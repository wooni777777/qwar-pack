function rpg:quest/nl
playsound minecraft:entity.villager.ambient player @s ~ ~ ~ 1 0.9
tellraw @s ["",{"text":"[돌쇠] ","color":"gold","bold":true},{"text":"내가 돌을 수집을 취미로 하고 있어서 돌을 모아줄 수 있겠니?","color":"white"}]
tellraw @s " "
tellraw @s ["",{"text":"          "},{"text":"[ 수 락 ]","color":"gold","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.q set 5"},"hover_event":{"action":"show_text","value":{"text":"퀘스트를 받습니다","color":"gray"}}}]

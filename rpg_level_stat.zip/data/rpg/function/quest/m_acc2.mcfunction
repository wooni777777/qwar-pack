scoreboard players set @s rpg.q_main 4
scoreboard players set @s rpg.qc 0
function rpg:quest/nl
tellraw @s ["",{"text":"[돌쇠] ","color":"gold","bold":true},{"text":"길가에 있는 ","color":"white"},{"text":"또돌맹","color":"gray","bold":true},{"text":" 을 잡아줘","color":"white"}]
tellraw @s ["",{"text":"  진행도 : ","color":"gray"},{"score":{"name":"@s","objective":"rpg.qc"},"color":"green"},{"text":" / ","color":"dark_gray"},{"score":{"name":"#q2_need","objective":"rpg.sys"},"color":"green"}]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1 1.6

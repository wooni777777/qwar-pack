scoreboard players set #qmn rpg.sys 99999
scoreboard players operation #qmn rpg.sys < #o1 rpg.sys
scoreboard players operation #qmn rpg.sys < #o2 rpg.sys
execute if score #qmn rpg.sys matches 99999 run return 0
execute if score #o1 rpg.sys = #qmn rpg.sys run function rpg:quest/clr_tuto
execute if score #o2 rpg.sys = #qmn rpg.sys run function rpg:quest/clr_main
execute if score #o1 rpg.sys = #qmn rpg.sys run scoreboard players set #o1 rpg.sys 99999
execute if score #o2 rpg.sys = #qmn rpg.sys run scoreboard players set #o2 rpg.sys 99999
function rpg:quest/clr_loop

tellraw @s " "
tellraw @s ["",{"text":"  사냥터 ","color":"gray"},{"text":"돌의 조각 섬","color":"aqua"},{"text":" 의 ","color":"gray"},{"text":"돌쇠","color":"gold","bold":true},{"text":" 가 도움을 기다리고 있습니다.","color":"gray"}]
function rpg:quest/loc_dolsoi

function rpg:quest/nl
tellraw @s ["",{"text":"[마을 어른] ","color":"yellow","bold":true},{"text":"검을 찾아줘서 정말 고마웠어. 몸조심 하려무나.","color":"white"}]

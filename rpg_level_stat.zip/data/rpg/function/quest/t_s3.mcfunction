function rpg:quest/nl
playsound minecraft:entity.villager.ambient player @s ~ ~ ~ 1 1.1
tellraw @s ["",{"text":"[마을 어른] ","color":"yellow","bold":true},{"text":"내 집에서 검을 잃어버렸어  내 검을 찾아줄 수 있겠어?","color":"white"}]
tellraw @s " "
tellraw @s ["",{"text":"          "},{"text":"[ 수 락 ]","color":"gold","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.q set 3"},"hover_event":{"action":"show_text","value":{"text":"퀘스트를 받습니다","color":"gray"}}}]

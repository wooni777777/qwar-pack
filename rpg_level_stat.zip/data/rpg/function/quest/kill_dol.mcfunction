advancement revoke @s only rpg:mob/kill_dol
function rpg:mob/pay_dol

tellraw @s ["",{"text":"    [튜토리얼] ","color":"yellow","bold":true},{"text":"잃어버린 검","color":"white"},{"text":"  -  ","color":"dark_gray"},{"text":"진행 중..","color":"aqua"}]
tellraw @s ["",{"text":"        어른의 집에서 ","color":"gray"},{"text":"진검","color":"aqua"},{"text":" 을 찾아 오세요","color":"gray"}]
function rpg:quest/loc_elder

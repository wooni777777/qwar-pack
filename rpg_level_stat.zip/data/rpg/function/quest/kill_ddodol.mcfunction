advancement revoke @s only rpg:mob/kill_ddodol
function rpg:mob/pay_ddodol
execute if score @s rpg.q_main matches 4 run function rpg:quest/cnt2

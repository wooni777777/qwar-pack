summon minecraft:chicken ^ ^ ^1.4 {Tags:["rpg_expchick","rpg_ec500","rpg_newc"],CustomName:{text:"경험치 닭 (500)",color:"gold",bold:true},CustomNameVisible:1b,NoAI:1b,PersistenceRequired:1b,DeathLootTable:"minecraft:empty",EggLayTime:2000000000}
attribute @e[tag=rpg_newc,limit=1] minecraft:max_health base set 1
data modify entity @e[tag=rpg_newc,limit=1] Health set value 1.0f
tag @e[tag=rpg_newc] remove rpg_newc
playsound minecraft:entity.chicken.egg player @s ~ ~ ~ 1 1.2

advancement revoke @s only rpg:mob/kill_pir1
advancement revoke @s only rpg:mob/kill_pir2
advancement revoke @s only rpg:mob/kill_pir3
function rpg:mob/pay_pirate
scoreboard players operation @s rpg.exp += #exp_mid rpg.sys
function rpg:exp/check

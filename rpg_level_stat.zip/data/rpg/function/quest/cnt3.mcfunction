scoreboard players add @s rpg.qc 1
execute if score @s rpg.qc >= #q3_need rpg.sys run function rpg:quest/step3_done
execute if score @s rpg.qc < #q3_need rpg.sys run tellraw @s ["",{"text":"[퀘스트] ","color":"yellow","bold":true},{"text":"돌맹이 ","color":"white"},{"score":{"name":"@s","objective":"rpg.qc"},"color":"green"},{"text":" / ","color":"dark_gray"},{"score":{"name":"#q3_need","objective":"rpg.sys"},"color":"green"}]

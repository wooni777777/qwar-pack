execute unless score @s rpg.q_tuto matches 0.. run scoreboard players set @s rpg.q_tuto 0
execute unless score @s rpg.q_main matches 0.. run scoreboard players set @s rpg.q_main 0
execute unless score @s rpg.qc matches 0.. run scoreboard players set @s rpg.qc 0
scoreboard players enable @s rpg.q
execute if score @s rpg.q_main matches ..0 run function rpg:quest/m_s1
execute if score @s rpg.q_main matches 1 run function rpg:quest/m_prog1
execute if score @s rpg.q_main matches 2 run function rpg:quest/m_done1
execute if score @s rpg.q_main matches 3 run function rpg:quest/m_offer2
execute if score @s rpg.q_main matches 4 run function rpg:quest/m_prog2
execute if score @s rpg.q_main matches 5 run function rpg:quest/m_done2
execute if score @s rpg.q_main matches 6 run function rpg:quest/m_offer3
execute if score @s rpg.q_main matches 7 run function rpg:quest/m_prog3
execute if score @s rpg.q_main matches 8 run function rpg:quest/m_done3
execute if score @s rpg.q_main matches 9.. run function rpg:quest/m_after

advancement revoke @s only rpg:quest/chick50
execute at @s rotated ~ 0 run function rpg:quest/sum_chick50

scoreboard players set @s rpg.q_main 5
tellraw @s [{"text":"[퀘스트] ","color":"yellow","bold":true},{"text":"목표 달성! ","color":"green","bold":true},{"text":"돌쇠 에게 돌아가세요.","color":"white"}]
execute at @s run playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1 1.4

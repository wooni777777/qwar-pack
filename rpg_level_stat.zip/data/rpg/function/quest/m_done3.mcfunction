scoreboard players set @s rpg.q_main 9
scoreboard players add @s rpg.qord 1
scoreboard players operation @s rpg.qo2 = @s rpg.qord
function rpg:quest/nl
tellraw @s ["",{"text":"[돌쇠] ","color":"gold","bold":true},{"text":"진짜 고마워!","color":"white"}]
tellraw @s " "
tellraw @s [{"text":"[퀘스트 완료] ","color":"gold","bold":true},{"text":"돌 수집가 돌쇠","color":"yellow","bold":true}]
function rpg:quest/chick100_2
function rpg:quest/chick50_1
function rpg:quest/bill100_1
tellraw @s ["",{"text":"  보상 : ","color":"gray"},{"text":"경험치 닭(100) 2개","color":"green"},{"text":" · ","color":"dark_gray"},{"text":"경험치 닭(50) 1개","color":"green"},{"text":" · ","color":"dark_gray"},{"text":"100원 수표 1장","color":"gold"}]
playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1 1

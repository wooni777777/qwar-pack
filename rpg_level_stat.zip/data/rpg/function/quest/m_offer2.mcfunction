tellraw @s ["",{"text":"[돌쇠] ","color":"gold","bold":true},{"text":"다음은 또돌맹을 잡아 줄 수 있겠니?","color":"white"}]
tellraw @s ["",{"text":"          "},{"text":"[ 수 락 ]","color":"gold","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.q set 6"},"hover_event":{"action":"show_text","value":{"text":"퀘스트를 받습니다","color":"gray"}}}]

tellraw @s ["",{"text":"    [튜토리얼] ","color":"gray","bold":true},{"text":"잃어버린 검","color":"gray"},{"text":"  -  ","color":"dark_gray"},{"text":"클리어","color":"gray"}]

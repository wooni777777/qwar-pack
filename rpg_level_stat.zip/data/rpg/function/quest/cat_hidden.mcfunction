tellraw @s ["",{"text":"  { 히든 퀘스트 }","color":"red","bold":true}]
tellraw @s ["",{"text":"    아직 발견한 히든 퀘스트가 없습니다","color":"dark_gray"}]

function rpg:quest/nl
playsound minecraft:entity.villager.ambient player @s ~ ~ ~ 1 1.1
tellraw @s ["",{"text":"[마을 어른] ","color":"yellow","bold":true},{"text":"안녕 너가 소문으로 유명한 그 사람이구나","color":"white"}]
tellraw @s " "
tellraw @s ["",{"text":"          "},{"text":"[ 다음 ]","color":"green","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.q set 1"},"hover_event":{"action":"show_text","value":{"text":"대화를 이어갑니다","color":"gray"}}}]

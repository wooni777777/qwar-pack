advancement revoke @s only rpg:quest/chick500
execute at @s rotated ~ 0 run function rpg:quest/sum_chick500

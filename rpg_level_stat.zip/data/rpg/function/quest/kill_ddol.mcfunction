advancement revoke @s only rpg:mob/kill_ddol
function rpg:mob/pay_ddol
execute if score @s rpg.q_main matches 1 run function rpg:quest/cnt1

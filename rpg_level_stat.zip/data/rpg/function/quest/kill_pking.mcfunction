# 보스 보상은 [드롭템 설정] 의 슬롯이 담당합니다 (v35)
#   죽인 방법과 상관없이 mob/on_death 에서 바닥에 떨어집니다.
advancement revoke @s only rpg:mob/kill_pking

advancement revoke @s only rpg:mob/kill_pking
function rpg:mob/pay_pking
scoreboard players operation @s rpg.exp += #exp_boss rpg.sys
function rpg:exp/check

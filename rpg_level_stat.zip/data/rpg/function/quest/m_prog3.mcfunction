function rpg:quest/nl
tellraw @s ["",{"text":"[돌쇠] ","color":"gold","bold":true},{"text":"아직 돌맹이 이(가) 부족해. 조금만 더 부탁할게!","color":"white"}]
tellraw @s ["",{"text":"  진행도 : ","color":"gray"},{"score":{"name":"@s","objective":"rpg.qc"},"color":"green"},{"text":" / ","color":"dark_gray"},{"score":{"name":"#q3_need","objective":"rpg.sys"},"color":"green"}]

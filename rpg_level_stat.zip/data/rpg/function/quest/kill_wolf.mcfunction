advancement revoke @s only rpg:mob/kill_wolf
function rpg:mob/pay_wolf

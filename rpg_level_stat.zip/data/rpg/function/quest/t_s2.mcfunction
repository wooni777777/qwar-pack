function rpg:quest/nl
playsound minecraft:entity.villager.ambient player @s ~ ~ ~ 1 1.1
tellraw @s ["",{"text":"[마을 어른] ","color":"yellow","bold":true},{"text":"가기전에 잠깐 나를 좀 도와줄 수 있겠어?","color":"white"}]
tellraw @s " "
tellraw @s ["",{"text":"          "},{"text":"[ 다음 ]","color":"green","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.q set 2"},"hover_event":{"action":"show_text","value":{"text":"대화를 이어갑니다","color":"gray"}}}]

advancement revoke @s only rpg:quest/killchick100
scoreboard players add @s rpg.exp 100
tellraw @s ["",{"text":"[경험치] ","color":"green","bold":true},{"text":"경험치 닭  +100","color":"white"}]
execute at @s run playsound minecraft:entity.player.levelup player @s ~ ~ ~ 0.8 1.8
execute at @s run particle minecraft:happy_villager ~ ~1 ~ 0.5 0.6 0.5 0 15 normal @a
function rpg:exp/check

tellraw @s ["",{"text":"    [메인] ","color":"gray","bold":true},{"text":"돌 수집가 돌쇠","color":"gray"},{"text":"  -  ","color":"dark_gray"},{"text":"클리어","color":"gray"}]

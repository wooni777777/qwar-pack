scoreboard players set @s rpg.q_main 6
function rpg:quest/nl
tellraw @s ["",{"text":"[돌쇠] ","color":"gold","bold":true},{"text":"고마워! 마지막으로 도와줄 수 있을까?","color":"white"}]
function rpg:quest/chick50_3
function rpg:quest/bill10_5
tellraw @s ["",{"text":"  보상 : ","color":"gray"},{"text":"경험치 닭(50) 3개","color":"green"},{"text":" · ","color":"dark_gray"},{"text":"10원 수표 5장","color":"gold"}]
playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1 1
tellraw @s " "
function rpg:quest/m_offer3

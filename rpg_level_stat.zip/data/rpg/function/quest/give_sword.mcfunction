give @s stone_sword[minecraft:custom_data={rpg_qsword:1b},minecraft:item_name={"text":"진검","color":"aqua","bold":true},minecraft:lore=[{"text":"퀘스트용 - 마을 어른에게 가져다 주세요","color":"gray","italic":false}],minecraft:attribute_modifiers=[],minecraft:max_stack_size=1,minecraft:unbreakable={}] 1
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"퀘스트용 [진검] 을 지급했습니다. 상자에 넣어 두세요.","color":"white"}]

execute unless score @s rpg.q_tuto matches 0.. run scoreboard players set @s rpg.q_tuto 0
execute unless score @s rpg.q_main matches 0.. run scoreboard players set @s rpg.q_main 0
execute unless score @s rpg.qc matches 0.. run scoreboard players set @s rpg.qc 0
scoreboard players enable @s rpg.q
execute if score @s rpg.q_tuto matches ..0 run function rpg:quest/t_s1
execute if score @s rpg.q_tuto matches 1 run function rpg:quest/t_check
execute if score @s rpg.q_tuto matches 2.. run function rpg:quest/t_after

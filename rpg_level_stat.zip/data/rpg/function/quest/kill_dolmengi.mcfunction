advancement revoke @s only rpg:mob/kill_dolmengi
function rpg:mob/pay_dolmengi
execute if score @s rpg.q_main matches 7 run function rpg:quest/cnt3

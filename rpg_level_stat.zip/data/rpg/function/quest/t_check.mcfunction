scoreboard players set #hs rpg.sys 0
execute store result score #hs rpg.sys run clear @s *[minecraft:custom_data~{rpg_qsword:1b}] 0
execute if score #hs rpg.sys matches 1.. run function rpg:quest/t_done
execute if score #hs rpg.sys matches ..0 run function rpg:quest/nl
execute if score #hs rpg.sys matches ..0 run tellraw @s ["",{"text":"[마을 어른] ","color":"yellow","bold":true},{"text":"아직 내 검을 못 찾았구나. 내 집을 잘 뒤져 보렴.","color":"white"}]

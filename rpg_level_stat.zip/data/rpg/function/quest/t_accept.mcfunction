scoreboard players set @s rpg.q_tuto 1
function rpg:quest/nl
tellraw @s [{"text":"[퀘스트 수락] ","color":"gold","bold":true},{"text":"잃어버린 검","color":"yellow","bold":true}]
tellraw @s ["",{"text":"  마을 어른의 집에서 ","color":"white"},{"text":"진검","color":"aqua","bold":true},{"text":" 을 찾아 들고 오세요.","color":"white"}]
function rpg:quest/loc_elder
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1 1.6

scoreboard players add @s rpg.qc 1
execute if score @s rpg.qc >= #q2_need rpg.sys run function rpg:quest/step2_done
execute if score @s rpg.qc < #q2_need rpg.sys run tellraw @s ["",{"text":"[퀘스트] ","color":"yellow","bold":true},{"text":"또돌맹 ","color":"white"},{"score":{"name":"@s","objective":"rpg.qc"},"color":"green"},{"text":" / ","color":"dark_gray"},{"score":{"name":"#q2_need","objective":"rpg.sys"},"color":"green"}]

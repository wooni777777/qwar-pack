scoreboard players set @s rpg.q_main 3
function rpg:quest/nl
tellraw @s ["",{"text":"[돌쇠] ","color":"gold","bold":true},{"text":"고마워! 다음도 도와줄 수 있을까?","color":"white"}]
function rpg:quest/chick50_1
function rpg:quest/bill10_1
tellraw @s ["",{"text":"  보상 : ","color":"gray"},{"text":"경험치 닭(50) 1개","color":"green"},{"text":" · ","color":"dark_gray"},{"text":"10원 수표 1장","color":"gold"}]
playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1 1
tellraw @s " "
function rpg:quest/m_offer2

kill @e[tag=rpg_qnpc]
scoreboard players set #elon rpg.sys 0
scoreboard players set #dson rpg.sys 0
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"퀘스트 NPC 를 모두 제거했습니다.","color":"white"}]

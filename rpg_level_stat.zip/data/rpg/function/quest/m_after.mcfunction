function rpg:quest/nl
tellraw @s ["",{"text":"[돌쇠] ","color":"gold","bold":true},{"text":"네 덕분에 수집품이 아주 늘었어. 언제든 또 놀러 오렴!","color":"white"}]

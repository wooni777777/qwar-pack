scoreboard players enable @s rpg.menu
scoreboard players enable @s rpg.q
execute unless score @s rpg.q_tuto matches 0.. run scoreboard players set @s rpg.q_tuto 0
execute unless score @s rpg.q_main matches 0.. run scoreboard players set @s rpg.q_main 0
execute unless score @s rpg.qc matches 0.. run scoreboard players set @s rpg.qc 0
execute unless score @s rpg.qcat matches 1..3 run scoreboard players set @s rpg.qcat 1
playsound minecraft:item.book.page_turn player @s ~ ~ ~ 1 1.2
tellraw @s " "
tellraw @s {"text":"━━━━━━━━━  퀘 스 트  ━━━━━━━━━","color":"dark_gray"}
execute if score @s rpg.qcat matches 1 run function rpg:quest/cat_main
execute if score @s rpg.qcat matches 2 run function rpg:quest/cat_sub
execute if score @s rpg.qcat matches 3 run function rpg:quest/cat_hidden
tellraw @s " "
execute if score @s rpg.qcat matches 1 run tellraw @s ["", {"text": "   "}, {"text": "▶ [ 메인 ]", "color": "green", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.q set 11"}}, {"text": "  "}, {"text": "[ 서브 ]", "color": "dark_gray", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.q set 12"}}, {"text": "  "}, {"text": "[ 히든 ]", "color": "dark_gray", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.q set 13"}}]
execute if score @s rpg.qcat matches 2 run tellraw @s ["", {"text": "   "}, {"text": "[ 메인 ]", "color": "dark_gray", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.q set 11"}}, {"text": "  "}, {"text": "▶ [ 서브 ]", "color": "gold", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.q set 12"}}, {"text": "  "}, {"text": "[ 히든 ]", "color": "dark_gray", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.q set 13"}}]
execute if score @s rpg.qcat matches 3 run tellraw @s ["", {"text": "   "}, {"text": "[ 메인 ]", "color": "dark_gray", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.q set 11"}}, {"text": "  "}, {"text": "[ 서브 ]", "color": "dark_gray", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.q set 12"}}, {"text": "  "}, {"text": "▶ [ 히든 ]", "color": "red", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.q set 13"}}]
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}

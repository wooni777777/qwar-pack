# 클리어 순번(rpg.qo*) 이 작은 것부터 출력
scoreboard players set #o1 rpg.sys 99999
scoreboard players set #o2 rpg.sys 99999
execute if score @s rpg.q_tuto matches 2.. run scoreboard players operation #o1 rpg.sys = @s rpg.qo1
execute if score @s rpg.q_main matches 9.. run scoreboard players operation #o2 rpg.sys = @s rpg.qo2
function rpg:quest/clr_loop

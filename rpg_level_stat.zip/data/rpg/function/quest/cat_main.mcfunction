tellraw @s ["",{"text":"  { 메인 퀘스트 }","color":"green","bold":true}]
# --- 클리어한 퀘스트 (클리어한 순서대로, 회색) ---
scoreboard players set #qc rpg.sys 0
execute if score @s rpg.q_tuto matches 2.. run scoreboard players add #qc rpg.sys 1
execute if score @s rpg.q_main matches 9.. run scoreboard players add #qc rpg.sys 1
execute if score #qc rpg.sys matches 1.. run function rpg:quest/clr_sort
# --- 진행중인 퀘스트 (아직 안 받은 퀘스트는 보여주지 않는다) ---
scoreboard players set #qp rpg.sys 0
execute if score @s rpg.q_tuto matches 1 run scoreboard players add #qp rpg.sys 1
execute if score @s rpg.q_main matches 1..8 run scoreboard players add #qp rpg.sys 1
execute if score #qc rpg.sys matches 1.. if score #qp rpg.sys matches 1.. run tellraw @s " "
execute if score @s rpg.q_tuto matches 1 run function rpg:quest/row_tuto
execute if score @s rpg.q_main matches 1..8 run function rpg:quest/row_main
execute if score #qc rpg.sys matches 0 if score #qp rpg.sys matches 0 run tellraw @s ["",{"text":"    진행 중인 메인 퀘스트가 없습니다","color":"dark_gray"}]

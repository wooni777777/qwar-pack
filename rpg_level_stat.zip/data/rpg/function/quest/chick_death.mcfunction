tag @s add rpg_dead
particle minecraft:happy_villager ~ ~0.4 ~ 0.3 0.3 0.3 0 12 normal @a

clear @s *[minecraft:custom_data~{rpg_qsword:1b}] 1
scoreboard players add @s rpg.qord 1
scoreboard players operation @s rpg.qo1 = @s rpg.qord
scoreboard players set @s rpg.q_tuto 2
function rpg:quest/nl
tellraw @s ["",{"text":"[마을 어른] ","color":"yellow","bold":true},{"text":"오 고마워  진검보다는 약하겠지만 훈련용 검을 줄게","color":"white"}]
tellraw @s " "
tellraw @s [{"text":"[퀘스트 완료] ","color":"gold","bold":true},{"text":"잃어버린 검","color":"yellow","bold":true}]
function rpg:quest/give_train
function rpg:quest/chick100_1
function rpg:quest/bill1_10
tellraw @s ["",{"text":"  보상 : ","color":"gray"},{"text":"훈련용 검","color":"white"},{"text":" · ","color":"dark_gray"},{"text":"경험치 닭(100) 1개","color":"green"},{"text":" · ","color":"dark_gray"},{"text":"1원 수표 10장","color":"gold"}]
function rpg:quest/loc_dolsoi_hint
playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1 1

execute if score @s rpg.q matches 1 if score @s rpg.q_tuto matches ..0 run function rpg:quest/t_s2
execute if score @s rpg.q matches 2 if score @s rpg.q_tuto matches ..0 run function rpg:quest/t_s3
execute if score @s rpg.q matches 3 if score @s rpg.q_tuto matches ..0 run function rpg:quest/t_accept
execute if score @s rpg.q matches 4 if score @s rpg.q_main matches ..0 run function rpg:quest/m_s2
execute if score @s rpg.q matches 5 if score @s rpg.q_main matches ..0 run function rpg:quest/m_acc1
execute if score @s rpg.q matches 6 if score @s rpg.q_main matches 3 run function rpg:quest/m_acc2
execute if score @s rpg.q matches 7 if score @s rpg.q_main matches 6 run function rpg:quest/m_acc3
execute if score @s rpg.q matches 11 run scoreboard players set @s rpg.qcat 1
execute if score @s rpg.q matches 12 run scoreboard players set @s rpg.qcat 2
execute if score @s rpg.q matches 13 run scoreboard players set @s rpg.qcat 3
execute if score @s rpg.q matches 11..13 run function rpg:quest/menu
scoreboard players set @s rpg.q 0
scoreboard players enable @s rpg.q

function rpg:quest/nl
playsound minecraft:entity.villager.ambient player @s ~ ~ ~ 1 0.9
tellraw @s ["",{"text":"[돌쇠] ","color":"gold","bold":true},{"text":"안녕 너 혹시 나를 좀 도와줄 수 있겠니?","color":"white"}]
tellraw @s " "
tellraw @s ["",{"text":"          "},{"text":"[ 다음 ]","color":"green","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.q set 4"},"hover_event":{"action":"show_text","value":{"text":"대화를 이어갑니다","color":"gray"}}}]

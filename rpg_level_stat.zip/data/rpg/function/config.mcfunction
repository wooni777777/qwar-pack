# ============================================================
#  설정값 - 이 파일의 숫자만 바꾸면 밸런스 조절이 끝납니다
#  (수정 후 /reload)
# ============================================================

# 레벨업 필요 경험치 = exp_base + exp_step*(레벨-1) + exp_quad*(레벨-1)^2
# 예) 19->20 레벨 : 100 + 540 + 20*324 = 7120
scoreboard players set #exp_base rpg.sys 100
scoreboard players set #exp_step rpg.sys 30
scoreboard players set #exp_quad rpg.sys 20

# 레벨업 시 지급하는 자유 스탯
scoreboard players set #sp_level rpg.sys 3

# 몹 처치 경험치 : 모든 몹 공통 + 등급 보너스
scoreboard players set #exp_kill rpg.sys 3
scoreboard players set #exp_mid rpg.sys 7
scoreboard players set #exp_high rpg.sys 22
scoreboard players set #exp_boss rpg.sys 297

# 바닐라 경험치(경험치 병, 경험치 구슬, 화로, 채굴 등) 1당 RPG 경험치
# 0 으로 두면 바닐라 경험치는 RPG 경험치로 전환되지 않습니다
scoreboard players set #xp_rate rpg.sys 1
# 1 이면 변환 후 바닐라 경험치를 0 으로 만들어 화면의 경험치 바/숫자를 완전히 없앤다
# (0 으로 두면 바닐라 경험치가 남아 인챈트에 쓸 수 있지만 초록 숫자가 보입니다)
scoreboard players set #xp_zero rpg.sys 1

# 레벨 1당 추가 최대체력 (v50 : 20)
scoreboard players set #hp_level rpg.sys 20

# 힘 1당  (공격력 단위 0.1 -> 6 = 공격력 +0.6) · 최대체력 (v50 : +0.6 / +4)
scoreboard players set #str_atk rpg.sys 6
scoreboard players set #str_hp rpg.sys 4

# 민첩 1당 (v50 : 공격력 +0.3 / 이속 +0.001 / 크리티컬 +0.35% / 최대체력 +3)
scoreboard players set #dex_atk rpg.sys 3
scoreboard players set #dex_spd rpg.sys 10
# 민첩 1당 최대체력
scoreboard players set #dex_hp rpg.sys 3

# 체력 1당  (v50 : 공격력 +0.1 (2 를 반으로) / 최대체력 +8 / 방어력 +0.1)
scoreboard players set #con_atk rpg.sys 2
scoreboard players set #con_hp rpg.sys 8

# 상수 (건드리지 마세요)
scoreboard players set #c2 rpg.sys 2
scoreboard players set #cm1 rpg.sys -1
scoreboard players set #c5 rpg.sys 5
scoreboard players set #c6 rpg.sys 6
scoreboard players set #c9 rpg.sys 9
scoreboard players set #c10 rpg.sys 10
scoreboard players set #c20 rpg.sys 20
scoreboard players set #c3 rpg.sys 3
scoreboard players set #c7 rpg.sys 7
scoreboard players set #c25 rpg.sys 25
scoreboard players set #c10000 rpg.sys 10000
scoreboard players set #c16 rpg.sys 16
scoreboard players set #c1000 rpg.sys 1000
scoreboard players set #c360 rpg.sys 360
scoreboard players set #c1024 rpg.sys 1024
# 바닐라 피해 1 이 실제 체력 몇 만큼인지 (몹/낙하/화상/명령어 피해 환산 배율)
scoreboard players set #dmgmul rpg.sys 1
# 민첩 1당 크리티컬 확률 (1000분율 · 2 로 나눔 : 7 = 0.35%)
scoreboard players set #dex_crit rpg.sys 7
# 급소찾기(민첩 50) 추가 크리티컬 확률 (30 = 3%)
scoreboard players set #crit_p rpg.sys 30
# 모든 플레이어 공격속도 보정
scoreboard players set #aspd rpg.sys 16
scoreboard players set #c50 rpg.sys 50
scoreboard players set #c70 rpg.sys 70
scoreboard players set #c90 rpg.sys 90
scoreboard players set #c92 rpg.sys 92
# 몬스터 모델 앞뒤 보정 (뒤돌아 보이면 function rpg:mob/face_flip)
execute unless score #mfoff rpg.sys matches 0.. run scoreboard players set #mfoff rpg.sys 180
scoreboard players set #c81 rpg.sys 81
scoreboard players set #c100 rpg.sys 100
scoreboard players set #c325 rpg.sys 325
scoreboard players set #c720 rpg.sys 720
scoreboard players set #c4440 rpg.sys 4440

# 회복 계산용 2의 거듭제곱
scoreboard players set #c4 rpg.sys 4
scoreboard players set #b0 rpg.sys 1
scoreboard players set #b1 rpg.sys 2
scoreboard players set #b2 rpg.sys 4
scoreboard players set #b3 rpg.sys 8
scoreboard players set #b4 rpg.sys 16
scoreboard players set #b5 rpg.sys 32
scoreboard players set #b6 rpg.sys 64
scoreboard players set #b7 rpg.sys 128

scoreboard players set #c7 rpg.sys 7
scoreboard players set #c12 rpg.sys 12
scoreboard players set #c15 rpg.sys 15
scoreboard players set #c30 rpg.sys 30
scoreboard players set #c40 rpg.sys 40
scoreboard players set #c60 rpg.sys 60
scoreboard players set #c8 rpg.sys 8
scoreboard players set #c350 rpg.sys 350

# ============================================================
#  도약 (민첩 20)
# ============================================================
# 한 번에 터뜨릴 돌풍구 개수. 숫자가 클수록 더 멀리/높이 날아갑니다. (권장 2~5)
scoreboard players set #leap_pow rpg.sys 3

# ============================================================
#  몬스터 / 사냥터
# ============================================================
# 잡몹 리스폰 대기 (초)
scoreboard players set #mob_cd rpg.sys 5
# 하위 보스 리스폰 대기 (초) - 900 = 15분
scoreboard players set #boss_cd rpg.sys 900
# 보스 회복 : 2초마다 최대체력의 몇 % 를 회복하는가
#  - in  : 최근 5초 안에 맞은 적이 있을 때 (전투 중)
#  - out : 아무도 안 때리고 있을 때 (도망/시간끌기 방지용, 원래 요청값 10%)
scoreboard players set #boss_rg_in rpg.sys 1
scoreboard players set #boss_rg_out rpg.sys 10
# 경험치 조각 1개당 RPG 경험치
scoreboard players set #shard_exp rpg.sys 10

# ============================================================
#  퀘스트 목표 수량
# ============================================================
scoreboard players set #q1_need rpg.sys 15
scoreboard players set #q2_need rpg.sys 20
scoreboard players set #q3_need rpg.sys 25

# ============================================================
#  스킬 아이템 쿨타임 (틱 단위 : 20 = 1초)
# ============================================================
# 도약 25초
scoreboard players set #leap_cd rpg.sys 500
# 기절시키기 40초 (v72 · 예전 60초)
scoreboard players set #stun_cd rpg.sys 800
# v51 : 그림자이동 쿨 (틱 · 900 = 45초) · 영웅의 힘 쿨 (틱 · 1200 = 60초) · 영웅의 힘 무적 (틱 · 60 = 3초)
scoreboard players set #shadow_cd rpg.sys 900
scoreboard players set #hero_cd rpg.sys 1200
scoreboard players set #hero_t rpg.sys 60

# 만렙 (이 레벨에 도달하면 더 이상 오르지 않습니다)
# 레벨 제한 없음 (필요 경험치 계산이 넘치지 않는 선에서 최대치)
scoreboard players set #lv_max rpg.sys 10000

# ============================================================
#  방어력 (v49) : 방어력 1당 받는 피해 -0.5 (고정 · 피해경감 % 와 따로)
#  def_min : 한 번 맞은 피해 중 이 % 는 방어력으로 못 줄임 (방어력이 아주 높아도 무적이 안 되게)
#            0 으로 하면 방어력만큼 전부 줄어듭니다 (피해 0 까지)
#  피해경감 % 는 패시브 · 버프 · 균열에서만 오르고, 방어력으로 줄이고 "남은" 피해에 적용됩니다 (최대 85%)
# ============================================================
scoreboard players set #def_min rpg.sys 20

# ============================================================
#  해적 왕 (보스)
# ============================================================
# 2초마다 회복하는 최대체력 %
scoreboard players set #pk_rg rpg.sys 5
# 쫄병 해적 2마리를 다시 부르는 간격 (초)
scoreboard players set #pk_sum rpg.sys 20
# 동시에 살아 있을 수 있는 쫄병 수 (이 수를 넘으면 더 부르지 않습니다)
scoreboard players set #pk_cap rpg.sys 5

# ============================================================
#  대쉬 (v56) : 0 = 탈것 없이 (기본 · 선 자세 · 웅크려도 안 끊김 · 오르막 뒤엔 실제 중력으로 떨어짐)
#              1 = 예전 v49 방식 (보이지 않는 탈것을 타서 내 화면은 더 부드럽지만 앉은 자세로 보이고 웅크리면 내려짐)
# ============================================================
scoreboard players set #dash_ride rpg.sys 0

# ============================================================
#  [타오르는 불꽃] 패시브 (v56 · v61 이름 변경 · 예전 이름 전투광) : 스코어보드 blaze-pas  1 = 가짐 · 2 = 발동 중 (0 이나 없으면 없음)
#    주기 : /scoreboard players set <플레이어> blaze-pas 1
#  평타 · 스킬로 적에게 실제 피해를 주거나, 맞으면 게이지가 차고 (허공 · 안 맞은 스킬은 X),
#  다 차면 정해진 시간 동안 공격력 · 이속이 오릅니다 (v61 : 방어력 증가 없앰 · 끝나면 게이지 0)
# ============================================================
# 게이지 최대치
scoreboard players set #blaze_max rpg.sys 100
# 한 번 때릴 때(평타) / 한 번 맞을 때 차는 양
scoreboard players set #blaze_hit rpg.sys 10
scoreboard players set #blaze_dmg rpg.sys 8
# v61 : 스킬 피해가 적에게 들어갈 때 차는 양 · 스킬로 다시 차기까지 틱 (10 = 0.5초 · 다단히트 · 범위 스킬 폭증 방지)
scoreboard players set #blaze_skl rpg.sys 10
scoreboard players set #blaze_scd rpg.sys 10
# 발동 시간 (틱 · 60 = 3초)
scoreboard players set #blaze_t rpg.sys 60
# 발동 중 : 추가 공격력 +% · 이동속도 +%   (v61 : 방어력 증가 없앰)
scoreboard players set #blaze_atk rpg.sys 30
scoreboard players set #blaze_def rpg.sys 0
scoreboard players set #blaze_spd rpg.sys 30

# ============================================================
#  폭탄 (v56) : 철문에 붙이면 띠 띠 띠 소리가 나고 이 시간(틱) 뒤 터짐 · 60 = 3초
# ============================================================
scoreboard players set #bomb_fuse rpg.sys 60

# ============================================================
#  국가 신호기 재고 (v56) : 네더별 성 상점에서 서버 전체가 함께 쓰는 재고
#    회차가 시작될 때마다 이 개수로 다시 채웁니다 · 지금 재고만 바꾸려면 function rpg:war/bcn_stock {n:개수}
# ============================================================
scoreboard players set #bcn_max rpg.sys 12

# ============================================================
#  v58 : 뱀 스킬 (rpg:fx/snake)
# ============================================================
# 1틱에 나아가는 거리 (x0.01 칸 · 60 = 0.6칸 = 1초에 12칸)
scoreboard players set #snake_spd rpg.sys 60
# 좌우로 꺾이는 각도 (도) · 한 번 흔들리는 데 걸리는 틱 (16 / 24 / 32 중 하나 권장)
scoreboard players set #snake_amp rpg.sys 40
scoreboard players set #snake_per rpg.sys 16

# ============================================================
#  v58 : [정밀사격] 패시브 (스코어보드 ranger-pas 가 1 인 플레이어)
#    같은 적을 연속으로 #prc_need 번 맞히면 (평타 · 화살 · 스킬 데미지 모두) 다음 한 방이 +#prc_bonus % 피해
#    다른 적을 때리거나 #prc_time 틱 동안 안 때리면 정밀도 0
# ============================================================
scoreboard players set #prc_need rpg.sys 5
scoreboard players set #prc_bonus rpg.sys 50
scoreboard players set #prc_time rpg.sys 60

# ============================================================
#  v58 : [악마의 힘] 스킬 아이템 — 은신 시간 · 쿨타임 (틱 · 20 = 1초)
# ============================================================
scoreboard players set #demon_t rpg.sys 200
scoreboard players set #demon_cd rpg.sys 1200

# ============================================================
#  v58 : 좌클릭 (L-click) — v61 : 허공 · 블록 좌클릭 감지 제거
#    L-click = 1 은 당근 낚싯대 무기로 진짜 평타를 적에게 맞혔을 때만 (4틱 뒤 0)
#    #lclick_air 는 더 이상 쓰지 않음 (예전 무기의 찌르기 · 숨은 인챈트는 손에 들면 자동으로 떼어짐)
# ============================================================
scoreboard players set #lclick_air rpg.sys 0

# ============================================================
#  v59 : launch-command 모드 (서버에 모드가 있어야 함)
#    1 = 도약(스킬 아이템) · 그림자이동(띄우기) · 끌기(CC) 를 launch 로 · 0 = 예전 방식 (돌풍구 · 순간이동)
#    rpg:fx/launch 대쉬 명령어는 이 값과 상관없이 늘 launch 를 씁니다
# ============================================================
scoreboard players set #launch_on rpg.sys 1
# 도약 : 정면 · 높이 (x0.01 · 130 = 1.3 -> 약 11칸 앞 · 3칸 높이)
scoreboard players set #leap_front rpg.sys 130
scoreboard players set #leap_up rpg.sys 70
# 그림자이동 : 대상을 시전자 반대쪽으로 밀기 · 위로 띄우기 (x0.01 · 100 = 약 6칸 높이)
scoreboard players set #shadow_push rpg.sys 30
scoreboard players set #shadow_up rpg.sys 100
# 런치 대쉬 fall:0 일 때 꼭대기에 머무는 틱 (40 = 2초)
scoreboard players set #ln_hover rpg.sys 40
# ============================================================
#  v59 : 전직 퀘스트 (모든 직업 NPC 공통) — 레벨 조건 · 처치할 몬스터 수 (막타)
# ============================================================
scoreboard players set #job_lv rpg.sys 5
scoreboard players set #job_kills rpg.sys 30

# ============================================================
#  v61 : 불 (rpg:cc/burn) 중첩
#    다시 걸 때마다 중첩 +1 (상한까지) · 1초마다 피해 = 기본 피해 x (100 + (중첩-1) x 중첩당%) / 100
#    지속시간 : 다시 걸면 남은 시간과 새 시간 중 긴 쪽 (+ 중첩당 추가 틱) · 최대 지속 틱을 넘지 않음
#    불이 꺼지면 (시간 끝 · 물 · 죽음 · 재접속 · CC 해제) 중첩도 0
# ============================================================
# 중첩 상한 (1 = 중첩 없음)
scoreboard players set #burn_max rpg.sys 5
# 중첩 1개당 피해 증가 % (50 = 2중첩 150% · 3중첩 200% · 5중첩 300%)
scoreboard players set #burn_stk rpg.sys 50
# 중첩될 때 남은 시간에 더하는 틱 (0 = 더하지 않음 · 20 = 1초)
scoreboard players set #burn_tadd rpg.sys 0
# 최대 지속 틱 (200 = 10초)
scoreboard players set #burn_tcap rpg.sys 200

# ============================================================
#  v61 : 번개 rpg:api/bolt_s {owner,base,ratio,y} (공격력 비례 · 시전자 안 맞음 · 진짜 번개 없음)
# ============================================================
# 번개 소리 음량 (x0.01 · 100 = 1.0 · 0 = 소리 없음 · 1.0 을 넘기면 들리는 거리가 늘어남)
scoreboard players set #bolt_vol rpg.sys 100
# 번개 소리 음높이 (x0.01 · 100 = 1.0 · 50 ~ 200)
scoreboard players set #bolt_pitch rpg.sys 100

# ============================================================
#  v61 : [H20] 럭키 펀치! 룰렛 범위 — 1 ~ 최대 (플레이어마다 rpg.l20m · 재접속해도 유지)
#    + 확률 = (나온 숫자 - 1) / (최대 - 1) · 최대 숫자가 나오면 무조건 +
#    + 가 발동한 그 공격으로 적을 처치하면 최대 + #l20_grow (처치 한 번에 한 번 · 상한 #l20_cap)
# ============================================================
scoreboard players set #l20_start rpg.sys 10
scoreboard players set #l20_grow rpg.sys 10
scoreboard players set #l20_cap rpg.sys 777

# ============================================================
#  v61 : 강화 · 낚싯대 강화 [강화 시도] 연타 막기 — 같은 사람이 다시 누를 수 있는 간격 (틱 · 10 = 0.5초)
# ============================================================
scoreboard players set #enh_cd rpg.sys 10

# ============================================================
#  v61 : NPC 대사 한 글자씩 (화면 방식 · [설정] 에서 플레이어마다 끌 수 있음)
# ============================================================
# 틱마다 늘어나는 글자 수 (1 = 1초에 20글자)
scoreboard players set #ty_speed rpg.sys 1
# 글자 소리 음량 (x0.01 · 0 = 소리 없음)
scoreboard players set #ty_vol rpg.sys 20

# ============================================================
#  v73 : [흑막의 대가] (스코어보드 mgs-pas 가 1 인 플레이어 · 상시)
#    가하는 피해 x(#mgs_out / 100) · 평타 · 화살로 플레이어를 때리면 잃은 체력의 +#mgs_outx % 를 한 번 더
#    받는 피해 +#mgs_in %  (기본 100 → 210 · H19 유리대포와 같은 방식 : 방어 · 경감 뒤 남은 피해 기준)
# ============================================================
scoreboard players set #mgs_out rpg.sys 230
scoreboard players set #mgs_outx rpg.sys 130
scoreboard players set #mgs_in rpg.sys 110
# v73 : 엑스트라 NPC 최대 수 (불러와진 구역 기준 · 많으면 클릭 검사 · 말풍선 부담)
scoreboard players set #ex_max rpg.sys 40

# ============================================================
#  v74 : 스킬 피해 넉백 (rpg:api/atk_hit_kb · tag_hit_kb · proxy_hit_kb 의 knockback 0~20 · 기본 스킬은 0 = 예전처럼 안 밀림)
#    k 1~10 : 바닐라 넉백(0.4) x k/10 → 대상에게 잠깐 넉백 저항 r1 을 더해 한 번
#    k 11~20 : 바닐라 넉백 한 번 + 두 번째 넉백 (저항 r2) → 합계 0.4 x (1 + 0.05 x (k-10))  (20 = 1.5배)
#    표를 바꾸면 세기 조절 (r1 · r2 = 0~1 · r2 -1 = 두 번째 없음)
# ============================================================
data modify storage rpg:kb t set value [{k:0,r1:1.0d,r2:-1.0d},{k:1,r1:0.90d,r2:-1.0d},{k:2,r1:0.80d,r2:-1.0d},{k:3,r1:0.70d,r2:-1.0d},{k:4,r1:0.60d,r2:-1.0d},{k:5,r1:0.50d,r2:-1.0d},{k:6,r1:0.40d,r2:-1.0d},{k:7,r1:0.30d,r2:-1.0d},{k:8,r1:0.20d,r2:-1.0d},{k:9,r1:0.10d,r2:-1.0d},{k:10,r1:0.00d,r2:-1.0d},{k:11,r1:0.0d,r2:0.45d},{k:12,r1:0.0d,r2:0.40d},{k:13,r1:0.0d,r2:0.35d},{k:14,r1:0.0d,r2:0.30d},{k:15,r1:0.0d,r2:0.25d},{k:16,r1:0.0d,r2:0.20d},{k:17,r1:0.0d,r2:0.15d},{k:18,r1:0.0d,r2:0.10d},{k:19,r1:0.0d,r2:0.05d},{k:20,r1:0.0d,r2:0.00d}]

# ============================================================
#  v74 : 농작물 매입 가격 (원 · 1개당) — 농작물 상인 (NPC 38) · 바꾸면 바로 적용 · 창에도 그 값이 보임
#    1 당근 · 2 황금 당근 · 3 감자 · 4 빵 · 5 호박(블록) · 6 수박(블록) · 7 케이크 · 8 호박파이
# ============================================================
scoreboard players set #fp1 rpg.sys 1
scoreboard players set #fp2 rpg.sys 20
scoreboard players set #fp3 rpg.sys 1
scoreboard players set #fp4 rpg.sys 4
scoreboard players set #fp5 rpg.sys 6
scoreboard players set #fp6 rpg.sys 8
scoreboard players set #fp7 rpg.sys 30
scoreboard players set #fp8 rpg.sys 10

# ============================================================
#  v74 : [불굴] (ber-pas 1) 추가 피해 % = (100 - 체력%)² / #ber_div  (125 = 체력 0% 에서 +80% · 50% 에서 +20%)
# ============================================================
scoreboard players set #ber_div rpg.sys 125

# ============================================================
#  v74 : 몬스터 고유 패턴 (19종 · 1 = 켬 · 0 = 끔)
# ============================================================
scoreboard players set #pat_on rpg.sys 1

# ============================================================
#  설정값 - 이 파일의 숫자만 바꾸면 밸런스 조절이 끝납니다
#  (수정 후 /reload)
# ============================================================

# 레벨업 필요 경험치 = exp_base + exp_step*(레벨-1) + exp_quad*(레벨-1)^2
# 예) 19->20 레벨 : 100 + 540 + 20*324 = 7120
scoreboard players set #exp_base rpg.sys 100
scoreboard players set #exp_step rpg.sys 30
scoreboard players set #exp_quad rpg.sys 20

# 레벨업 시 지급하는 자유 스탯
scoreboard players set #sp_level rpg.sys 3

# 몹 처치 경험치 : 모든 몹 공통 + 등급 보너스
scoreboard players set #exp_kill rpg.sys 3
scoreboard players set #exp_mid rpg.sys 7
scoreboard players set #exp_high rpg.sys 22
scoreboard players set #exp_boss rpg.sys 297

# 바닐라 경험치(경험치 병, 경험치 구슬, 화로, 채굴 등) 1당 RPG 경험치
# 0 으로 두면 바닐라 경험치는 RPG 경험치로 전환되지 않습니다
scoreboard players set #xp_rate rpg.sys 1
# 1 이면 변환 후 바닐라 경험치를 0 으로 만들어 화면의 경험치 바/숫자를 완전히 없앤다
# (0 으로 두면 바닐라 경험치가 남아 인챈트에 쓸 수 있지만 초록 숫자가 보입니다)
scoreboard players set #xp_zero rpg.sys 1

# 레벨 1당 추가 최대체력
scoreboard players set #hp_level rpg.sys 2

# 힘 1당  (공격력 단위 0.1 -> 5 = 공격력 +0.5)
scoreboard players set #str_atk rpg.sys 3
scoreboard players set #str_hp rpg.sys 1

# 민첩 1당 (공격력 +0.3 / 이속 +0.001 / 크리티컬 0.2%)
scoreboard players set #dex_atk rpg.sys 1
scoreboard players set #dex_spd rpg.sys 10
# 민첩 1당 최대체력
scoreboard players set #dex_hp rpg.sys 1

# 체력 1당  (공격력 +0.2 / 최대체력 +3)
scoreboard players set #con_atk rpg.sys 1
scoreboard players set #con_hp rpg.sys 3

# 상수 (건드리지 마세요)
scoreboard players set #c2 rpg.sys 2
scoreboard players set #cm1 rpg.sys -1
scoreboard players set #c5 rpg.sys 5
scoreboard players set #c6 rpg.sys 6
scoreboard players set #c9 rpg.sys 9
scoreboard players set #c10 rpg.sys 10
scoreboard players set #c20 rpg.sys 20
scoreboard players set #c3 rpg.sys 3
scoreboard players set #c7 rpg.sys 7
scoreboard players set #c25 rpg.sys 25
scoreboard players set #c10000 rpg.sys 10000
scoreboard players set #c16 rpg.sys 16
scoreboard players set #c1000 rpg.sys 1000
scoreboard players set #c360 rpg.sys 360
scoreboard players set #c1024 rpg.sys 1024
# 바닐라 피해 1 이 실제 체력 몇 만큼인지 (몹/낙하/화상/명령어 피해 환산 배율)
scoreboard players set #dmgmul rpg.sys 1
# 민첩 1당 크리티컬 확률 (1000분율 : 5 = 0.5%)
scoreboard players set #dex_crit rpg.sys 7
# 급소찾기(민첩 50) 추가 크리티컬 확률 (50 = 5%)
scoreboard players set #crit_p rpg.sys 30
# 모든 플레이어 공격속도 보정
scoreboard players set #aspd rpg.sys 16
scoreboard players set #c50 rpg.sys 50
scoreboard players set #c70 rpg.sys 70
scoreboard players set #c90 rpg.sys 90
scoreboard players set #c92 rpg.sys 92
# 몬스터 모델 앞뒤 보정 (뒤돌아 보이면 function rpg:mob/face_flip)
execute unless score #mfoff rpg.sys matches 0.. run scoreboard players set #mfoff rpg.sys 180
scoreboard players set #c81 rpg.sys 81
scoreboard players set #c100 rpg.sys 100
scoreboard players set #c325 rpg.sys 325
scoreboard players set #c720 rpg.sys 720
scoreboard players set #c4440 rpg.sys 4440

# 회복 계산용 2의 거듭제곱
scoreboard players set #c4 rpg.sys 4
scoreboard players set #b0 rpg.sys 1
scoreboard players set #b1 rpg.sys 2
scoreboard players set #b2 rpg.sys 4
scoreboard players set #b3 rpg.sys 8
scoreboard players set #b4 rpg.sys 16
scoreboard players set #b5 rpg.sys 32
scoreboard players set #b6 rpg.sys 64
scoreboard players set #b7 rpg.sys 128

scoreboard players set #c7 rpg.sys 7
scoreboard players set #c12 rpg.sys 12
scoreboard players set #c15 rpg.sys 15
scoreboard players set #c30 rpg.sys 30
scoreboard players set #c40 rpg.sys 40
scoreboard players set #c60 rpg.sys 60
scoreboard players set #c8 rpg.sys 8
scoreboard players set #c350 rpg.sys 350

# ============================================================
#  도약 (민첩 20)
# ============================================================
# 한 번에 터뜨릴 돌풍구 개수. 숫자가 클수록 더 멀리/높이 날아갑니다. (권장 2~5)
scoreboard players set #leap_pow rpg.sys 3

# ============================================================
#  몬스터 / 사냥터
# ============================================================
# 잡몹 리스폰 대기 (초)
scoreboard players set #mob_cd rpg.sys 5
# 하위 보스 리스폰 대기 (초) - 900 = 15분
scoreboard players set #boss_cd rpg.sys 900
# 보스 회복 : 2초마다 최대체력의 몇 % 를 회복하는가
#  - in  : 최근 5초 안에 맞은 적이 있을 때 (전투 중)
#  - out : 아무도 안 때리고 있을 때 (도망/시간끌기 방지용, 원래 요청값 10%)
scoreboard players set #boss_rg_in rpg.sys 1
scoreboard players set #boss_rg_out rpg.sys 10
# 경험치 조각 1개당 RPG 경험치
scoreboard players set #shard_exp rpg.sys 10

# ============================================================
#  퀘스트 목표 수량
# ============================================================
scoreboard players set #q1_need rpg.sys 15
scoreboard players set #q2_need rpg.sys 20
scoreboard players set #q3_need rpg.sys 25

# ============================================================
#  스킬 아이템 쿨타임 (틱 단위 : 20 = 1초)
# ============================================================
# 도약 40초
scoreboard players set #leap_cd rpg.sys 500
# 기절시키기 90초
scoreboard players set #stun_cd rpg.sys 1200

# 만렙 (이 레벨에 도달하면 더 이상 오르지 않습니다)
# 레벨 제한 없음 (필요 경험치 계산이 넘치지 않는 선에서 최대치)
scoreboard players set #lv_max rpg.sys 10000

# ============================================================
#  방어력 : 피해 경감 % = 방어력*100 / (방어력 + def_k)
#  낮출수록 방어력 1당 효율이 올라갑니다 (180 -> 방어력 180 에서 50%)
# ============================================================
scoreboard players set #def_k rpg.sys 180

# ============================================================
#  해적 왕 (보스)
# ============================================================
# 2초마다 회복하는 최대체력 %
scoreboard players set #pk_rg rpg.sys 5
# 쫄병 해적 3마리를 다시 부르는 간격 (초)
scoreboard players set #pk_sum rpg.sys 20
# 동시에 살아 있을 수 있는 쫄병 수 (이 수를 넘으면 더 부르지 않습니다)
scoreboard players set #pk_cap rpg.sys 9

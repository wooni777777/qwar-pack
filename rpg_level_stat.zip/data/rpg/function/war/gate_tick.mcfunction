# 자기 국가 사람이 가까이 오면 성문이 열립니다 (0.5초마다 · 내부용)
execute if score #cs1on rpg.sys matches 1 run function rpg:war/gate1
execute if score #cs2on rpg.sys matches 1 run function rpg:war/gate2
execute if score #cs3on rpg.sys matches 1 run function rpg:war/gate3
execute if score #cs4on rpg.sys matches 1 run function rpg:war/gate4
execute if score #cs5on rpg.sys matches 1 run function rpg:war/gate5
execute if score #cs6on rpg.sys matches 1 run function rpg:war/gate6
execute if score #cs7on rpg.sys matches 1 run function rpg:war/gate7
execute if score #cs8on rpg.sys matches 1 run function rpg:war/gate8

# 예전 성 신호기 바꾸기 (v42 · 한 번 · as 신호기 표식 at 표식)
#   가짜 신호기(셜커 + 블록 디스플레이) 삭제 -> 바닥 철 3x3 -> 표식 자리에 진짜 신호기 -> 4칸 위 나라색 유리
kill @e[type=minecraft:shulker,tag=rpg_bcn,distance=..3]
kill @e[type=minecraft:block_display,tag=rpg_cabd,distance=..3]
execute if block ~ ~-2 ~ minecraft:beacon run setblock ~ ~-2 ~ minecraft:stone_bricks
fill ~-1 ~-1 ~-1 ~1 ~-1 ~1 minecraft:iron_block
setblock ~ ~ ~ minecraft:beacon
execute if score @s rpg.csn matches 1 run setblock ~ ~4 ~ minecraft:red_stained_glass
execute if score @s rpg.csn matches 2 run setblock ~ ~4 ~ minecraft:orange_stained_glass
execute if score @s rpg.csn matches 3 run setblock ~ ~4 ~ minecraft:yellow_stained_glass
execute if score @s rpg.csn matches 4 run setblock ~ ~4 ~ minecraft:green_stained_glass
execute if score @s rpg.csn matches 5 run setblock ~ ~4 ~ minecraft:blue_stained_glass
execute if score @s rpg.csn matches 6 run setblock ~ ~4 ~ minecraft:purple_stained_glass
execute if score @s rpg.csn matches 7 run setblock ~ ~4 ~ minecraft:pink_stained_glass
execute if score @s rpg.csn matches 8 run setblock ~ ~4 ~ minecraft:white_stained_glass
tp @e[type=minecraft:text_display,tag=rpg_cabt,distance=..3,limit=1] ~ ~3.2 ~
tag @s add rpg_cab42
function rpg:war/bcn_txt

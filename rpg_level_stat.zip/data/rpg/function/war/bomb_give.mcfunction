# ── 폭탄 1개 지급 ──
#   성문(철문) 하나를 부숩니다. 선전포고한 국가의 성에서만 터집니다.
give @s minecraft:fire_charge[minecraft:custom_data={rpg_bomb:1},minecraft:item_model="rpg:bomb",minecraft:item_name={"text":"폭탄","color":"gold","bold":true},minecraft:lore=[{"text":"성문 앞에서 우클릭","color":"gray","italic":false},{"text":"철문 1개를 부숩니다","color":"gray","italic":false},{"text":"선전포고한 국가의 성에서만 터집니다","color":"dark_red","italic":false}],minecraft:enchantment_glint_override=true,minecraft:max_stack_size=16,minecraft:consumable={consume_seconds:0.4f,animation:"none",sound:"minecraft:entity.tnt.primed",has_consume_particles:false}] 1
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"폭탄","color":"gold","bold":true},{"text":" 1개를 받았습니다.","color":"white"}]
return 1

# ── 폭탄 1개 지급 (v40 · 당근 낚싯대 방식 : 블록에 대고 눌러도 안 날아갑니다) ──
give @s minecraft:carrot_on_a_stick[!minecraft:max_damage,minecraft:max_stack_size=16,minecraft:custom_data={rpg_bomb:1},minecraft:item_model="rpg:bomb",minecraft:item_name={"text":"폭탄","color":"gold","bold":true},minecraft:lore=[{"text":"철문 앞에서 우클릭 - 철문 1개를 부숩니다","color":"gray","italic":false},{"text":"선전포고한 국가의 성에서만 · 전쟁 중에만","color":"dark_red","italic":false},{"text":"한 번 터뜨리면 30초 재사용 대기","color":"dark_gray","italic":false}],minecraft:enchantment_glint_override=true] 1
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"폭탄","color":"gold","bold":true},{"text":" 1개를 받았습니다.","color":"white"}]
return 1

$scoreboard players set #ca$(s)on rpg.sys 1
$scoreboard players set #ca$(s)n rpg.sys $(n)
$scoreboard players set #ca$(s)k rpg.sys $(k)
$scoreboard players operation #ca$(s)id rpg.sys = #caid rpg.sys
$scoreboard players set #cu$(n)_$(k) rpg.sys $(s)
$execute store result score #ca$(s)bx rpg.sys run data get entity @e[tag=rpg_canew,tag=rpg_cab,limit=1] Pos[0] 10
$execute store result score #ca$(s)by rpg.sys run data get entity @e[tag=rpg_canew,tag=rpg_cab,limit=1] Pos[1] 10
$execute store result score #ca$(s)bz rpg.sys run data get entity @e[tag=rpg_canew,tag=rpg_cab,limit=1] Pos[2] 10

# [기록 지우기] (op · rpg.wcs 1001~1032)
execute unless entity @s[tag=op] run return 0
scoreboard players operation #bs rpg.sys = @s rpg.wcs
scoreboard players remove #bs rpg.sys 1000
function rpg:war/ca_free
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"성 기록을 지웠습니다.","color":"red"}]
function rpg:war/cs_list

# (v43 · 내부용) 대기열 맨 앞 빼고 다음으로
data remove storage rpg:war wq[0]
function rpg:war/wipe_next

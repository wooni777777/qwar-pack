# [확정] — 비밀번호 저장 (v42 · as 정문 표식 · 매크로 k)
execute unless score #pn rpg.sys = #dn rpg.sys run return run tellraw @a[tag=rpg_pwp] [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"이 성의 국가만 비밀번호를 정할 수 있습니다.","color":"red"}]
execute unless score #pp rpg.sys matches 1.. run return run function rpg:war/door_q_set with storage rpg:war dq
scoreboard players operation @s rpg.pwv = #pp rpg.sys
scoreboard players set @a[tag=rpg_pwp] rpg.pwm 0
scoreboard players set @a[tag=rpg_pwp] rpg.pwp 0
$tellraw @a[tag=rpg_pwp] ["", {"text": "[철문] ", "color": "gold", "bold": true}, {"text": "$(k)성", "color": "aqua", "bold": true}, {"text": " 철문 비밀번호를 저장했습니다. 이제부터 이 비밀번호를 넣어야 열립니다.", "color": "green"}]
execute at @a[tag=rpg_pwp] run playsound minecraft:block.note_block.chime player @a[tag=rpg_pwp] ~ ~ ~ 1 1.4

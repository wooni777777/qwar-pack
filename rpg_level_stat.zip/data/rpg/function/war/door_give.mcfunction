# 철문 1개 지급 (v39 · 모험 모드에서도 설치 가능)
give @s minecraft:iron_door[minecraft:can_place_on=[{}],minecraft:item_name={"text":"철문","color":"white","bold":true},minecraft:lore=[{"text":"어디에나 설치할 수 있습니다","color":"gray","italic":false}]] 1

tag @s remove rpg_wbcn
execute if entity @s[tag=rpg_wadv,gamemode=survival] run gamemode adventure @s

# 눈에서 0.25칸씩 앞으로 (최대 5.5칸) — 신호기에 닿으면 판정, 막히면 끝 (v42 · 내부용)
execute if block ~ ~ ~ minecraft:beacon run return run function rpg:war/bl_hit
execute unless block ~ ~ ~ #rpg:pass run return 0
scoreboard players remove #bls rpg.sys 1
execute if score #bls rpg.sys matches 1.. positioned ^ ^ ^0.25 run function rpg:war/bl_ray

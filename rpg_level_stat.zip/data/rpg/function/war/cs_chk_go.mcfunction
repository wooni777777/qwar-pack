scoreboard players set #csgone rpg.sys 0
$execute positioned $(x) $(y) $(z) unless block ~ ~ ~ minecraft:beacon run scoreboard players set #csgone rpg.sys 1
$execute if score #csgone rpg.sys matches 1 positioned $(x) $(y) $(z) run function rpg:war/bb_drop

scoreboard players set #csgone rpg.sys 0
$execute positioned $(x) $(y) $(z) unless block ~ ~ ~ minecraft:beacon run scoreboard players set #csgone rpg.sys 1

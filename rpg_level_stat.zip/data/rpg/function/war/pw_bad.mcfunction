# 비밀번호 틀림 (v42)
scoreboard players operation @a[tag=rpg_pwp] rpg.pwl = #gtick rpg.sys
tellraw @a[tag=rpg_pwp] [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"비밀번호가 틀렸습니다.","color":"red"}]
execute at @a[tag=rpg_pwp] run playsound minecraft:block.note_block.bass player @a[tag=rpg_pwp] ~ ~ ~ 1 0.6

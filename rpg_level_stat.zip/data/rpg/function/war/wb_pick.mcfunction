# 금곡괭이 구매 (5,000원 · v40)
execute unless score @s money matches 5000.. run return run tellraw @s [{"text":"[전쟁 상점] ","color":"red","bold":true},{"text":"돈이 부족합니다. (5,000원)","color":"red"}]
scoreboard players remove @s money 5000
function rpg:war/pick_give
execute at @s run playsound minecraft:entity.villager.yes player @s ~ ~ ~ 1 1.2
return 1

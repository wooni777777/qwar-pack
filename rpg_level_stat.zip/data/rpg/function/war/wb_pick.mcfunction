# 금곡괭이 구매 (150,000원 · v39)
execute unless score @s money matches 150000.. run return run tellraw @s [{"text":"[전쟁 상점] ","color":"red","bold":true},{"text":"돈이 부족합니다. (150,000원)","color":"red"}]
scoreboard players set #ok rpg.sys 0
execute store result score #ok rpg.sys run function rpg:war/pick_give
execute unless score #ok rpg.sys matches 1 run return run tellraw @s [{"text":"[전쟁 상점] ","color":"red","bold":true},{"text":"지급에 실패했습니다. 돈은 그대로입니다.","color":"red"}]
scoreboard players remove @s money 150000
execute at @s run playsound minecraft:entity.villager.yes player @s ~ ~ ~ 1 1.2
return 1

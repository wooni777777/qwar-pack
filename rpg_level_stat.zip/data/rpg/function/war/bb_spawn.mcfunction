# 부서진 신호기 1개를 이 자리에 떨어뜨림 (v50 · 내부용 · positioned 떨어질 자리)
#   안 사라짐 · 불/폭발에 안 없어짐 · 빛남 (멀리서도 보이게)
summon minecraft:item ~ ~0.5 ~ {Tags:["rpg_bbi","rpg_bbin"],Item:{id:"minecraft:stone",count:1},PickupDelay:10s,Age:-32768s,Invulnerable:1b,Glowing:1b}
item replace entity @e[type=minecraft:item,tag=rpg_bbin,limit=1] contents with minecraft:paper[minecraft:custom_data={rpg_brokenb:1},minecraft:item_model="minecraft:beacon",minecraft:item_name={"text":"부서진 신호기","color":"gray","bold":true},minecraft:lore=[{"text":"멸망한 국가의 신호기","color":"dark_gray","italic":false},{"text":"네더별 성 상점에서 네더별 10개로 팝니다","color":"gray","italic":false},{"text":"들고 죽으면 1개가 그 자리에 떨어집니다","color":"dark_red","italic":false}],minecraft:max_stack_size=16] 1
tag @e[type=minecraft:item,tag=rpg_bbin] remove rpg_bbin

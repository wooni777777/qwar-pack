scoreboard players set @s rpg.npcd 20
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"해당 위치는 블럭을 설치할 수 없습니다. (신호기 둘레 3x3)","color":"red"}]
execute at @s run playsound minecraft:block.note_block.bit master @s ~ ~ ~ 1 2
execute at @s run playsound minecraft:block.note_block.bit master @s ~ ~ ~ 1 1.5

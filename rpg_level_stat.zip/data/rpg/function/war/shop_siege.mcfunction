scoreboard players enable @s rpg.wsh
playsound minecraft:item.book.page_turn player @s ~ ~ ~ 1 1.2
tellraw @s " "
tellraw @s ["",{"text":"━━━━━  ","color":"dark_gray"},{"text":"네더별 상점 [ 공성 ]","color":"gold","bold":true},{"text":"  ━━━━━","color":"dark_gray"}]
tellraw @s {"text":"   성을 부수는 물건을 팝니다. 값은 네더별로 받습니다.","color":"gray"}
tellraw @s " "
tellraw @s ["",{"text":"   "},{"text":"폭탄","color":"gold","bold":true,"hover_event":{"action":"show_text","value":{"text":"성문 철문 1개를 부숩니다","color":"gray"}}},{"text":"    네더별 3개   ","color":"gold"},{"text":"[구매]","color":"green","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wsh set 1"}}]
tellraw @s ["",{"text":"   "},{"text":"금곡괭이","color":"yellow","bold":true,"hover_event":{"action":"show_text","value":{"text":"국가 신호기만 캘 수 있습니다","color":"gray"}}},{"text":"    네더별 10개   ","color":"gold"},{"text":"[구매]","color":"green","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wsh set 2"}}]
tellraw @s " "
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}

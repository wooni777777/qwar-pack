scoreboard players enable @s rpg.wsh
playsound minecraft:item.book.page_turn player @s ~ ~ ~ 1 1.2
tellraw @s " "
tellraw @s ["",{"text":"━━━━━  ","color":"dark_gray"},{"text":"네더별 성 상점","color":"gold","bold":true},{"text":"  ━━━━━","color":"dark_gray"}]
tellraw @s {"text":"   우리 국가의 신호기를 팔고, 부서진 신호기를 사들입니다.","color":"gray"}
tellraw @s " "
tellraw @s ["",{"text":"   "},{"text":"국가 신호기 (우리 국가)","color":"aqua","bold":true,"hover_event":{"action":"show_text","value":{"text":"50x50 돌벽돌 성을 세웁니다 · 국가에 들어가 있어야 삽니다","color":"gray"}}},{"text":"    네더별 60개   ","color":"gold"},{"text":"[구매]","color":"green","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wsh set 1"}}]
tellraw @s ["",{"text":"   "},{"text":"부서진 신호기 판매","color":"gray","bold":true,"hover_event":{"action":"show_text","value":{"text":"국가 신호기를 부수면 얻는 조각 · 1개에 네더별 10개","color":"gray"}}},{"text":"    네더별 10개 받음   ","color":"gold"},{"text":"[판매]","color":"yellow","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wsh set 2"}}]
tellraw @s " "
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}

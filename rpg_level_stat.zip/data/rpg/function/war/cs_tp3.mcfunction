execute store result storage rpg:war tp.x int 1 run scoreboard players get #cs3x rpg.sys
execute store result storage rpg:war tp.y int 1 run scoreboard players get #cs3y rpg.sys
execute store result storage rpg:war tp.z int 1 run scoreboard players get #cs3z rpg.sys
function rpg:war/cs_tp_go with storage rpg:war tp
tellraw @s ["",{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"노랑 국가의 성","color":"yellow","bold":true},{"text":" 으로 이동했습니다.","color":"white"}]

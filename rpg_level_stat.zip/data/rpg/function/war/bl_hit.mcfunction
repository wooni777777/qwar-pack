# 보고 있는 신호기가 성 신호기인지 (v42 · 내부용)
scoreboard players set #blk rpg.sys 0
execute align xyz positioned ~0.5 ~ ~0.5 as @e[type=minecraft:marker,tag=rpg_cab,distance=..0.8,limit=1] run function rpg:war/bl_elig
return 1

# 전쟁이 끝나면 모두 서바이벌로 되돌린다
execute as @a[tag=rpg_wadv] run function rpg:war/adv_off

# (v43 · 내부용) 철거하려고 강제로 불러온 청크 풀기
execute unless data storage rpg:war wfl[0] run return 0
data modify storage rpg:war wu set from storage rpg:war wfl[0]
function rpg:war/wipe_unfl1 with storage rpg:war wu
data remove storage rpg:war wfl[0]
function rpg:war/wipe_unfl

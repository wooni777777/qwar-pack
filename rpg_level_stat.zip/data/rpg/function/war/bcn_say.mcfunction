tellraw @a " "
$tellraw @a ["",{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"$(nm) 국가","color":"$(cl)","bold":true},{"text":" 의 ","color":"white"},{"text":"$(k)성","color":"aqua","bold":true},{"text":" 신호기가 부서졌습니다!","color":"red","bold":true}]
tellraw @a " "

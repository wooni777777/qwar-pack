# (v43 · 내부용 · 매크로) 정말 성 자리인지 확인 — 신호기 표식 / 신호기 블록 / 성 바닥 무늬 중 하나라도 있어야 지움
scoreboard players set #wsg rpg.sys 0
$execute in $(d) if entity @e[type=minecraft:marker,tag=rpg_cab,x=$(x),y=$(y),z=$(z),distance=..2] run scoreboard players set #wsg rpg.sys 1
$execute in $(d) if block $(x) $(y) $(z) minecraft:beacon run scoreboard players set #wsg rpg.sys 1
$execute in $(d) if block $(x) $(yf) $(z) minecraft:stone_bricks if block $(x) $(yg) $(z) minecraft:polished_andesite run scoreboard players set #wsg rpg.sys 1
execute if score #wsg rpg.sys matches 0 run return run function rpg:war/wipe_pop
function rpg:war/wipe_do with storage rpg:war wa

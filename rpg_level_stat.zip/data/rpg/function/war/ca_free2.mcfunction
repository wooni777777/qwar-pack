$scoreboard players operation #fn rpg.sys = #ca$(s)n rpg.sys
$scoreboard players operation #fk rpg.sys = #ca$(s)k rpg.sys
$scoreboard players set #ca$(s)on rpg.sys 0
execute store result storage rpg:war fr.n int 1 run scoreboard players get #fn rpg.sys
execute store result storage rpg:war fr.k int 1 run scoreboard players get #fk rpg.sys
function rpg:war/ca_free3 with storage rpg:war fr

scoreboard players enable @s rpg.wcs
tellraw @s " "
tellraw @s {"text":"━━━━━━━━━  성  현  황  ━━━━━━━━━","color":"dark_gray"}
scoreboard players set #rowc rpg.sys 0
execute if score #ca1on rpg.sys matches 1 run function rpg:war/ca_row {s:1}
execute if score #ca2on rpg.sys matches 1 run function rpg:war/ca_row {s:2}
execute if score #ca3on rpg.sys matches 1 run function rpg:war/ca_row {s:3}
execute if score #ca4on rpg.sys matches 1 run function rpg:war/ca_row {s:4}
execute if score #ca5on rpg.sys matches 1 run function rpg:war/ca_row {s:5}
execute if score #ca6on rpg.sys matches 1 run function rpg:war/ca_row {s:6}
execute if score #ca7on rpg.sys matches 1 run function rpg:war/ca_row {s:7}
execute if score #ca8on rpg.sys matches 1 run function rpg:war/ca_row {s:8}
execute if score #ca9on rpg.sys matches 1 run function rpg:war/ca_row {s:9}
execute if score #ca10on rpg.sys matches 1 run function rpg:war/ca_row {s:10}
execute if score #ca11on rpg.sys matches 1 run function rpg:war/ca_row {s:11}
execute if score #ca12on rpg.sys matches 1 run function rpg:war/ca_row {s:12}
execute if score #ca13on rpg.sys matches 1 run function rpg:war/ca_row {s:13}
execute if score #ca14on rpg.sys matches 1 run function rpg:war/ca_row {s:14}
execute if score #ca15on rpg.sys matches 1 run function rpg:war/ca_row {s:15}
execute if score #ca16on rpg.sys matches 1 run function rpg:war/ca_row {s:16}
execute if score #ca17on rpg.sys matches 1 run function rpg:war/ca_row {s:17}
execute if score #ca18on rpg.sys matches 1 run function rpg:war/ca_row {s:18}
execute if score #ca19on rpg.sys matches 1 run function rpg:war/ca_row {s:19}
execute if score #ca20on rpg.sys matches 1 run function rpg:war/ca_row {s:20}
execute if score #ca21on rpg.sys matches 1 run function rpg:war/ca_row {s:21}
execute if score #ca22on rpg.sys matches 1 run function rpg:war/ca_row {s:22}
execute if score #ca23on rpg.sys matches 1 run function rpg:war/ca_row {s:23}
execute if score #ca24on rpg.sys matches 1 run function rpg:war/ca_row {s:24}
execute if score #ca25on rpg.sys matches 1 run function rpg:war/ca_row {s:25}
execute if score #ca26on rpg.sys matches 1 run function rpg:war/ca_row {s:26}
execute if score #ca27on rpg.sys matches 1 run function rpg:war/ca_row {s:27}
execute if score #ca28on rpg.sys matches 1 run function rpg:war/ca_row {s:28}
execute if score #ca29on rpg.sys matches 1 run function rpg:war/ca_row {s:29}
execute if score #ca30on rpg.sys matches 1 run function rpg:war/ca_row {s:30}
execute if score #ca31on rpg.sys matches 1 run function rpg:war/ca_row {s:31}
execute if score #ca32on rpg.sys matches 1 run function rpg:war/ca_row {s:32}
execute if score #rowc rpg.sys matches 0 run tellraw @s {"text":"   세워진 성이 없습니다.","color":"dark_gray"}
tellraw @s " "
tellraw @s {"text":"   [기록 지우기] 는 가짜 신호기 · 표식만 지웁니다. 블록은 그대로 남습니다.","color":"dark_gray"}
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}

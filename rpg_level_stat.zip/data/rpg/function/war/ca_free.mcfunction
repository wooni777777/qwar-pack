# 성 기록 지우기 (내부용 · #bs 슬롯) — [전쟁터] 목록에서 빠집니다. 다른 성 번호는 그대로.
execute store result storage rpg:war fr.s int 1 run scoreboard players get #bs rpg.sys
function rpg:war/ca_free2 with storage rpg:war fr
execute as @e[tag=rpg_ca] if score @s rpg.csid = #bs rpg.sys run kill @s

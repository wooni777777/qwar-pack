# 못 부수는 신호기를 보고 있을 때 이유 (v42 · 1초에 한 번)
scoreboard players set @s rpg.npcd 20
execute if score #blk rpg.sys matches 2 run title @s actionbar {"text":"국가에 들어가야 신호기를 부술 수 있습니다","color":"red"}
execute if score #blk rpg.sys matches 3 run title @s actionbar {"text":"우리 국가의 신호기입니다","color":"green"}
execute if score #blk rpg.sys matches 4 run title @s actionbar {"text":"신호기는 전쟁 중에만 부술 수 있습니다","color":"red"}
execute if score #blk rpg.sys matches 5 run title @s actionbar {"text":"선전포고한 국가의 신호기만 부술 수 있습니다","color":"red"}

# 먹힌 신호기를 그대로 돌려준다 (내부용)
execute at @s run summon minecraft:item ~ ~1 ~ {Tags:["rpg_cstmp"],Item:{id:"minecraft:stone",count:1},PickupDelay:0s,NoGravity:1b,Invulnerable:1b}
data modify entity @e[tag=rpg_cstmp,limit=1] Item set from storage rpg:war hold
data modify entity @e[tag=rpg_cstmp,limit=1] Item.count set value 1
data modify entity @e[tag=rpg_cstmp,limit=1] Owner set from entity @s UUID
tag @e[tag=rpg_cstmp] remove rpg_cstmp

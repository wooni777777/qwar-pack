# 네더별 2개 판매 -> 10,000원 (v39)
scoreboard players set #ns rpg.sys 0
execute store result score #ns rpg.sys run clear @s minecraft:nether_star 0
execute if score #ns rpg.sys matches ..1 run return run tellraw @s [{"text":"[상점] ","color":"aqua","bold":true},{"text":"네더별이 2개 있어야 팔 수 있습니다.","color":"red"}]
clear @s minecraft:nether_star 2
scoreboard players add @s money 10000
tellraw @s [{"text":"[상점] ","color":"aqua","bold":true},{"text":"네더별 2개 -> ","color":"white"},{"text":"10,000원","color":"gold","bold":true}]
execute at @s run playsound minecraft:entity.villager.yes player @s ~ ~ ~ 1 1.2
return 1

# ── 성 (v40) ── 정문 = ^0 ^0 ^0 (플레이어가 서 있던 칸) · 성은 등 뒤로 49 x 49
#   ^왼쪽  ^위  ^앞   (앞 = 플레이어가 보던 쪽 = 성 바깥)
# 터 비우기 (49 x 23 x 49)
fill ^-24 ^0 ^0 ^24 ^22 ^-24 minecraft:air
fill ^-24 ^0 ^-25 ^24 ^22 ^-48 minecraft:air
# 바닥 (두 겹)
fill ^-24 ^-2 ^0 ^24 ^-2 ^-48 minecraft:stone_bricks
fill ^-24 ^-1 ^0 ^24 ^-1 ^-48 minecraft:stone_bricks
# 정문 -> 계단 길 / 탑 둘레 길
fill ^-2 ^-1 ^-1 ^2 ^-1 ^-8 minecraft:polished_andesite
fill ^-5 ^-1 ^-19 ^5 ^-1 ^-29 minecraft:polished_andesite
setblock ^0 ^-1 ^-2 minecraft:sea_lantern
setblock ^0 ^-1 ^-5 minecraft:sea_lantern
setblock ^0 ^-1 ^-8 minecraft:sea_lantern
# 바깥 벽 (높이 7) + 나라색 띠 + 난간
fill ^-24 ^0 ^0 ^24 ^6 ^0 minecraft:stone_bricks
fill ^-24 ^0 ^-48 ^24 ^6 ^-48 minecraft:stone_bricks
fill ^24 ^0 ^-1 ^24 ^6 ^-47 minecraft:stone_bricks
fill ^-24 ^0 ^-1 ^-24 ^6 ^-47 minecraft:stone_bricks
$fill ^-24 ^7 ^0 ^24 ^7 ^0 minecraft:$(c)_concrete
$fill ^-24 ^7 ^-48 ^24 ^7 ^-48 minecraft:$(c)_concrete
$fill ^24 ^7 ^-1 ^24 ^7 ^-47 minecraft:$(c)_concrete
$fill ^-24 ^7 ^-1 ^-24 ^7 ^-47 minecraft:$(c)_concrete
fill ^-24 ^8 ^0 ^24 ^8 ^0 minecraft:stone_brick_wall
fill ^-24 ^8 ^-48 ^24 ^8 ^-48 minecraft:stone_brick_wall
fill ^24 ^8 ^-1 ^24 ^8 ^-47 minecraft:stone_brick_wall
fill ^-24 ^8 ^-1 ^-24 ^8 ^-47 minecraft:stone_brick_wall
# 네 귀퉁이 탑 (5x5 · 높이 11)
fill ^20 ^0 ^0 ^24 ^10 ^-4 minecraft:stone_bricks
$fill ^20 ^11 ^0 ^24 ^11 ^-4 minecraft:$(c)_concrete
fill ^20 ^12 ^0 ^24 ^12 ^-4 minecraft:stone_brick_wall
fill ^21 ^12 ^-1 ^23 ^12 ^-3 minecraft:air
fill ^20 ^0 ^-44 ^24 ^10 ^-48 minecraft:stone_bricks
$fill ^20 ^11 ^-44 ^24 ^11 ^-48 minecraft:$(c)_concrete
fill ^20 ^12 ^-44 ^24 ^12 ^-48 minecraft:stone_brick_wall
fill ^21 ^12 ^-45 ^23 ^12 ^-47 minecraft:air
fill ^-24 ^0 ^0 ^-20 ^10 ^-4 minecraft:stone_bricks
$fill ^-24 ^11 ^0 ^-20 ^11 ^-4 minecraft:$(c)_concrete
fill ^-24 ^12 ^0 ^-20 ^12 ^-4 minecraft:stone_brick_wall
fill ^-23 ^12 ^-1 ^-21 ^12 ^-3 minecraft:air
fill ^-24 ^0 ^-44 ^-20 ^10 ^-48 minecraft:stone_bricks
$fill ^-24 ^11 ^-44 ^-20 ^11 ^-48 minecraft:$(c)_concrete
fill ^-24 ^12 ^-44 ^-20 ^12 ^-48 minecraft:stone_brick_wall
fill ^-23 ^12 ^-45 ^-21 ^12 ^-47 minecraft:air
# 정문 : 철문 1칸 · 문 바닥 기반암 · 문 옆 벽(^1 ^0 ^0)은 여닫이 장치 자리
fill ^0 ^0 ^0 ^0 ^1 ^0 minecraft:air
setblock ^0 ^-1 ^0 minecraft:bedrock
setblock ^0 ^2 ^0 minecraft:chiseled_stone_bricks
$setblock ^1 ^3 ^0 minecraft:$(c)_concrete
$setblock ^-1 ^3 ^0 minecraft:$(c)_concrete
$setblock ^0 ^0 ^0 minecraft:iron_door[facing=$(fw),half=lower,hinge=left,open=false]
$setblock ^0 ^1 ^0 minecraft:iron_door[facing=$(fw),half=upper,hinge=left,open=false]
# 양 옆 농사터 (밭만 · 씨앗 없음)
fill ^6 ^-1 ^-6 ^20 ^-1 ^-42 minecraft:farmland[moisture=7]
fill ^9 ^-1 ^-6 ^9 ^-1 ^-42 minecraft:water
fill ^17 ^-1 ^-6 ^17 ^-1 ^-42 minecraft:water
fill ^5 ^0 ^-5 ^21 ^0 ^-5 minecraft:stripped_spruce_wood
fill ^5 ^0 ^-43 ^21 ^0 ^-43 minecraft:stripped_spruce_wood
fill ^5 ^0 ^-5 ^5 ^0 ^-43 minecraft:stripped_spruce_wood
fill ^21 ^0 ^-5 ^21 ^0 ^-43 minecraft:stripped_spruce_wood
fill ^5 ^0 ^-23 ^5 ^0 ^-25 minecraft:air
setblock ^5 ^1 ^-5 minecraft:lantern
setblock ^21 ^1 ^-5 minecraft:lantern
setblock ^5 ^1 ^-43 minecraft:lantern
setblock ^21 ^1 ^-43 minecraft:lantern
fill ^-6 ^-1 ^-6 ^-20 ^-1 ^-42 minecraft:farmland[moisture=7]
fill ^-9 ^-1 ^-6 ^-9 ^-1 ^-42 minecraft:water
fill ^-17 ^-1 ^-6 ^-17 ^-1 ^-42 minecraft:water
fill ^-5 ^0 ^-5 ^-21 ^0 ^-5 minecraft:stripped_spruce_wood
fill ^-5 ^0 ^-43 ^-21 ^0 ^-43 minecraft:stripped_spruce_wood
fill ^-5 ^0 ^-5 ^-5 ^0 ^-43 minecraft:stripped_spruce_wood
fill ^-21 ^0 ^-5 ^-21 ^0 ^-43 minecraft:stripped_spruce_wood
fill ^-5 ^0 ^-23 ^-5 ^0 ^-25 minecraft:air
setblock ^-5 ^1 ^-5 minecraft:lantern
setblock ^-21 ^1 ^-5 minecraft:lantern
setblock ^-5 ^1 ^-43 minecraft:lantern
setblock ^-21 ^1 ^-43 minecraft:lantern
# 가운데 탑 (7x7) : 계단으로 올라가면 맨 위에 신호기
fill ^-3 ^0 ^-21 ^3 ^10 ^-27 minecraft:stone_bricks
fill ^-3 ^11 ^-21 ^3 ^11 ^-27 minecraft:polished_andesite
$fill ^-3 ^11 ^-21 ^3 ^11 ^-21 minecraft:$(c)_concrete
$fill ^-3 ^11 ^-27 ^3 ^11 ^-27 minecraft:$(c)_concrete
$fill ^-3 ^11 ^-22 ^-3 ^11 ^-26 minecraft:$(c)_concrete
$fill ^3 ^11 ^-22 ^3 ^11 ^-26 minecraft:$(c)_concrete
fill ^-3 ^12 ^-27 ^3 ^12 ^-27 minecraft:stone_brick_wall
fill ^-3 ^12 ^-22 ^-3 ^12 ^-26 minecraft:stone_brick_wall
fill ^3 ^12 ^-22 ^3 ^12 ^-26 minecraft:stone_brick_wall
setblock ^-3 ^12 ^-21 minecraft:stone_brick_wall
setblock ^-2 ^12 ^-21 minecraft:stone_brick_wall
setblock ^2 ^12 ^-21 minecraft:stone_brick_wall
setblock ^3 ^12 ^-21 minecraft:stone_brick_wall
setblock ^-3 ^13 ^-21 minecraft:lantern
setblock ^3 ^13 ^-21 minecraft:lantern
setblock ^-3 ^13 ^-27 minecraft:lantern
setblock ^3 ^13 ^-27 minecraft:lantern
# 신호기 (v42) : 탑 꼭대기 바닥 철 3x3 -> 그 위 진짜 신호기 (맨손으로 부숨 · 위에 서면 텔포 가능) -> 4칸 위 나라색 유리 (빛 색)
fill ^-1 ^11 ^-23 ^1 ^11 ^-25 minecraft:iron_block
setblock ^0 ^12 ^-24 minecraft:beacon
$setblock ^0 ^16 ^-24 minecraft:$(c)_stained_glass
# 계단 (3칸 폭 · 12단)
$fill ^-1 ^0 ^-9 ^1 ^0 ^-9 minecraft:stone_brick_stairs[facing=$(bk),half=bottom]
fill ^2 ^0 ^-9 ^2 ^0 ^-9 minecraft:stone_bricks
setblock ^2 ^1 ^-9 minecraft:stone_brick_wall
fill ^-2 ^0 ^-9 ^-2 ^0 ^-9 minecraft:stone_bricks
setblock ^-2 ^1 ^-9 minecraft:stone_brick_wall
fill ^-1 ^0 ^-10 ^1 ^0 ^-10 minecraft:stone_bricks
$fill ^-1 ^1 ^-10 ^1 ^1 ^-10 minecraft:stone_brick_stairs[facing=$(bk),half=bottom]
fill ^2 ^0 ^-10 ^2 ^1 ^-10 minecraft:stone_bricks
setblock ^2 ^2 ^-10 minecraft:stone_brick_wall
fill ^-2 ^0 ^-10 ^-2 ^1 ^-10 minecraft:stone_bricks
setblock ^-2 ^2 ^-10 minecraft:stone_brick_wall
fill ^-1 ^0 ^-11 ^1 ^1 ^-11 minecraft:stone_bricks
$fill ^-1 ^2 ^-11 ^1 ^2 ^-11 minecraft:stone_brick_stairs[facing=$(bk),half=bottom]
fill ^2 ^0 ^-11 ^2 ^2 ^-11 minecraft:stone_bricks
setblock ^2 ^3 ^-11 minecraft:stone_brick_wall
fill ^-2 ^0 ^-11 ^-2 ^2 ^-11 minecraft:stone_bricks
setblock ^-2 ^3 ^-11 minecraft:stone_brick_wall
fill ^-1 ^0 ^-12 ^1 ^2 ^-12 minecraft:stone_bricks
$fill ^-1 ^3 ^-12 ^1 ^3 ^-12 minecraft:stone_brick_stairs[facing=$(bk),half=bottom]
fill ^2 ^0 ^-12 ^2 ^3 ^-12 minecraft:stone_bricks
setblock ^2 ^4 ^-12 minecraft:stone_brick_wall
fill ^-2 ^0 ^-12 ^-2 ^3 ^-12 minecraft:stone_bricks
setblock ^-2 ^4 ^-12 minecraft:stone_brick_wall
fill ^-1 ^0 ^-13 ^1 ^3 ^-13 minecraft:stone_bricks
$fill ^-1 ^4 ^-13 ^1 ^4 ^-13 minecraft:stone_brick_stairs[facing=$(bk),half=bottom]
fill ^2 ^0 ^-13 ^2 ^4 ^-13 minecraft:stone_bricks
setblock ^2 ^5 ^-13 minecraft:stone_brick_wall
fill ^-2 ^0 ^-13 ^-2 ^4 ^-13 minecraft:stone_bricks
setblock ^-2 ^5 ^-13 minecraft:stone_brick_wall
fill ^-1 ^0 ^-14 ^1 ^4 ^-14 minecraft:stone_bricks
$fill ^-1 ^5 ^-14 ^1 ^5 ^-14 minecraft:stone_brick_stairs[facing=$(bk),half=bottom]
fill ^2 ^0 ^-14 ^2 ^5 ^-14 minecraft:stone_bricks
setblock ^2 ^6 ^-14 minecraft:stone_brick_wall
fill ^-2 ^0 ^-14 ^-2 ^5 ^-14 minecraft:stone_bricks
setblock ^-2 ^6 ^-14 minecraft:stone_brick_wall
fill ^-1 ^0 ^-15 ^1 ^5 ^-15 minecraft:stone_bricks
$fill ^-1 ^6 ^-15 ^1 ^6 ^-15 minecraft:stone_brick_stairs[facing=$(bk),half=bottom]
fill ^2 ^0 ^-15 ^2 ^6 ^-15 minecraft:stone_bricks
setblock ^2 ^7 ^-15 minecraft:stone_brick_wall
fill ^-2 ^0 ^-15 ^-2 ^6 ^-15 minecraft:stone_bricks
setblock ^-2 ^7 ^-15 minecraft:stone_brick_wall
fill ^-1 ^0 ^-16 ^1 ^6 ^-16 minecraft:stone_bricks
$fill ^-1 ^7 ^-16 ^1 ^7 ^-16 minecraft:stone_brick_stairs[facing=$(bk),half=bottom]
fill ^2 ^0 ^-16 ^2 ^7 ^-16 minecraft:stone_bricks
setblock ^2 ^8 ^-16 minecraft:stone_brick_wall
fill ^-2 ^0 ^-16 ^-2 ^7 ^-16 minecraft:stone_bricks
setblock ^-2 ^8 ^-16 minecraft:stone_brick_wall
fill ^-1 ^0 ^-17 ^1 ^7 ^-17 minecraft:stone_bricks
$fill ^-1 ^8 ^-17 ^1 ^8 ^-17 minecraft:stone_brick_stairs[facing=$(bk),half=bottom]
fill ^2 ^0 ^-17 ^2 ^8 ^-17 minecraft:stone_bricks
setblock ^2 ^9 ^-17 minecraft:stone_brick_wall
fill ^-2 ^0 ^-17 ^-2 ^8 ^-17 minecraft:stone_bricks
setblock ^-2 ^9 ^-17 minecraft:stone_brick_wall
fill ^-1 ^0 ^-18 ^1 ^8 ^-18 minecraft:stone_bricks
$fill ^-1 ^9 ^-18 ^1 ^9 ^-18 minecraft:stone_brick_stairs[facing=$(bk),half=bottom]
fill ^2 ^0 ^-18 ^2 ^9 ^-18 minecraft:stone_bricks
setblock ^2 ^10 ^-18 minecraft:stone_brick_wall
fill ^-2 ^0 ^-18 ^-2 ^9 ^-18 minecraft:stone_bricks
setblock ^-2 ^10 ^-18 minecraft:stone_brick_wall
fill ^-1 ^0 ^-19 ^1 ^9 ^-19 minecraft:stone_bricks
$fill ^-1 ^10 ^-19 ^1 ^10 ^-19 minecraft:stone_brick_stairs[facing=$(bk),half=bottom]
fill ^2 ^0 ^-19 ^2 ^10 ^-19 minecraft:stone_bricks
setblock ^2 ^11 ^-19 minecraft:stone_brick_wall
fill ^-2 ^0 ^-19 ^-2 ^10 ^-19 minecraft:stone_bricks
setblock ^-2 ^11 ^-19 minecraft:stone_brick_wall
fill ^-1 ^0 ^-20 ^1 ^10 ^-20 minecraft:stone_bricks
$fill ^-1 ^11 ^-20 ^1 ^11 ^-20 minecraft:stone_brick_stairs[facing=$(bk),half=bottom]
fill ^2 ^0 ^-20 ^2 ^11 ^-20 minecraft:stone_bricks
setblock ^2 ^12 ^-20 minecraft:stone_brick_wall
fill ^-2 ^0 ^-20 ^-2 ^11 ^-20 minecraft:stone_bricks
setblock ^-2 ^12 ^-20 minecraft:stone_brick_wall
# 성 엔티티 (v42) : 정문 표식 / 철문 우클릭 칸 / 신호기 표식 / 가운데 표식 / 신호기 위 글자
$summon minecraft:marker ^ ^ ^ {Tags:["rpg_ca","rpg_cag","rpg_cag42","rpg_canew"],Rotation:[$(yaw).0f,0.0f]}
summon minecraft:interaction ^ ^ ^ {Tags:["rpg_ca","rpg_cadoor","rpg_canew","rpg_cad43"],width:1.2f,height:2.0f,response:1b}
summon minecraft:marker ^ ^12 ^-24 {Tags:["rpg_ca","rpg_cab","rpg_cab42","rpg_canew"]}
summon minecraft:marker ^ ^ ^-24 {Tags:["rpg_ca","rpg_cac","rpg_canew"]}
summon minecraft:text_display ^ ^15.2 ^-24 {Tags:["rpg_ca","rpg_cabt","rpg_canew"],billboard:"center",alignment:"center",see_through:false,background:1073741824,view_range:1.6f,text:{text:"신호기"}}

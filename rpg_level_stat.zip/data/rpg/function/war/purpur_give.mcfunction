# ── 퍼퍼 블럭 64개 지급 (v40 · 모험 모드에서도 어디에나 설치) ──
give @s minecraft:purpur_block[minecraft:can_place_on=[{}],minecraft:item_name={"text":"퍼퍼 블럭","color":"light_purple","bold":true},minecraft:lore=[{"text":"모험 모드에서도 어디에나 놓을 수 있습니다","color":"gray","italic":false},{"text":"적 성벽을 넘거나 신호기에 다가갈 때","color":"dark_gray","italic":false}]] 64
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"퍼퍼 블럭 64개","color":"light_purple","bold":true},{"text":" 를 받았습니다.","color":"white"}]
return 1

$particle minecraft:dust_color_transition{from_color:[1.0,0.1,0.1],to_color:[1.0,0.1,0.1],scale:1.6} ~$(a) ~0.6 ~-25 0 0 0 0 1 force @a
$particle minecraft:dust_color_transition{from_color:[1.0,0.1,0.1],to_color:[1.0,0.1,0.1],scale:1.6} ~$(a) ~0.6 ~24 0 0 0 0 1 force @a
$particle minecraft:dust_color_transition{from_color:[1.0,0.1,0.1],to_color:[1.0,0.1,0.1],scale:1.6} ~-25 ~0.6 ~$(a) 0 0 0 0 1 force @a
$particle minecraft:dust_color_transition{from_color:[1.0,0.1,0.1],to_color:[1.0,0.1,0.1],scale:1.6} ~24 ~0.6 ~$(a) 0 0 0 0 1 force @a

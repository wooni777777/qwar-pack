execute store result storage rpg:war tp.x int 1 run scoreboard players get #cs6x rpg.sys
execute store result storage rpg:war tp.y int 1 run scoreboard players get #cs6y rpg.sys
execute store result storage rpg:war tp.z int 1 run scoreboard players get #cs6z rpg.sys
function rpg:war/cs_tp_go with storage rpg:war tp
tellraw @s ["",{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"보라 국가의 성","color":"dark_purple","bold":true},{"text":" 으로 이동했습니다.","color":"white"}]

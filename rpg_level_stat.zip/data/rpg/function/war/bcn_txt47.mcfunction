# (v47 · 한 번 · as 신호기 표식)
tag @s add rpg_cab47
function rpg:war/bcn_txt

# 성 하나 철거 (v43 · 내부용 · 매크로) — 바닥은 흙/잔디로 덮고 건물 자리는 공기 (49 x 23 x 49 · 반씩)
$execute in $(d) run fill $(x1) $(yf) $(z1) $(x2) $(yf) $(z2) $(fb)
$execute in $(d) run fill $(x1) $(yg) $(z1) $(x2) $(yg) $(z2) $(ft)
$execute in $(d) as @a[x=$(x1),y=$(yf),z=$(z1),dx=48,dy=24,dz=48] at @s run tp @s ~ $(ya) ~
$execute in $(d) run fill $(x1) $(ya) $(z1) $(x2) $(yb) $(zm) minecraft:air
$execute in $(d) run fill $(x1) $(ya) $(zm1) $(x2) $(yb) $(z2) minecraft:air
$execute in $(d) run kill @e[type=!minecraft:player,tag=rpg_ca,x=$(x1),y=$(yf),z=$(z1),dx=48,dy=24,dz=48]
$execute in $(d) run kill @e[type=minecraft:item,x=$(x1),y=$(yf),z=$(z1),dx=48,dy=24,dz=48]
$execute in $(d) run kill @e[type=minecraft:experience_orb,x=$(x1),y=$(yf),z=$(z1),dx=48,dy=24,dz=48]
scoreboard players add #wcnt rpg.sys 1
function rpg:war/wipe_pop

execute if score #war_run rpg.sys matches 0 run return 0
scoreboard players operation #war_s rpg.sys = #war_time rpg.sys
scoreboard players operation #war_s rpg.sys /= #c20 rpg.sys
scoreboard players operation #war_m rpg.sys = #war_s rpg.sys
scoreboard players operation #war_m rpg.sys /= #c60 rpg.sys
scoreboard players operation #war_s rpg.sys %= #c60 rpg.sys
execute store result storage rpg:war t.m int 1 run scoreboard players get #war_m rpg.sys
execute store result storage rpg:war t.s int 1 run scoreboard players get #war_s rpg.sys
execute if score #war_pause rpg.sys matches 1 run bossbar set rpg:war name {"text":"-{전쟁}-  일시 정지","color":"gray","bold":true}
execute if score #war_pause rpg.sys matches 0 if score #war_s rpg.sys matches 10.. run function rpg:war/name with storage rpg:war t
execute if score #war_pause rpg.sys matches 0 if score #war_s rpg.sys matches ..9 run function rpg:war/name0 with storage rpg:war t
# 블록 보호
execute if score #war_prot rpg.sys matches 1 run function rpg:war/guard

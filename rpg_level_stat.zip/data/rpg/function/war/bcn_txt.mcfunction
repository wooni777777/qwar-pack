# 신호기 위 글자 갱신 (v42 · as 신호기 표식)
scoreboard players operation #nx rpg.sys = @s rpg.csn
function rpg:war/natnm
data modify storage rpg:war bt set from storage rpg:war nm
execute store result storage rpg:war bt.k int 1 run scoreboard players get @s rpg.csk
execute at @s as @e[type=minecraft:text_display,tag=rpg_cabt,distance=..4,limit=1] run function rpg:war/bcn_txt2 with storage rpg:war bt

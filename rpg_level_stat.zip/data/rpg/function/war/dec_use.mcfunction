advancement revoke @s only rpg:war/declare
# 전쟁 중이 아니면 돌려준다
execute if score #war_run rpg.sys matches 0 run function rpg:war/dec_refund
execute if score #war_run rpg.sys matches 0 run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"선전포고는 전쟁 중에만 쓸 수 있습니다.","color":"red"}]
# 국가가 없으면 돌려준다
execute unless score @s rpg.natn matches 1..8 run function rpg:war/dec_refund
execute unless score @s rpg.natn matches 1..8 run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"먼저 국가에 들어가야 합니다. (메뉴 > 국가 > 양털 클릭)","color":"red"}]
scoreboard players set @s rpg.wdp 1
function rpg:war/dec_menu

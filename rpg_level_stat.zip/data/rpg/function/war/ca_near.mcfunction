# 새 성 자리가 다른 성과 겹치는지 (내부용 · #near · 매크로 yaw)
scoreboard players set #near rpg.sys 0
$execute rotated $(yaw) 0 positioned ^ ^ ^-24 positioned ~-48.5 ~-40 ~-48.5 if entity @e[type=minecraft:marker,tag=rpg_cac,dx=96,dy=80,dz=96] run scoreboard players set #near rpg.sys 1

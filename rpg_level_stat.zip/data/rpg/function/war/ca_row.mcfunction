scoreboard players add #rowc rpg.sys 1
$scoreboard players operation #nx rpg.sys = #ca$(s)n rpg.sys
function rpg:war/natnm
data modify storage rpg:war row set from storage rpg:war nm
$data modify storage rpg:war row.s set value $(s)
$scoreboard players set #rt rpg.sys $(s)
scoreboard players add #rt rpg.sys 1000
execute store result storage rpg:war row.t int 1 run scoreboard players get #rt rpg.sys
$execute store result storage rpg:war row.k int 1 run scoreboard players get #ca$(s)k rpg.sys
$execute store result storage rpg:war row.x int 0.1 run scoreboard players get #ca$(s)bx rpg.sys
$execute store result storage rpg:war row.y int 0.1 run scoreboard players get #ca$(s)by rpg.sys
$execute store result storage rpg:war row.z int 0.1 run scoreboard players get #ca$(s)bz rpg.sys
function rpg:war/ca_row2 with storage rpg:war row

# 비밀번호 입력 / [확정] 등 (v42 · as 플레이어 · /trigger rpg.pw set <숫자>)
#   숫자 = 비밀번호 · -1 [확정] · -2 [다시 입력] · -3 [비밀번호 바꾸기]
scoreboard players operation #pv rpg.sys = @s rpg.pw
scoreboard players set @s rpg.pw 0
scoreboard players enable @s rpg.pw
scoreboard players add @s rpg.pwl 0
execute unless score @s rpg.pwd matches 1.. run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"먼저 성 철문을 우클릭하세요.","color":"red"}]
scoreboard players operation #pa rpg.sys = #gtick rpg.sys
scoreboard players operation #pa rpg.sys -= @s rpg.pwt
execute unless score #pa rpg.sys matches 0..1200 run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"시간이 지났습니다. 철문을 다시 우클릭하세요.","color":"red"}]
scoreboard players set #pn rpg.sys 0
execute if score @s rpg.natn matches -2147483648.. run scoreboard players operation #pn rpg.sys = @s rpg.natn
scoreboard players operation #pd rpg.sys = @s rpg.pwd
scoreboard players operation #pm rpg.sys = @s rpg.pwm
scoreboard players operation #pp rpg.sys = @s rpg.pwp
scoreboard players operation #pl rpg.sys = #gtick rpg.sys
scoreboard players operation #pl rpg.sys -= @s rpg.pwl
scoreboard players set #pf rpg.sys 0
tag @s add rpg_pwp
execute as @e[type=minecraft:marker,tag=rpg_cag] if score @s rpg.cbid = #pd rpg.sys at @s run function rpg:war/pw_do
tag @s remove rpg_pwp
execute if score #pf rpg.sys matches 0 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"그 성은 이제 없습니다.","color":"red"}]

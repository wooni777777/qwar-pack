# 예전 철문 우클릭 칸 넓히기 (v43 · 한 번 · as 우클릭 칸)
data modify entity @s width set value 1.2f
tag @s add rpg_cad43

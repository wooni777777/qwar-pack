# (v43 · 내부용 · 매크로) 성 자리 청크 16개 강제 불러오기 (원래 강제로 불러와져 있던 청크는 건드리지 않음)
$function rpg:war/wipe_fl1 {d:"$(d)",x:$(x1),z:$(z1)}
$function rpg:war/wipe_fl1 {d:"$(d)",x:$(x1),z:$(zb)}
$function rpg:war/wipe_fl1 {d:"$(d)",x:$(x1),z:$(zc)}
$function rpg:war/wipe_fl1 {d:"$(d)",x:$(x1),z:$(z2)}
$function rpg:war/wipe_fl1 {d:"$(d)",x:$(xb),z:$(z1)}
$function rpg:war/wipe_fl1 {d:"$(d)",x:$(xb),z:$(zb)}
$function rpg:war/wipe_fl1 {d:"$(d)",x:$(xb),z:$(zc)}
$function rpg:war/wipe_fl1 {d:"$(d)",x:$(xb),z:$(z2)}
$function rpg:war/wipe_fl1 {d:"$(d)",x:$(xc),z:$(z1)}
$function rpg:war/wipe_fl1 {d:"$(d)",x:$(xc),z:$(zb)}
$function rpg:war/wipe_fl1 {d:"$(d)",x:$(xc),z:$(zc)}
$function rpg:war/wipe_fl1 {d:"$(d)",x:$(xc),z:$(z2)}
$function rpg:war/wipe_fl1 {d:"$(d)",x:$(x2),z:$(z1)}
$function rpg:war/wipe_fl1 {d:"$(d)",x:$(x2),z:$(zb)}
$function rpg:war/wipe_fl1 {d:"$(d)",x:$(x2),z:$(zc)}
$function rpg:war/wipe_fl1 {d:"$(d)",x:$(x2),z:$(z2)}

# 스탯 초기화 종이 구매 (네더별 10개 · v50)
scoreboard players set #ns rpg.sys 0
execute store result score #ns rpg.sys run clear @s minecraft:nether_star 0
execute if score #ns rpg.sys matches ..9 run return run tellraw @s [{"text":"[상점] ","color":"aqua","bold":true},{"text":"네더별이 부족합니다. (10개 필요 · 지금 ","color":"red"},{"score":{"name":"#ns","objective":"rpg.sys"},"color":"yellow"},{"text":"개)","color":"red"}]
clear @s minecraft:nether_star 10
function rpg:war/sreset_give
tellraw @s [{"text":"[상점] ","color":"aqua","bold":true},{"text":"스탯 초기화 종이","color":"light_purple","bold":true},{"text":" 1장을 샀습니다.","color":"white"}]
execute at @s run playsound minecraft:entity.villager.yes player @s ~ ~ ~ 1 1.2
return 1

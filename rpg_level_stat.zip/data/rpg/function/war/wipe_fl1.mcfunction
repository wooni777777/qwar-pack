# (v43 · 내부용 · 매크로 d x z) 청크 하나 강제 불러오기 — 이미 강제면 그대로 두고 기록 안 함
scoreboard players set #fq rpg.sys 0
$execute in $(d) store success score #fq rpg.sys run forceload query $(x) $(z)
execute if score #fq rpg.sys matches 1 run return 0
$execute in $(d) run forceload add $(x) $(z)
$data modify storage rpg:war wfl append value {d:"$(d)",x:$(x),z:$(z)}

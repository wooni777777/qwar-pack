tellraw @s " "
tellraw @s {"text": "━━━━━━━  선전포고 현황  ━━━━━━━", "color": "dark_gray"}
execute if score #war_run rpg.sys matches 0 run tellraw @s {"text":"   진행 중인 전쟁이 없습니다","color":"red"}
scoreboard players set #wdn rpg.sys 0
execute if score #wd12 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd12 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "빨강", "color": "red", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "주황", "color": "gold", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd13 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd13 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "빨강", "color": "red", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "노랑", "color": "yellow", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd14 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd14 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "빨강", "color": "red", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "초록", "color": "green", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd15 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd15 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "빨강", "color": "red", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "파랑", "color": "blue", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd16 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd16 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "빨강", "color": "red", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "보라", "color": "dark_purple", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd17 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd17 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "빨강", "color": "red", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "분홍", "color": "light_purple", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd18 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd18 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "빨강", "color": "red", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "하양", "color": "white", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd21 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd21 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "주황", "color": "gold", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "빨강", "color": "red", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd23 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd23 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "주황", "color": "gold", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "노랑", "color": "yellow", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd24 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd24 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "주황", "color": "gold", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "초록", "color": "green", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd25 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd25 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "주황", "color": "gold", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "파랑", "color": "blue", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd26 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd26 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "주황", "color": "gold", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "보라", "color": "dark_purple", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd27 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd27 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "주황", "color": "gold", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "분홍", "color": "light_purple", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd28 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd28 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "주황", "color": "gold", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "하양", "color": "white", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd31 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd31 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "노랑", "color": "yellow", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "빨강", "color": "red", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd32 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd32 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "노랑", "color": "yellow", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "주황", "color": "gold", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd34 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd34 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "노랑", "color": "yellow", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "초록", "color": "green", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd35 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd35 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "노랑", "color": "yellow", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "파랑", "color": "blue", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd36 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd36 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "노랑", "color": "yellow", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "보라", "color": "dark_purple", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd37 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd37 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "노랑", "color": "yellow", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "분홍", "color": "light_purple", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd38 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd38 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "노랑", "color": "yellow", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "하양", "color": "white", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd41 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd41 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "초록", "color": "green", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "빨강", "color": "red", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd42 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd42 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "초록", "color": "green", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "주황", "color": "gold", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd43 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd43 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "초록", "color": "green", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "노랑", "color": "yellow", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd45 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd45 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "초록", "color": "green", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "파랑", "color": "blue", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd46 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd46 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "초록", "color": "green", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "보라", "color": "dark_purple", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd47 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd47 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "초록", "color": "green", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "분홍", "color": "light_purple", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd48 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd48 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "초록", "color": "green", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "하양", "color": "white", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd51 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd51 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "파랑", "color": "blue", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "빨강", "color": "red", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd52 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd52 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "파랑", "color": "blue", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "주황", "color": "gold", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd53 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd53 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "파랑", "color": "blue", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "노랑", "color": "yellow", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd54 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd54 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "파랑", "color": "blue", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "초록", "color": "green", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd56 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd56 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "파랑", "color": "blue", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "보라", "color": "dark_purple", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd57 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd57 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "파랑", "color": "blue", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "분홍", "color": "light_purple", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd58 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd58 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "파랑", "color": "blue", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "하양", "color": "white", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd61 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd61 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "보라", "color": "dark_purple", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "빨강", "color": "red", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd62 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd62 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "보라", "color": "dark_purple", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "주황", "color": "gold", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd63 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd63 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "보라", "color": "dark_purple", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "노랑", "color": "yellow", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd64 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd64 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "보라", "color": "dark_purple", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "초록", "color": "green", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd65 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd65 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "보라", "color": "dark_purple", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "파랑", "color": "blue", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd67 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd67 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "보라", "color": "dark_purple", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "분홍", "color": "light_purple", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd68 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd68 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "보라", "color": "dark_purple", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "하양", "color": "white", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd71 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd71 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "분홍", "color": "light_purple", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "빨강", "color": "red", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd72 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd72 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "분홍", "color": "light_purple", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "주황", "color": "gold", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd73 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd73 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "분홍", "color": "light_purple", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "노랑", "color": "yellow", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd74 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd74 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "분홍", "color": "light_purple", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "초록", "color": "green", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd75 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd75 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "분홍", "color": "light_purple", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "파랑", "color": "blue", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd76 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd76 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "분홍", "color": "light_purple", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "보라", "color": "dark_purple", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd78 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd78 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "분홍", "color": "light_purple", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "하양", "color": "white", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd81 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd81 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "하양", "color": "white", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "빨강", "color": "red", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd82 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd82 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "하양", "color": "white", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "주황", "color": "gold", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd83 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd83 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "하양", "color": "white", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "노랑", "color": "yellow", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd84 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd84 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "하양", "color": "white", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "초록", "color": "green", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd85 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd85 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "하양", "color": "white", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "파랑", "color": "blue", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd86 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd86 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "하양", "color": "white", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "보라", "color": "dark_purple", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wd87 rpg.sys matches 1 run scoreboard players add #wdn rpg.sys 1
execute if score #wd87 rpg.sys matches 1 run tellraw @s ["", {"text": "   "}, {"text": "하양", "color": "white", "bold": true}, {"text": "  ▶  ", "color": "dark_gray"}, {"text": "분홍", "color": "light_purple", "bold": true}, {"text": "   의 성을 부술 수 있습니다", "color": "gray"}]
execute if score #wdn rpg.sys matches 0 run tellraw @s {"text":"   아직 선전포고한 국가가 없습니다","color":"dark_gray"}
tellraw @s {"text": "━━━━━━━━━━━━━━━━━━━━━━━━━━", "color": "dark_gray"}

execute if score #cri rpg.sys matches 50.. run return 0
scoreboard players operation #cra rpg.sys = #cri rpg.sys
scoreboard players remove #cra rpg.sys 25
execute store result storage rpg:war pv.a int 1 run scoreboard players get #cra rpg.sys
function rpg:war/cs_pt with storage rpg:war pv
scoreboard players add #cri rpg.sys 2
function rpg:war/cs_ring

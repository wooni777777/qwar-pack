# 성 신호기 유지 (v42 · as 신호기 표식 at 표식 · 0.5초마다)
#   부순 사람 없이 없어졌으면 (명령어 · 크리에이티브 등) 다시 놓는다. 서바이벌로 부순 것은 war/bcn_mined 가 처리
execute if block ~ ~ ~ minecraft:beacon run return 0
execute if entity @a[distance=..10,scores={rpg.bmn=1..}] run return 0
setblock ~ ~ ~ minecraft:beacon

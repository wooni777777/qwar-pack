scoreboard players enable @s rpg.wdc
scoreboard players enable @s rpg.wmn
execute unless score @s rpg.wdp matches 1 run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"쓸 수 있는 선전포고가 없습니다. (선전포고를 우클릭하세요)","color":"red"}]
tellraw @s " "
tellraw @s {"text": "━━━━━━  어느 국가에 선전포고?  ━━━━━━", "color": "dark_gray"}
tellraw @s {"text":"   고른 국가의 성만 부술 수 있게 됩니다.","color":"dark_gray"}
tellraw @s " "
execute unless score @s rpg.natn matches 1 run tellraw @s ["", {"text": "   "}, {"text": "[ 빨강 국가 ]", "color": "red", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.wdc set 1"}, "hover_event": {"action": "show_text", "value": {"text": "빨강 국가에 선전포고합니다", "color": "gray"}}}]
execute unless score @s rpg.natn matches 2 run tellraw @s ["", {"text": "   "}, {"text": "[ 주황 국가 ]", "color": "gold", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.wdc set 2"}, "hover_event": {"action": "show_text", "value": {"text": "주황 국가에 선전포고합니다", "color": "gray"}}}]
execute unless score @s rpg.natn matches 3 run tellraw @s ["", {"text": "   "}, {"text": "[ 노랑 국가 ]", "color": "yellow", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.wdc set 3"}, "hover_event": {"action": "show_text", "value": {"text": "노랑 국가에 선전포고합니다", "color": "gray"}}}]
execute unless score @s rpg.natn matches 4 run tellraw @s ["", {"text": "   "}, {"text": "[ 초록 국가 ]", "color": "green", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.wdc set 4"}, "hover_event": {"action": "show_text", "value": {"text": "초록 국가에 선전포고합니다", "color": "gray"}}}]
execute unless score @s rpg.natn matches 5 run tellraw @s ["", {"text": "   "}, {"text": "[ 파랑 국가 ]", "color": "blue", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.wdc set 5"}, "hover_event": {"action": "show_text", "value": {"text": "파랑 국가에 선전포고합니다", "color": "gray"}}}]
execute unless score @s rpg.natn matches 6 run tellraw @s ["", {"text": "   "}, {"text": "[ 보라 국가 ]", "color": "dark_purple", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.wdc set 6"}, "hover_event": {"action": "show_text", "value": {"text": "보라 국가에 선전포고합니다", "color": "gray"}}}]
execute unless score @s rpg.natn matches 7 run tellraw @s ["", {"text": "   "}, {"text": "[ 분홍 국가 ]", "color": "light_purple", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.wdc set 7"}, "hover_event": {"action": "show_text", "value": {"text": "분홍 국가에 선전포고합니다", "color": "gray"}}}]
execute unless score @s rpg.natn matches 8 run tellraw @s ["", {"text": "   "}, {"text": "[ 하양 국가 ]", "color": "white", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.wdc set 8"}, "hover_event": {"action": "show_text", "value": {"text": "하양 국가에 선전포고합니다", "color": "gray"}}}]
tellraw @s {"text": "━━━━━━━━━━━━━━━━━━━━━━━━━━", "color": "dark_gray"}

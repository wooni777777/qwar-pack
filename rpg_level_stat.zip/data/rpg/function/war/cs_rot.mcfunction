# 플레이어가 보는 방향을 동서남북 4방향으로 맞춘다 (내부용 · storage rpg:war rot)
execute store result score #ry rpg.sys run data get entity @s Rotation[0]
scoreboard players add #ry rpg.sys 36045
scoreboard players operation #ry rpg.sys /= #k90 rpg.sys
scoreboard players operation #ry rpg.sys %= #k4 rpg.sys
execute if score #ry rpg.sys matches 0 run data modify storage rpg:war rot set value {yaw:0,fw:"south",bk:"north"}
execute if score #ry rpg.sys matches 1 run data modify storage rpg:war rot set value {yaw:90,fw:"west",bk:"east"}
execute if score #ry rpg.sys matches 2 run data modify storage rpg:war rot set value {yaw:180,fw:"north",bk:"south"}
execute if score #ry rpg.sys matches 3 run data modify storage rpg:war rot set value {yaw:270,fw:"east",bk:"west"}

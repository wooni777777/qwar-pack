# 정문 우클릭 칸 유지 (v42 · 0.5초마다 · as 정문 표식 at 표식)
#   철문이 부서져 있으면 칸을 치운다 (그 자리에 새 철문을 달 수 있게) · 철문이 다시 있으면 칸을 만든다
execute unless block ~ ~ ~ minecraft:iron_door run kill @e[type=minecraft:interaction,tag=rpg_cadoor,distance=..0.6]
execute as @e[type=minecraft:interaction,tag=rpg_cadoor,tag=!rpg_cad43,distance=..0.6] run function rpg:war/door_w43
execute if block ~ ~ ~ minecraft:iron_door unless entity @e[type=minecraft:interaction,tag=rpg_cadoor,distance=..0.6] run function rpg:war/door_ie

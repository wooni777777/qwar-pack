# 정문 우클릭 칸 유지 (v42 · 0.5초마다 · as 정문 표식 at 표식)
#   철문이 부서져 있으면 칸을 치운다 (그 자리에 새 철문을 달 수 있게) · 철문이 다시 있으면 칸을 만든다
execute unless block ~ ~ ~ minecraft:iron_door align xyz positioned ~0.5 ~ ~0.5 run kill @e[type=minecraft:interaction,tag=rpg_cadoor,distance=..0.58]
# v47 : 예전 넓은 칸(1.2) -> 철문 판자에 맞춘 가는 칸 4개로
execute align xyz positioned ~0.5 ~ ~0.5 if entity @e[type=minecraft:interaction,tag=rpg_cadoor,tag=!rpg_cad47,distance=..0.7] run function rpg:war/door_ie
execute if block ~ ~ ~ minecraft:iron_door align xyz positioned ~0.5 ~ ~0.5 unless entity @e[type=minecraft:interaction,tag=rpg_cadoor,distance=..0.58] run function rpg:war/door_ie

execute unless block ~-1 ~-1 ~24 minecraft:redstone_block run fill ~-1 ~-1 ~24 ~0 ~-1 ~24 minecraft:redstone_block

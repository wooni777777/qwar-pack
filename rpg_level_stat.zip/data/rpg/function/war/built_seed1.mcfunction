# (v43 · 내부용 · 매크로 s) 등록된 성 한 개 -> 지은 성 목록 (신호기 좌표 x10 을 블록 좌표로)
$execute unless score #ca$(s)bx rpg.sys matches -2147483648.. run return 0
$scoreboard players operation #bsx rpg.sys = #ca$(s)bx rpg.sys
$scoreboard players operation #bsy rpg.sys = #ca$(s)by rpg.sys
$scoreboard players operation #bsz rpg.sys = #ca$(s)bz rpg.sys
scoreboard players operation #bsx rpg.sys /= #k10 rpg.sys
scoreboard players operation #bsy rpg.sys /= #k10 rpg.sys
scoreboard players operation #bsz rpg.sys /= #k10 rpg.sys
data modify storage rpg:war nb set value {d:"minecraft:overworld"}
execute store result storage rpg:war nb.x int 1 run scoreboard players get #bsx rpg.sys
execute store result storage rpg:war nb.y int 1 run scoreboard players get #bsy rpg.sys
execute store result storage rpg:war nb.z int 1 run scoreboard players get #bsz rpg.sys
data modify storage rpg:war built append from storage rpg:war nb

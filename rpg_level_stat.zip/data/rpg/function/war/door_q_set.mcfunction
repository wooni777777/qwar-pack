# 처음 쓰는 철문 : 저장할 비밀번호 물어보기 (v42 · 매크로 k)
scoreboard players set @a[tag=rpg_pwp] rpg.pwm 1
scoreboard players set @a[tag=rpg_pwp] rpg.pwp 0
tellraw @a[tag=rpg_pwp] " "
$tellraw @a[tag=rpg_pwp] ["", {"text": "[철문] ", "color": "gold", "bold": true}, {"text": "$(k)성", "color": "aqua", "bold": true}, {"text": " 철문 — 저장할 비밀번호를 입력하세요  ", "color": "white"}, {"text": "[비밀번호 입력]", "color": "green", "bold": true, "click_event": {"action": "suggest_command", "command": "/trigger rpg.pw set "}, "hover_event": {"action": "show_text", "value": {"text": "누르면 채팅창에  /trigger rpg.pw set  이 들어갑니다.\n뒤에 숫자 비밀번호를 쓰고 엔터", "color": "gray"}}}]
tellraw @a[tag=rpg_pwp] {"text":"   숫자만 (1 ~ 2147483647) · 입력한 뒤 [확정] 을 누르면 저장됩니다","color":"dark_gray"}

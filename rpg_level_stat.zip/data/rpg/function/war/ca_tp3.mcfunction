$execute store result storage rpg:war tp.x double 0.1 run scoreboard players get #ca$(s)bx rpg.sys
$execute store result storage rpg:war tp.y double 0.1 run scoreboard players get #ca$(s)by rpg.sys
$execute store result storage rpg:war tp.z double 0.1 run scoreboard players get #ca$(s)bz rpg.sys
function rpg:war/ca_tp4 with storage rpg:war tp
$tellraw @s ["",{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"$(k)성","color":"aqua","bold":true},{"text":" 신호기 위로 이동했습니다.","color":"white"}]
execute at @s run playsound minecraft:entity.enderman.teleport player @a ~ ~ ~ 1 1

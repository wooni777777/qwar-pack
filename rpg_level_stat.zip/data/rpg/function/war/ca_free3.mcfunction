$scoreboard players set #cu$(n)_$(k) rpg.sys 0

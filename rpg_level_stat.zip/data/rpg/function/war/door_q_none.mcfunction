# 비밀번호가 아직 없는 다른 국가 철문 (v42 · 매크로 k)
$tellraw @a[tag=rpg_pwp] ["", {"text": "[철문] ", "color": "gold", "bold": true}, {"text": "$(k)성", "color": "aqua", "bold": true}, {"text": " 철문은 아직 비밀번호가 없습니다. 이 성의 국가만 비밀번호를 정할 수 있습니다.", "color": "red"}]

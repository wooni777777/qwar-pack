scoreboard players set #war_time rpg.sys 36000
scoreboard players set #war_max rpg.sys 36000
data modify storage rpg:war w.n set value "30분"
function rpg:war/go

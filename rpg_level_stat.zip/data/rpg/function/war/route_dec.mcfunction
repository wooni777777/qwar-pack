# 선전포고 국가 선택 처리
execute if score @s rpg.wdc matches 1 run function rpg:war/dec1
execute if score @s rpg.wdc matches 2 run function rpg:war/dec2
execute if score @s rpg.wdc matches 3 run function rpg:war/dec3
execute if score @s rpg.wdc matches 4 run function rpg:war/dec4
execute if score @s rpg.wdc matches 5 run function rpg:war/dec5
execute if score @s rpg.wdc matches 6 run function rpg:war/dec6
execute if score @s rpg.wdc matches 7 run function rpg:war/dec7
execute if score @s rpg.wdc matches 8 run function rpg:war/dec8
scoreboard players set @s rpg.wdc 0
scoreboard players enable @s rpg.wdc

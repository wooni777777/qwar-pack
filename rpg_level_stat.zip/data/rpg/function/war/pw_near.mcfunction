# 비밀번호 입력 중인 사람이 철문 가까이(3칸 안)에 있는지 (v47 · 1틱마다 · as at 플레이어)
scoreboard players operation #pd rpg.sys = @s rpg.pwd
scoreboard players set #pnr rpg.sys 0
execute as @e[type=minecraft:marker,tag=rpg_cag,distance=..3.2] if score @s rpg.cbid = #pd rpg.sys run scoreboard players set #pnr rpg.sys 1
execute if score #pnr rpg.sys matches 0 run function rpg:war/pw_far

# (v43 · 내부용 · as 성 개체)
data modify storage rpg:war orp set value {s:0}
execute store result storage rpg:war orp.s int 1 run scoreboard players get @s rpg.csid
function rpg:war/ca_orphan2 with storage rpg:war orp

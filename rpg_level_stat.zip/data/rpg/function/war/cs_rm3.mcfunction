scoreboard players set #cs3on rpg.sys 0
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"노랑 국가의 성 기록을 지웠습니다.","color":"red"}]
function rpg:war/cs_list

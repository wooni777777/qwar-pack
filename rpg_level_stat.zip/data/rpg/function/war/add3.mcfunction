execute if score #war_run rpg.sys matches 0 run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"진행 중인 전쟁이 없습니다.","color":"red"}]
scoreboard players add #war_time rpg.sys 36000
scoreboard players add #war_max rpg.sys 36000
execute store result bossbar rpg:war max run scoreboard players get #war_max rpg.sys
tellraw @a [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"전쟁 시간이 30분 늘어났습니다.","color":"gold"}]
function rpg:war/sec

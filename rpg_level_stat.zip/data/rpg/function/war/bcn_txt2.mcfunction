# 신호기 위 글자 (v47 : 둘째 줄 "신호기를 맨손으로 부수면 함락" 지움 · 매크로 nm k cl)
$data modify entity @s text set value {"text":"$(nm) 국가 $(k)성","color":"$(cl)","bold":true}

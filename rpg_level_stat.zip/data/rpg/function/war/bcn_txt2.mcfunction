$data modify entity @s text set value ["",{"text":"$(nm) 국가 $(k)성","color":"$(cl)","bold":true},{"text":"\n신호기를 맨손으로 부수면 함락","color":"gray"}]

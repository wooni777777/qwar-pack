$execute if score #wd$(a)$(b) rpg.sys matches 1.. run scoreboard players set #bdecl rpg.sys 1

# 폭탄 구매 (네더별 3개)
scoreboard players set #ns rpg.sys 0
execute store result score #ns rpg.sys run clear @s minecraft:nether_star 0
execute if score #ns rpg.sys matches ..2 run return run tellraw @s [{"text":"[상점] ","color":"aqua","bold":true},{"text":"네더별이 부족합니다. (3개 필요)","color":"red"}]
clear @s minecraft:nether_star 3
function rpg:war/bomb_give
execute at @s run playsound minecraft:entity.villager.yes player @s ~ ~ ~ 1 1.2
return 1

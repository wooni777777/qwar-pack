# 열린 철문 닫기 (v43 · as 누른 사람) — 국가 상관없이 누구나
execute as @e[type=minecraft:marker,tag=rpg_cag] if score @s rpg.cbid = #dci rpg.sys at @s run function rpg:war/door_close
return 1

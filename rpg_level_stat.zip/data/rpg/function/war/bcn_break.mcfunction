# 신호기 파괴 (v42 · as 신호기 표식 at 표식 · 신호기 블록은 이미 부서진 상태)
scoreboard players operation #bs rpg.sys = @s rpg.csid
scoreboard players operation #bn rpg.sys = @s rpg.csn
scoreboard players operation #bk rpg.sys = @s rpg.csk
particle minecraft:explosion_emitter ~ ~0.5 ~ 0 0 0 0 1 force @a
particle minecraft:end_rod ~ ~0.5 ~ 0.4 0.6 0.4 0.15 60 force @a
playsound minecraft:block.beacon.deactivate master @a ~ ~ ~ 3 0.8
playsound minecraft:entity.generic.explode master @a ~ ~ ~ 2 1.0
execute as @a[tag=rpg_batk] run function rpg:war/bb_give
scoreboard players operation #nx rpg.sys = #bn rpg.sys
function rpg:war/natnm
data modify storage rpg:war an set from storage rpg:war nm
execute store result storage rpg:war an.k int 1 run scoreboard players get #bk rpg.sys
execute store result storage rpg:war an.n int 1 run scoreboard players get #bn rpg.sys
function rpg:war/bcn_say with storage rpg:war an
function rpg:war/ca_free
# 그 국가에 남은 성이 없으면 멸망
scoreboard players operation #dn rpg.sys = #bn rpg.sys
function rpg:war/ca_count
execute if score #dc rpg.sys matches 0 run function rpg:war/fall_n with storage rpg:war an

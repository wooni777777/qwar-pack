execute if score #war_run rpg.sys matches 0 run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"진행 중인 전쟁이 없습니다.","color":"red"}]
function rpg:war/end

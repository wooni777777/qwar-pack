$tellraw @a[scores={rpg.natn=$(n)}] ["",{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"$(k)성","color":"aqua","bold":true},{"text":"의 철문이 파괴되었습니다","color":"red"}]

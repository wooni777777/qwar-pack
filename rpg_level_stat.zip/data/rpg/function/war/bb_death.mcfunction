# 부서진 신호기를 갖고 죽음 (v50 · as/at 죽은 플레이어 · hid/on_death)
#   인벤에서 1개 없애고 죽은 자리에 1개 떨어뜨림 (인벤 유지 서버용 · 인벤이 다 떨어지는 서버면 이미 떨어져 있어서 아무것도 안 함)
scoreboard players set #bbn rpg.sys 0
execute store result score #bbn rpg.sys run clear @s minecraft:paper[minecraft:custom_data~{rpg_brokenb:1}] 0
execute if score #bbn rpg.sys matches ..0 run return 0
clear @s minecraft:paper[minecraft:custom_data~{rpg_brokenb:1}] 1
function rpg:war/bb_spawn
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"부서진 신호기","color":"gray","bold":true},{"text":" 1개를 죽은 자리에 떨어뜨렸습니다.","color":"red"}]

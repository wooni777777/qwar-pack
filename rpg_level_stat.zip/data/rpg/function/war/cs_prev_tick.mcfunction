# 성 자리를 빨간 선으로 그린다 (내부용)
scoreboard players set #cri rpg.sys 0
function rpg:war/cs_ring

# 성 자리를 선으로 그린다 (v40 · 4틱마다 · 본인에게만)
function rpg:war/cs_rot
execute align xyz positioned ~0.5 ~ ~0.5 run function rpg:war/cs_pv with storage rpg:war rot

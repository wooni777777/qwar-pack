# 미리보기 켜기 / 끄기
execute if entity @s[tag=rpg_csprev] run tag @s remove rpg_csprev
execute if entity @s[tag=rpg_csprev] run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"미리보기를 껐습니다.","color":"gray"}]
tag @s add rpg_csprev
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"미리보기를 켰습니다. 움직이면 자리도 같이 움직입니다.","color":"gold"}]
return 1

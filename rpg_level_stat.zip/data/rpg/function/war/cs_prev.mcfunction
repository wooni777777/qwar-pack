# 미리보기 켜기 / 끄기 (v40 : 끄기가 안 되던 문제 수정)
execute if entity @s[tag=rpg_csprev] run return run function rpg:war/cs_prev_off
tag @s add rpg_csprev
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"미리보기를 켰습니다. 움직이면 자리도 같이 움직입니다.","color":"gold"}]
return 1

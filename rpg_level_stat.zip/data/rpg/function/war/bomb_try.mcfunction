# 이 성의 문을 부술 수 있는지 본다 (내부용)
$execute positioned $(x) $(y) $(z) unless entity @s[distance=..16] run return 0
$execute unless score #wd$(m)$(n) rpg.sys matches 1 run return 0
$execute positioned $(x) $(y) $(z) run function rpg:war/bomb_blow

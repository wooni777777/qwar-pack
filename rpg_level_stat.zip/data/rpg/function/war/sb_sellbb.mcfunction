# 부서진 신호기 판매 -> 네더별 10개 (v39)
scoreboard players set #bb rpg.sys 0
execute store result score #bb rpg.sys run clear @s minecraft:paper[minecraft:custom_data~{rpg_brokenb:1}] 0
execute if score #bb rpg.sys matches ..0 run return run tellraw @s [{"text":"[상점] ","color":"aqua","bold":true},{"text":"부서진 신호기가 없습니다. (국가 신호기를 금곡괭이로 부수면 얻습니다)","color":"red"}]
clear @s minecraft:paper[minecraft:custom_data~{rpg_brokenb:1}] 1
function rpg:war/star_give {n:10}
tellraw @s [{"text":"[상점] ","color":"aqua","bold":true},{"text":"부서진 신호기 1개 -> ","color":"white"},{"text":"네더별 10개","color":"dark_red","bold":true}]
execute at @s run playsound minecraft:entity.villager.yes player @s ~ ~ ~ 1 1.2
return 1

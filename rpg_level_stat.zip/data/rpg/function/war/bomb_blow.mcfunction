# 성문 철문 1개를 부순다 (내부용 · 성 한가운데에서 실행)
scoreboard players set #bd rpg.sys 0
execute if block ~-1 ~ ~24 minecraft:iron_door run scoreboard players set #bd rpg.sys 1
execute if score #bd rpg.sys matches 1 run fill ~-1 ~ ~24 ~-1 ~1 ~24 minecraft:air
execute if score #bd rpg.sys matches 0 if block ~0 ~ ~24 minecraft:iron_door run scoreboard players set #bd rpg.sys 2
execute if score #bd rpg.sys matches 2 run fill ~0 ~ ~24 ~0 ~1 ~24 minecraft:air
execute if score #bd rpg.sys matches ..0 run return 0
scoreboard players set #bmok rpg.sys 1
particle minecraft:explosion_emitter ~ ~1 ~24 0 0 0 0 1 force @a
particle minecraft:large_smoke ~ ~1 ~24 1.2 1.2 1.2 0.05 60 force @a
playsound minecraft:entity.generic.explode master @a ~ ~1 ~24 3 0.9
tellraw @a ["",{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"성문이 부서졌습니다!","color":"gold","bold":true}]

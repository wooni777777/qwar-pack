# 철문 우클릭 칸 (v42 · as 정문 표식 at 표식)
summon minecraft:interaction ~ ~ ~ {Tags:["rpg_ca","rpg_cadoor","rpg_cadn","rpg_cad43"],width:1.2f,height:2.0f,response:1b}
scoreboard players operation @e[type=minecraft:interaction,tag=rpg_cadn] rpg.csid = @s rpg.csid
scoreboard players operation @e[type=minecraft:interaction,tag=rpg_cadn] rpg.csn = @s rpg.csn
scoreboard players operation @e[type=minecraft:interaction,tag=rpg_cadn] rpg.csk = @s rpg.csk
scoreboard players operation @e[type=minecraft:interaction,tag=rpg_cadn] rpg.cbid = @s rpg.cbid
tag @e[tag=rpg_cadn] remove rpg_cadn

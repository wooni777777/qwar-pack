# 철문 우클릭 칸 (v47 · as 정문 표식 at 표식) — 철문 판자(두께 3/16)에 맞춘 가는 칸 4개
#   닫힘 : 철문이 보는 방향의 반대쪽 가장자리 (동쪽을 보고 달면 서쪽 가장자리) · 열림 : 경첩 쪽 가장자리
execute align xyz positioned ~0.5 ~ ~0.5 run kill @e[type=minecraft:interaction,tag=rpg_cadoor,distance=..0.58]
execute align xyz positioned ~0.5 ~ ~0.5 run function rpg:war/door_ie2
scoreboard players operation @e[type=minecraft:interaction,tag=rpg_cadn] rpg.csid = @s rpg.csid
scoreboard players operation @e[type=minecraft:interaction,tag=rpg_cadn] rpg.csn = @s rpg.csn
scoreboard players operation @e[type=minecraft:interaction,tag=rpg_cadn] rpg.csk = @s rpg.csk
scoreboard players operation @e[type=minecraft:interaction,tag=rpg_cadn] rpg.cbid = @s rpg.cbid
tag @e[tag=rpg_cadn] remove rpg_cadn

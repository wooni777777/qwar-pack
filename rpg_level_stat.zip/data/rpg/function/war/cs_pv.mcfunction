$execute rotated $(yaw) 0 run function rpg:war/cs_pv2

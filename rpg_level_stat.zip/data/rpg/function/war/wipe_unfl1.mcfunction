# (v43 · 내부용 · 매크로 d x z)
$execute in $(d) run forceload remove $(x) $(z)

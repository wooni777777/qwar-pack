# 예전 돌의 핵 · 늑대의 별(네더의 별 모양) / 예전 설명(보스가 남긴 별)·이름이 다른 네더의 별 -> v42 아이템 (0.5초마다 · as 플레이어)
scoreboard players set #mc rpg.sys 0
execute store result score #mc rpg.sys run clear @s minecraft:nether_star[minecraft:item_name={text:"돌의 핵",color:"aqua",bold:true}]
execute store result storage rpg:war mg.n int 1 run scoreboard players get #mc rpg.sys
execute if score #mc rpg.sys matches 1.. run function rpg:mob/core_give_dol with storage rpg:war mg
scoreboard players set #mc rpg.sys 0
execute store result score #mc rpg.sys run clear @s minecraft:nether_star[minecraft:item_name={text:"늑대의 별",color:"gold",bold:true}]
execute store result storage rpg:war mg.n int 1 run scoreboard players get #mc rpg.sys
execute if score #mc rpg.sys matches 1.. run function rpg:mob/core_give_wolf with storage rpg:war mg
scoreboard players set #mc rpg.sys 0
execute store result score #mc rpg.sys run clear @s minecraft:nether_star[!minecraft:custom_data~{rpg_star:2}]
execute store result storage rpg:war mg.n int 1 run scoreboard players get #mc rpg.sys
execute if score #mc rpg.sys matches 1.. run function rpg:war/star_give with storage rpg:war mg

# 설치 금지 칸의 블록 제거 (블록은 아이템으로 떨어집니다)
setblock ~ ~ ~ minecraft:air destroy
execute as @p[distance=..8,gamemode=!spectator] unless score @s rpg.npcd matches 1.. run function rpg:war/np_msg

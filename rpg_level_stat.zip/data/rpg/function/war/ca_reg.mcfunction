# 방금 지은 성을 기록한다 (내부용 · as 플레이어 · #cs 슬롯 · #ck 번호)
scoreboard players add #caid rpg.sys 1
scoreboard players operation @e[tag=rpg_canew] rpg.csid = #cs rpg.sys
scoreboard players operation @e[tag=rpg_canew] rpg.csn = @s rpg.natn
scoreboard players operation @e[tag=rpg_canew] rpg.csk = #ck rpg.sys
scoreboard players operation @e[tag=rpg_canew] rpg.cbid = #caid rpg.sys
execute store result storage rpg:war rg.s int 1 run scoreboard players get #cs rpg.sys
execute store result storage rpg:war rg.n int 1 run scoreboard players get @s rpg.natn
execute store result storage rpg:war rg.k int 1 run scoreboard players get #ck rpg.sys
function rpg:war/ca_reg2 with storage rpg:war rg
execute as @e[tag=rpg_canew,tag=rpg_cab] run function rpg:war/bcn_txt
tag @e[tag=rpg_canew] remove rpg_canew

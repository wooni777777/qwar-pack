scoreboard players set #war_time rpg.sys 144000
scoreboard players set #war_max rpg.sys 144000
data modify storage rpg:war w.n set value "2시간"
function rpg:war/go

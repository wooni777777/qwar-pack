# ── 금곡괭이 1개 지급 (v41) ──
#   그냥 금곡괭이 (효율 · 부서지지 않음 없음). 전쟁 중 모험 모드에서도 "전쟁 관련 블럭(퍼퍼)" 은 캘 수 있게 can_break 만 붙입니다.
give @s minecraft:golden_pickaxe[minecraft:custom_data={rpg_gpick:1},minecraft:can_break=[{blocks:["minecraft:purpur_block","minecraft:purpur_pillar","minecraft:purpur_stairs","minecraft:purpur_slab"]}]] 1
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"금곡괭이","color":"yellow","bold":true},{"text":" 를 받았습니다.","color":"white"}]
return 1

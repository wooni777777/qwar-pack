# ── 금곡괭이 1개 지급 ──
#   국가 신호기(beacon)만 캘 수 있습니다. 다른 블록은 못 캡니다.
give @s minecraft:golden_pickaxe[minecraft:custom_data={rpg_gpick:1},minecraft:item_name={"text":"금곡괭이","color":"yellow","bold":true},minecraft:lore=[{"text":"국가 신호기만 캘 수 있습니다","color":"gray","italic":false},{"text":"신호기를 부수면 그 국가는 멸망합니다","color":"dark_red","italic":false}],minecraft:can_break=[{blocks:"minecraft:beacon"}],minecraft:unbreakable={},minecraft:enchantments={"minecraft:efficiency":5},minecraft:enchantment_glint_override=true,minecraft:max_stack_size=1] 1
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"금곡괭이","color":"yellow","bold":true},{"text":" 를 받았습니다.","color":"white"}]
return 1

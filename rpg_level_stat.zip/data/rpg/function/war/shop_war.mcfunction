scoreboard players enable @s rpg.wsh
playsound minecraft:item.book.page_turn player @s ~ ~ ~ 1 1.2
tellraw @s " "
tellraw @s ["",{"text":"━━━━━  ","color":"dark_gray"},{"text":"전쟁 상점","color":"red","bold":true},{"text":"  ━━━━━","color":"dark_gray"}]
tellraw @s {"text":"   전쟁 물자를 돈으로 팝니다.","color":"gray"}
tellraw @s " "
tellraw @s ["",{"text":"   "},{"text":"퍼퍼 블럭 64개","color":"light_purple","bold":true,"hover_event":{"action":"show_text","value":{"text":"모험 모드에서도 어디에나 놓을 수 있는 블럭 · 적 성벽을 넘을 때","color":"gray"}}},{"text":"    5,000원   ","color":"gold"},{"text":"[구매]","color":"green","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wsh set 11"}}]
tellraw @s ["",{"text":"   "},{"text":"금곡괭이","color":"yellow","bold":true,"hover_event":{"action":"show_text","value":{"text":"전쟁 관련 블럭만 캘 수 있습니다","color":"gray"}}},{"text":"    5,000원   ","color":"gold"},{"text":"[구매]","color":"green","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wsh set 12"}}]
tellraw @s ["",{"text":"   "},{"text":"폭탄","color":"gold","bold":true,"hover_event":{"action":"show_text","value":{"text":"철문 앞에서 우클릭 - 철문 1개 · 선전포고한 국가 성에서만 · 30초 재사용 대기","color":"gray"}}},{"text":"    30,000원   ","color":"gold"},{"text":"[구매]","color":"green","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wsh set 13"}}]
tellraw @s " "
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}

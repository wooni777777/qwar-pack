scoreboard players enable @s rpg.wsh
playsound minecraft:item.book.page_turn player @s ~ ~ ~ 1 1.2
tellraw @s " "
tellraw @s ["",{"text":"━━━━━  ","color":"dark_gray"},{"text":"전쟁 상점","color":"red","bold":true},{"text":"  ━━━━━","color":"dark_gray"}]
tellraw @s {"text":"   전쟁 물자를 돈으로 팝니다.","color":"gray"}
tellraw @s " "
tellraw @s ["",{"text":"   "},{"text":"폭탄","color":"gold","bold":true,"hover_event":{"action":"show_text","value":{"text":"성문 철문 1개를 부숩니다","color":"gray"}}},{"text":"    50,000원   ","color":"gold"},{"text":"[구매]","color":"green","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wsh set 11"}}]
tellraw @s ["",{"text":"   "},{"text":"선전포고","color":"dark_red","bold":true,"hover_event":{"action":"show_text","value":{"text":"그 국가의 성을 부술 수 있게 됩니다","color":"gray"}}},{"text":"    20,000원   ","color":"gold"},{"text":"[구매]","color":"green","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wsh set 12"}}]
tellraw @s ["",{"text":"   "},{"text":"최상급 회복 포션 16개","color":"red","bold":true,"hover_event":{"action":"show_text","value":{"text":"체력 500 회복 x16","color":"gray"}}},{"text":"    10,000원   ","color":"gold"},{"text":"[구매]","color":"green","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wsh set 13"}}]
tellraw @s ["",{"text":"   "},{"text":"금곡괭이","color":"yellow","bold":true,"hover_event":{"action":"show_text","value":{"text":"국가 신호기만 캘 수 있습니다","color":"gray"}}},{"text":"    150,000원   ","color":"gold"},{"text":"[구매]","color":"green","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wsh set 14"}}]
tellraw @s " "
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}

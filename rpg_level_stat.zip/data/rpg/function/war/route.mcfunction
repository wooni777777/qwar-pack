# [전쟁] 메뉴 클릭 처리 (op 전용)
execute unless entity @s[tag=op] run function rpg:menu/noperm
execute unless entity @s[tag=op] run scoreboard players set @s rpg.war 0
execute unless entity @s[tag=op] run return 0
execute if score @s rpg.war matches 1 run function rpg:war/ask
execute if score @s rpg.war matches 2 run function rpg:war/force
execute if score @s rpg.war matches 3 run function rpg:war/pause
execute if score @s rpg.war matches 4 run function rpg:war/add_menu
execute if score @s rpg.war matches 5 run function rpg:war/dec_list
execute if score @s rpg.war matches 6 run function rpg:war/prot_go
execute if score @s rpg.war matches 7 run function rpg:war/dec_give
execute if score @s rpg.war matches 9 run function rpg:war/open
execute if score @s rpg.war matches 11 run function rpg:war/s1
execute if score @s rpg.war matches 12 run function rpg:war/s2
execute if score @s rpg.war matches 13 run function rpg:war/s3
execute if score @s rpg.war matches 21 run function rpg:war/add1
execute if score @s rpg.war matches 22 run function rpg:war/add2
execute if score @s rpg.war matches 23 run function rpg:war/add3
execute if score @s rpg.war matches 24 run function rpg:war/add4
execute if score @s rpg.war matches 2..3 run function rpg:war/open
execute if score @s rpg.war matches 6..7 run function rpg:war/open
execute if score @s rpg.war matches 11..13 run function rpg:war/open
scoreboard players set @s rpg.war 0
scoreboard players enable @s rpg.war

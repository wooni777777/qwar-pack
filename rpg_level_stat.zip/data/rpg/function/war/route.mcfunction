# [전쟁] 메뉴 클릭 처리 (op 전용)
execute unless entity @s[tag=op] run function rpg:menu/noperm
execute unless entity @s[tag=op] run scoreboard players set @s rpg.wmn 0
execute unless entity @s[tag=op] run return 0
execute if score @s rpg.wmn matches 1 run function rpg:war/ask
execute if score @s rpg.wmn matches 2 run function rpg:war/force
execute if score @s rpg.wmn matches 3 run function rpg:war/pause
execute if score @s rpg.wmn matches 4 run function rpg:war/add_menu
execute if score @s rpg.wmn matches 5 run function rpg:war/dec_list
execute if score @s rpg.wmn matches 6 run function rpg:war/prot_go
execute if score @s rpg.wmn matches 7 run function rpg:war/dec_give
execute if score @s rpg.wmn matches 8 run function rpg:war/cs_list
execute if score @s rpg.wmn matches 31 run function rpg:war/cs_give
execute if score @s rpg.wmn matches 32 run function rpg:war/bomb_give
execute if score @s rpg.wmn matches 33 run function rpg:war/pick_give
execute if score @s rpg.wmn matches 41 run function rpg:war/cs_rm1
execute if score @s rpg.wmn matches 42 run function rpg:war/cs_rm2
execute if score @s rpg.wmn matches 43 run function rpg:war/cs_rm3
execute if score @s rpg.wmn matches 44 run function rpg:war/cs_rm4
execute if score @s rpg.wmn matches 45 run function rpg:war/cs_rm5
execute if score @s rpg.wmn matches 46 run function rpg:war/cs_rm6
execute if score @s rpg.wmn matches 47 run function rpg:war/cs_rm7
execute if score @s rpg.wmn matches 48 run function rpg:war/cs_rm8
execute if score @s rpg.wmn matches 31..33 run function rpg:war/open
execute if score @s rpg.wmn matches 9 run function rpg:war/open
execute if score @s rpg.wmn matches 11 run function rpg:war/s1
execute if score @s rpg.wmn matches 12 run function rpg:war/s2
execute if score @s rpg.wmn matches 13 run function rpg:war/s3
execute if score @s rpg.wmn matches 21 run function rpg:war/add1
execute if score @s rpg.wmn matches 22 run function rpg:war/add2
execute if score @s rpg.wmn matches 23 run function rpg:war/add3
execute if score @s rpg.wmn matches 24 run function rpg:war/add4
execute if score @s rpg.wmn matches 2..3 run function rpg:war/open
execute if score @s rpg.wmn matches 6..7 run function rpg:war/open
execute if score @s rpg.wmn matches 11..13 run function rpg:war/open
scoreboard players set @s rpg.wmn 0
scoreboard players enable @s rpg.wmn

# 선전포고 구매 (네더별 5개 · v39)
scoreboard players set #ns rpg.sys 0
execute store result score #ns rpg.sys run clear @s minecraft:nether_star 0
execute if score #ns rpg.sys matches ..4 run return run tellraw @s [{"text":"[상점] ","color":"aqua","bold":true},{"text":"네더별이 부족합니다. (5개 필요 · 지금 ","color":"red"},{"score":{"name":"#ns","objective":"rpg.sys"},"color":"yellow"},{"text":"개)","color":"red"}]
clear @s minecraft:nether_star 5
function rpg:war/dec_give
execute at @s run playsound minecraft:entity.villager.yes player @s ~ ~ ~ 1 1.2
return 1

# 방금 지은 성을 "지은 성 목록"에 적기 (v43 · 내부용 · as 플레이어 at 플레이어 · 초기화 때 철거용)
data modify storage rpg:war nb set value {d:""}
execute store result storage rpg:war nb.x int 1 run data get entity @e[tag=rpg_canew,tag=rpg_cab,limit=1] Pos[0]
execute store result storage rpg:war nb.y int 1 run data get entity @e[tag=rpg_canew,tag=rpg_cab,limit=1] Pos[1]
execute store result storage rpg:war nb.z int 1 run data get entity @e[tag=rpg_canew,tag=rpg_cab,limit=1] Pos[2]
execute if dimension minecraft:overworld run data modify storage rpg:war nb.d set value "minecraft:overworld"
execute if dimension minecraft:the_nether run data modify storage rpg:war nb.d set value "minecraft:the_nether"
execute if dimension minecraft:the_end run data modify storage rpg:war nb.d set value "minecraft:the_end"
data modify storage rpg:war built append from storage rpg:war nb

# 전쟁 시작 (시간은 war/s1~s3 에서 정해 놓고 들어옵니다)
execute if score #war_run rpg.sys matches 1 run return 0
scoreboard players set #war_run rpg.sys 1
scoreboard players set #war_pause rpg.sys 0
function rpg:war/dec_reset
# 회차는 멈추고 보스바도 숨긴다 (전쟁이 끝나면 되돌립니다)
scoreboard players operation #rnd_sav rpg.sys = #rnd_pause rpg.sys
execute if score #rnd_run rpg.sys matches 1 run scoreboard players set #rnd_pause rpg.sys 1
execute if score #rnd_run rpg.sys matches 1 run bossbar set rpg:round visible false
# 전쟁 보스바
execute if score #war_bb rpg.sys matches 0 run bossbar add rpg:war {"text":"-{전쟁}-","color":"red","bold":true}
scoreboard players set #war_bb rpg.sys 1
bossbar set rpg:war color red
bossbar set rpg:war style notched_10
execute store result bossbar rpg:war max run scoreboard players get #war_max rpg.sys
execute store result bossbar rpg:war value run scoreboard players get #war_time rpg.sys
bossbar set rpg:war players @a
bossbar set rpg:war visible true
function rpg:war/sec
tellraw @a " "
tellraw @a [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"전쟁이 시작되었습니다","color":"red","bold":true}]
tellraw @a " "

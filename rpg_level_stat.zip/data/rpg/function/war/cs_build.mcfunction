# ── 50x50 돌벽돌 성 (중심에서 -25 ~ +24) ──
# 터 고르기
fill ~-25 ~-1 ~-25 ~24 ~-1 ~24 minecraft:stone_bricks
fill ~-25 ~0 ~-25 ~24 ~12 ~24 minecraft:air
# 바깥 벽 (높이 6)
fill ~-25 ~0 ~-25 ~24 ~5 ~-25 minecraft:stone_bricks
fill ~-25 ~0 ~24 ~24 ~5 ~24 minecraft:stone_bricks
fill ~-25 ~0 ~-24 ~-25 ~5 ~23 minecraft:stone_bricks
fill ~24 ~0 ~-24 ~24 ~5 ~23 minecraft:stone_bricks
# 나라색 띠
$fill ~-25 ~6 ~-25 ~24 ~6 ~-25 $(c)
$fill ~-25 ~6 ~24 ~24 ~6 ~24 $(c)
$fill ~-25 ~6 ~-24 ~-25 ~6 ~23 $(c)
$fill ~24 ~6 ~-24 ~24 ~6 ~23 $(c)
# 총안 (성벽 위 난간)
fill ~-25 ~7 ~-25 ~24 ~7 ~-25 minecraft:stone_brick_wall
fill ~-25 ~7 ~24 ~24 ~7 ~24 minecraft:stone_brick_wall
fill ~-25 ~7 ~-24 ~-25 ~7 ~23 minecraft:stone_brick_wall
fill ~24 ~7 ~-24 ~24 ~7 ~23 minecraft:stone_brick_wall
# 네 귀퉁이 탑 (7x7 · 높이 12)
fill ~-25 ~0 ~-25 ~-19 ~11 ~-19 minecraft:stone_bricks
fill ~-24 ~1 ~-24 ~-20 ~11 ~-20 minecraft:air
$fill ~-25 ~12 ~-25 ~-19 ~12 ~-19 $(c)
fill ~-25 ~13 ~-25 ~-19 ~13 ~-19 minecraft:stone_brick_wall
fill ~-24 ~13 ~-24 ~-20 ~13 ~-20 minecraft:air
fill ~18 ~0 ~-25 ~24 ~11 ~-19 minecraft:stone_bricks
fill ~19 ~1 ~-24 ~23 ~11 ~-20 minecraft:air
$fill ~18 ~12 ~-25 ~24 ~12 ~-19 $(c)
fill ~18 ~13 ~-25 ~24 ~13 ~-19 minecraft:stone_brick_wall
fill ~19 ~13 ~-24 ~23 ~13 ~-20 minecraft:air
fill ~-25 ~0 ~18 ~-19 ~11 ~24 minecraft:stone_bricks
fill ~-24 ~1 ~19 ~-20 ~11 ~23 minecraft:air
$fill ~-25 ~12 ~18 ~-19 ~12 ~24 $(c)
fill ~-25 ~13 ~18 ~-19 ~13 ~24 minecraft:stone_brick_wall
fill ~-24 ~13 ~19 ~-20 ~13 ~23 minecraft:air
fill ~18 ~0 ~18 ~24 ~11 ~24 minecraft:stone_bricks
fill ~19 ~1 ~19 ~23 ~11 ~23 minecraft:air
$fill ~18 ~12 ~18 ~24 ~12 ~24 $(c)
fill ~18 ~13 ~18 ~24 ~13 ~24 minecraft:stone_brick_wall
fill ~19 ~13 ~19 ~23 ~13 ~23 minecraft:air
# 정문 (남쪽 가운데) — 기반암으로 표시해 둡니다
fill ~-3 ~0 ~24 ~-3 ~3 ~24 minecraft:bedrock
fill ~2 ~0 ~24 ~2 ~3 ~24 minecraft:bedrock
fill ~-2 ~3 ~24 ~1 ~3 ~24 minecraft:bedrock
fill ~-2 ~0 ~24 ~1 ~2 ~24 minecraft:air
setblock ~-1 ~ ~24 minecraft:iron_door[facing=north,half=lower,hinge=left]
setblock ~-1 ~1 ~24 minecraft:iron_door[facing=north,half=upper,hinge=left]
setblock ~0 ~ ~24 minecraft:iron_door[facing=north,half=lower,hinge=right]
setblock ~0 ~1 ~24 minecraft:iron_door[facing=north,half=upper,hinge=right]
# 문을 여닫는 숨은 장치 (문 바로 아래)
fill ~-1 ~-1 ~24 ~0 ~-1 ~24 minecraft:stone_bricks
# 가운데 신호기 (이걸 부수면 국가가 멸망합니다)
fill ~-3 ~-1 ~-3 ~3 ~-1 ~3 minecraft:chiseled_stone_bricks
fill ~-1 ~-1 ~-1 ~1 ~-1 ~1 minecraft:iron_block
setblock ~ ~ ~ minecraft:beacon
# 신호기 둘레 기둥
$fill ~-3 ~0 ~-3 ~-3 ~4 ~-3 $(c)
setblock ~-3 ~5 ~-3 minecraft:sea_lantern
$fill ~3 ~0 ~-3 ~3 ~4 ~-3 $(c)
setblock ~3 ~5 ~-3 minecraft:sea_lantern
$fill ~-3 ~0 ~3 ~-3 ~4 ~3 $(c)
setblock ~-3 ~5 ~3 minecraft:sea_lantern
$fill ~3 ~0 ~3 ~3 ~4 ~3 $(c)
setblock ~3 ~5 ~3 minecraft:sea_lantern
# 안쪽 통로 바닥
fill ~-24 ~-1 ~-24 ~23 ~-1 ~23 minecraft:stone_bricks replace minecraft:air

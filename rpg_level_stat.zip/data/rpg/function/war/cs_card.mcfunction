# 성 설치 카드 (내부용)
scoreboard players enable @s rpg.wcs
playsound minecraft:item.book.page_turn player @s ~ ~ ~ 1 1.2
tellraw @s " "
tellraw @s {"text":"━━━━━━━  국 가 신 호 기  ━━━━━━━","color":"dark_gray"}
execute unless score @s rpg.natn matches 1..8 run tellraw @s ["",{"text":"   먼저 국가에 들어가야 합니다. ","color":"red"},{"text":"(메뉴 > 국가)","color":"dark_gray"}]
execute if score @s rpg.natn matches 1..8 run tellraw @s ["",{"text":"   지금 서 있는 자리를 ","color":"gray"},{"text":"성의 한가운데","color":"aqua","bold":true},{"text":" 로 삼습니다.","color":"gray"}]
execute if score @s rpg.natn matches 1..8 run tellraw @s ["",{"text":"   바깥 벽까지 사방 25칸 ","color":"dark_gray"},{"text":"(총 50x50)","color":"dark_gray"}]
tellraw @s " "
execute if score @s rpg.natn matches 1..8 run tellraw @s ["",{"text":"   "},{"text":"[ 미리보기 켜기/끄기 ]","color":"gold","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wcs set 1"},"hover_event":{"action":"show_text","value":{"text":"빨간 선으로 성 자리를 보여줍니다","color":"gray"}}},{"text":"   "},{"text":"[ 설치 ]","color":"green","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wcs set 2"},"hover_event":{"action":"show_text","value":{"text":"여기에 성을 짓습니다 (신호기 1개 소모)","color":"gray"}}}]
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}

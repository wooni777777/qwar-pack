# 국가 신호기 우클릭 카드 (v40)
scoreboard players enable @s rpg.wcs
playsound minecraft:item.book.page_turn player @s ~ ~ ~ 1 1.2
tellraw @s " "
tellraw @s {"text":"━━━━━━━  국 가 신 호 기  ━━━━━━━","color":"dark_gray"}
execute unless score @s rpg.natn matches 1..8 run tellraw @s ["",{"text":"   먼저 국가에 들어가야 합니다. ","color":"red"},{"text":"(메뉴 > 국가)","color":"dark_gray"}]
execute if score @s rpg.natn matches 1..8 run tellraw @s ["",{"text":"   지금 서 있는 곳이 ","color":"gray"},{"text":"정문","color":"aqua","bold":true},{"text":" 이고, ","color":"gray"},{"text":"등 뒤로","color":"aqua","bold":true},{"text":" 성이 지어집니다.","color":"gray"}]
execute if score @s rpg.natn matches 1..8 run tellraw @s {"text":"   (49 x 49 · 양 옆 농사터 · 가운데 계단 탑 꼭대기에 신호기)","color":"dark_gray"}
execute if score #war_run rpg.sys matches 1 run tellraw @s {"text":"   지금은 전쟁 중이라 설치할 수 없습니다.","color":"red"}
tellraw @s " "
execute if score @s rpg.natn matches 1..8 run tellraw @s ["",{"text":"   "},{"text":"[ 미리보기 켜기/끄기 ]","color":"gold","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wcs set 1"},"hover_event":{"action":"show_text","value":{"text":"빨간 선 = 성 자리 · 초록 = 정문 · 하늘색 = 신호기","color":"gray"}}},{"text":"   "},{"text":"[ 설치 ]","color":"green","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wcs set 2"},"hover_event":{"action":"show_text","value":{"text":"지금 보는 방향 기준으로 등 뒤에 성을 짓습니다","color":"gray"}}}]
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}

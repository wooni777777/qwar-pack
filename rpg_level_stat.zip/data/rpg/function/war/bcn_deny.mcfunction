scoreboard players set @s rpg.npcd 30
$tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"$(m)","color":"red"}]

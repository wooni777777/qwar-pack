scoreboard players enable @s rpg.wsh
playsound minecraft:item.book.page_turn player @s ~ ~ ~ 1 1.2
tellraw @s " "
tellraw @s ["",{"text":"━━━━━  ","color":"dark_gray"},{"text":"네더별 상점 [ 보급 ]","color":"green","bold":true},{"text":"  ━━━━━","color":"dark_gray"}]
tellraw @s {"text":"   전쟁 보급품을 팝니다. 값은 네더별로 받습니다.","color":"gray"}
tellraw @s " "
tellraw @s ["",{"text":"   "},{"text":"선전포고","color":"dark_red","bold":true,"hover_event":{"action":"show_text","value":{"text":"그 국가의 성을 부술 수 있게 됩니다","color":"gray"}}},{"text":"    네더별 1개   ","color":"gold"},{"text":"[구매]","color":"green","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wsh set 4"}}]
tellraw @s ["",{"text":"   "},{"text":"최상급 회복 포션 16개","color":"red","bold":true,"hover_event":{"action":"show_text","value":{"text":"체력 500 회복 x16","color":"gray"}}},{"text":"    네더별 2개   ","color":"gold"},{"text":"[구매]","color":"green","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wsh set 5"}}]
tellraw @s " "
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}

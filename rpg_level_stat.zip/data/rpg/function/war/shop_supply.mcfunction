scoreboard players enable @s rpg.wsh
playsound minecraft:item.book.page_turn player @s ~ ~ ~ 1 1.2
tellraw @s " "
tellraw @s ["",{"text":"━━━━━  ","color":"dark_gray"},{"text":"네더별 보스 소환 상점","color":"green","bold":true},{"text":"  ━━━━━","color":"dark_gray"}]
tellraw @s {"text":"   보스를 불러내는 물건을 팝니다. (일반 보스만 · 잠꾸러기 늑대는 필드 보스라 없음)","color":"gray"}
tellraw @s " "
tellraw @s ["",{"text":"   "},{"text":"돌 보스 소환석","color":"dark_red","bold":true,"hover_event":{"action":"show_text","value":{"text":"꾹 우클릭하면 눈앞에 보스 [돌] 소환 · 드롭은 [드롭템 설정] 그대로","color":"gray"}}},{"text":"    네더별 10개   ","color":"gold"},{"text":"[구매]","color":"green","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wsh set 7"}}]
tellraw @s ["",{"text":"   "},{"text":"해적 왕 소환 나팔","color":"dark_red","bold":true,"hover_event":{"action":"show_text","value":{"text":"꾹 우클릭하면 눈앞에 보스 [해적 왕] 소환 · 드롭은 [드롭템 설정] 그대로","color":"gray"}}},{"text":"    네더별 10개   ","color":"gold"},{"text":"[구매]","color":"green","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wsh set 8"}}]
tellraw @s {"text":"   앞으로 나오는 보스도 여기에 네더별 10개로 추가됩니다.","color":"dark_gray"}
tellraw @s " "
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}

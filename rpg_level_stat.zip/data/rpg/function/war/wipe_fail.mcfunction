# (v43 · 내부용 · 매크로) 10초 안에 청크가 안 불러와짐 -> 건너뛰고 다음 초기화 때 다시
$tellraw @a[tag=op] ["", {"text": "[q후계자 전쟁] ", "color": "gray"}, {"text": "성 하나 ($(x) $(y) $(z)) 를 불러오지 못해 철거를 건너뜁니다. 다음 초기화 때 다시 시도합니다.", "color": "red"}]
data modify storage rpg:war built append from storage rpg:war wq[0]
function rpg:war/wipe_pop

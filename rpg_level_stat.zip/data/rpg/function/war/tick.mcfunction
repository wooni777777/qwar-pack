execute if score #war_run rpg.sys matches 1 run bossbar set rpg:war players @a
execute if score #war_run rpg.sys matches 1 if score #war_pause rpg.sys matches 0 run scoreboard players remove #war_time rpg.sys 1
execute if score #war_run rpg.sys matches 1 store result bossbar rpg:war value run scoreboard players get #war_time rpg.sys
execute if score #war_run rpg.sys matches 1 if score #war_time rpg.sys matches ..0 run function rpg:war/end

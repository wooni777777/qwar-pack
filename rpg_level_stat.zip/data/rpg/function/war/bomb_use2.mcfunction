# 폭탄 우클릭 (v40 · as 플레이어 at 플레이어)
execute unless score #war_run rpg.sys matches 1 run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"폭탄은 전쟁 중에만 터집니다.","color":"red"}]
execute unless score @s rpg.natn matches 1..8 run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"먼저 국가에 들어가야 합니다.","color":"red"}]
execute if score @s rpg.bcd matches 1.. run return run tellraw @s ["",{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"폭탄 재사용 대기 ","color":"red"},{"score":{"name":"@s","objective":"rpg.bcd"},"color":"yellow","bold":true},{"text":"초","color":"red"}]
# 가장 가까운 남의 성 (가운데 표식 36칸 안)
scoreboard players operation #bmy rpg.sys = @s rpg.natn
tag @e[tag=rpg_bct] remove rpg_bct
execute as @e[type=minecraft:marker,tag=rpg_cac,distance=..36,sort=nearest] unless score @s rpg.csn = #bmy rpg.sys run tag @s add rpg_bct
execute unless entity @e[tag=rpg_bct] run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"다른 국가의 성 안이나 성문 앞에서만 쓸 수 있습니다.","color":"red"}]
scoreboard players operation #bn rpg.sys = @e[tag=rpg_bct,sort=nearest,limit=1] rpg.csn
scoreboard players operation #bk rpg.sys = @e[tag=rpg_bct,sort=nearest,limit=1] rpg.csk
tag @e[tag=rpg_bct] remove rpg_bct
execute store result storage rpg:war bh.a int 1 run scoreboard players get #bmy rpg.sys
execute store result storage rpg:war bh.b int 1 run scoreboard players get #bn rpg.sys
scoreboard players set #bdecl rpg.sys 0
function rpg:war/bcn_decl with storage rpg:war bh
execute if score #bdecl rpg.sys matches 0 run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"선전포고한 국가의 성에서만 터집니다.","color":"red"}]
scoreboard players set #bdf rpg.sys 0
function rpg:war/bd_scan
execute if score #bdf rpg.sys matches 0 run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"3칸 안에 부술 철문이 없습니다.","color":"red"}]
# 성공 : 폭탄 1개 소모 · 30초 대기 · 그 성 주인 국가에 알림 (소리 없음)
clear @s *[minecraft:custom_data~{rpg_bomb:1}] 1
scoreboard players set @s rpg.bcd 30
scoreboard players operation #nx rpg.sys = #bn rpg.sys
function rpg:war/natnm
data modify storage rpg:war an set from storage rpg:war nm
execute store result storage rpg:war an.k int 1 run scoreboard players get #bk rpg.sys
execute store result storage rpg:war an.n int 1 run scoreboard players get #bn rpg.sys
function rpg:war/door_say with storage rpg:war an
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"철문을 부쉈습니다! (폭탄 30초 대기)","color":"gold","bold":true}]
return 1

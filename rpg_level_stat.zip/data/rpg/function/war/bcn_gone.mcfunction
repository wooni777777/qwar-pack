# 성 신호기가 부서졌다 (v42 · as 신호기 표식 at 표식 · 부순 사람 = rpg_batk)
execute as @e[type=minecraft:item,distance=..5] if items entity @s contents minecraft:beacon run kill @s
scoreboard players operation #bn rpg.sys = @s rpg.csn
execute unless score #ban rpg.sys matches 1..8 run return run function rpg:war/bcn_back {m:"국가에 들어가야 신호기를 부술 수 있습니다."}
execute if score #ban rpg.sys = #bn rpg.sys run return run function rpg:war/bcn_back {m:"우리 국가의 신호기입니다."}
execute unless score #war_run rpg.sys matches 1 run return run function rpg:war/bcn_back {m:"신호기는 전쟁 중에만 부술 수 있습니다."}
execute store result storage rpg:war bh.a int 1 run scoreboard players get #ban rpg.sys
execute store result storage rpg:war bh.b int 1 run scoreboard players get #bn rpg.sys
scoreboard players set #bdecl rpg.sys 0
function rpg:war/bcn_decl with storage rpg:war bh
execute if score #bdecl rpg.sys matches 0 run return run function rpg:war/bcn_back {m:"선전포고한 국가의 신호기만 부술 수 있습니다."}
function rpg:war/bcn_break

kill @e[type=minecraft:marker,tag=rpg_warpoint]
tag @a remove war1
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"전쟁터 텔포 지점을 삭제했습니다.","color":"red"}]

# 서 있는 자리를 [전쟁터] 텔포 지점으로 지정합니다
kill @e[type=minecraft:marker,tag=rpg_warpoint]
summon minecraft:marker ~ ~ ~ {Tags:["rpg_warpoint"]}
tag @a add war1
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"전쟁터 텔포 지점을 이 자리로 지정했습니다. (모든 플레이어 해금)","color":"green"}]
execute at @s run playsound minecraft:block.beacon.activate player @s ~ ~ ~ 1 1.2

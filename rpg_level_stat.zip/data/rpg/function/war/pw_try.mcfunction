# 비밀번호 확인 (v42 · as 정문 표식 at 표식 · 매크로 k) — 틀리면 3초 동안 다시 못 넣음
execute if score #pl rpg.sys matches 0..59 run return run tellraw @a[tag=rpg_pwp] [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"잠시 뒤에 다시 입력하세요. (틀리면 3초 대기)","color":"red"}]
execute unless score #pv rpg.sys = @s rpg.pwv run return run function rpg:war/pw_bad
function rpg:war/door_open
# v47 : "철문이 열렸습니다" 대신 띠링 소리 + [N성] 철문 [비밀번호 바꾸기]
execute at @a[tag=rpg_pwp] run playsound minecraft:block.note_block.chime player @a[tag=rpg_pwp] ~ ~ ~ 1 1.6
execute at @a[tag=rpg_pwp] run playsound minecraft:entity.experience_orb.pickup player @a[tag=rpg_pwp] ~ ~ ~ 0.6 1.4
scoreboard players set @a[tag=rpg_pwp] rpg.pwm 0
execute if score #pn rpg.sys = #dn rpg.sys run scoreboard players set @a[tag=rpg_pwp] rpg.pwm 3
$execute if score #pn rpg.sys = #dn rpg.sys run tellraw @a[tag=rpg_pwp] ["",{"text":"[$(k)성] ","color":"aqua","bold":true},{"text":"철문 ","color":"white"},{"text":"[비밀번호 바꾸기]","color":"yellow","click_event":{"action":"run_command","command":"trigger rpg.pw set -3"},"hover_event":{"action":"show_text","value":{"text":"우리 국가 성만 · 60초 안에","color":"gray"}}}]
$execute unless score #pn rpg.sys = #dn rpg.sys run tellraw @a[tag=rpg_pwp] ["",{"text":"[$(k)성] ","color":"aqua","bold":true},{"text":"철문","color":"white"}]

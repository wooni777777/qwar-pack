scoreboard players enable @s rpg.war
execute if score #war_run rpg.sys matches 1 run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"이미 전쟁이 진행 중입니다.","color":"red"}]
tellraw @s " "
tellraw @s {"text": "━━━━━━━  전쟁 시간 고르기  ━━━━━━━", "color": "dark_gray"}
tellraw @s ["", {"text": "   "}, {"text": "[ 30분 ]", "color": "red", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.war set 11"}}, {"text": "   "}, {"text": "[ 1시간 ]", "color": "red", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.war set 12"}}, {"text": "   "}, {"text": "[ 2시간 ]", "color": "red", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.war set 13"}}, {"text": "   "}]
tellraw @s {"text": "━━━━━━━━━━━━━━━━━━━━━━━━━━", "color": "dark_gray"}

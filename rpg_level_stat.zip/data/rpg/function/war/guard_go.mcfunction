$execute as @a[x=$(x),y=$(y),z=$(z),dx=$(dx),dy=$(dy),dz=$(dz),gamemode=survival,tag=!rpg_wbcn] run function rpg:war/adv_on
$execute as @a[tag=rpg_wadv] unless entity @s[x=$(x),y=$(y),z=$(z),dx=$(dx),dy=$(dy),dz=$(dz)] run function rpg:war/adv_off

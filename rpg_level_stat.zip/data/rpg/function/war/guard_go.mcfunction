execute as @a[distance=..400,gamemode=survival,tag=!op] run function rpg:war/adv_on

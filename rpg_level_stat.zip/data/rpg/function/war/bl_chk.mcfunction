# 모험 모드(블록 보호)인데 성 신호기를 보고 있으면 잠깐 서바이벌 -> 맨손으로 부술 수 있게 (v42 · 매 틱 · as 플레이어 at 플레이어)
#   #blk 1 = 부술 수 있는 신호기 / 2~5 = 못 부수는 신호기 (이유)
scoreboard players set #blk rpg.sys 0
scoreboard players set #bls rpg.sys 22
scoreboard players set #ban rpg.sys 0
execute if score @s rpg.natn matches -2147483648.. run scoreboard players operation #ban rpg.sys = @s rpg.natn
execute anchored eyes positioned ^ ^ ^ run function rpg:war/bl_ray
execute if score #blk rpg.sys matches 1 unless entity @s[tag=rpg_wbcn] run function rpg:war/bl_on
execute unless score #blk rpg.sys matches 1 if entity @s[tag=rpg_wbcn] run function rpg:war/bl_off
execute if score #blk rpg.sys matches 2.. unless score @s rpg.npcd matches 1.. run function rpg:war/bl_why

gamemode adventure @s
tag @s add rpg_wadv
title @s actionbar [{"text":"전쟁터 - 블록을 건드릴 수 없습니다","color":"red"}]

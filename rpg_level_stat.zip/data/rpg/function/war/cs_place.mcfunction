# 성 설치 (v40 · as 플레이어 at 플레이어)
execute unless score @s rpg.natn matches 1..8 run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"먼저 국가에 들어가야 합니다.","color":"red"}]
execute if score #war_run rpg.sys matches 1 run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"전쟁 중에는 성을 설치할 수 없습니다.","color":"red"}]
execute unless items entity @s weapon.* *[minecraft:custom_data~{rpg_nbeacon:1}] run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"국가 신호기를 손에 들어야 합니다.","color":"red"}]
function rpg:war/ca_slot
execute if score #cs rpg.sys matches 0 run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"성이 너무 많습니다. (서버 전체 최대 32개)","color":"red"}]
execute store result storage rpg:war kn.n int 1 run scoreboard players get @s rpg.natn
function rpg:war/ca_knext with storage rpg:war kn
function rpg:war/cs_rot
execute align xyz positioned ~0.5 ~ ~0.5 run function rpg:war/ca_near with storage rpg:war rot
execute if score #near rpg.sys matches 1 run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"다른 성과 겹칩니다. 조금 떨어진 곳에서 설치하세요. (미리보기 빨간 선 참고)","color":"red"}]
clear @s *[minecraft:custom_data~{rpg_nbeacon:1}] 1
tag @s remove rpg_csprev
function rpg:war/cs_rot
data modify storage rpg:war cb set from storage rpg:war rot
execute if score @s rpg.natn matches 1 run data modify storage rpg:war cb.c set value "red"
execute if score @s rpg.natn matches 2 run data modify storage rpg:war cb.c set value "orange"
execute if score @s rpg.natn matches 3 run data modify storage rpg:war cb.c set value "yellow"
execute if score @s rpg.natn matches 4 run data modify storage rpg:war cb.c set value "green"
execute if score @s rpg.natn matches 5 run data modify storage rpg:war cb.c set value "blue"
execute if score @s rpg.natn matches 6 run data modify storage rpg:war cb.c set value "purple"
execute if score @s rpg.natn matches 7 run data modify storage rpg:war cb.c set value "pink"
execute if score @s rpg.natn matches 8 run data modify storage rpg:war cb.c set value "white"
execute align xyz positioned ~0.5 ~ ~0.5 run function rpg:war/ca_build with storage rpg:war cb
function rpg:war/ca_reg
execute at @s run playsound minecraft:block.beacon.activate player @a ~ ~ ~ 1 0.8
execute at @s run function rpg:fx/firework {r:0.35,g:0.85,b:1.0,rad:4,spd:0.5,size:1.8,dense:18,h:2.0}
# 채팅 정리 (요청하신 줄바꿈 66개)
tellraw @s {"text":"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"}
tellraw @s ["",{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"성 설치 완료 — ","color":"green","bold":true},{"score":{"name":"#ck","objective":"rpg.sys"},"color":"aqua","bold":true},{"text":"성","color":"aqua","bold":true},{"text":"  (메뉴 > 텔포 > 전쟁터 에서 이동)","color":"gray"}]
scoreboard players operation #nx rpg.sys = @s rpg.natn
function rpg:war/natnm
data modify storage rpg:war an set from storage rpg:war nm
execute store result storage rpg:war an.k int 1 run scoreboard players get #ck rpg.sys
function rpg:war/cs_announce with storage rpg:war an
return 1

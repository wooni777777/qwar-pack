# 성 설치 (내부용)
execute unless score @s rpg.natn matches 1..8 run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"먼저 국가에 들어가야 합니다.","color":"red"}]
execute unless items entity @s weapon.* *[minecraft:custom_data~{rpg_nbeacon:1}] run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"국가 신호기를 손에 들어야 합니다.","color":"red"}]
scoreboard players set #csx rpg.sys 0
execute if score @s rpg.natn matches 1 if score #cs1on rpg.sys matches 1 run scoreboard players set #csx rpg.sys 1
execute if score @s rpg.natn matches 2 if score #cs2on rpg.sys matches 1 run scoreboard players set #csx rpg.sys 1
execute if score @s rpg.natn matches 3 if score #cs3on rpg.sys matches 1 run scoreboard players set #csx rpg.sys 1
execute if score @s rpg.natn matches 4 if score #cs4on rpg.sys matches 1 run scoreboard players set #csx rpg.sys 1
execute if score @s rpg.natn matches 5 if score #cs5on rpg.sys matches 1 run scoreboard players set #csx rpg.sys 1
execute if score @s rpg.natn matches 6 if score #cs6on rpg.sys matches 1 run scoreboard players set #csx rpg.sys 1
execute if score @s rpg.natn matches 7 if score #cs7on rpg.sys matches 1 run scoreboard players set #csx rpg.sys 1
execute if score @s rpg.natn matches 8 if score #cs8on rpg.sys matches 1 run scoreboard players set #csx rpg.sys 1
execute if score #csx rpg.sys matches 1 run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"우리 국가는 이미 성이 있습니다. (op 가 rpg:war/cs_remove 로 지울 수 있습니다)","color":"red"}]
clear @s *[minecraft:custom_data~{rpg_nbeacon:1}] 1
tag @s remove rpg_csprev
# 좌표 기억
execute store result score #cpx rpg.sys run data get entity @s Pos[0]
execute store result score #cpy rpg.sys run data get entity @s Pos[1]
execute store result score #cpz rpg.sys run data get entity @s Pos[2]
execute if score @s rpg.natn matches 1 run scoreboard players operation #cs1x rpg.sys = #cpx rpg.sys
execute if score @s rpg.natn matches 1 run scoreboard players operation #cs1y rpg.sys = #cpy rpg.sys
execute if score @s rpg.natn matches 1 run scoreboard players operation #cs1z rpg.sys = #cpz rpg.sys
execute if score @s rpg.natn matches 1 run scoreboard players set #cs1on rpg.sys 1
execute if score @s rpg.natn matches 2 run scoreboard players operation #cs2x rpg.sys = #cpx rpg.sys
execute if score @s rpg.natn matches 2 run scoreboard players operation #cs2y rpg.sys = #cpy rpg.sys
execute if score @s rpg.natn matches 2 run scoreboard players operation #cs2z rpg.sys = #cpz rpg.sys
execute if score @s rpg.natn matches 2 run scoreboard players set #cs2on rpg.sys 1
execute if score @s rpg.natn matches 3 run scoreboard players operation #cs3x rpg.sys = #cpx rpg.sys
execute if score @s rpg.natn matches 3 run scoreboard players operation #cs3y rpg.sys = #cpy rpg.sys
execute if score @s rpg.natn matches 3 run scoreboard players operation #cs3z rpg.sys = #cpz rpg.sys
execute if score @s rpg.natn matches 3 run scoreboard players set #cs3on rpg.sys 1
execute if score @s rpg.natn matches 4 run scoreboard players operation #cs4x rpg.sys = #cpx rpg.sys
execute if score @s rpg.natn matches 4 run scoreboard players operation #cs4y rpg.sys = #cpy rpg.sys
execute if score @s rpg.natn matches 4 run scoreboard players operation #cs4z rpg.sys = #cpz rpg.sys
execute if score @s rpg.natn matches 4 run scoreboard players set #cs4on rpg.sys 1
execute if score @s rpg.natn matches 5 run scoreboard players operation #cs5x rpg.sys = #cpx rpg.sys
execute if score @s rpg.natn matches 5 run scoreboard players operation #cs5y rpg.sys = #cpy rpg.sys
execute if score @s rpg.natn matches 5 run scoreboard players operation #cs5z rpg.sys = #cpz rpg.sys
execute if score @s rpg.natn matches 5 run scoreboard players set #cs5on rpg.sys 1
execute if score @s rpg.natn matches 6 run scoreboard players operation #cs6x rpg.sys = #cpx rpg.sys
execute if score @s rpg.natn matches 6 run scoreboard players operation #cs6y rpg.sys = #cpy rpg.sys
execute if score @s rpg.natn matches 6 run scoreboard players operation #cs6z rpg.sys = #cpz rpg.sys
execute if score @s rpg.natn matches 6 run scoreboard players set #cs6on rpg.sys 1
execute if score @s rpg.natn matches 7 run scoreboard players operation #cs7x rpg.sys = #cpx rpg.sys
execute if score @s rpg.natn matches 7 run scoreboard players operation #cs7y rpg.sys = #cpy rpg.sys
execute if score @s rpg.natn matches 7 run scoreboard players operation #cs7z rpg.sys = #cpz rpg.sys
execute if score @s rpg.natn matches 7 run scoreboard players set #cs7on rpg.sys 1
execute if score @s rpg.natn matches 8 run scoreboard players operation #cs8x rpg.sys = #cpx rpg.sys
execute if score @s rpg.natn matches 8 run scoreboard players operation #cs8y rpg.sys = #cpy rpg.sys
execute if score @s rpg.natn matches 8 run scoreboard players operation #cs8z rpg.sys = #cpz rpg.sys
execute if score @s rpg.natn matches 8 run scoreboard players set #cs8on rpg.sys 1
data modify storage rpg:war cb set value {c:"minecraft:white_concrete"}
execute if score @s rpg.natn matches 1 run data modify storage rpg:war cb.c set value "minecraft:red_concrete"
execute if score @s rpg.natn matches 2 run data modify storage rpg:war cb.c set value "minecraft:orange_concrete"
execute if score @s rpg.natn matches 3 run data modify storage rpg:war cb.c set value "minecraft:yellow_concrete"
execute if score @s rpg.natn matches 4 run data modify storage rpg:war cb.c set value "minecraft:green_concrete"
execute if score @s rpg.natn matches 5 run data modify storage rpg:war cb.c set value "minecraft:blue_concrete"
execute if score @s rpg.natn matches 6 run data modify storage rpg:war cb.c set value "minecraft:purple_concrete"
execute if score @s rpg.natn matches 7 run data modify storage rpg:war cb.c set value "minecraft:pink_concrete"
execute if score @s rpg.natn matches 8 run data modify storage rpg:war cb.c set value "minecraft:white_concrete"
execute at @s align xyz run function rpg:war/cs_build with storage rpg:war cb
execute at @s run playsound minecraft:block.beacon.activate player @a ~ ~ ~ 1 0.8
execute at @s run function rpg:fx/firework {r:0.35,g:0.85,b:1.0,rad:4,spd:0.5,size:1.8,dense:18,h:2.0}
tellraw @a " "
tellraw @a ["",{"text":"[q후계자 전쟁] ","color":"gray"},{"selector":"@s","color":"yellow"},{"text":" 님의 국가가 ","color":"white"},{"text":"성","color":"aqua","bold":true},{"text":" 을 세웠습니다!","color":"white"}]
tellraw @a " "
return 1

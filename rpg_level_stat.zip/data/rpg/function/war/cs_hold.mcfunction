data modify storage rpg:war hold set from entity @s SelectedItem

execute store result storage rpg:war gt.x int 1 run scoreboard players get #cs4x rpg.sys
execute store result storage rpg:war gt.y int 1 run scoreboard players get #cs4y rpg.sys
execute store result storage rpg:war gt.z int 1 run scoreboard players get #cs4z rpg.sys
data modify storage rpg:war gt.n set value 4
function rpg:war/gate_one with storage rpg:war gt

# 철문 칸에 가려진 당근 낚싯대 우클릭을 대신 넘겨 준다 (v42)
scoreboard players add @s rpg.coas 1
scoreboard players add @s rpg.uleap 1

tag @s remove rpg_csprev
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"미리보기를 껐습니다.","color":"gray"}]
return 1

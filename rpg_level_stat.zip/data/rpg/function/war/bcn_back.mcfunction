# 부술 수 없는 사람이 부쉈다 -> 신호기 되돌리기 (v42 · as 신호기 표식 · 매크로 m)
setblock ~ ~ ~ minecraft:beacon
playsound minecraft:block.beacon.activate block @a ~ ~ ~ 1 1.3
$execute as @a[tag=rpg_batk] run function rpg:war/bcn_deny {m:"$(m)"}

# 국가 신호기 카드 클릭 처리
execute if score @s rpg.wcs matches 1 run function rpg:war/cs_prev
execute if score @s rpg.wcs matches 2 at @s run function rpg:war/cs_place
scoreboard players set @s rpg.wcs 0
scoreboard players enable @s rpg.wcs

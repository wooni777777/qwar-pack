$bossbar set rpg:war name [{"text":"-{전쟁}-  ","color":"red","bold":true},{"text":"$(m):0$(s)","color":"white","bold":true}]

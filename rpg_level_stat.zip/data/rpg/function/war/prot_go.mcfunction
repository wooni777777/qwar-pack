scoreboard players operation #wpr rpg.sys = #war_prot rpg.sys
execute if score #wpr rpg.sys matches 1 run scoreboard players set #war_prot rpg.sys 0
execute if score #wpr rpg.sys matches 1 run function rpg:war/guard_off
execute if score #wpr rpg.sys matches 1 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"블록 보호를 껐습니다. (전쟁터에서 블록을 부술 수 있습니다)","color":"red"}]
execute if score #wpr rpg.sys matches 0 run scoreboard players set #war_prot rpg.sys 1
execute if score #wpr rpg.sys matches 0 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"블록 보호를 켰습니다.","color":"green"}]

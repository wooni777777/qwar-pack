# 절대계약서 1권 지급 (v39)
give @s minecraft:writable_book[minecraft:custom_data={rpg_contract:1},minecraft:item_name={"text":"절대계약서","color":"dark_purple","bold":true},minecraft:lore=[{"text":"계약 내용을 쓰고 서명한 뒤","color":"gray","italic":false},{"text":"제작자에게 가져가면 강제로 이루어집니다","color":"gray","italic":false}],minecraft:enchantment_glint_override=true] 1
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"절대계약서","color":"dark_purple","bold":true},{"text":" 를 받았습니다. 쓰고 서명한 뒤 제작자에게 가져가세요.","color":"white"}]

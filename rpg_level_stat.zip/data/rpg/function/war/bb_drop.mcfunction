# 국가 신호기가 부서진 자리 (v39 · 내부용 · positioned 신호기 자리)
#   바닐라 신호기 아이템은 없애고, 가장 가까운 플레이어(= 부순 사람)에게 "부서진 신호기" 를 준다
kill @e[type=minecraft:item,distance=..6,nbt={Item:{id:"minecraft:beacon"}}]
execute as @p[distance=..12,gamemode=!spectator] run function rpg:war/bb_take

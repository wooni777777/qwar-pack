# 국가 신호기가 부서진 자리 (v39 · v50 · 내부용 · positioned 신호기 자리)
#   바닐라 신호기 아이템은 없애고, 그 자리에 "부서진 신호기" 를 떨어뜨림
kill @e[type=minecraft:item,distance=..6,nbt={Item:{id:"minecraft:beacon"}}]
function rpg:war/bb_spawn

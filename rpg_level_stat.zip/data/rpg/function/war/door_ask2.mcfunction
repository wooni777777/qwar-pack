# (v42 · as 정문 표식 · 누른 사람 = rpg_pwp · #pn = 그 사람 국가)
scoreboard players operation #dn rpg.sys = @s rpg.csn
execute store result storage rpg:war dq.k int 1 run scoreboard players get @s rpg.csk
execute if score @s rpg.pwv matches 1.. run return run function rpg:war/door_q_open with storage rpg:war dq
execute unless score #pn rpg.sys = #dn rpg.sys run return run function rpg:war/door_q_none with storage rpg:war dq
function rpg:war/door_q_set with storage rpg:war dq

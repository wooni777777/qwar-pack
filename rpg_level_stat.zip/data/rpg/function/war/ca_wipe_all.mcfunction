# 초기화 : 지은 국가 성 전부 철거 (v43 · 건물 · 신호기 · 철문 · 비밀번호 · 표식 · 성 기록)
#   멀리 있어 안 불러와진 성은 잠깐 그 청크만 강제로 불러와서(forceload) 지우고, 원래대로 풀어 둡니다
execute unless data storage rpg:war built run data modify storage rpg:war built set value []
scoreboard players set #wn rpg.sys 0
execute store result score #wn rpg.sys run data get storage rpg:war built
execute unless data storage rpg:war wq[0] run scoreboard players set #wcnt rpg.sys 0
data modify storage rpg:war wq append from storage rpg:war built[]
data modify storage rpg:war built set value []
function rpg:war/ca_reg_clear
kill @e[tag=rpg_ca]
tag @a remove rpg_csprev
scoreboard players set @a rpg.pwd 0
scoreboard players set @a rpg.pwm 0
scoreboard players set #wcnt rpg.sys 0
execute if score #wn rpg.sys matches 1.. run tellraw @a ["", {"text": "[q후계자 전쟁] ", "color": "gray"}, {"text": "국가 성 ", "color": "red"}, {"score": {"name": "#wn", "objective": "rpg.sys"}, "color": "gold", "bold": true}, {"text": "개를 철거합니다... (몇 초 걸립니다)", "color": "red"}]
schedule function rpg:war/wipe_next 2t replace

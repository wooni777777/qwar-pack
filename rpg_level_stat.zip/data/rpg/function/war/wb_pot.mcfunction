# 최상급 회복 포션 16개 (10,000원)
execute unless score @s money matches 10000.. run return run tellraw @s [{"text":"[전쟁 상점] ","color":"red","bold":true},{"text":"돈이 부족합니다. (10,000원)","color":"red"}]
scoreboard players remove @s money 10000
function rpg:shop/buy6 {n:16}
execute at @s run playsound minecraft:entity.villager.yes player @s ~ ~ ~ 1 1.2
return 1

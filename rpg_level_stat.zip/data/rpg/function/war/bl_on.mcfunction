tag @s add rpg_wbcn
gamemode survival @s
title @s actionbar {"text":"적 신호기 — 맨손으로 부수세요!","color":"gold","bold":true}

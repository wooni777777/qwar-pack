# v43 : 이미 지어져 있는 성을 "지은 성 목록"에 한 번 넣기 (내부용 · load)
execute unless data storage rpg:war built run data modify storage rpg:war built set value []
scoreboard players set #k10 rpg.sys 10
execute if score #ca1on rpg.sys matches 1 run function rpg:war/built_seed1 {s:1}
execute if score #ca2on rpg.sys matches 1 run function rpg:war/built_seed1 {s:2}
execute if score #ca3on rpg.sys matches 1 run function rpg:war/built_seed1 {s:3}
execute if score #ca4on rpg.sys matches 1 run function rpg:war/built_seed1 {s:4}
execute if score #ca5on rpg.sys matches 1 run function rpg:war/built_seed1 {s:5}
execute if score #ca6on rpg.sys matches 1 run function rpg:war/built_seed1 {s:6}
execute if score #ca7on rpg.sys matches 1 run function rpg:war/built_seed1 {s:7}
execute if score #ca8on rpg.sys matches 1 run function rpg:war/built_seed1 {s:8}
execute if score #ca9on rpg.sys matches 1 run function rpg:war/built_seed1 {s:9}
execute if score #ca10on rpg.sys matches 1 run function rpg:war/built_seed1 {s:10}
execute if score #ca11on rpg.sys matches 1 run function rpg:war/built_seed1 {s:11}
execute if score #ca12on rpg.sys matches 1 run function rpg:war/built_seed1 {s:12}
execute if score #ca13on rpg.sys matches 1 run function rpg:war/built_seed1 {s:13}
execute if score #ca14on rpg.sys matches 1 run function rpg:war/built_seed1 {s:14}
execute if score #ca15on rpg.sys matches 1 run function rpg:war/built_seed1 {s:15}
execute if score #ca16on rpg.sys matches 1 run function rpg:war/built_seed1 {s:16}
execute if score #ca17on rpg.sys matches 1 run function rpg:war/built_seed1 {s:17}
execute if score #ca18on rpg.sys matches 1 run function rpg:war/built_seed1 {s:18}
execute if score #ca19on rpg.sys matches 1 run function rpg:war/built_seed1 {s:19}
execute if score #ca20on rpg.sys matches 1 run function rpg:war/built_seed1 {s:20}
execute if score #ca21on rpg.sys matches 1 run function rpg:war/built_seed1 {s:21}
execute if score #ca22on rpg.sys matches 1 run function rpg:war/built_seed1 {s:22}
execute if score #ca23on rpg.sys matches 1 run function rpg:war/built_seed1 {s:23}
execute if score #ca24on rpg.sys matches 1 run function rpg:war/built_seed1 {s:24}
execute if score #ca25on rpg.sys matches 1 run function rpg:war/built_seed1 {s:25}
execute if score #ca26on rpg.sys matches 1 run function rpg:war/built_seed1 {s:26}
execute if score #ca27on rpg.sys matches 1 run function rpg:war/built_seed1 {s:27}
execute if score #ca28on rpg.sys matches 1 run function rpg:war/built_seed1 {s:28}
execute if score #ca29on rpg.sys matches 1 run function rpg:war/built_seed1 {s:29}
execute if score #ca30on rpg.sys matches 1 run function rpg:war/built_seed1 {s:30}
execute if score #ca31on rpg.sys matches 1 run function rpg:war/built_seed1 {s:31}
execute if score #ca32on rpg.sys matches 1 run function rpg:war/built_seed1 {s:32}

scoreboard players set #cs5on rpg.sys 0
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"파랑 국가의 성 기록을 지웠습니다.","color":"red"}]
function rpg:war/cs_list

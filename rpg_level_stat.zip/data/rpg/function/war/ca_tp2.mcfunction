$scoreboard players operation #ts rpg.sys = #cu$(n)_$(k) rpg.sys
execute unless score #ts rpg.sys matches 1.. run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"그 성은 이제 없습니다.","color":"red"}]
execute store result storage rpg:war ct.s int 1 run scoreboard players get #ts rpg.sys
function rpg:war/ca_tp3 with storage rpg:war ct

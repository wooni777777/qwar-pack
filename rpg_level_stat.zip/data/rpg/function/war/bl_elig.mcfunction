# 이 신호기를 부술 수 있는 사람인가 (v42 · as 신호기 표식 · #ban = 보는 사람 국가)
scoreboard players operation #bn rpg.sys = @s rpg.csn
scoreboard players set #blk rpg.sys 2
execute unless score #ban rpg.sys matches 1..8 run return 0
scoreboard players set #blk rpg.sys 3
execute if score #ban rpg.sys = #bn rpg.sys run return 0
scoreboard players set #blk rpg.sys 4
execute unless score #war_run rpg.sys matches 1 run return 0
execute store result storage rpg:war bh.a int 1 run scoreboard players get #ban rpg.sys
execute store result storage rpg:war bh.b int 1 run scoreboard players get #bn rpg.sys
scoreboard players set #bdecl rpg.sys 0
function rpg:war/bcn_decl with storage rpg:war bh
scoreboard players set #blk rpg.sys 5
execute if score #bdecl rpg.sys matches 1 run scoreboard players set #blk rpg.sys 1

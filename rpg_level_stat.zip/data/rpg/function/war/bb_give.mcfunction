# 부서진 신호기 1개 지급 (v39)
give @s minecraft:paper[minecraft:custom_data={rpg_brokenb:1},minecraft:item_model="minecraft:beacon",minecraft:item_name={"text":"부서진 신호기","color":"gray","bold":true},minecraft:lore=[{"text":"멸망한 국가의 신호기","color":"dark_gray","italic":false},{"text":"네더별 성 상점에서 네더별 10개로 팝니다","color":"gray","italic":false}],minecraft:max_stack_size=16] 1
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"부서진 신호기","color":"gray","bold":true},{"text":" 를 얻었습니다. 네더별 성 상점에 팔면 네더별 10개!","color":"white"}]

# 예전 성 정문 바꾸기 (v42 · 한 번 · as 정문 표식 at 표식) — 레드스톤 여닫이 치우고 우클릭 칸 만들기
execute rotated as @s if block ^1 ^ ^ minecraft:redstone_block run setblock ^1 ^ ^ minecraft:stone_bricks
execute unless entity @e[type=minecraft:interaction,tag=rpg_cadoor,distance=..0.6] run function rpg:war/door_ie
tag @s add rpg_cag42

# 예전 폭탄 / 국가 신호기를 새 아이템으로 (v40 · 0.5초마다 · as 플레이어)
scoreboard players set #mc rpg.sys 0
execute store result score #mc rpg.sys run clear @s minecraft:fire_charge[minecraft:custom_data~{rpg_bomb:1}]
execute store result storage rpg:war mg.n int 1 run scoreboard players get #mc rpg.sys
execute if score #mc rpg.sys matches 1.. run function rpg:war/bomb_given with storage rpg:war mg
scoreboard players set #mc rpg.sys 0
execute store result score #mc rpg.sys run clear @s minecraft:beacon[minecraft:custom_data~{rpg_nbeacon:1}]
execute store result storage rpg:war mg.n int 1 run scoreboard players get #mc rpg.sys
execute if score #mc rpg.sys matches 1.. run function rpg:war/cs_given with storage rpg:war mg

clear @s minecraft:beacon[!minecraft:custom_data] 1
function rpg:war/bb_give

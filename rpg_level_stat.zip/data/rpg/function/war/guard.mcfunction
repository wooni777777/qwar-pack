# 전쟁터 안에서는 블록을 못 건드리게 어드벤처 모드로 바꾼다 (전쟁 중 · 1초마다)
#   v42 : op 태그도 보호합니다. 건축은 크리에이티브로 (크리에이티브 · 관전은 그대로)
#         성 신호기는 쳐다보는 동안만 서바이벌 -> 맨손으로 부술 수 있음 (war/bl_chk) · 철문은 폭탄으로
#   범위는 좌표로 정해져 있습니다 (rpg:war/field 로 바꿀 수 있습니다)
function rpg:war/guard_go with storage rpg:war fld

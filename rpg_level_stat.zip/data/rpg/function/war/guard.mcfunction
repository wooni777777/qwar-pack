# 전쟁터 안에서는 블록을 못 건드리게 어드벤처 모드로 바꾼다
execute as @e[type=minecraft:marker,tag=rpg_warpoint,limit=1] at @s run function rpg:war/guard_go
# 전쟁터를 벗어났으면 되돌린다 (차원이 달라도 안전하게)
execute as @a[tag=rpg_wadv] at @s unless entity @e[type=minecraft:marker,tag=rpg_warpoint,distance=..400] run function rpg:war/adv_off

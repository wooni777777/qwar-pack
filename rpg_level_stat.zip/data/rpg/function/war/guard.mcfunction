# 전쟁터 안에서는 블록을 못 건드리게 어드벤처 모드로 바꾼다
#   범위는 좌표로 정해져 있습니다 (rpg:war/field 로 바꿀 수 있습니다)
function rpg:war/guard_go with storage rpg:war fld

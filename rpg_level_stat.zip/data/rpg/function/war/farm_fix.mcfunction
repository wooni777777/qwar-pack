# 성 양옆 밭 복구 (v50 · 내부용 · as 성 정문 표식 at 표식 · 매 틱 · 64칸 안에 사람이 있을 때만)
#   밟아서 흙이 된 자리를 바로 경작지(촉촉)로 되돌립니다 · 밭 자리(war/ca_build2)와 똑같은 범위 · 흙만 바꿈
fill ^6 ^-1 ^-6 ^20 ^-1 ^-42 minecraft:farmland[moisture=7] replace minecraft:dirt
fill ^-6 ^-1 ^-6 ^-20 ^-1 ^-42 minecraft:farmland[moisture=7] replace minecraft:dirt

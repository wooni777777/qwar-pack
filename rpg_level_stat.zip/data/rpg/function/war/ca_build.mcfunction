# 성 짓기 입구 (내부용 · 정문 칸 가운데에서 실행 · storage rpg:war cb {c,yaw,fw,bk})
$execute rotated $(yaw) 0 run function rpg:war/ca_build2 with storage rpg:war cb

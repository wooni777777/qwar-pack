# 성 철거 대기열에서 하나 꺼내 준비 (v43 · 내부용 · schedule / 이어서)
function rpg:war/wipe_unfl
execute unless data storage rpg:war wq[0] run return run function rpg:war/wipe_done
scoreboard players set #wtry rpg.sys 0
data modify storage rpg:war wc set value {x:0,y:-10000,z:0,d:""}
data modify storage rpg:war wc merge from storage rpg:war wq[0]
execute if data storage rpg:war wc{d:""} run return run function rpg:war/wipe_pop
execute store result score #wx rpg.sys run data get storage rpg:war wc.x
execute store result score #wy rpg.sys run data get storage rpg:war wc.y
execute store result score #wz rpg.sys run data get storage rpg:war wc.z
data modify storage rpg:war wa set value {fb:"minecraft:dirt",ft:"minecraft:grass_block"}
data modify storage rpg:war wa.d set from storage rpg:war wc.d
execute if data storage rpg:war wc{d:"minecraft:the_nether"} run data modify storage rpg:war wa merge value {fb:"minecraft:netherrack",ft:"minecraft:netherrack"}
execute if data storage rpg:war wc{d:"minecraft:the_end"} run data modify storage rpg:war wa merge value {fb:"minecraft:end_stone",ft:"minecraft:end_stone"}
execute store result storage rpg:war wa.x int 1 run scoreboard players get #wx rpg.sys
execute store result storage rpg:war wa.y int 1 run scoreboard players get #wy rpg.sys
execute store result storage rpg:war wa.z int 1 run scoreboard players get #wz rpg.sys
# 가로 x : 가운데 -24 ~ +24 (16칸 간격 4점 = 청크 4개)
scoreboard players operation #w1 rpg.sys = #wx rpg.sys
scoreboard players remove #w1 rpg.sys 24
execute store result storage rpg:war wa.x1 int 1 run scoreboard players get #w1 rpg.sys
scoreboard players add #w1 rpg.sys 16
execute store result storage rpg:war wa.xb int 1 run scoreboard players get #w1 rpg.sys
scoreboard players add #w1 rpg.sys 16
execute store result storage rpg:war wa.xc int 1 run scoreboard players get #w1 rpg.sys
scoreboard players add #w1 rpg.sys 16
execute store result storage rpg:war wa.x2 int 1 run scoreboard players get #w1 rpg.sys
# 세로 z : 가운데 -24 ~ +24 · 반으로 나눠 지움 (zm | zm1)
scoreboard players operation #w1 rpg.sys = #wz rpg.sys
scoreboard players remove #w1 rpg.sys 24
execute store result storage rpg:war wa.z1 int 1 run scoreboard players get #w1 rpg.sys
scoreboard players add #w1 rpg.sys 16
execute store result storage rpg:war wa.zb int 1 run scoreboard players get #w1 rpg.sys
scoreboard players add #w1 rpg.sys 16
execute store result storage rpg:war wa.zc int 1 run scoreboard players get #w1 rpg.sys
scoreboard players add #w1 rpg.sys 16
execute store result storage rpg:war wa.z2 int 1 run scoreboard players get #w1 rpg.sys
execute store result storage rpg:war wa.zm int 1 run scoreboard players get #wz rpg.sys
scoreboard players operation #w1 rpg.sys = #wz rpg.sys
scoreboard players add #w1 rpg.sys 1
execute store result storage rpg:war wa.zm1 int 1 run scoreboard players get #w1 rpg.sys
# 높이 : 신호기 -14 (바닥 아래겹) · -13 (바닥 윗겹) · -12 ~ +10 (건물)
scoreboard players operation #w1 rpg.sys = #wy rpg.sys
scoreboard players remove #w1 rpg.sys 14
execute store result storage rpg:war wa.yf int 1 run scoreboard players get #w1 rpg.sys
scoreboard players add #w1 rpg.sys 1
execute store result storage rpg:war wa.yg int 1 run scoreboard players get #w1 rpg.sys
scoreboard players add #w1 rpg.sys 1
execute store result storage rpg:war wa.ya int 1 run scoreboard players get #w1 rpg.sys
scoreboard players add #w1 rpg.sys 22
execute store result storage rpg:war wa.yb int 1 run scoreboard players get #w1 rpg.sys
function rpg:war/wipe_fl with storage rpg:war wa
schedule function rpg:war/wipe_try 3t replace

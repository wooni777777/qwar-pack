# [k성] 누름 -> 그 성 신호기 위로 (as 플레이어)
scoreboard players set #ok rpg.sys 1
execute unless score @s rpg.natn matches 1..8 run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"국가에 들어가야 합니다.","color":"red"}]
scoreboard players operation #tk rpg.sys = @s rpg.tp
scoreboard players remove #tk rpg.sys 100
execute store result storage rpg:war ct.n int 1 run scoreboard players get @s rpg.natn
execute store result storage rpg:war ct.k int 1 run scoreboard players get #tk rpg.sys
function rpg:war/ca_tp2 with storage rpg:war ct

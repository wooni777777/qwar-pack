# 철문 닫기 (v42 · as 정문 표식 at 표식)
function rpg:war/door_st {o:"false"}
scoreboard players set @s rpg.dop 0
playsound minecraft:block.iron_door.close block @a ~ ~ ~ 1 1
# v47 : 판자 위치에 맞춰 우클릭 칸 다시
function rpg:war/door_ie

# (v43 · 내부용 · 매크로 s) 그 번호의 성이 살아 있고 같은 성이면 그대로 · 아니면 치움
$execute if score #ca$(s)on rpg.sys matches 1 if score #ca$(s)id rpg.sys = @s rpg.cbid run return 0
kill @s

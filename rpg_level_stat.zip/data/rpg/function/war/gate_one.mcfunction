$execute positioned $(x) $(y) $(z) if entity @a[distance=..8,scores={rpg.natn=$(n)},gamemode=!spectator] run function rpg:war/gate_open
$execute positioned $(x) $(y) $(z) unless entity @a[distance=..8,scores={rpg.natn=$(n)},gamemode=!spectator] run function rpg:war/gate_close

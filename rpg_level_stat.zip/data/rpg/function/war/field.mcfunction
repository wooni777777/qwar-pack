# ── 전쟁터 범위를 지금 서 있는 자리로 바꾼다 ──
#   function rpg:war/field {x:113,y:-60,z:54,dx:799,dy:120,dz:799}
#     x y z    시작 모서리 좌표
#     dx dy dz 거기서부터의 크기 (끝 좌표 - 시작 좌표)
#   지금 값 : 113 -60 54  ~  912 60 853
$data modify storage rpg:war fld set value {x:$(x),y:$(y),z:$(z),dx:$(dx),dy:$(dy),dz:$(dz)}
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"전쟁터 범위를 바꿨습니다.","color":"green"}]
return 1

# 전쟁 종료
scoreboard players set #war_run rpg.sys 0
scoreboard players set #war_pause rpg.sys 0
scoreboard players set #war_time rpg.sys 0
execute if score #war_bb rpg.sys matches 1 run bossbar remove rpg:war
scoreboard players set #war_bb rpg.sys 0
function rpg:war/dec_reset
function rpg:war/guard_off
# 회차를 원래대로 돌려놓는다
execute if score #rnd_run rpg.sys matches 1 run scoreboard players operation #rnd_pause rpg.sys = #rnd_sav rpg.sys
execute if score #rnd_run rpg.sys matches 1 run bossbar set rpg:round visible true
execute if score #rnd_run rpg.sys matches 1 run function rpg:round/sec
tellraw @a " "
tellraw @a [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"전쟁이 끝났습니다","color":"red","bold":true}]
tellraw @a " "

# 철문을 누른 사람 (v42 · as 플레이어)
#   당근 낚싯대류(폭탄 · 스킬 등)를 들고 누른 것은 원래대로 그 아이템을 쓴 것으로 넘긴다
execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick run return run function rpg:war/door_pass
execute if items entity @s weapon.mainhand minecraft:warped_fungus_on_a_stick run return run scoreboard players add @s rpg.ustun 1
execute if score #dex rpg.sys matches 0 run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"철문이 부서져 있습니다. (상점 철문을 이 자리에 다시 달면 비밀번호도 그대로 씁니다)","color":"red"}]
scoreboard players operation @s rpg.pwd = #dci rpg.sys
scoreboard players operation @s rpg.pwt = #gtick rpg.sys
scoreboard players set @s rpg.pwm 0
scoreboard players set @s rpg.pwp 0
scoreboard players enable @s rpg.pw
scoreboard players set #pn rpg.sys 0
execute if score @s rpg.natn matches -2147483648.. run scoreboard players operation #pn rpg.sys = @s rpg.natn
tag @s add rpg_pwp
execute as @e[type=minecraft:marker,tag=rpg_cag] if score @s rpg.cbid = #dci rpg.sys run function rpg:war/door_ask2
tag @s remove rpg_pwp

execute if score #bmok rpg.sys matches 1 run return 0
execute store result storage rpg:war bm.x int 1 run scoreboard players get #cs4x rpg.sys
execute store result storage rpg:war bm.y int 1 run scoreboard players get #cs4y rpg.sys
execute store result storage rpg:war bm.z int 1 run scoreboard players get #cs4z rpg.sys
data modify storage rpg:war bm.n set value 4
function rpg:war/bomb_try with storage rpg:war bm

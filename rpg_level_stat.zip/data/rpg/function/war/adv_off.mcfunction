tag @s remove rpg_wadv
tag @s remove rpg_wbcn
execute if entity @s[gamemode=adventure] run gamemode survival @s

tag @s remove rpg_wadv
gamemode survival @s

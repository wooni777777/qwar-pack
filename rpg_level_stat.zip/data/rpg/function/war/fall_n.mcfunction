$function rpg:war/fall$(n)

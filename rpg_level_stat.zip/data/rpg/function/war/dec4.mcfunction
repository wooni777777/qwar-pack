# 초록 국가에 선전포고
execute unless score @s rpg.wdp matches 1 run return 0
execute if score @s rpg.natn matches 4 run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"자기 국가에는 선전포고할 수 없습니다.","color":"red"}]
scoreboard players set @s rpg.wdp 0
execute if score @s rpg.natn matches 1 run scoreboard players set #wd14 rpg.sys 1
execute if score @s rpg.natn matches 1 run tellraw @a ["", {"text": "[q후계자 전쟁] ", "color": "gray"}, {"text": "빨강 국가", "color": "red", "bold": true}, {"text": " 가 ", "color": "white"}, {"text": "초록 국가", "color": "green", "bold": true}, {"text": " 에 선전포고했습니다!", "color": "red", "bold": true}]
execute if score @s rpg.natn matches 2 run scoreboard players set #wd24 rpg.sys 1
execute if score @s rpg.natn matches 2 run tellraw @a ["", {"text": "[q후계자 전쟁] ", "color": "gray"}, {"text": "주황 국가", "color": "gold", "bold": true}, {"text": " 가 ", "color": "white"}, {"text": "초록 국가", "color": "green", "bold": true}, {"text": " 에 선전포고했습니다!", "color": "red", "bold": true}]
execute if score @s rpg.natn matches 3 run scoreboard players set #wd34 rpg.sys 1
execute if score @s rpg.natn matches 3 run tellraw @a ["", {"text": "[q후계자 전쟁] ", "color": "gray"}, {"text": "노랑 국가", "color": "yellow", "bold": true}, {"text": " 가 ", "color": "white"}, {"text": "초록 국가", "color": "green", "bold": true}, {"text": " 에 선전포고했습니다!", "color": "red", "bold": true}]
execute if score @s rpg.natn matches 5 run scoreboard players set #wd54 rpg.sys 1
execute if score @s rpg.natn matches 5 run tellraw @a ["", {"text": "[q후계자 전쟁] ", "color": "gray"}, {"text": "파랑 국가", "color": "blue", "bold": true}, {"text": " 가 ", "color": "white"}, {"text": "초록 국가", "color": "green", "bold": true}, {"text": " 에 선전포고했습니다!", "color": "red", "bold": true}]
execute if score @s rpg.natn matches 6 run scoreboard players set #wd64 rpg.sys 1
execute if score @s rpg.natn matches 6 run tellraw @a ["", {"text": "[q후계자 전쟁] ", "color": "gray"}, {"text": "보라 국가", "color": "dark_purple", "bold": true}, {"text": " 가 ", "color": "white"}, {"text": "초록 국가", "color": "green", "bold": true}, {"text": " 에 선전포고했습니다!", "color": "red", "bold": true}]
execute if score @s rpg.natn matches 7 run scoreboard players set #wd74 rpg.sys 1
execute if score @s rpg.natn matches 7 run tellraw @a ["", {"text": "[q후계자 전쟁] ", "color": "gray"}, {"text": "분홍 국가", "color": "light_purple", "bold": true}, {"text": " 가 ", "color": "white"}, {"text": "초록 국가", "color": "green", "bold": true}, {"text": " 에 선전포고했습니다!", "color": "red", "bold": true}]
execute if score @s rpg.natn matches 8 run scoreboard players set #wd84 rpg.sys 1
execute if score @s rpg.natn matches 8 run tellraw @a ["", {"text": "[q후계자 전쟁] ", "color": "gray"}, {"text": "하양 국가", "color": "white", "bold": true}, {"text": " 가 ", "color": "white"}, {"text": "초록 국가", "color": "green", "bold": true}, {"text": " 에 선전포고했습니다!", "color": "red", "bold": true}]

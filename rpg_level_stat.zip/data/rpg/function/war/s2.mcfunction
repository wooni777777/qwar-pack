scoreboard players set #war_time rpg.sys 72000
scoreboard players set #war_max rpg.sys 72000
data modify storage rpg:war w.n set value "1시간"
function rpg:war/go

# 폭탄 우클릭 (내부용)
advancement revoke @s only rpg:war/bomb
execute unless score #war_run rpg.sys matches 1 run function rpg:war/bomb_back
execute unless score #war_run rpg.sys matches 1 run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"폭탄은 전쟁 중에만 터집니다.","color":"red"}]
execute unless score @s rpg.natn matches 1..8 run function rpg:war/bomb_back
execute unless score @s rpg.natn matches 1..8 run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"먼저 국가에 들어가야 합니다.","color":"red"}]
scoreboard players set #bmok rpg.sys 0
execute store result storage rpg:war bm.m int 1 run scoreboard players get @s rpg.natn
execute if score #cs1on rpg.sys matches 1 unless score @s rpg.natn matches 1 run function rpg:war/bomb_t1
execute if score #cs2on rpg.sys matches 1 unless score @s rpg.natn matches 2 run function rpg:war/bomb_t2
execute if score #cs3on rpg.sys matches 1 unless score @s rpg.natn matches 3 run function rpg:war/bomb_t3
execute if score #cs4on rpg.sys matches 1 unless score @s rpg.natn matches 4 run function rpg:war/bomb_t4
execute if score #cs5on rpg.sys matches 1 unless score @s rpg.natn matches 5 run function rpg:war/bomb_t5
execute if score #cs6on rpg.sys matches 1 unless score @s rpg.natn matches 6 run function rpg:war/bomb_t6
execute if score #cs7on rpg.sys matches 1 unless score @s rpg.natn matches 7 run function rpg:war/bomb_t7
execute if score #cs8on rpg.sys matches 1 unless score @s rpg.natn matches 8 run function rpg:war/bomb_t8
execute if score #bmok rpg.sys matches 0 run function rpg:war/bomb_back
execute if score #bmok rpg.sys matches 0 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"선전포고한 국가의 성문 앞에서만 터집니다.","color":"red"}]
return run scoreboard players get #bmok rpg.sys

# (v40) 예전 화염구 폭탄을 쓴 경우 : 새 폭탄으로 바꿔 줍니다
advancement revoke @s only rpg:war/bomb
function rpg:war/bomb_give
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"폭탄이 새 방식으로 바뀌었습니다. 다시 우클릭하세요.","color":"yellow"}]

$bossbar set rpg:war name [{"text":"-{전쟁}-  ","color":"red","bold":true},{"text":"$(m):$(s)","color":"white","bold":true}]

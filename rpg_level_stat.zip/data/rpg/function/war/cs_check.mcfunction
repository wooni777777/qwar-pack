# 성의 신호기가 남아 있는지 본다 (1초마다 · 내부용)
execute if score #cs1on rpg.sys matches 1 run function rpg:war/cs_chk1
execute if score #cs2on rpg.sys matches 1 run function rpg:war/cs_chk2
execute if score #cs3on rpg.sys matches 1 run function rpg:war/cs_chk3
execute if score #cs4on rpg.sys matches 1 run function rpg:war/cs_chk4
execute if score #cs5on rpg.sys matches 1 run function rpg:war/cs_chk5
execute if score #cs6on rpg.sys matches 1 run function rpg:war/cs_chk6
execute if score #cs7on rpg.sys matches 1 run function rpg:war/cs_chk7
execute if score #cs8on rpg.sys matches 1 run function rpg:war/cs_chk8

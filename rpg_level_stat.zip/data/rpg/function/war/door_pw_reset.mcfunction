# (op) 가까운 성 철문 비밀번호 지우기 — 철문 5칸 안에서 /function rpg:war/door_pw_reset (v42)
#   지우면 그 성 국가 사람이 철문을 우클릭해서 새 비밀번호를 정할 수 있습니다
execute unless entity @s[tag=op] run return fail
scoreboard players set #pf rpg.sys 0
execute as @e[type=minecraft:marker,tag=rpg_cag,distance=..5,sort=nearest,limit=1] store success score #pf rpg.sys run scoreboard players set @s rpg.pwv 0
execute if score #pf rpg.sys matches 1 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"가까운 성 철문의 비밀번호를 지웠습니다.","color":"green"}]
execute if score #pf rpg.sys matches 0 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"5칸 안에 성 철문이 없습니다.","color":"red"}]
return run scoreboard players get #pf rpg.sys

# 상점 클릭 처리 (v39)
#   네더별 성 상점     1 국가 신호기(60)   2 부서진 신호기 판매(+10)
#   네더별 템 상점     3 절대계약서(5)     4 선전포고(5)   5 철문(3)   6 네더별 2개 판매(+10,000원)
#   네더별 보스 소환   7 돌 소환석(10)     8 해적 왕 소환 나팔(10)
#   전쟁 상점(돈)     11 폭탄  12 선전포고  13 포션 16개  14 금곡괭이
execute if score @s rpg.wsh matches 1 run function rpg:war/sb_beacon
execute if score @s rpg.wsh matches 2 run function rpg:war/sb_sellbb
execute if score @s rpg.wsh matches 3 run function rpg:war/sb_contract
execute if score @s rpg.wsh matches 4 run function rpg:war/sb_decl
execute if score @s rpg.wsh matches 5 run function rpg:war/sb_door
execute if score @s rpg.wsh matches 6 run function rpg:war/sb_sellstar
execute if score @s rpg.wsh matches 7 run function rpg:war/sb_bs1
execute if score @s rpg.wsh matches 8 run function rpg:war/sb_bs2
execute if score @s rpg.wsh matches 11 run function rpg:war/wb_bomb
execute if score @s rpg.wsh matches 12 run function rpg:war/wb_decl
execute if score @s rpg.wsh matches 13 run function rpg:war/wb_pot
execute if score @s rpg.wsh matches 14 run function rpg:war/wb_pick
scoreboard players set @s rpg.wsh 0
scoreboard players enable @s rpg.wsh

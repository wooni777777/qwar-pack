# 전쟁 상점 클릭 처리
execute if score @s rpg.wsh matches 1 run function rpg:war/sb_bomb
execute if score @s rpg.wsh matches 2 run function rpg:war/sb_pick
execute if score @s rpg.wsh matches 3 run function rpg:war/sb_beacon
execute if score @s rpg.wsh matches 4 run function rpg:war/sb_decl
execute if score @s rpg.wsh matches 5 run function rpg:war/sb_pot
execute if score @s rpg.wsh matches 11 run function rpg:war/wb_bomb
execute if score @s rpg.wsh matches 12 run function rpg:war/wb_decl
execute if score @s rpg.wsh matches 13 run function rpg:war/wb_pot
scoreboard players set @s rpg.wsh 0
scoreboard players enable @s rpg.wsh

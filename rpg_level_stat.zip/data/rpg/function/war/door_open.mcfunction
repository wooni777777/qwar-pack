# 철문 열기 (v42 · as 정문 표식 at 표식) — 5초 뒤 저절로 닫힘
function rpg:war/door_st {o:"true"}
scoreboard players set @s rpg.dop 100
playsound minecraft:block.iron_door.open block @a ~ ~ ~ 1 1

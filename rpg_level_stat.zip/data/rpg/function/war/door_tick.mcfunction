# 열린 철문 시간 (v42 · 0.5초마다 · as 정문 표식 at 표식)
scoreboard players remove @s rpg.dop 10
execute if score @s rpg.dop matches ..0 run function rpg:war/door_close

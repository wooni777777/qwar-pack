# 성 철거 끝 (v43 · 내부용)
execute if score #wcnt rpg.sys matches 1.. run tellraw @a ["", {"text": "[q후계자 전쟁] ", "color": "gray"}, {"text": "국가 성 ", "color": "green"}, {"score": {"name": "#wcnt", "objective": "rpg.sys"}, "color": "gold", "bold": true}, {"text": "개 철거를 마쳤습니다.", "color": "green"}]
scoreboard players set #wcnt rpg.sys 0

# 국가 신호기 우클릭 (내부용)
advancement revoke @s only rpg:war/beacon
function rpg:war/cs_regive
function rpg:war/cs_card

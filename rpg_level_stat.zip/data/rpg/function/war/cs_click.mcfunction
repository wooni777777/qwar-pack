# (v40) 예전 신호기 블록 아이템을 쓴 경우 : 새 국가 신호기로 바꿔 줍니다
advancement revoke @s only rpg:war/beacon
function rpg:war/cs_give
function rpg:war/cs_card

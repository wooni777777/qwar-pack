# 국가 번호 #nx -> storage rpg:war nm {nm,cl} (내부용)
data modify storage rpg:war nm set value {nm:"?",cl:"gray"}
execute if score #nx rpg.sys matches 1 run data modify storage rpg:war nm set value {nm:"빨강",cl:"red"}
execute if score #nx rpg.sys matches 2 run data modify storage rpg:war nm set value {nm:"주황",cl:"gold"}
execute if score #nx rpg.sys matches 3 run data modify storage rpg:war nm set value {nm:"노랑",cl:"yellow"}
execute if score #nx rpg.sys matches 4 run data modify storage rpg:war nm set value {nm:"초록",cl:"green"}
execute if score #nx rpg.sys matches 5 run data modify storage rpg:war nm set value {nm:"파랑",cl:"blue"}
execute if score #nx rpg.sys matches 6 run data modify storage rpg:war nm set value {nm:"보라",cl:"dark_purple"}
execute if score #nx rpg.sys matches 7 run data modify storage rpg:war nm set value {nm:"분홍",cl:"light_purple"}
execute if score #nx rpg.sys matches 8 run data modify storage rpg:war nm set value {nm:"하양",cl:"white"}

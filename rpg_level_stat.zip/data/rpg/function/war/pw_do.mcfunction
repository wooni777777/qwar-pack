# (v42 · as 정문 표식 at 표식 · 입력한 사람 = rpg_pwp)
scoreboard players set #pf rpg.sys 1
scoreboard players operation #dn rpg.sys = @s rpg.csn
execute store result storage rpg:war dq.k int 1 run scoreboard players get @s rpg.csk
execute if score #pv rpg.sys matches 1.. if score #pm rpg.sys matches 1 run return run function rpg:war/pw_set with storage rpg:war dq
execute if score #pv rpg.sys matches 1.. if score #pm rpg.sys matches 2..3 run return run function rpg:war/pw_try with storage rpg:war dq
execute if score #pv rpg.sys matches -1 if score #pm rpg.sys matches 1 run return run function rpg:war/pw_ok with storage rpg:war dq
execute if score #pv rpg.sys matches -2 if score #pm rpg.sys matches 1 run return run function rpg:war/door_q_set with storage rpg:war dq
execute if score #pv rpg.sys matches -3 if score #pm rpg.sys matches 3 if score #pn rpg.sys = #dn rpg.sys run return run function rpg:war/door_q_set with storage rpg:war dq
tellraw @a[tag=rpg_pwp] [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"숫자(1 이상)만 넣을 수 있습니다. 철문을 다시 우클릭하세요.","color":"red"}]

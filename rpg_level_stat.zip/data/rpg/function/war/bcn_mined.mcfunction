# 신호기 블록을 부쉈다 (v42 · as 부순 플레이어 at 플레이어 · 매 틱)
scoreboard players set @s rpg.bmn 0
scoreboard players set #ban rpg.sys 0
execute if score @s rpg.natn matches -2147483648.. run scoreboard players operation #ban rpg.sys = @s rpg.natn
tag @s add rpg_batk
execute as @e[type=minecraft:marker,tag=rpg_cab,distance=..10] at @s unless block ~ ~ ~ minecraft:beacon run function rpg:war/bcn_gone
tag @s remove rpg_batk

$execute positioned $(x) $(y) $(z) run tp @s ~ ~1.05 ~

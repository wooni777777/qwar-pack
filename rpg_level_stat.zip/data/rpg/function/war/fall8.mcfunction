# 하양 국가 멸망 (내부용)
scoreboard players set #cs8on rpg.sys 0
tellraw @a " "
tellraw @a ["",{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"하양 국가","color":"white","bold":true},{"text":" 의 신호기가 부서졌습니다 — ","color":"white"},{"text":"멸망","color":"dark_red","bold":true},{"text":"!","color":"white"}]
tellraw @a " "
execute as @a run playsound minecraft:entity.wither.death master @s ~ ~ ~ 0.7 0.6
execute as @a[scores={rpg.natn=8}] run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"우리 국가가 멸망했습니다. 국가에서 나왔습니다.","color":"red"}]
execute as @a[scores={rpg.natn=8}] run team leave @s
scoreboard players set @a[scores={rpg.natn=8}] rpg.natn 0

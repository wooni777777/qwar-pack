# 청크가 다 불러와졌는지 보고 철거 (v43 · 내부용 · schedule · 최대 10초 기다림)
execute unless data storage rpg:war wq[0] run return 0
scoreboard players add #wtry rpg.sys 1
scoreboard players set #wok rpg.sys 0
function rpg:war/wipe_chk with storage rpg:war wa
execute if score #wok rpg.sys matches 1 run return run function rpg:war/wipe_sig with storage rpg:war wa
execute if score #wtry rpg.sys matches 40.. run return run function rpg:war/wipe_fail with storage rpg:war wa
schedule function rpg:war/wipe_try 5t replace

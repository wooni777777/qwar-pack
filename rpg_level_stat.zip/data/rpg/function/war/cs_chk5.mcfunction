execute store result storage rpg:war ck.x int 1 run scoreboard players get #cs5x rpg.sys
execute store result storage rpg:war ck.y int 1 run scoreboard players get #cs5y rpg.sys
execute store result storage rpg:war ck.z int 1 run scoreboard players get #cs5z rpg.sys
function rpg:war/cs_chk_go with storage rpg:war ck
execute if score #csgone rpg.sys matches 1 run function rpg:war/fall5

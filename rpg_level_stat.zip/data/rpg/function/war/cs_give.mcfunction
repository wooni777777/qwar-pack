# ── 국가 신호기 1개 지급 ──
#   우클릭하면 미리보기 / 설치 창이 뜹니다.
give @s minecraft:beacon[minecraft:custom_data={rpg_nbeacon:1},minecraft:item_name={"text":"국가 신호기","color":"aqua","bold":true},minecraft:lore=[{"text":"우클릭 - 성 미리보기 / 설치","color":"gray","italic":false},{"text":"50x50 돌벽돌 성이 지어집니다","color":"gray","italic":false},{"text":"신호기가 부서지면 국가가 멸망합니다","color":"dark_red","italic":false}],minecraft:enchantment_glint_override=true,minecraft:max_stack_size=4,minecraft:consumable={consume_seconds:0.2f,animation:"none",sound:"minecraft:block.beacon.activate",has_consume_particles:false}] 1
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"국가 신호기","color":"aqua","bold":true},{"text":" 1개를 받았습니다.","color":"white"}]
return 1

# ── 국가 신호기 1개 지급 (v40 · 당근 낚싯대 방식 : 블록으로 설치되지 않습니다) ──
give @s minecraft:carrot_on_a_stick[!minecraft:max_damage,minecraft:max_stack_size=4,minecraft:custom_data={rpg_nbeacon:1},minecraft:item_model="minecraft:beacon",minecraft:item_name={"text":"국가 신호기","color":"aqua","bold":true},minecraft:lore=[{"text":"우클릭 - 성 미리보기 / 설치","color":"gray","italic":false},{"text":"서 있는 곳이 정문, 등 뒤로 성이 지어집니다","color":"gray","italic":false},{"text":"전쟁 중에는 설치할 수 없습니다","color":"dark_red","italic":false}],minecraft:enchantment_glint_override=true] 1
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"국가 신호기","color":"aqua","bold":true},{"text":" 1개를 받았습니다.","color":"white"}]
return 1

execute if score #war_run rpg.sys matches 0 run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"진행 중인 전쟁이 없습니다.","color":"red"}]
scoreboard players operation #wp rpg.sys = #war_pause rpg.sys
execute if score #wp rpg.sys matches 0 run scoreboard players set #war_pause rpg.sys 1
execute if score #wp rpg.sys matches 0 run tellraw @a [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"전쟁이 일시 정지되었습니다.","color":"gray"}]
execute if score #wp rpg.sys matches 1 run scoreboard players set #war_pause rpg.sys 0
execute if score #wp rpg.sys matches 1 run tellraw @a [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"전쟁이 다시 시작되었습니다.","color":"red"}]
function rpg:war/sec

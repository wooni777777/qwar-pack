scoreboard players enable @s rpg.war
scoreboard players enable @s rpg.menu
playsound minecraft:item.book.page_turn player @s ~ ~ ~ 1 1.2
tellraw @s " "
tellraw @s {"text": "━━━━━━━━━  전  쟁  ━━━━━━━━━", "color": "dark_gray"}
execute if score #war_run rpg.sys matches 0 run tellraw @s ["",{"text":"   상태 : ","color":"dark_gray"},{"text":"전쟁 없음","color":"gray"}]
execute if score #war_run rpg.sys matches 1 if score #war_pause rpg.sys matches 0 run tellraw @s ["",{"text":"   상태 : ","color":"dark_gray"},{"text":"전쟁 중","color":"red","bold":true}]
execute if score #war_run rpg.sys matches 1 if score #war_pause rpg.sys matches 1 run tellraw @s ["",{"text":"   상태 : ","color":"dark_gray"},{"text":"일시 정지","color":"gray"}]
execute if score #war_prot rpg.sys matches 1 run tellraw @s ["",{"text":"   블록 보호 : ","color":"dark_gray"},{"text":"켜짐","color":"green"},{"text":"   (전쟁터 안에서 블록을 못 건드립니다)","color":"dark_gray"}]
execute if score #war_prot rpg.sys matches 0 run tellraw @s ["",{"text":"   블록 보호 : ","color":"dark_gray"},{"text":"꺼짐","color":"red"}]
tellraw @s " "
tellraw @s ["", {"text": "   "}, {"text": "[ 전쟁 시작 ]", "color": "red", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.war set 1"}, "hover_event": {"action": "show_text", "value": {"text": "30분 / 1시간 / 2시간 중에서 고릅니다", "color": "gray"}}}, {"text": "  "}, {"text": "[ 전쟁 강제 종료 ]", "color": "dark_red", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.war set 2"}, "hover_event": {"action": "show_text", "value": {"text": "진행 중인 전쟁을 즉시 끝냅니다", "color": "gray"}}}]
tellraw @s ["", {"text": "   "}, {"text": "[ 전쟁 일시 정지 ]", "color": "gray", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.war set 3"}, "hover_event": {"action": "show_text", "value": {"text": "시간을 멈춥니다 / 다시 누르면 재개", "color": "gray"}}}, {"text": "  "}, {"text": "[ 전쟁 시간 추가 ]", "color": "gold", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.war set 4"}}]
tellraw @s " "
tellraw @s ["", {"text": "   "}, {"text": "[ 선전포고 현황 ]", "color": "aqua", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.war set 5"}, "hover_event": {"action": "show_text", "value": {"text": "어느 국가가 어느 국가에 선전포고했는지", "color": "gray"}}}, {"text": "  "}, {"text": "[ 블록 보호 ]", "color": "green", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.war set 6"}, "hover_event": {"action": "show_text", "value": {"text": "전쟁터 안에서 블록을 못 건드리게 (켜기/끄기)", "color": "gray"}}}, {"text": "  "}, {"text": "[ 선전포고 지급 ]", "color": "light_purple", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.war set 7"}, "hover_event": {"action": "show_text", "value": {"text": "시험용 - 선전포고 1장을 나에게 줍니다", "color": "gray"}}}]
tellraw @s {"text": "━━━━━━━━━━━━━━━━━━━━━━━━━━", "color": "dark_gray"}

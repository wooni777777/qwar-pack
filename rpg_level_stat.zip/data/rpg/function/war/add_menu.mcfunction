scoreboard players enable @s rpg.wmn
tellraw @s " "
tellraw @s {"text": "━━━━━━━  전쟁 시간 추가  ━━━━━━━", "color": "dark_gray"}
execute if score #war_run rpg.sys matches 0 run tellraw @s ["",{"text":"   진행 중인 전쟁이 없습니다","color":"red"}]
tellraw @s ["", {"text": "   "}, {"text": "[ 5분 ]", "color": "gold", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.wmn set 21"}}, {"text": "  "}, {"text": "[ 10분 ]", "color": "gold", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.wmn set 22"}}, {"text": "  "}, {"text": "[ 30분 ]", "color": "gold", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.wmn set 23"}}, {"text": "  "}, {"text": "[ 1시간 ]", "color": "gold", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.wmn set 24"}}, {"text": "  "}]
tellraw @s {"text": "━━━━━━━━━━━━━━━━━━━━━━━━━━", "color": "dark_gray"}

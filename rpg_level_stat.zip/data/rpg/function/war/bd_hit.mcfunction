scoreboard players set #bdf rpg.sys 1
fill ~ ~-1 ~ ~ ~1 ~ minecraft:air replace minecraft:iron_door
particle minecraft:explosion_emitter ~ ~0.5 ~ 0 0 0 0 1 force @a
particle minecraft:large_smoke ~ ~0.5 ~ 1.0 1.0 1.0 0.05 50 force @a
playsound minecraft:entity.generic.explode master @a ~ ~ ~ 3 0.9

# 성 안쪽에서 누른 철문 (v43 · as 누른 사람) — 비밀번호 없이 열림 · 5초 뒤 저절로 닫힘
execute as @e[type=minecraft:marker,tag=rpg_cag] if score @s rpg.cbid = #dci rpg.sys at @s run function rpg:war/door_open
return 1

# 최상급 회복 포션 16개 (네더별 2개)
scoreboard players set #ns rpg.sys 0
execute store result score #ns rpg.sys run clear @s minecraft:nether_star 0
execute if score #ns rpg.sys matches ..1 run return run tellraw @s [{"text":"[상점] ","color":"aqua","bold":true},{"text":"네더별이 부족합니다. (2개 필요)","color":"red"}]
clear @s minecraft:nether_star 2
function rpg:shop/buy6 {n:16}
execute at @s run playsound minecraft:entity.villager.yes player @s ~ ~ ~ 1 1.2
return 1

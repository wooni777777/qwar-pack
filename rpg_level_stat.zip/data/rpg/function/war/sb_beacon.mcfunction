# 우리 국가 신호기 구매 (네더별 60개 · v39)
execute unless score @s rpg.natn matches 1..8 run return run tellraw @s [{"text":"[상점] ","color":"aqua","bold":true},{"text":"국가에 들어가야 살 수 있습니다. (메뉴 > 국가)","color":"red"}]
scoreboard players set #ns rpg.sys 0
execute store result score #ns rpg.sys run clear @s minecraft:nether_star 0
execute if score #ns rpg.sys matches ..59 run return run tellraw @s [{"text":"[상점] ","color":"aqua","bold":true},{"text":"네더별이 부족합니다. (60개 필요 · 지금 ","color":"red"},{"score":{"name":"#ns","objective":"rpg.sys"},"color":"yellow"},{"text":"개)","color":"red"}]
clear @s minecraft:nether_star 60
function rpg:war/cs_give
execute at @s run playsound minecraft:entity.villager.yes player @s ~ ~ ~ 1 1.2
return 1

execute store result storage rpg:war gt.x int 1 run scoreboard players get #cs8x rpg.sys
execute store result storage rpg:war gt.y int 1 run scoreboard players get #cs8y rpg.sys
execute store result storage rpg:war gt.z int 1 run scoreboard players get #cs8z rpg.sys
data modify storage rpg:war gt.n set value 8
function rpg:war/gate_one with storage rpg:war gt

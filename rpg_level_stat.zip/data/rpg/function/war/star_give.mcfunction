# 네더별 n개 지급 (해적 왕이 떨구는 네더별과 똑같은 아이템 · 겹쳐 쌓임)
#   function rpg:war/star_give {n:10}
$give @s minecraft:nether_star[minecraft:custom_data={rpg_bossdrop:1},minecraft:item_name={text:"네더별",color:"dark_red",bold:true},minecraft:lore=[{text:"해적 왕이 남긴 별",color:"gray",italic:false}],minecraft:enchantment_glint_override=true] $(n)

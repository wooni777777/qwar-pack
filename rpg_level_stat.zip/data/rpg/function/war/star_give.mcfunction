# 네더의 별 n개 지급 (v42 · 모든 보스 드롭 · 욕심쟁이 · 상점에서 쓰는 별 — 전부 같은 아이템이라 겹쳐 쌓임)
#   function rpg:war/star_give {n:10}
$give @s minecraft:nether_star[minecraft:custom_data={rpg_star:2},minecraft:item_name={text:"네더의 별",color:"light_purple",bold:true},minecraft:lore=[{text:"네더별 상점에서 씁니다",color:"dark_gray",italic:false}]] $(n)

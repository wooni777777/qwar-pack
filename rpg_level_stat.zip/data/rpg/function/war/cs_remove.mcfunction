# 성 기록을 전부 지웁니다 (블록은 안 지웁니다)
scoreboard players set #cs1on rpg.sys 0
scoreboard players set #cs2on rpg.sys 0
scoreboard players set #cs3on rpg.sys 0
scoreboard players set #cs4on rpg.sys 0
scoreboard players set #cs5on rpg.sys 0
scoreboard players set #cs6on rpg.sys 0
scoreboard players set #cs7on rpg.sys 0
scoreboard players set #cs8on rpg.sys 0
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"모든 성 기록을 지웠습니다.","color":"red"}]
return 1

# 성 기록을 전부 지웁니다 (블록은 안 지웁니다 · op)
function rpg:war/ca_reg_clear
kill @e[tag=rpg_ca]
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"모든 성 기록을 지웠습니다.","color":"red"}]
return 1

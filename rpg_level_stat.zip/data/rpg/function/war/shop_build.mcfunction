scoreboard players enable @s rpg.wsh
playsound minecraft:item.book.page_turn player @s ~ ~ ~ 1 1.2
tellraw @s " "
tellraw @s ["",{"text":"━━━━━  ","color":"dark_gray"},{"text":"네더별 상점 [ 건설 ]","color":"aqua","bold":true},{"text":"  ━━━━━","color":"dark_gray"}]
tellraw @s {"text":"   성을 세우는 물건을 팝니다. 값은 네더별로 받습니다.","color":"gray"}
tellraw @s " "
tellraw @s ["",{"text":"   "},{"text":"국가 신호기","color":"aqua","bold":true,"hover_event":{"action":"show_text","value":{"text":"50x50 돌벽돌 성을 세웁니다","color":"gray"}}},{"text":"    네더별 5개   ","color":"gold"},{"text":"[구매]","color":"green","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wsh set 3"}}]
tellraw @s " "
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}

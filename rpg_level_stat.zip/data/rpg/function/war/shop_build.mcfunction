scoreboard players enable @s rpg.wsh
playsound minecraft:item.book.page_turn player @s ~ ~ ~ 1 1.2
tellraw @s " "
tellraw @s ["",{"text":"━━━━━  ","color":"dark_gray"},{"text":"네더별 템 상점","color":"aqua","bold":true},{"text":"  ━━━━━","color":"dark_gray"}]
tellraw @s {"text":"   전쟁에 쓰는 물건을 팝니다. 값은 네더별로 받습니다.","color":"gray"}
tellraw @s " "
tellraw @s ["",{"text":"   "},{"text":"절대계약서","color":"dark_purple","bold":true,"hover_event":{"action":"show_text","value":{"text":"쓰고 서명해서 제작자에게 주면 강제로 이루어집니다","color":"gray"}}},{"text":"    네더별 5개   ","color":"gold"},{"text":"[구매]","color":"green","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wsh set 3"}}]
tellraw @s ["",{"text":"   "},{"text":"선전포고","color":"dark_red","bold":true,"hover_event":{"action":"show_text","value":{"text":"우클릭 -> 채팅에서 선전포고할 국가를 고릅니다","color":"gray"}}},{"text":"    네더별 5개   ","color":"gold"},{"text":"[구매]","color":"green","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wsh set 4"}}]
tellraw @s ["",{"text":"   "},{"text":"철문","color":"white","bold":true,"hover_event":{"action":"show_text","value":{"text":"어디에나 설치할 수 있는 철문","color":"gray"}}},{"text":"    네더별 3개   ","color":"gold"},{"text":"[구매]","color":"green","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wsh set 5"}}]
tellraw @s ["",{"text":"   "},{"text":"네더별 2개 판매","color":"dark_red","bold":true,"hover_event":{"action":"show_text","value":{"text":"네더별 2개를 10,000원에 팝니다","color":"gray"}}},{"text":"    10,000원 받음   ","color":"gold"},{"text":"[판매]","color":"yellow","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.wsh set 6"}}]
tellraw @s " "
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}

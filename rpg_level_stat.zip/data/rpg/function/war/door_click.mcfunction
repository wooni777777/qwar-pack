# 성 철문 우클릭 (v43 · as 우클릭 칸 at 칸 = 철문 아래칸 · v47 : 칸이 판자 쪽으로 0.4칸 치우쳐 있어 블록 가운데로 맞춰 판정)
#   열린 철문 -> 누구나 닫기 · 성 안쪽에서 누름 -> 비밀번호 없이 열기 · 바깥에서 누름 -> 비밀번호
scoreboard players operation #dci rpg.sys = @s rpg.cbid
execute align xyz positioned ~0.5 ~ ~0.5 run function rpg:war/door_click2
data remove entity @s interaction

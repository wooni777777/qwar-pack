# 성 철문 우클릭 (v42 · as 우클릭 칸 at 칸 = 철문 아래칸)
scoreboard players operation #dci rpg.sys = @s rpg.cbid
scoreboard players set #dex rpg.sys 0
execute if block ~ ~ ~ minecraft:iron_door run scoreboard players set #dex rpg.sys 1
execute on target run function rpg:war/door_ask
data remove entity @s interaction

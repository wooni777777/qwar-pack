# 성 철문 우클릭 (v43 · as 우클릭 칸 at 칸 = 철문 아래칸)
#   열린 철문 -> 누구나 닫기 · 성 안쪽에서 누름 -> 비밀번호 없이 열기 · 바깥에서 누름 -> 비밀번호
scoreboard players operation #dci rpg.sys = @s rpg.cbid
scoreboard players set #dex rpg.sys 0
execute if block ~ ~ ~ minecraft:iron_door run scoreboard players set #dex rpg.sys 1
scoreboard players set #dop rpg.sys 0
execute if block ~ ~ ~ minecraft:iron_door[open=true] run scoreboard players set #dop rpg.sys 1
scoreboard players set #din rpg.sys 0
execute on target run tag @s add rpg_dclk
# 성 안쪽 = 정문 표식이 바라보는 쪽의 반대 (^ ^ ^-  방향)
#   #dfo 1 : 철문이 바깥을 봄(성 지을 때 그대로 · 판자가 안쪽 가장자리) -> 문 가운데에서 안쪽 0.2칸부터
#   #dfo 0 : 철문이 안쪽을 봄(바깥에서 다시 단 문 · 판자가 바깥 가장자리) -> 문 가운데에서 바깥 0.4칸부터
scoreboard players set #dfo rpg.sys 1
execute if block ~ ~ ~ minecraft:iron_door[facing=north] if entity @e[type=minecraft:marker,tag=rpg_cag,distance=..0.8,y_rotation=-45..45] run scoreboard players set #dfo rpg.sys 0
execute if block ~ ~ ~ minecraft:iron_door[facing=east] if entity @e[type=minecraft:marker,tag=rpg_cag,distance=..0.8,y_rotation=45..135] run scoreboard players set #dfo rpg.sys 0
execute if block ~ ~ ~ minecraft:iron_door[facing=south] if entity @e[type=minecraft:marker,tag=rpg_cag,distance=..0.8,y_rotation=135..] run scoreboard players set #dfo rpg.sys 0
execute if block ~ ~ ~ minecraft:iron_door[facing=south] if entity @e[type=minecraft:marker,tag=rpg_cag,distance=..0.8,y_rotation=..-135] run scoreboard players set #dfo rpg.sys 0
execute if block ~ ~ ~ minecraft:iron_door[facing=west] if entity @e[type=minecraft:marker,tag=rpg_cag,distance=..0.8,y_rotation=-135..-45] run scoreboard players set #dfo rpg.sys 0
execute if score #dfo rpg.sys matches 1 as @e[type=minecraft:marker,tag=rpg_cag,distance=..0.8] if score @s rpg.cbid = #dci rpg.sys at @s positioned ^ ^ ^-100 if entity @a[tag=rpg_dclk,distance=..99.8] run scoreboard players set #din rpg.sys 1
execute if score #dfo rpg.sys matches 0 as @e[type=minecraft:marker,tag=rpg_cag,distance=..0.8] if score @s rpg.cbid = #dci rpg.sys at @s positioned ^ ^ ^-100 if entity @a[tag=rpg_dclk,distance=..100.4] run scoreboard players set #din rpg.sys 1
execute as @a[tag=rpg_dclk,limit=1] run function rpg:war/door_ask
tag @a[tag=rpg_dclk] remove rpg_dclk
data remove entity @s interaction

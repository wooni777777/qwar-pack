# 비밀번호 입력 중인데 철문에서 멀어짐 (v47 · 내부용 · as 플레이어) — 채팅을 밀어 올려 버튼을 못 누르게 · 입력 끝
tellraw @s {"text":"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"}
scoreboard players set @s rpg.pwm 0
scoreboard players set @s rpg.pwp 0
scoreboard players set @s rpg.pwd 0

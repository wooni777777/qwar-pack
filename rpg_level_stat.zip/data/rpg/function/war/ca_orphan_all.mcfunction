# 기록이 없는 성 표식 / 글자 / 철문 칸 치우기 (v43 · 10초마다)
scoreboard players set #orc rpg.sys 0
execute as @e[tag=rpg_ca,scores={rpg.cbid=1..}] run function rpg:war/ca_orphan

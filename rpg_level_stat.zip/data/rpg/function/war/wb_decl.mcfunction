# 선전포고 구매 (20,000원)
execute unless score @s money matches 20000.. run return run tellraw @s [{"text":"[전쟁 상점] ","color":"red","bold":true},{"text":"돈이 부족합니다. (20,000원)","color":"red"}]
scoreboard players remove @s money 20000
function rpg:war/dec_give
execute at @s run playsound minecraft:entity.villager.yes player @s ~ ~ ~ 1 1.2
return 1

# 사신수 무기 4종 전부 지급
function rpg:beast/give_azure
function rpg:beast/give_tiger
function rpg:beast/give_vermilion
function rpg:beast/give_heiwu

tellraw @s {"text":"━━━━━━━  사신수 무기  ━━━━━━━","color":"dark_gray"}
tellraw @s ["",{"text":"  /function rpg:beast/give_azure","color":"aqua"},{"text":"   청룡의 검","color":"gray"}]
tellraw @s ["",{"text":"  /function rpg:beast/give_tiger","color":"white"},{"text":"   백호의 도끼","color":"gray"}]
tellraw @s ["",{"text":"  /function rpg:beast/give_vermilion","color":"red"},{"text":"   주작의 단검","color":"gray"}]
tellraw @s ["",{"text":"  /function rpg:beast/give_heiwu","color":"dark_green"},{"text":"   현무의 창","color":"gray"}]
tellraw @s ["",{"text":"  /function rpg:beast/give_all","color":"green"},{"text":"      4종 전부","color":"gray"}]
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}

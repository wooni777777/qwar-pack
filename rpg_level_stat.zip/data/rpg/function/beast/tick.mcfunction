# 주작의 단검 - 들고 있는 동안 화염 면역
execute as @a if items entity @s weapon.mainhand *[minecraft:custom_data~{rpg_beast:3}] run effect give @s minecraft:fire_resistance 2 0 true

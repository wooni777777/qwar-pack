# 8월 크리스탈을 바닥에 떨군다
$summon minecraft:item ~ ~0.6 ~ {Item:{id:"minecraft:echo_shard",count:$(n),components:{"minecraft:custom_data":{rpg_crystal:8,rpg_bossdrop:1},"minecraft:item_model":"rpg:crystal_08","minecraft:item_name":{text:"8월 크리스탈",color:"yellow",bold:true},"minecraft:lore":[{text:"장비 상점에서 쓰는 재료",color:"gray",italic:false}],"minecraft:max_stack_size":64}}}

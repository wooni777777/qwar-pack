# 8월 크리스탈을 가장 가까운 플레이어에게 준다
$give @a[tag=rpg_rwd,limit=1] minecraft:echo_shard[minecraft:custom_data={rpg_crystal:8,rpg_bossdrop:1},minecraft:item_model="rpg:crystal_08",minecraft:item_name={text:"8월 크리스탈",color:"yellow",bold:true},minecraft:lore=[{text:"장비 상점에서 쓰는 재료",color:"gray",italic:false}],minecraft:max_stack_size=64] $(n)

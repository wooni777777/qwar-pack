# 종류 바꾸기 (0 없음 ~ 4 고정템 · 돌아감)
$scoreboard players add #ds$(b)$(s)k rpg.sys $(st)
$execute if score #ds$(b)$(s)k rpg.sys matches ..-1 run scoreboard players set #ds$(b)$(s)k rpg.sys 4
$execute if score #ds$(b)$(s)k rpg.sys matches 5.. run scoreboard players set #ds$(b)$(s)k rpg.sys 0
$execute if score #ds$(b)$(s)v rpg.sys matches ..0 run scoreboard players set #ds$(b)$(s)v rpg.sys 1

# 새로 소환된 몹에 레벨 배율을 적용한다 (as 몹) — v39 : 체력은 가짜 피(rpg.mmx) 에 적용
function rpg:mob/lv_get
# 배율(%) = 100 + (레벨 - 기본레벨) × 10
scoreboard players operation #mlm rpg.sys = #mlv rpg.sys
scoreboard players operation #mlm rpg.sys -= #mlb rpg.sys
scoreboard players operation #mlm rpg.sys *= #c10 rpg.sys
scoreboard players operation #mlm rpg.sys += #c100 rpg.sys
execute if score #mlm rpg.sys matches ..10 run scoreboard players set #mlm rpg.sys 10
execute if score #mlm rpg.sys matches 100 run return 0
# 최대체력 (가짜 피)
scoreboard players operation #mlh rpg.sys = @s rpg.mmx
scoreboard players operation #mlh rpg.sys *= #mlm rpg.sys
scoreboard players operation #mlh rpg.sys /= #c100 rpg.sys
execute if score #mlh rpg.sys matches ..1 run scoreboard players set #mlh rpg.sys 1
scoreboard players operation @s rpg.mmx = #mlh rpg.sys
scoreboard players operation @s rpg.mhp = #mlh rpg.sys
scoreboard players operation @s rpg.php = #mlh rpg.sys
# 공격력
scoreboard players set #mla rpg.sys 0
execute store result score #mla rpg.sys run attribute @s minecraft:attack_damage get 1
scoreboard players operation #mla rpg.sys *= #mlm rpg.sys
scoreboard players operation #mla rpg.sys /= #c100 rpg.sys
execute if score #mla rpg.sys matches ..1 run scoreboard players set #mla rpg.sys 1
execute store result storage rpg:mob lv.a int 1 run scoreboard players get #mla rpg.sys
function rpg:mob/lv_seta with storage rpg:mob lv

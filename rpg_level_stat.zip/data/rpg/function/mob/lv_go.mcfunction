# 새로 소환된 몹에 레벨 배율을 적용한다 (as 몹)
scoreboard players set #mlv rpg.sys 1
scoreboard players set #mlb rpg.sys 1
execute if entity @s[tag=rpg_m_ddol] run scoreboard players operation #mlv rpg.sys = #mlv_ddol rpg.sys
execute if entity @s[tag=rpg_m_ddol] run scoreboard players set #mlb rpg.sys 1
execute if entity @s[tag=rpg_m_ddodol] run scoreboard players operation #mlv rpg.sys = #mlv_ddodol rpg.sys
execute if entity @s[tag=rpg_m_ddodol] run scoreboard players set #mlb rpg.sys 3
execute if entity @s[tag=rpg_m_dolmengi] run scoreboard players operation #mlv rpg.sys = #mlv_dolmengi rpg.sys
execute if entity @s[tag=rpg_m_dolmengi] run scoreboard players set #mlb rpg.sys 5
execute if entity @s[tag=rpg_m_dol] run scoreboard players operation #mlv rpg.sys = #mlv_dol rpg.sys
execute if entity @s[tag=rpg_m_dol] run scoreboard players set #mlb rpg.sys 10
execute if entity @s[tag=rpg_m_wolf] run scoreboard players operation #mlv rpg.sys = #mlv_wolf rpg.sys
execute if entity @s[tag=rpg_m_wolf] run scoreboard players set #mlb rpg.sys 15
execute if entity @s[tag=rpg_m_pir1] run scoreboard players operation #mlv rpg.sys = #mlv_pir1 rpg.sys
execute if entity @s[tag=rpg_m_pir1] run scoreboard players set #mlb rpg.sys 8
execute if entity @s[tag=rpg_m_pir2] run scoreboard players operation #mlv rpg.sys = #mlv_pir2 rpg.sys
execute if entity @s[tag=rpg_m_pir2] run scoreboard players set #mlb rpg.sys 10
execute if entity @s[tag=rpg_m_pir3] run scoreboard players operation #mlv rpg.sys = #mlv_pir3 rpg.sys
execute if entity @s[tag=rpg_m_pir3] run scoreboard players set #mlb rpg.sys 9
execute if entity @s[tag=rpg_m_pking] run scoreboard players operation #mlv rpg.sys = #mlv_pking rpg.sys
execute if entity @s[tag=rpg_m_pking] run scoreboard players set #mlb rpg.sys 20
# 배율(%) = 100 + (레벨 - 기본레벨) × 10
scoreboard players operation #mlm rpg.sys = #mlv rpg.sys
scoreboard players operation #mlm rpg.sys -= #mlb rpg.sys
scoreboard players operation #mlm rpg.sys *= #c10 rpg.sys
scoreboard players operation #mlm rpg.sys += #c100 rpg.sys
execute if score #mlm rpg.sys matches ..10 run scoreboard players set #mlm rpg.sys 10
execute if score #mlm rpg.sys matches 100 run return 0
# 최대체력
scoreboard players set #mlh rpg.sys 0
execute store result score #mlh rpg.sys run attribute @s minecraft:max_health get 1
scoreboard players operation #mlh rpg.sys *= #mlm rpg.sys
scoreboard players operation #mlh rpg.sys /= #c100 rpg.sys
execute if score #mlh rpg.sys matches ..1 run scoreboard players set #mlh rpg.sys 1
# 공격력
scoreboard players set #mla rpg.sys 0
execute store result score #mla rpg.sys run attribute @s minecraft:attack_damage get 1
scoreboard players operation #mla rpg.sys *= #mlm rpg.sys
scoreboard players operation #mla rpg.sys /= #c100 rpg.sys
execute if score #mla rpg.sys matches ..1 run scoreboard players set #mla rpg.sys 1
execute store result storage rpg:mob lv.h int 1 run scoreboard players get #mlh rpg.sys
execute store result storage rpg:mob lv.a int 1 run scoreboard players get #mla rpg.sys
function rpg:mob/lv_set with storage rpg:mob lv
# 늑대에게 /data modify 를 쓰면 최대체력이 8 로 돌아가므로 즉시회복으로 채운다
execute unless entity @s[tag=rpg_m_wolf] store result entity @s Health float 1 run scoreboard players get #mlh rpg.sys
execute if entity @s[tag=rpg_m_wolf] run effect give @s minecraft:instant_health 1 40 true
scoreboard players operation @s rpg.php = #mlh rpg.sys

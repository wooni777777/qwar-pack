# 몹 설정 + 스폰 지점을 통째로 저장한다
data modify storage rpg:mobsave cfg set value {}
execute store result storage rpg:mobsave cfg.lv_ddol int 1 run scoreboard players get #mlv_ddol rpg.sys
execute store result storage rpg:mobsave cfg.lv_ddodol int 1 run scoreboard players get #mlv_ddodol rpg.sys
execute store result storage rpg:mobsave cfg.lv_dolmengi int 1 run scoreboard players get #mlv_dolmengi rpg.sys
execute store result storage rpg:mobsave cfg.lv_dol int 1 run scoreboard players get #mlv_dol rpg.sys
execute store result storage rpg:mobsave cfg.lv_wolf int 1 run scoreboard players get #mlv_wolf rpg.sys
execute store result storage rpg:mobsave cfg.lv_pir1 int 1 run scoreboard players get #mlv_pir1 rpg.sys
execute store result storage rpg:mobsave cfg.lv_pir2 int 1 run scoreboard players get #mlv_pir2 rpg.sys
execute store result storage rpg:mobsave cfg.lv_pir3 int 1 run scoreboard players get #mlv_pir3 rpg.sys
execute store result storage rpg:mobsave cfg.lv_pking int 1 run scoreboard players get #mlv_pking rpg.sys
execute store result storage rpg:mobsave cfg.n_d1 int 1 run scoreboard players get #dr_d1n rpg.sys
execute store result storage rpg:mobsave cfg.p_d1 int 1 run scoreboard players get #dr_d1p rpg.sys
execute store result storage rpg:mobsave cfg.n_d2 int 1 run scoreboard players get #dr_d2n rpg.sys
execute store result storage rpg:mobsave cfg.p_d2 int 1 run scoreboard players get #dr_d2p rpg.sys
execute store result storage rpg:mobsave cfg.n_d3 int 1 run scoreboard players get #dr_d3n rpg.sys
execute store result storage rpg:mobsave cfg.p_d3 int 1 run scoreboard players get #dr_d3p rpg.sys
execute store result storage rpg:mobsave cfg.n_d4 int 1 run scoreboard players get #dr_d4n rpg.sys
execute store result storage rpg:mobsave cfg.p_d4 int 1 run scoreboard players get #dr_d4p rpg.sys
execute store result storage rpg:mobsave cfg.n_w1 int 1 run scoreboard players get #dr_w1n rpg.sys
execute store result storage rpg:mobsave cfg.p_w1 int 1 run scoreboard players get #dr_w1p rpg.sys
execute store result storage rpg:mobsave cfg.n_w2 int 1 run scoreboard players get #dr_w2n rpg.sys
execute store result storage rpg:mobsave cfg.p_w2 int 1 run scoreboard players get #dr_w2p rpg.sys
execute store result storage rpg:mobsave cfg.n_k1 int 1 run scoreboard players get #dr_k1n rpg.sys
execute store result storage rpg:mobsave cfg.p_k1 int 1 run scoreboard players get #dr_k1p rpg.sys
execute store result storage rpg:mobsave cfg.n_k2 int 1 run scoreboard players get #dr_k2n rpg.sys
execute store result storage rpg:mobsave cfg.p_k2 int 1 run scoreboard players get #dr_k2p rpg.sys
execute store result storage rpg:mobsave cfg.n_k3 int 1 run scoreboard players get #dr_k3n rpg.sys
execute store result storage rpg:mobsave cfg.p_k3 int 1 run scoreboard players get #dr_k3p rpg.sys
execute store result storage rpg:mobsave cfg.n_k4 int 1 run scoreboard players get #dr_k4n rpg.sys
execute store result storage rpg:mobsave cfg.p_k4 int 1 run scoreboard players get #dr_k4p rpg.sys
execute store result storage rpg:mobsave cfg.n_k5 int 1 run scoreboard players get #dr_k5n rpg.sys
execute store result storage rpg:mobsave cfg.p_k5 int 1 run scoreboard players get #dr_k5p rpg.sys
execute store result storage rpg:mobsave cfg.n_k6 int 1 run scoreboard players get #dr_k6n rpg.sys
execute store result storage rpg:mobsave cfg.p_k6 int 1 run scoreboard players get #dr_k6p rpg.sys
data modify storage rpg:mobsave pts set value []
scoreboard players set #spn rpg.sys 0
execute as @e[type=minecraft:marker,tag=rpg_sp] run function rpg:mob/save_pt
tellraw @s ["",{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"몬스터 설정과 스폰 지점 ","color":"green"},{"score":{"name":"#spn","objective":"rpg.sys"},"color":"green","bold":true},{"text":"개를 저장했습니다.","color":"green"}]
playsound minecraft:block.note_block.pling player @s ~ ~ ~ 1 1.8

kill @e[type=minecraft:marker,tag=rpg_sp_pir3,distance=..8]
playsound minecraft:block.beacon.deactivate player @s ~ ~ ~ 1 1.6

# [몬스터] 메뉴 클릭 처리
execute unless entity @s[tag=op] run function rpg:menu/noperm
execute unless entity @s[tag=op] run scoreboard players set @s rpg.mob 0
execute unless entity @s[tag=op] run return 0
execute if score @s rpg.mob matches 1 run function rpg:mob/open
execute if score @s rpg.mob matches 2 run function rpg:mob/kill_all
execute if score @s rpg.mob matches 3 run function rpg:mob/save_all
execute if score @s rpg.mob matches 4 run function rpg:mob/load_all
execute if score @s rpg.mob matches 11 at @s run function rpg:mob/point_ddol
execute if score @s rpg.mob matches 31 at @s run function rpg:mob/prm_ddol
execute if score @s rpg.mob matches 51 at @s run function rpg:mob/ploc_ddol
execute if score @s rpg.mob matches 71 run function rpg:mob/lvdn_ddol
execute if score @s rpg.mob matches 91 run function rpg:mob/lvup_ddol
execute if score @s rpg.mob matches 131 at @s run function rpg:mob/now_ddol
execute if score @s rpg.mob matches 12 at @s run function rpg:mob/point_ddodol
execute if score @s rpg.mob matches 32 at @s run function rpg:mob/prm_ddodol
execute if score @s rpg.mob matches 52 at @s run function rpg:mob/ploc_ddodol
execute if score @s rpg.mob matches 72 run function rpg:mob/lvdn_ddodol
execute if score @s rpg.mob matches 92 run function rpg:mob/lvup_ddodol
execute if score @s rpg.mob matches 132 at @s run function rpg:mob/now_ddodol
execute if score @s rpg.mob matches 13 at @s run function rpg:mob/point_dolmengi
execute if score @s rpg.mob matches 33 at @s run function rpg:mob/prm_dolmengi
execute if score @s rpg.mob matches 53 at @s run function rpg:mob/ploc_dolmengi
execute if score @s rpg.mob matches 73 run function rpg:mob/lvdn_dolmengi
execute if score @s rpg.mob matches 93 run function rpg:mob/lvup_dolmengi
execute if score @s rpg.mob matches 133 at @s run function rpg:mob/now_dolmengi
execute if score @s rpg.mob matches 14 at @s run function rpg:mob/point_dol
execute if score @s rpg.mob matches 34 at @s run function rpg:mob/prm_dol
execute if score @s rpg.mob matches 54 at @s run function rpg:mob/ploc_dol
execute if score @s rpg.mob matches 74 run function rpg:mob/lvdn_dol
execute if score @s rpg.mob matches 94 run function rpg:mob/lvup_dol
execute if score @s rpg.mob matches 134 at @s run function rpg:mob/now_dol
execute if score @s rpg.mob matches 15 at @s run function rpg:mob/point_wolf
execute if score @s rpg.mob matches 35 at @s run function rpg:mob/prm_wolf
execute if score @s rpg.mob matches 55 at @s run function rpg:mob/ploc_wolf
execute if score @s rpg.mob matches 75 run function rpg:mob/lvdn_wolf
execute if score @s rpg.mob matches 95 run function rpg:mob/lvup_wolf
execute if score @s rpg.mob matches 135 at @s run function rpg:mob/now_wolf
execute if score @s rpg.mob matches 16 at @s run function rpg:mob/point_pir1
execute if score @s rpg.mob matches 36 at @s run function rpg:mob/prm_pir1
execute if score @s rpg.mob matches 56 at @s run function rpg:mob/ploc_pir1
execute if score @s rpg.mob matches 76 run function rpg:mob/lvdn_pir1
execute if score @s rpg.mob matches 96 run function rpg:mob/lvup_pir1
execute if score @s rpg.mob matches 136 at @s run function rpg:mob/now_pir1
execute if score @s rpg.mob matches 17 at @s run function rpg:mob/point_pir2
execute if score @s rpg.mob matches 37 at @s run function rpg:mob/prm_pir2
execute if score @s rpg.mob matches 57 at @s run function rpg:mob/ploc_pir2
execute if score @s rpg.mob matches 77 run function rpg:mob/lvdn_pir2
execute if score @s rpg.mob matches 97 run function rpg:mob/lvup_pir2
execute if score @s rpg.mob matches 137 at @s run function rpg:mob/now_pir2
execute if score @s rpg.mob matches 18 at @s run function rpg:mob/point_pir3
execute if score @s rpg.mob matches 38 at @s run function rpg:mob/prm_pir3
execute if score @s rpg.mob matches 58 at @s run function rpg:mob/ploc_pir3
execute if score @s rpg.mob matches 78 run function rpg:mob/lvdn_pir3
execute if score @s rpg.mob matches 98 run function rpg:mob/lvup_pir3
execute if score @s rpg.mob matches 138 at @s run function rpg:mob/now_pir3
execute if score @s rpg.mob matches 19 at @s run function rpg:mob/point_pking
execute if score @s rpg.mob matches 39 at @s run function rpg:mob/prm_pking
execute if score @s rpg.mob matches 59 at @s run function rpg:mob/ploc_pking
execute if score @s rpg.mob matches 79 run function rpg:mob/lvdn_pking
execute if score @s rpg.mob matches 99 run function rpg:mob/lvup_pking
execute if score @s rpg.mob matches 139 at @s run function rpg:mob/now_pking
execute if score @s rpg.mob matches 2..4 run function rpg:mob/open
scoreboard players set @s rpg.mob 0
scoreboard players enable @s rpg.mob

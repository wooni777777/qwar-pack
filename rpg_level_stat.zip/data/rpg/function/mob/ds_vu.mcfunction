# 값 다음 것으로 (내부용)
$scoreboard players operation #rk rpg.sys = #ds$(b)$(s)k rpg.sys
scoreboard players set #mmax rpg.sys 1
execute if score #rk rpg.sys matches 1 run scoreboard players set #mmax rpg.sys 8
execute if score #rk rpg.sys matches 2 run scoreboard players set #mmax rpg.sys 3
execute if score #rk rpg.sys matches 3 run scoreboard players set #mmax rpg.sys 12
$execute if score #rk rpg.sys matches 4 run scoreboard players set #mmax rpg.sys $(fx)
$scoreboard players add #ds$(b)$(s)v rpg.sys 1
$execute if score #ds$(b)$(s)v rpg.sys matches ..0 run scoreboard players operation #ds$(b)$(s)v rpg.sys = #mmax rpg.sys
$execute if score #ds$(b)$(s)v rpg.sys > #mmax rpg.sys run scoreboard players set #ds$(b)$(s)v rpg.sys 1

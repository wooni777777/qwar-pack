scoreboard players remove #mlv_pking rpg.sys 1
execute if score #mlv_pking rpg.sys matches ..0 run scoreboard players set #mlv_pking rpg.sys 1
function rpg:mob/open

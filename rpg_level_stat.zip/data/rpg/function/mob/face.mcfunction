# 모델을 몹이 보는 방향으로 돌린다 (내부용 · 바뀔 때만)
execute store result score #myaw rpg.sys run data get entity @s Rotation[0] 1
scoreboard players operation #myaw rpg.sys += #mfoff rpg.sys
execute if score #myaw rpg.sys = @s rpg.yaw run return 0
scoreboard players operation @s rpg.yaw = #myaw rpg.sys
execute store result storage rpg:main fc.y int 1 run scoreboard players get #myaw rpg.sys
execute on passengers if entity @s[tag=rpg_mdisp] run function rpg:mob/face_go with storage rpg:main fc

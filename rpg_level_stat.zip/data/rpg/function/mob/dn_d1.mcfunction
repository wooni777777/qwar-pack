scoreboard players remove #dr_d1n rpg.sys 1
execute if score #dr_d1n rpg.sys matches ..0 run scoreboard players set #dr_d1n rpg.sys 0
function rpg:mob/drop_d

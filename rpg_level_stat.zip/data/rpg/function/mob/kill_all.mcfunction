# 몬스터 · 모델 · 이름표 · 스폰 지점까지 전부 정리 (v37)
#   ※ [저장 불러오기] 를 누르면 저장해 둔 스폰 지점이 그대로 되살아납니다.
scoreboard players set #kn rpg.sys 0
execute store result score #kn rpg.sys if entity @e[type=minecraft:marker,tag=rpg_sp]
kill @e[tag=rpg_mob]
kill @e[tag=rpg_mdisp,tag=!rpg_preview]
kill @e[tag=rpg_mtext]
kill @e[tag=rpg_expchick]
kill @e[type=minecraft:marker,tag=rpg_sp]
tellraw @s ["",{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"몬스터 · 모델 · 이름표와 ","color":"white"},{"text":"스폰 지점 ","color":"red","bold":true},{"score":{"name":"#kn","objective":"rpg.sys"},"color":"red","bold":true},{"text":"개","color":"red","bold":true},{"text":" 까지 전부 지웠습니다.","color":"white"}]
tellraw @s ["",{"text":"   되살리려면 ","color":"dark_gray"},{"text":"[ 저장 불러오기 ]","color":"gold","bold":true,"click_event":{"action":"run_command","command":"trigger rpg.mob set 4"}},{"text":" 를 누르세요.","color":"dark_gray"}]
playsound minecraft:entity.generic.explode player @s ~ ~ ~ 0.4 1.6

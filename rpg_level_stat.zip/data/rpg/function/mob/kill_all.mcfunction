kill @e[tag=rpg_mob]
kill @e[tag=rpg_mdisp,tag=!rpg_preview]
kill @e[tag=rpg_mtext]
kill @e[tag=rpg_expchick]
execute as @e[type=minecraft:marker,tag=rpg_sp] run scoreboard players set @s rpg.cd 0
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"몬스터 / 모델 / 이름표를 모두 정리했습니다. (스폰 지점은 그대로)","color":"white"}]

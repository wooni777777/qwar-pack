data modify entity @s Health set value 1024.0f
scoreboard players set @s rpg.mlh 102400

# 잠꾸러기 늑대 처치 보상
give @s paper[minecraft:custom_data={rpg_bill:1000},minecraft:item_model="rpg:bill_4",minecraft:item_name={"text":"1000원","color":"aqua","bold":true},minecraft:lore=[{"text":"q후계자 전쟁 수표","color":"dark_gray","italic":false},{"text":"우클릭하면 소지금으로 들어갑니다","color":"gray","italic":false}],minecraft:consumable={consume_seconds:0.25f,animation:"none",sound:"minecraft:item.book.page_turn",has_consume_particles:false}] 1
function rpg:quest/chick500_1
execute at @s run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 0.8 1.5
tellraw @s ["",{"text":"[보스] ","color":"gold","bold":true},{"text":"잠꾸러기 늑대 처치 - 1000원 수표 · 경험치 닭(500)","color":"white"}]

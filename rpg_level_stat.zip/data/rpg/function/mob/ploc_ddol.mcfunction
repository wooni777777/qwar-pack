tag @s add rpg_lister
tellraw @s ["",{"text":"━━━━━  ","color":"dark_gray"},{"text":"똘","color":"gray","bold":true},{"text":"  스폰 지점  ━━━━━","color":"dark_gray"}]
execute as @e[type=minecraft:marker,tag=rpg_sp_ddol] at @s run function rpg:mob/point_l1
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}
tag @s remove rpg_lister

scoreboard players set #bh rpg.sys 0
execute store result score #bh rpg.sys run data get entity @s Health 1
execute store result score #bm rpg.sys run attribute @s minecraft:max_health get 1
execute unless score @s rpg.php matches 0.. run scoreboard players operation @s rpg.php = #bh rpg.sys
# 최근에 맞았으면 전투 상태 (5초)
execute if score #bh rpg.sys < @s rpg.php if score @s rpg.cbt matches ..2 run scoreboard players set @s rpg.cbt 3
execute if score @s rpg.cbt matches 1.. run scoreboard players remove @s rpg.cbt 1

# 회복량 = 최대체력 * (전투중 in% / 비전투 out%) / 100
scoreboard players operation #bhl rpg.sys = #bm rpg.sys
execute if score @s rpg.cbt matches 1.. run scoreboard players operation #bhl rpg.sys *= #boss_rg_in rpg.sys
execute if score @s rpg.cbt matches ..0 run scoreboard players operation #bhl rpg.sys *= #boss_rg_out rpg.sys
scoreboard players operation #bhl rpg.sys /= #c100 rpg.sys
# 해적 왕 : 2초마다 최대체력의 pk_rg % 회복 (전투/비전투 공통)
execute if entity @s[tag=rpg_m_pking] run scoreboard players operation #bhl rpg.sys = #bm rpg.sys
execute if entity @s[tag=rpg_m_pking] run scoreboard players operation #bhl rpg.sys *= #pk_rg rpg.sys
execute if entity @s[tag=rpg_m_pking] run scoreboard players operation #bhl rpg.sys /= #c100 rpg.sys
execute if score #bhl rpg.sys matches ..0 run scoreboard players set #bhl rpg.sys 1

scoreboard players operation #bnew rpg.sys = #bh rpg.sys
scoreboard players operation #bnew rpg.sys += #bhl rpg.sys
execute if score #bnew rpg.sys > #bm rpg.sys run scoreboard players operation #bnew rpg.sys = #bm rpg.sys
execute if score #bh rpg.sys matches 1.. if score #bnew rpg.sys > #bh rpg.sys unless entity @s[tag=rpg_m_wolf] store result entity @s Health float 1 run scoreboard players get #bnew rpg.sys
execute if score #bh rpg.sys matches 1.. if entity @s[tag=rpg_m_wolf] if score @s rpg.cbt matches 1.. run effect give @s minecraft:instant_health 1 3 true
execute if score #bh rpg.sys matches 1.. if entity @s[tag=rpg_m_wolf] if score @s rpg.cbt matches ..0 run effect give @s minecraft:instant_health 1 6 true
execute if score #bh rpg.sys matches 1.. if score #bnew rpg.sys > #bh rpg.sys run particle minecraft:happy_villager ~ ~1.4 ~ 0.6 0.8 0.6 0 12 normal @a
scoreboard players operation @s rpg.php = #bnew rpg.sys

# 화난 해적 를 지금 이 자리에 한 마리 소환 (스폰 지점 없음)
function rpg:mob/spawn_pir2
scoreboard players set @e[tag=rpg_new,limit=1,sort=nearest] rpg.sid -999
tag @e[tag=rpg_new] add rpg_nolea
execute as @e[tag=rpg_new,limit=1,sort=nearest] run function rpg:mob/lv_go
tag @e[tag=rpg_new] remove rpg_new
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"화난 해적","color":"red","bold":true},{"text":" 을(를) 이 자리에 소환했습니다.","color":"white"}]

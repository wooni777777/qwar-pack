scoreboard players enable @s rpg.mdr
scoreboard players enable @s rpg.mob
playsound minecraft:item.book.page_turn player @s ~ ~ ~ 1 1.2
tellraw @s " "
tellraw @s ["",{"text":"━━━━━  드롭템 설정 : ","color":"dark_gray"},{"text":"잠꾸러기 늑대","color":"gold","bold":true},{"text":"  ━━━━━","color":"dark_gray"}]
tellraw @s {"text":"   ◀ ▶ 로 종류와 값을 고르고, 개수와 확률을 정합니다. 종류가 [없음] 이면 안 나옵니다.","color":"dark_gray"}
tellraw @s {"text":"   종류 : 없음 / 돈 수표 / 경험치 닭 / 크리스탈 / 고정템","color":"dark_gray"}
tellraw @s " "
data modify storage rpg:mob r set value {b:"w",s:1,bn:2}
function rpg:mob/ds_row with storage rpg:mob r
data modify storage rpg:mob r.s set value 2
data modify storage rpg:mob r.b set value "w"
data modify storage rpg:mob r.bn set value 2
function rpg:mob/ds_row with storage rpg:mob r
data modify storage rpg:mob r.s set value 3
data modify storage rpg:mob r.b set value "w"
data modify storage rpg:mob r.bn set value 2
function rpg:mob/ds_row with storage rpg:mob r
data modify storage rpg:mob r.s set value 4
data modify storage rpg:mob r.b set value "w"
data modify storage rpg:mob r.bn set value 2
function rpg:mob/ds_row with storage rpg:mob r
data modify storage rpg:mob r.s set value 5
data modify storage rpg:mob r.b set value "w"
data modify storage rpg:mob r.bn set value 2
function rpg:mob/ds_row with storage rpg:mob r
data modify storage rpg:mob r.s set value 6
data modify storage rpg:mob r.b set value "w"
data modify storage rpg:mob r.bn set value 2
function rpg:mob/ds_row with storage rpg:mob r
data modify storage rpg:mob r.s set value 7
data modify storage rpg:mob r.b set value "w"
data modify storage rpg:mob r.bn set value 2
function rpg:mob/ds_row with storage rpg:mob r
data modify storage rpg:mob r.s set value 8
data modify storage rpg:mob r.b set value "w"
data modify storage rpg:mob r.bn set value 2
function rpg:mob/ds_row with storage rpg:mob r
tellraw @s " "
tellraw @s ["", {"text": "   "}, {"text": "[ 저장 ]", "color": "green", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.mdr set 1"}, "hover_event": {"action": "show_text", "value": {"text": "지금 설정을 저장합니다 (몹 레벨 · 스폰 지점 포함)", "color": "gray"}}}, {"text": "   "}, {"text": "[ 뒤로 ]", "color": "aqua", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.mob set 1"}}]
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}

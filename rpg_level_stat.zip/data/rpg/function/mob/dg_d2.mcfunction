# 돌 - 경험치 조각
$summon minecraft:item ~ ~0.6 ~ {Item:{id:"minecraft:amethyst_shard",count:$(n),components:{"minecraft:custom_data":{rpg_exp:1},"minecraft:item_name":{text:"경험치 조각",color:"green",bold:true},"minecraft:lore":[{text:"1개당 경험치 10",color:"gray",italic:false},{text:"가까이 가면 자동으로 흡수됩니다",color:"dark_gray",italic:false}],"minecraft:enchantment_glint_override":true}}}

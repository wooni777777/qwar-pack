# 해적 왕의 핵 n개 지급 (v41 · function rpg:mob/core_give_pking {n:1})
$give @s minecraft:paper[minecraft:custom_data={rpg_core:"pking"},minecraft:item_model="rpg:core_pking",minecraft:item_name={text:"해적 왕의 핵",color:"dark_red",bold:true},minecraft:lore=[{text:"필드 보스 [해적 왕] 의 보석",color:"gray",italic:false}]] $(n)

execute if score @s rpg.sid > #spid rpg.sys run scoreboard players operation #spid rpg.sys = @s rpg.sid

kill @e[type=minecraft:marker,tag=rpg_sp_dol,distance=..8]
playsound minecraft:block.beacon.deactivate player @s ~ ~ ~ 1 1.6

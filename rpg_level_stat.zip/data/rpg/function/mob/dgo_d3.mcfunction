execute store result storage rpg:mob dr.n int 1 run scoreboard players get #dr_d3n rpg.sys
function rpg:mob/dg_d3 with storage rpg:mob dr

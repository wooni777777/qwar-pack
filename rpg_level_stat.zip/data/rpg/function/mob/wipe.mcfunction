tag @e[tag=rpg_mob] add rpg_paid
tag @e[tag=rpg_mob] add rpg_dead
kill @e[tag=rpg_mob]
kill @e[tag=rpg_mdisp]
kill @e[tag=rpg_mtext]
kill @e[type=minecraft:marker,tag=rpg_sp]
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"불러온 청크의 몬스터와 스폰 지점을 전부 제거했습니다.","color":"red"}]

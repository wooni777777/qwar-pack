# 돌의 핵 를 가장 가까운 플레이어에게 준다
$give @a[tag=rpg_rwd,limit=1] minecraft:nether_star[minecraft:custom_data={rpg_bossdrop:1},minecraft:item_name={text:"돌의 핵",color:"aqua",bold:true},minecraft:lore=[{text:"하위 보스 [돌] 이 남긴 결정",color:"gray",italic:false}],minecraft:enchantment_glint_override=true] $(n)

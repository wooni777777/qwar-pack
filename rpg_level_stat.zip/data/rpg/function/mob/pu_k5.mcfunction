scoreboard players add #dr_k5p rpg.sys 5
execute if score #dr_k5p rpg.sys matches 100.. run scoreboard players set #dr_k5p rpg.sys 100
function rpg:mob/drop_k

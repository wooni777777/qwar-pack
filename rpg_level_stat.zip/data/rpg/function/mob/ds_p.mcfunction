# 확률 바꾸기 (0 ~ 100 · 5씩)
$scoreboard players add #ds$(b)$(s)p rpg.sys $(p)
$execute if score #ds$(b)$(s)p rpg.sys matches ..-1 run scoreboard players set #ds$(b)$(s)p rpg.sys 0
$execute if score #ds$(b)$(s)p rpg.sys matches 101.. run scoreboard players set #ds$(b)$(s)p rpg.sys 100

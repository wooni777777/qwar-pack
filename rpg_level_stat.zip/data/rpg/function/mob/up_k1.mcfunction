scoreboard players add #dr_k1n rpg.sys 1
execute if score #dr_k1n rpg.sys matches 64.. run scoreboard players set #dr_k1n rpg.sys 64
function rpg:mob/drop_k

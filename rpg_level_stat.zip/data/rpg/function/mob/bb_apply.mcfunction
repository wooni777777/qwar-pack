$data modify entity @s billboard set value "$(v)"
data modify entity @s Rotation set value [0.0f,0.0f]
tag @s remove rpg_bbnew

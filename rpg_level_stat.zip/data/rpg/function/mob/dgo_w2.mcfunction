execute store result storage rpg:mob dr.n int 1 run scoreboard players get #dr_w2n rpg.sys
function rpg:mob/dg_w2 with storage rpg:mob dr

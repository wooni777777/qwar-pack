# 해적 왕 몸 (v39 · 내부용 · 소환 직후 rpg_new 에게)
#   머리 슬롯 = 3D 머리 모델 (고개를 돌리면 같이 돕니다)
#   가슴 = 몸통 + 두 팔 (장비 레이어)  /  바지 = 두 다리 (장비 레이어)
#   본체가 투명이어도 입힌 장비는 보이기 때문에, 스켈레톤이 걷고 팔을 휘두르는 대로 똑같이 움직입니다.
item replace entity @e[tag=rpg_new,limit=1] armor.head with minecraft:paper[minecraft:item_model="rpg:pir_king_head"]
item replace entity @e[tag=rpg_new,limit=1] armor.chest with minecraft:paper[minecraft:item_model="rpg:empty",minecraft:equippable={slot:"chest",asset_id:"rpg:mob_pir_king"}]
item replace entity @e[tag=rpg_new,limit=1] armor.legs with minecraft:paper[minecraft:item_model="rpg:empty",minecraft:equippable={slot:"legs",asset_id:"rpg:mob_pir_king"}]

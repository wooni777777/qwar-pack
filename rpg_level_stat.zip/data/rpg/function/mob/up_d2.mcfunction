scoreboard players add #dr_d2n rpg.sys 1
execute if score #dr_d2n rpg.sys matches 64.. run scoreboard players set #dr_d2n rpg.sys 64
function rpg:mob/drop_d

# 화난 해적  |  체력 170 / 공격력 20 / 이동속도 0.3   (이 숫자만 고치면 됩니다)
# 모델 높이가 어긋나면 item_display 의 translation 두 번째 숫자 (-1.038) 를 조절하세요.
# 이름표 높이는 text_display 의 translation 두 번째 숫자 (0.682) 입니다.
summon minecraft:skeleton ~ ~ ~ {Tags:["rpg_mob","rpg_m_pir2","rpg_new"],CustomName:{text:"화난 해적",color:"red",bold:true},CustomNameVisible:0b,PersistenceRequired:1b,Silent:1b,CanPickUpLoot:0b,DeathLootTable:"minecraft:empty",Passengers:[{id:"minecraft:item_display",Tags:["rpg_mdisp","rpg_hum"],Rotation:[0.0f,0.0f],item:{id:"minecraft:stone",count:1,components:{"minecraft:item_model":"rpg:pir_rage"}},item_display:"fixed",billboard:"fixed",view_range:1.8f,shadow_radius:0.42f,shadow_strength:0.6f,transformation:{translation:[0.0f,-1.038f,0.0f],left_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.05f,1.05f,1.05f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}},{id:"minecraft:text_display",Tags:["rpg_mtext"],Rotation:[0.0f,0.0f],billboard:"center",alignment:"center",see_through:false,background:1073741824,view_range:1.5f,text:{text:"화난 해적",color:"red",bold:true},transformation:{translation:[0.0f,0.682f,0.0f],left_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}]}
effect give @e[tag=rpg_new] minecraft:invisibility infinite 0 true
attribute @e[tag=rpg_new,limit=1] minecraft:max_health base set 170
attribute @e[tag=rpg_new,limit=1] minecraft:attack_damage base set 20
attribute @e[tag=rpg_new,limit=1] minecraft:movement_speed base set 0.3
attribute @e[tag=rpg_new,limit=1] minecraft:follow_range base set 26
attribute @e[tag=rpg_new,limit=1] minecraft:knockback_resistance base set 0.3
attribute @e[tag=rpg_new,limit=1] minecraft:scale base set 1.05
# 햇빛 화상 방지용 투명 아이템
item replace entity @e[tag=rpg_new,limit=1] armor.head with minecraft:carrot[minecraft:item_model="rpg:empty"]
data modify entity @e[tag=rpg_new,limit=1] drop_chances set value {head:0.0f,chest:0.0f,legs:0.0f,feet:0.0f,mainhand:0.0f,offhand:0.0f}
data modify entity @e[tag=rpg_new,limit=1] Health set value 170.0f
scoreboard players set @e[tag=rpg_new,limit=1] rpg.php 170
scoreboard players set @e[tag=rpg_new,limit=1] rpg.cbt 0
particle minecraft:poof ~ ~0.6 ~ 0.3 0.4 0.3 0.01 8 normal @a
playsound minecraft:entity.pillager.ambient hostile @a ~ ~ ~ 0.9 0.7

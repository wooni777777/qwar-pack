$execute as @a[distance=..3.5,gamemode=!spectator] run damage @s $(d) minecraft:mob_attack by @e[tag=rpg_pkcur,limit=1]

execute unless entity @e[tag=rpg_keep] run tag @s add rpg_keep

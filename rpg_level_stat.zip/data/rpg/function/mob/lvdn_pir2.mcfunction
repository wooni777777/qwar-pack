scoreboard players remove #mlv_pir2 rpg.sys 1
execute if score #mlv_pir2 rpg.sys matches ..0 run scoreboard players set #mlv_pir2 rpg.sys 1
function rpg:mob/open

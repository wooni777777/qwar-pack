data modify storage rpg:mobsave one set value {t:"ddol"}
execute if entity @s[tag=rpg_sp_ddol] run data modify storage rpg:mobsave one.t set value "ddol"
execute if entity @s[tag=rpg_sp_ddodol] run data modify storage rpg:mobsave one.t set value "ddodol"
execute if entity @s[tag=rpg_sp_dolmengi] run data modify storage rpg:mobsave one.t set value "dolmengi"
execute if entity @s[tag=rpg_sp_dol] run data modify storage rpg:mobsave one.t set value "dol"
execute if entity @s[tag=rpg_sp_wolf] run data modify storage rpg:mobsave one.t set value "wolf"
execute if entity @s[tag=rpg_sp_pir1] run data modify storage rpg:mobsave one.t set value "pir1"
execute if entity @s[tag=rpg_sp_pir2] run data modify storage rpg:mobsave one.t set value "pir2"
execute if entity @s[tag=rpg_sp_pir3] run data modify storage rpg:mobsave one.t set value "pir3"
execute if entity @s[tag=rpg_sp_pking] run data modify storage rpg:mobsave one.t set value "pking"
data modify storage rpg:mobsave one.x set from entity @s Pos[0]
data modify storage rpg:mobsave one.y set from entity @s Pos[1]
data modify storage rpg:mobsave one.z set from entity @s Pos[2]
data modify storage rpg:mobsave pts append from storage rpg:mobsave one
scoreboard players add #spn rpg.sys 1

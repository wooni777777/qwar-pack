$data modify entity @s Rotation set value [$(y)f,0.0f]

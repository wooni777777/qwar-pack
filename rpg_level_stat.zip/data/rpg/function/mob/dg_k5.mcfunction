# 해적 왕 - 네더별 (추가)
$summon minecraft:item ~ ~0.6 ~ {Item:{id:"minecraft:nether_star",count:$(n)}}

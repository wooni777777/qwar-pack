# 돌 드롭 (개수·확률은 [드롭템 설정] 에서 조절)
scoreboard players set #dr rpg.sys 0
execute store result score #dr rpg.sys run random value 1..100
execute if score #dr rpg.sys <= #dr_d1p rpg.sys if score #dr_d1n rpg.sys matches 1.. run function rpg:mob/dgo_d1
scoreboard players set #dr rpg.sys 0
execute store result score #dr rpg.sys run random value 1..100
execute if score #dr rpg.sys <= #dr_d2p rpg.sys if score #dr_d2n rpg.sys matches 1.. run function rpg:mob/dgo_d2
scoreboard players set #dr rpg.sys 0
execute store result score #dr rpg.sys run random value 1..100
execute if score #dr rpg.sys <= #dr_d3p rpg.sys if score #dr_d3n rpg.sys matches 1.. run function rpg:mob/dgo_d3
scoreboard players set #dr rpg.sys 0
execute store result score #dr rpg.sys run random value 1..100
execute if score #dr rpg.sys <= #dr_d4p rpg.sys if score #dr_d4n rpg.sys matches 1.. run function rpg:mob/dgo_d4

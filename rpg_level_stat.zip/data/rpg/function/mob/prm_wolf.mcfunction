kill @e[type=minecraft:marker,tag=rpg_sp_wolf,distance=..8]
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"잠꾸러기 늑대","color":"gold","bold":true},{"text":" 스폰 지점을 8칸 안에서 제거했습니다.","color":"white"}]
playsound minecraft:block.beacon.deactivate player @s ~ ~ ~ 1 1.6

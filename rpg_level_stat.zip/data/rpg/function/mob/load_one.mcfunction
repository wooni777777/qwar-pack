$execute positioned $(x) $(y) $(z) run function rpg:mob/sp_$(t)

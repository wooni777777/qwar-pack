scoreboard players add #mlv_dol rpg.sys 1
execute if score #mlv_dol rpg.sys matches 200.. run scoreboard players set #mlv_dol rpg.sys 200
function rpg:mob/open

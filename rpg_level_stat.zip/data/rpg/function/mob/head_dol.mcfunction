# (v39) 몸 입히기로 바뀌었습니다
function rpg:mob/gear_dol

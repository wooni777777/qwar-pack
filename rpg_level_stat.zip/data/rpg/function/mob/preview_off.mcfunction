kill @e[tag=rpg_preview]
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"모델 미리보기를 치웠습니다.","color":"white"}]

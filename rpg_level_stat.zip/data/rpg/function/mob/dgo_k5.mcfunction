execute store result storage rpg:mob dr.n int 1 run scoreboard players get #dr_k5n rpg.sys
function rpg:mob/dg_k5 with storage rpg:mob dr

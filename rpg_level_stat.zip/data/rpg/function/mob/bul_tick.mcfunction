# 총알 1틱 (v41 · as 총알 at 총알) — 0.5칸씩 3번 = 1틱에 1.5칸
#   #bhit : 0 날아가는 중 / 1 맞춤 / 2 벽 (kill 한 뒤에도 @s 는 잡히므로 이 값으로 멈춥니다)
scoreboard players set #bhit rpg.sys 0
scoreboard players remove @s rpg.cd 1
scoreboard players set #bst rpg.sys 3
function rpg:mob/bul_move
execute if score #bhit rpg.sys matches 0 if score @s rpg.cd matches ..0 run kill @s

# 잠꾸러기 늑대  |  체력 2500 / 공격력 34 / 이동속도 0.33   (이 숫자만 고치면 됩니다)
# 주의 : 늑대에게 /data modify 를 쓰면 마인크래프트가 최대 체력을 8 로 되돌립니다.
#        그래서 체력은 반드시 attribute + 즉시회복 으로만 다룹니다.
summon minecraft:wolf ~ ~ ~ {Tags:["rpg_mob","rpg_m_wolf","rpg_boss","rpg_new"],CustomName:{text:"잠꾸러기 늑대",color:"gold",bold:true},CustomNameVisible:0b,PersistenceRequired:1b,CanPickUpLoot:0b,DeathLootTable:"minecraft:empty",Passengers:[{id:"minecraft:text_display",Tags:["rpg_mtext"],Rotation:[0.0f,0.0f],billboard:"center",alignment:"center",see_through:false,background:1073741824,view_range:1.5f,text:{text:"잠꾸러기 늑대",color:"gold",bold:true},transformation:{translation:[0.0f,0.55f,0.0f],left_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}]}
attribute @e[tag=rpg_new,limit=1] minecraft:max_health base set 2500
attribute @e[tag=rpg_new,limit=1] minecraft:attack_damage base set 34
attribute @e[tag=rpg_new,limit=1] minecraft:movement_speed base set 0.33
attribute @e[tag=rpg_new,limit=1] minecraft:follow_range base set 40
attribute @e[tag=rpg_new,limit=1] minecraft:knockback_resistance base set 0.9
attribute @e[tag=rpg_new,limit=1] minecraft:scale base set 2.2
effect give @e[tag=rpg_new] minecraft:instant_health 1 12 true
scoreboard players set @e[tag=rpg_new,limit=1] rpg.php 2500
scoreboard players set @e[tag=rpg_new,limit=1] rpg.cbt 0
particle minecraft:poof ~ ~0.5 ~ 0.4 0.4 0.4 0.03 12 normal @a
playsound minecraft:entity.wolf.growl hostile @a ~ ~ ~ 1.4 0.5
# 태어나자마자 화난 상태로
execute as @e[tag=rpg_new,limit=1] at @s run function rpg:mob/wolf_anger

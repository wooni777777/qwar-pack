scoreboard players remove #mlv_ddodol rpg.sys 1
execute if score #mlv_ddodol rpg.sys matches ..0 run scoreboard players set #mlv_ddodol rpg.sys 1
function rpg:mob/open

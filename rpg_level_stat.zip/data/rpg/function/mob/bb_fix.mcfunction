# 이미 세상에 있는 모델의 방향을 설정값에 맞춘다 (내부용)
$execute as @e[tag=rpg_mdisp,tag=!rpg_preview] unless data entity @s {billboard:"$(v)"} run data modify entity @s billboard set value "$(v)"

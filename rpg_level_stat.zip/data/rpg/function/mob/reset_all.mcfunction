# 겹쳐 쌓인 몹 / 모델 / 이름표를 전부 지웁니다. 스폰 지점은 그대로 두므로 곧 다시 스폰됩니다.
kill @e[tag=rpg_mob]
kill @e[tag=rpg_mdisp,tag=!rpg_preview]
kill @e[tag=rpg_mtext]
execute as @e[type=minecraft:marker,tag=rpg_sp] run function rpg:mob/spid_max
execute as @e[type=minecraft:marker,tag=rpg_sp] run scoreboard players set @s rpg.cd 0

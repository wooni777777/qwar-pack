scoreboard players remove #dr_k4p rpg.sys 5
execute if score #dr_k4p rpg.sys matches ..0 run scoreboard players set #dr_k4p rpg.sys 0
function rpg:mob/drop_k

scoreboard players add #mlv_ddodol rpg.sys 1
execute if score #mlv_ddodol rpg.sys matches 200.. run scoreboard players set #mlv_ddodol rpg.sys 200
function rpg:mob/open

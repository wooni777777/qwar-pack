# 종류 다음 것으로 (내부용)
$scoreboard players add #ds$(b)$(s)k rpg.sys 1
$execute if score #ds$(b)$(s)k rpg.sys matches ..-1 run scoreboard players set #ds$(b)$(s)k rpg.sys 4
$execute if score #ds$(b)$(s)k rpg.sys matches 5.. run scoreboard players set #ds$(b)$(s)k rpg.sys 0
$execute if score #ds$(b)$(s)v rpg.sys matches ..0 run scoreboard players set #ds$(b)$(s)v rpg.sys 1

# 지금 자리에서 부딪힌 것이 있는지 본다 (내부용)
particle minecraft:crit ~ ~ ~ 0.08 0.08 0.08 0 2 normal @a
execute if entity @a[distance=..2.2,gamemode=!spectator] run function rpg:mob/rock_hit
execute if entity @s if entity @e[distance=..2.2,tag=!rpg_mob,tag=!rpg_rock,tag=!rpg_model,tag=!rpg_mtext,tag=!rpg_npcE,tag=!god,type=!minecraft:marker,type=!minecraft:item_display,type=!minecraft:text_display,type=!minecraft:block_display,type=!minecraft:interaction,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:player] run function rpg:mob/rock_hit
execute if entity @s unless block ~ ~ ~ #rpg:pass run function rpg:mob/rock_end

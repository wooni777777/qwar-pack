particle minecraft:crit ~ ~ ~ 0.08 0.08 0.08 0 2 normal @a
scoreboard players remove @s rpg.cd 1
execute if entity @a[distance=..1.7,gamemode=!spectator] run function rpg:mob/rock_hit
execute if entity @s unless block ~ ~ ~ #minecraft:replaceable run function rpg:mob/rock_end
execute if entity @s[tag=rpg_rock] if score @s rpg.cd matches ..0 run function rpg:mob/rock_end

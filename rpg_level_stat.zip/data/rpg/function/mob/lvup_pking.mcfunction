scoreboard players add #mlv_pking rpg.sys 1
execute if score #mlv_pking rpg.sys matches 200.. run scoreboard players set #mlv_pking rpg.sys 200
function rpg:mob/open

scoreboard players set #btimer rpg.sys 0
execute as @e[tag=rpg_boss,tag=!rpg_dead] at @s run function rpg:mob/boss_tick
execute as @e[tag=rpg_m_dol,tag=!rpg_dead] at @s run function rpg:mob/boss_rock

data modify storage rpg:main bb.v set value "fixed"
execute as @e[tag=rpg_mdisp] run data modify entity @s billboard set value "fixed"
execute as @e[tag=rpg_mdisp] run data modify entity @s Rotation set value [0.0f,0.0f]
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"모델 방향 : ","color":"white"},{"text":"fixed","color":"aqua","bold":true},{"text":" - 회전하지 않고 완전히 고정","color":"gray"}]

# 돌 고정템 값에 맞는 아이템을 고른다 (내부용)
execute if score #rv rpg.sys matches 1 run function rpg:mob/dsp_fx_d1 with storage rpg:mob g
execute if score #rv rpg.sys matches 2 run function rpg:mob/dsp_fx_d2 with storage rpg:mob g

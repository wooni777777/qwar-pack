function rpg:mob/sp_dol
playsound minecraft:block.beacon.activate player @s ~ ~ ~ 1 1.6

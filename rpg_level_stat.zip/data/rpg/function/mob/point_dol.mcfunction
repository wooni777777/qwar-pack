function rpg:mob/sp_dol
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"돌","color":"dark_red","bold":true},{"text":" 스폰 지점을 이 자리에 만들었습니다.","color":"white"}]
playsound minecraft:block.beacon.activate player @s ~ ~ ~ 1 1.6

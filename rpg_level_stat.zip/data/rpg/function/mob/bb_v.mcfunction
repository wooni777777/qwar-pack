data modify storage rpg:main bb.v set value "vertical"
execute as @e[tag=rpg_mdisp,tag=!rpg_hum] run data modify entity @s billboard set value "vertical"
execute as @e[tag=rpg_mdisp,tag=!rpg_hum] run data modify entity @s Rotation set value [0.0f,0.0f]
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"모델 방향 : ","color":"white"},{"text":"vertical","color":"aqua","bold":true},{"text":" - 좌우만 따라감 - 엔티티 각도 때문에 누울 수 있음","color":"gray"}]

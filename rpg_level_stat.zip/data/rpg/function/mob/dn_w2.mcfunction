scoreboard players remove #dr_w2n rpg.sys 1
execute if score #dr_w2n rpg.sys matches ..0 run scoreboard players set #dr_w2n rpg.sys 0
function rpg:mob/drop_w

$attribute @s minecraft:attack_damage base set $(a)

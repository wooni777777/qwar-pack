# ── 몬스터 모델이 뒤돌아 보이면 이걸 한 번 누르세요 ──
#   function rpg:mob/face_flip
#   모델 앞뒤를 180도 뒤집습니다. 다시 누르면 원래대로.
scoreboard players add #mfoff rpg.sys 180
execute if score #mfoff rpg.sys matches 360.. run scoreboard players set #mfoff rpg.sys 0
scoreboard players set @e[tag=rpg_mob] rpg.yaw 99999
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"몬스터 모델 앞뒤를 뒤집었습니다. (지금 값 ","color":"white"},{"score":{"name":"#mfoff","objective":"rpg.sys"},"color":"yellow","bold":true},{"text":"도)","color":"white"}]
return 1

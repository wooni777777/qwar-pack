# 2초마다 가장 가까운 플레이어에게 돌을 던진다 (근접 평타와 동시에 나갑니다)
execute if entity @a[distance=..26,gamemode=!spectator] run function rpg:mob/rock_throw

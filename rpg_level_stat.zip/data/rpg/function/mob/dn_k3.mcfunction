scoreboard players remove #dr_k3n rpg.sys 1
execute if score #dr_k3n rpg.sys matches ..0 run scoreboard players set #dr_k3n rpg.sys 0
function rpg:mob/drop_k

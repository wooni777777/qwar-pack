scoreboard players add #dr_d1p rpg.sys 5
execute if score #dr_d1p rpg.sys matches 100.. run scoreboard players set #dr_d1p rpg.sys 100
function rpg:mob/drop_d

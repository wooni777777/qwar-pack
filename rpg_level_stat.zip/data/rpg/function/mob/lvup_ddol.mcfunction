scoreboard players add #mlv_ddol rpg.sys 1
execute if score #mlv_ddol rpg.sys matches 200.. run scoreboard players set #mlv_ddol rpg.sys 200
function rpg:mob/open

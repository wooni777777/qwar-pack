tag @s add rpg_dead
function rpg:mob/anim_die
particle minecraft:poof ~ ~0.6 ~ 0.35 0.4 0.35 0.03 30 normal @a
particle minecraft:crit ~ ~0.6 ~ 0.35 0.4 0.35 0.2 25 normal @a
playsound minecraft:block.stone.break block @a ~ ~ ~ 1 0.7
execute if entity @s[tag=rpg_m_ddol] run loot spawn ~ ~0.4 ~ loot rpg:mob/drop_ddol
execute if entity @s[tag=rpg_m_ddodol] run loot spawn ~ ~0.4 ~ loot rpg:mob/drop_ddodol
execute if entity @s[tag=rpg_m_dolmengi] run loot spawn ~ ~0.4 ~ loot rpg:mob/drop_dolmengi
execute if entity @s[tag=rpg_m_dol] run function rpg:mob/drop2_d
execute if entity @s[tag=rpg_m_dol] at @s run function rpg:hid/h2_boss1
execute if entity @s[tag=rpg_m_wolf] run function rpg:mob/drop2_w
execute if entity @s[tag=rpg_m_wolf] at @s run function rpg:hid/h2_boss3
execute if entity @s[tag=rpg_m_wolf] run playsound minecraft:entity.wolf.death master @a ~ ~ ~ 1 0.6
execute if entity @s[tag=rpg_m_wolf] run tellraw @a[distance=..80] [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"잠꾸러기 늑대","color":"gold","bold":true},{"text":" 이(가) 쓰러졌다!","color":"white"}]
execute if entity @s[tag=rpg_m_pir1] run loot spawn ~ ~0.4 ~ loot rpg:mob/drop_pirate
execute if entity @s[tag=rpg_m_pir1] run playsound minecraft:entity.pillager.death master @a ~ ~ ~ 1 0.9
execute if entity @s[tag=rpg_m_pir2] run loot spawn ~ ~0.4 ~ loot rpg:mob/drop_pirate
execute if entity @s[tag=rpg_m_pir2] run playsound minecraft:entity.pillager.death master @a ~ ~ ~ 1 0.9
execute if entity @s[tag=rpg_m_pir3] run loot spawn ~ ~0.4 ~ loot rpg:mob/drop_pirate
execute if entity @s[tag=rpg_m_pir3] run playsound minecraft:entity.pillager.death master @a ~ ~ ~ 1 0.9
execute if entity @s[tag=rpg_m_pking] run function rpg:mob/drop2_k
execute if entity @s[tag=rpg_m_pking] at @s as @e[tag=rpg_minion,tag=!rpg_dead,distance=..48] run function rpg:mob/rm_mob
execute if entity @s[tag=rpg_m_pking] run playsound minecraft:entity.wither.death master @a ~ ~ ~ 1 0.9
execute if entity @s[tag=rpg_m_pking] run tellraw @a[distance=..80] [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"해적 왕","color":"dark_red","bold":true},{"text":" 이(가) 쓰러졌다!","color":"white"}]
execute if entity @s[tag=rpg_m_pir1] run loot spawn ~ ~0.4 ~ loot rpg:mob/drop_pirate
execute if entity @s[tag=rpg_m_pir1] run playsound minecraft:entity.pillager.death master @a ~ ~ ~ 1 0.9
execute if entity @s[tag=rpg_m_pir2] run loot spawn ~ ~0.4 ~ loot rpg:mob/drop_pirate
execute if entity @s[tag=rpg_m_pir2] run playsound minecraft:entity.pillager.death master @a ~ ~ ~ 1 0.9
execute if entity @s[tag=rpg_m_pir3] run loot spawn ~ ~0.4 ~ loot rpg:mob/drop_pirate
execute if entity @s[tag=rpg_m_pir3] run playsound minecraft:entity.pillager.death master @a ~ ~ ~ 1 0.9
execute if entity @s[tag=rpg_m_pking] run function rpg:mob/drop2_k
execute if entity @s[tag=rpg_m_pking] at @s as @e[tag=rpg_minion,tag=!rpg_dead,distance=..48] run function rpg:mob/rm_mob
execute if entity @s[tag=rpg_m_pking] run playsound minecraft:entity.wither.death master @a ~ ~ ~ 1 0.9
execute if entity @s[tag=rpg_m_pking] run tellraw @a[distance=..80] [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"해적 왕","color":"dark_red","bold":true},{"text":" 이(가) 쓰러졌다!","color":"white"}]
# 보스가 떨군 아이템은 사방으로 흩뿌린다
execute if entity @s[tag=rpg_boss] run function rpg:mob/scatter_all
execute if entity @s[tag=rpg_m_dol] run playsound minecraft:entity.wither.death master @a ~ ~ ~ 0.7 1.4
execute if entity @s[tag=rpg_m_dol] run tellraw @a[distance=..60] [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"돌","color":"dark_red","bold":true},{"text":" 이(가) 쓰러졌다!","color":"white"}]

# 몬스터가 죽었을 때 (v39 · 내부용 · 죽인 방법과 상관없이 한 번만)
tag @s add rpg_dead
function rpg:mob/anim_die
particle minecraft:poof ~ ~0.6 ~ 0.35 0.4 0.35 0.03 30 normal @a
particle minecraft:crit ~ ~0.6 ~ 0.35 0.4 0.35 0.2 25 normal @a
playsound minecraft:block.stone.break block @a ~ ~ ~ 1 0.7
# 가짜 피가 0 이 되기 전에 한 방에 죽었으면 (진짜 피 1024 를 한 번에 넘긴 경우) 여기서 보상
execute unless entity @s[tag=rpg_paid] run function rpg:mob/reward
tag @a remove rpg_rwd
execute if entity @s[tag=rpg_m_pir1] run playsound minecraft:entity.pillager.death master @a ~ ~ ~ 1 0.9
execute if entity @s[tag=rpg_m_pir2] run playsound minecraft:entity.pillager.death master @a ~ ~ ~ 1 0.9
execute if entity @s[tag=rpg_m_pir3] run playsound minecraft:entity.pillager.death master @a ~ ~ ~ 1 0.9
# ── 보스 ──
execute if entity @s[tag=rpg_m_dol] at @s run function rpg:hid/h2_boss1
execute if entity @s[tag=rpg_m_dol] run playsound minecraft:entity.wither.death master @a ~ ~ ~ 0.7 1.4
execute if entity @s[tag=rpg_m_wolf] at @s run function rpg:hid/h2_boss3
execute if entity @s[tag=rpg_m_wolf] run playsound minecraft:entity.wolf.death master @a ~ ~ ~ 1 0.6
execute if entity @s[tag=rpg_m_pking] at @s as @e[tag=rpg_minion,tag=!rpg_dead,distance=..48] run function rpg:mob/rm_mob
execute if entity @s[tag=rpg_m_pking] run playsound minecraft:entity.wither.death master @a ~ ~ ~ 1 0.9
# ── 보스 경험치 : 근처 모두에게 ──
execute if entity @s[tag=rpg_boss] run function rpg:mob/boss_exp

tag @s add rpg_dead
function rpg:mob/anim_die
particle minecraft:poof ~ ~0.6 ~ 0.35 0.4 0.35 0.03 30 normal @a
particle minecraft:crit ~ ~0.6 ~ 0.35 0.4 0.35 0.2 25 normal @a
playsound minecraft:block.stone.break block @a ~ ~ ~ 1 0.7
execute if entity @s[tag=rpg_m_ddol] run loot spawn ~ ~0.4 ~ loot rpg:mob/drop_ddol
execute if entity @s[tag=rpg_m_ddodol] run loot spawn ~ ~0.4 ~ loot rpg:mob/drop_ddodol
execute if entity @s[tag=rpg_m_dolmengi] run loot spawn ~ ~0.4 ~ loot rpg:mob/drop_dolmengi
execute if entity @s[tag=rpg_m_dol] run loot spawn ~ ~0.6 ~ loot rpg:mob/drop_dol
execute if entity @s[tag=rpg_m_wolf] run function rpg:mob/wolf_drop
execute if entity @s[tag=rpg_m_wolf] run playsound minecraft:entity.wolf.death master @a ~ ~ ~ 1 0.6
execute if entity @s[tag=rpg_m_wolf] run tellraw @a[distance=..80] [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"잠꾸러기 늑대","color":"gold","bold":true},{"text":" 이(가) 쓰러졌다!","color":"white"}]
# 보스가 떨군 아이템은 사방으로 흩뿌린다
execute if entity @s[tag=rpg_boss] run function rpg:mob/scatter_all
execute if entity @s[tag=rpg_m_dol] run playsound minecraft:entity.wither.death master @a ~ ~ ~ 0.7 1.4
execute if entity @s[tag=rpg_m_dol] run tellraw @a[distance=..60] [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"돌","color":"dark_red","bold":true},{"text":" 이(가) 쓰러졌다!","color":"white"}]

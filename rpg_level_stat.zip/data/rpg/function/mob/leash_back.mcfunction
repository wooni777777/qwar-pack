# 스폰 지점으로 되돌린다 — 체력은 그대로 둡니다 (v35)
execute as @e[type=minecraft:marker,tag=rpg_sp] if score @s rpg.sid = #sid rpg.sys run tag @s add rpg_home
execute if entity @e[tag=rpg_home] run tp @s @e[type=minecraft:marker,tag=rpg_home,limit=1,sort=nearest]
tag @e[tag=rpg_home] remove rpg_home
particle minecraft:cloud ~ ~1 ~ 0.4 0.6 0.4 0.02 20 normal @a

execute as @e[type=minecraft:marker,tag=rpg_sp] if score @s rpg.sid = #sid rpg.sys run tag @s add rpg_home
execute if entity @e[tag=rpg_home] run tp @s @e[type=minecraft:marker,tag=rpg_home,limit=1,sort=nearest]
tag @e[tag=rpg_home] remove rpg_home
# 되돌아오면 체력 전체 회복 (끌어내서 잡는 꼼수 방지)
execute store result score #mx rpg.sys run attribute @s minecraft:max_health get 1
execute unless entity @s[tag=rpg_m_wolf] store result entity @s Health float 1 run scoreboard players get #mx rpg.sys
execute if entity @s[tag=rpg_m_wolf] run effect give @s minecraft:instant_health 1 12 true
scoreboard players operation @s rpg.php = #mx rpg.sys
particle minecraft:cloud ~ ~1 ~ 0.4 0.6 0.4 0.02 20 normal @a

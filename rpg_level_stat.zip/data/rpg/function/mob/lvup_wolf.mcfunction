scoreboard players add #mlv_wolf rpg.sys 1
execute if score #mlv_wolf rpg.sys matches 200.. run scoreboard players set #mlv_wolf rpg.sys 200
function rpg:mob/open

tag @s add rpg_lister
tellraw @s ["",{"text":"━━━━━  ","color":"dark_gray"},{"text":"잠꾸러기 늑대","color":"gold","bold":true},{"text":"  스폰 지점  ━━━━━","color":"dark_gray"}]
execute as @e[type=minecraft:marker,tag=rpg_sp_wolf] at @s run function rpg:mob/point_l1
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}
tag @s remove rpg_lister

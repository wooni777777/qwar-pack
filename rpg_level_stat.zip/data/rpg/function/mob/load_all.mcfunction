# 저장해 둔 몹 설정 + 스폰 지점을 되살린다
execute unless data storage rpg:mobsave cfg run return run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"저장된 내용이 없습니다. 먼저 [전체 저장] 을 눌러주세요.","color":"red"}]
execute if data storage rpg:mobsave cfg.lv_ddol store result score #mlv_ddol rpg.sys run data get storage rpg:mobsave cfg.lv_ddol
execute if data storage rpg:mobsave cfg.lv_ddodol store result score #mlv_ddodol rpg.sys run data get storage rpg:mobsave cfg.lv_ddodol
execute if data storage rpg:mobsave cfg.lv_dolmengi store result score #mlv_dolmengi rpg.sys run data get storage rpg:mobsave cfg.lv_dolmengi
execute if data storage rpg:mobsave cfg.lv_dol store result score #mlv_dol rpg.sys run data get storage rpg:mobsave cfg.lv_dol
execute if data storage rpg:mobsave cfg.lv_wolf store result score #mlv_wolf rpg.sys run data get storage rpg:mobsave cfg.lv_wolf
execute if data storage rpg:mobsave cfg.lv_pir1 store result score #mlv_pir1 rpg.sys run data get storage rpg:mobsave cfg.lv_pir1
execute if data storage rpg:mobsave cfg.lv_pir2 store result score #mlv_pir2 rpg.sys run data get storage rpg:mobsave cfg.lv_pir2
execute if data storage rpg:mobsave cfg.lv_pir3 store result score #mlv_pir3 rpg.sys run data get storage rpg:mobsave cfg.lv_pir3
execute if data storage rpg:mobsave cfg.lv_pking store result score #mlv_pking rpg.sys run data get storage rpg:mobsave cfg.lv_pking
execute if data storage rpg:mobsave cfg.n_d1 store result score #dr_d1n rpg.sys run data get storage rpg:mobsave cfg.n_d1
execute if data storage rpg:mobsave cfg.p_d1 store result score #dr_d1p rpg.sys run data get storage rpg:mobsave cfg.p_d1
execute if data storage rpg:mobsave cfg.n_d2 store result score #dr_d2n rpg.sys run data get storage rpg:mobsave cfg.n_d2
execute if data storage rpg:mobsave cfg.p_d2 store result score #dr_d2p rpg.sys run data get storage rpg:mobsave cfg.p_d2
execute if data storage rpg:mobsave cfg.n_d3 store result score #dr_d3n rpg.sys run data get storage rpg:mobsave cfg.n_d3
execute if data storage rpg:mobsave cfg.p_d3 store result score #dr_d3p rpg.sys run data get storage rpg:mobsave cfg.p_d3
execute if data storage rpg:mobsave cfg.n_d4 store result score #dr_d4n rpg.sys run data get storage rpg:mobsave cfg.n_d4
execute if data storage rpg:mobsave cfg.p_d4 store result score #dr_d4p rpg.sys run data get storage rpg:mobsave cfg.p_d4
execute if data storage rpg:mobsave cfg.n_w1 store result score #dr_w1n rpg.sys run data get storage rpg:mobsave cfg.n_w1
execute if data storage rpg:mobsave cfg.p_w1 store result score #dr_w1p rpg.sys run data get storage rpg:mobsave cfg.p_w1
execute if data storage rpg:mobsave cfg.n_w2 store result score #dr_w2n rpg.sys run data get storage rpg:mobsave cfg.n_w2
execute if data storage rpg:mobsave cfg.p_w2 store result score #dr_w2p rpg.sys run data get storage rpg:mobsave cfg.p_w2
execute if data storage rpg:mobsave cfg.n_k1 store result score #dr_k1n rpg.sys run data get storage rpg:mobsave cfg.n_k1
execute if data storage rpg:mobsave cfg.p_k1 store result score #dr_k1p rpg.sys run data get storage rpg:mobsave cfg.p_k1
execute if data storage rpg:mobsave cfg.n_k2 store result score #dr_k2n rpg.sys run data get storage rpg:mobsave cfg.n_k2
execute if data storage rpg:mobsave cfg.p_k2 store result score #dr_k2p rpg.sys run data get storage rpg:mobsave cfg.p_k2
execute if data storage rpg:mobsave cfg.n_k3 store result score #dr_k3n rpg.sys run data get storage rpg:mobsave cfg.n_k3
execute if data storage rpg:mobsave cfg.p_k3 store result score #dr_k3p rpg.sys run data get storage rpg:mobsave cfg.p_k3
execute if data storage rpg:mobsave cfg.n_k4 store result score #dr_k4n rpg.sys run data get storage rpg:mobsave cfg.n_k4
execute if data storage rpg:mobsave cfg.p_k4 store result score #dr_k4p rpg.sys run data get storage rpg:mobsave cfg.p_k4
execute if data storage rpg:mobsave cfg.n_k5 store result score #dr_k5n rpg.sys run data get storage rpg:mobsave cfg.n_k5
execute if data storage rpg:mobsave cfg.p_k5 store result score #dr_k5p rpg.sys run data get storage rpg:mobsave cfg.p_k5
execute if data storage rpg:mobsave cfg.n_k6 store result score #dr_k6n rpg.sys run data get storage rpg:mobsave cfg.n_k6
execute if data storage rpg:mobsave cfg.p_k6 store result score #dr_k6p rpg.sys run data get storage rpg:mobsave cfg.p_k6
# 지금 있는 스폰 지점을 전부 지우고 저장본으로 다시 만든다
kill @e[type=minecraft:marker,tag=rpg_sp]
scoreboard players set #spn rpg.sys 0
data modify storage rpg:mobsave work set from storage rpg:mobsave pts
function rpg:mob/load_pt
tellraw @s ["",{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"저장본을 불러왔습니다. 스폰 지점 ","color":"green"},{"score":{"name":"#spn","objective":"rpg.sys"},"color":"green","bold":true},{"text":"개","color":"green"}]
playsound minecraft:block.beacon.activate player @s ~ ~ ~ 1 1.4

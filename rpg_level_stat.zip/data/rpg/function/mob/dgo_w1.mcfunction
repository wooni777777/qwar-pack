execute store result storage rpg:mob dr.n int 1 run scoreboard players get #dr_w1n rpg.sys
function rpg:mob/dg_w1 with storage rpg:mob dr

function rpg:mob/sp_ddodol
playsound minecraft:block.beacon.activate player @s ~ ~ ~ 1 1.6

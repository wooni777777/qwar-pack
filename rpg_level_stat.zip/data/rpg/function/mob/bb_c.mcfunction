data modify storage rpg:main bb.v set value "center"
execute as @e[tag=rpg_mdisp] run data modify entity @s billboard set value "center"
execute as @e[tag=rpg_mdisp] run data modify entity @s Rotation set value [0.0f,0.0f]
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"모델 방향 : ","color":"white"},{"text":"center","color":"aqua","bold":true},{"text":" - 좌우·위아래 전부 카메라 기준 - 항상 정면으로 플레이어를 봄 (기본)","color":"gray"}]

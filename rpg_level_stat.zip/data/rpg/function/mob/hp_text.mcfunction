scoreboard players set #bh rpg.sys 0
scoreboard players operation #bh rpg.sys = @s rpg.mhp
scoreboard players operation #bm rpg.sys = @s rpg.mmx
execute if score #bh rpg.sys matches ..0 run scoreboard players set #bh rpg.sys 0
data modify storage rpg:main mtxt.nm set value "몬스터"
data modify storage rpg:main mtxt.cl set value "gray"
execute if entity @s[tag=rpg_m_ddol] run data modify storage rpg:main mtxt.nm set value "똘"
execute if entity @s[tag=rpg_m_ddodol] run data modify storage rpg:main mtxt.nm set value "또돌맹"
execute if entity @s[tag=rpg_m_dolmengi] run data modify storage rpg:main mtxt.nm set value "돌맹이"
execute if entity @s[tag=rpg_m_dolmengi] run data modify storage rpg:main mtxt.cl set value "white"
execute if entity @s[tag=rpg_m_dol] run data modify storage rpg:main mtxt.nm set value "돌"
execute if entity @s[tag=rpg_m_dol] run data modify storage rpg:main mtxt.cl set value "dark_red"
execute if entity @s[tag=rpg_m_wolf] run data modify storage rpg:main mtxt.nm set value "잠꾸러기 늑대"
execute if entity @s[tag=rpg_m_wolf] run data modify storage rpg:main mtxt.cl set value "gold"
execute if entity @s[tag=rpg_m_pir1] run data modify storage rpg:main mtxt.nm set value "눈다친 해적"
execute if entity @s[tag=rpg_m_pir1] run data modify storage rpg:main mtxt.cl set value "gray"
execute if entity @s[tag=rpg_m_pir2] run data modify storage rpg:main mtxt.nm set value "화난 해적"
execute if entity @s[tag=rpg_m_pir2] run data modify storage rpg:main mtxt.cl set value "red"
execute if entity @s[tag=rpg_m_pir3] run data modify storage rpg:main mtxt.nm set value "총든 해적"
execute if entity @s[tag=rpg_m_pir3] run data modify storage rpg:main mtxt.cl set value "dark_aqua"
execute if entity @s[tag=rpg_m_pking] run data modify storage rpg:main mtxt.nm set value "해적 왕"
execute if entity @s[tag=rpg_m_pking] run data modify storage rpg:main mtxt.cl set value "dark_red"
execute store result storage rpg:main mtxt.hp int 1 run scoreboard players get #bh rpg.sys
execute store result storage rpg:main mtxt.mx int 1 run scoreboard players get #bm rpg.sys
execute on passengers if entity @s[tag=rpg_mtext] run function rpg:mob/hp_set with storage rpg:main mtxt

# 가짜 피가 없는 몹 (예전 버전에 소환된 몹 등) 을 가짜 피 방식으로 바꾼다
# 예전 몸(머리 위 모델)을 단 2족 몹은 치운다 -> 스폰 지점에서 새 몸으로 다시 나옵니다
execute if entity @s[tag=rpg_m_dol] run function rpg:mob/rm_mob
execute if entity @s[tag=rpg_m_dolmengi] run function rpg:mob/rm_mob
execute if entity @s[tag=rpg_m_pir1] run function rpg:mob/rm_mob
execute if entity @s[tag=rpg_m_pir2] run function rpg:mob/rm_mob
execute if entity @s[tag=rpg_m_pir3] run function rpg:mob/rm_mob
execute if entity @s[tag=rpg_m_pking] run function rpg:mob/rm_mob
execute if entity @s[tag=rpg_dead] run return 0
execute store result score @s rpg.mmx run attribute @s minecraft:max_health get 1
execute store result score @s rpg.mhp run data get entity @s Health 1
execute if score @s rpg.mhp matches ..0 run scoreboard players set @s rpg.mhp 1
execute if score @s rpg.mmx matches ..0 run scoreboard players set @s rpg.mmx 1
scoreboard players operation @s rpg.php = @s rpg.mhp
attribute @s minecraft:max_health base set 1024
execute unless entity @s[tag=rpg_m_wolf] run data modify entity @s Health set value 1024.0f
execute if entity @s[tag=rpg_m_wolf] run effect give @s minecraft:instant_health 1 8 true
scoreboard players set @s rpg.mlh -1
scoreboard players set @s rpg.mfr 0

# 해적 왕 - 2월 크리스탈
$summon minecraft:item ~ ~0.6 ~ {Item:{id:"minecraft:echo_shard",count:$(n),components:{"minecraft:custom_data":{rpg_crystal:2},"minecraft:item_model":"rpg:crystal_02","minecraft:item_name":{text:"2월 크리스탈",color:"gray",bold:true},"minecraft:lore":[{text:"장비 상점에서 쓰는 재료",color:"gray",italic:false}],"minecraft:enchantment_glint_override":true}}}

scoreboard players remove #mlv_pir3 rpg.sys 1
execute if score #mlv_pir3 rpg.sys matches ..0 run scoreboard players set #mlv_pir3 rpg.sys 1
function rpg:mob/open

scoreboard players operation #sid rpg.sys = @s rpg.sid
scoreboard players set #cnt rpg.sys 0
execute as @e[tag=rpg_mob,tag=!rpg_dead,distance=..20] if score @s rpg.sid = #sid rpg.sys run scoreboard players add #cnt rpg.sys 1

# 어떤 이유로든 같은 지점의 몹이 겹쳐 늘어나면 전부 지우고 하나만 다시 뽑는다
execute if score #cnt rpg.sys matches 2.. run function rpg:mob/dedupe

# 살아 있으면 쿨타임을 계속 채워 둔다
execute if score #cnt rpg.sys matches 1 if entity @s[tag=rpg_sp_dol] run scoreboard players operation @s rpg.cd = #boss_cd rpg.sys
execute if score #cnt rpg.sys matches 1 if entity @s[tag=rpg_sp_wolf] run scoreboard players operation @s rpg.cd = #boss_cd rpg.sys
execute if score #cnt rpg.sys matches 1 if entity @s[tag=rpg_sp_pking] run scoreboard players operation @s rpg.cd = #boss_cd rpg.sys
execute if score #cnt rpg.sys matches 1 unless entity @s[tag=rpg_sp_dol] unless entity @s[tag=rpg_sp_wolf] unless entity @s[tag=rpg_sp_pking] run scoreboard players operation @s rpg.cd = #mob_cd rpg.sys

# 죽어 있으면 쿨타임을 깎고, 다 되면 근처에 플레이어가 있을 때만 스폰
execute if score #cnt rpg.sys matches 0 if score @s rpg.cd matches 1.. run scoreboard players remove @s rpg.cd 1
execute if score #cnt rpg.sys matches 0 if score @s rpg.cd matches ..0 if entity @a[distance=..30,gamemode=!spectator] run function rpg:mob/spawn_do

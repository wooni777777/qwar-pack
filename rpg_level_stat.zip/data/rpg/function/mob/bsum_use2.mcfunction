# 해적 왕 소환 나팔 사용 (v39 · 발전과제 보상 · 아이템은 1개 소모됨)
advancement revoke @s only rpg:mob/bsum2
execute at @s rotated ~ 0 positioned ^ ^ ^2.5 run function rpg:mob/bsum_go {t:"pking",nm:"해적 왕"}

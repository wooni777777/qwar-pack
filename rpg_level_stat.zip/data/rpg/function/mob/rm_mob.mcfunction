# 몹을 보상 없이 치운다 (쫄병 정리 · 중복 정리 · 스폰 지점 삭제) — v39
execute on passengers if entity @s[tag=rpg_mdisp] run kill @s
execute on passengers if entity @s[tag=rpg_mtext] run kill @s
tag @s add rpg_paid
tag @s add rpg_dead
kill @s

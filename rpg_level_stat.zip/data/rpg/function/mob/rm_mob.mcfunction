execute on passengers if entity @s[tag=rpg_mdisp] run kill @s
execute on passengers if entity @s[tag=rpg_mtext] run kill @s
kill @s

scoreboard players remove #mlv_dol rpg.sys 1
execute if score #mlv_dol rpg.sys matches ..0 run scoreboard players set #mlv_dol rpg.sys 1
function rpg:mob/open

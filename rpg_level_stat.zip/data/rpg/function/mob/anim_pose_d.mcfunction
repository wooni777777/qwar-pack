execute if entity @s[tag=rpg_m_ddol] on passengers if entity @s[tag=rpg_mdisp] run function rpg:mob/anim_ddol_d
execute if entity @s[tag=rpg_m_ddodol] on passengers if entity @s[tag=rpg_mdisp] run function rpg:mob/anim_ddodol_d
execute if entity @s[tag=rpg_m_dolmengi] on passengers if entity @s[tag=rpg_mdisp] run function rpg:mob/anim_dolmengi_d
execute if entity @s[tag=rpg_m_dol] on passengers if entity @s[tag=rpg_mdisp] run function rpg:mob/anim_dol_d

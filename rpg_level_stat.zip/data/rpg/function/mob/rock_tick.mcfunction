tp @s ^ ^ ^0.85
execute at @s run function rpg:mob/rock_step

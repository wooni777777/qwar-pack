# 던진 돌 1틱 (내부용) — 0.3칸씩 3번 나눠 날아가므로 빨라도 지나치지 않습니다
scoreboard players remove @s rpg.cd 1
scoreboard players set #rst rpg.sys 3
function rpg:mob/rock_move
execute if entity @s[tag=rpg_rock] if score @s rpg.cd matches ..0 at @s run function rpg:mob/rock_end

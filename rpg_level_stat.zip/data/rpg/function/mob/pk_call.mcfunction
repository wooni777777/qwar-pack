# 쫄병 해적 3마리 소환
playsound minecraft:entity.ender_dragon.growl hostile @a ~ ~ ~ 1.2 1.7
playsound minecraft:item.trident.thunder hostile @a ~ ~ ~ 0.7 1.8
particle minecraft:soul ~ ~1 ~ 1.4 0.7 1.4 0.05 50 normal @a
tellraw @a[distance=..48] [{"text":"[해적 왕] ","color":"dark_red","bold":true},{"text":"전부 갑판 위로 올라와라!","color":"red"}]
execute rotated ~ 0 positioned ^ ^ ^3 run function rpg:mob/pk_one
execute rotated ~120 0 positioned ^ ^ ^3 run function rpg:mob/pk_one
execute rotated ~240 0 positioned ^ ^ ^3 run function rpg:mob/pk_one

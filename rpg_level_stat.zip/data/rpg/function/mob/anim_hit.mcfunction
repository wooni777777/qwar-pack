tag @s add rpg_atk
scoreboard players set @s rpg.anim 5
function rpg:mob/anim_pose_h
execute at @s run playsound minecraft:block.stone.hit hostile @a ~ ~ ~ 1.1 0.7

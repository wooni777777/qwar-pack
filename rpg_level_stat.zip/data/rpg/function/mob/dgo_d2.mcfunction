execute store result storage rpg:mob dr.n int 1 run scoreboard players get #dr_d2n rpg.sys
function rpg:mob/dg_d2 with storage rpg:mob dr

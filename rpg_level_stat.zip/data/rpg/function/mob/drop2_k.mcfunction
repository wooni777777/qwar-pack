# 해적 왕 드롭 (개수·확률은 [드롭템 설정] 에서 조절)
scoreboard players set #dr rpg.sys 0
execute store result score #dr rpg.sys run random value 1..100
execute if score #dr rpg.sys <= #dr_k1p rpg.sys if score #dr_k1n rpg.sys matches 1.. run function rpg:mob/dgo_k1
scoreboard players set #dr rpg.sys 0
execute store result score #dr rpg.sys run random value 1..100
execute if score #dr rpg.sys <= #dr_k2p rpg.sys if score #dr_k2n rpg.sys matches 1.. run function rpg:mob/dgo_k2
scoreboard players set #dr rpg.sys 0
execute store result score #dr rpg.sys run random value 1..100
execute if score #dr rpg.sys <= #dr_k3p rpg.sys if score #dr_k3n rpg.sys matches 1.. run function rpg:mob/dgo_k3
scoreboard players set #dr rpg.sys 0
execute store result score #dr rpg.sys run random value 1..100
execute if score #dr rpg.sys <= #dr_k4p rpg.sys if score #dr_k4n rpg.sys matches 1.. run function rpg:mob/dgo_k4
scoreboard players set #dr rpg.sys 0
execute store result score #dr rpg.sys run random value 1..100
execute if score #dr rpg.sys <= #dr_k5p rpg.sys if score #dr_k5n rpg.sys matches 1.. run function rpg:mob/dgo_k5
scoreboard players set #dr rpg.sys 0
execute store result score #dr rpg.sys run random value 1..100
execute if score #dr rpg.sys <= #dr_k6p rpg.sys if score #dr_k6n rpg.sys matches 1.. run function rpg:mob/dgo_k6

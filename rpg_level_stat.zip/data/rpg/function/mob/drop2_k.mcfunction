# 해적 왕 드롭 (개수 · 확률 · 종류는 [드롭템 설정] 에서)
function rpg:mob/ds_roll {b:"k",s:1}
function rpg:mob/ds_roll {b:"k",s:2}
function rpg:mob/ds_roll {b:"k",s:3}
function rpg:mob/ds_roll {b:"k",s:4}
function rpg:mob/ds_roll {b:"k",s:5}
function rpg:mob/ds_roll {b:"k",s:6}
function rpg:mob/ds_roll {b:"k",s:7}
function rpg:mob/ds_roll {b:"k",s:8}

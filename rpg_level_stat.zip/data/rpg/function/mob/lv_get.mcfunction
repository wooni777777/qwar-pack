# 이 몹 종류의 지금 레벨(#mlv) 과 기본 레벨(#mlb) (내부용 · as 몹)
scoreboard players set #mlv rpg.sys 1
scoreboard players set #mlb rpg.sys 1
execute if entity @s[tag=rpg_m_ddol] run scoreboard players operation #mlv rpg.sys = #mlv_ddol rpg.sys
execute if entity @s[tag=rpg_m_ddol] run scoreboard players set #mlb rpg.sys 1
execute if entity @s[tag=rpg_m_ddodol] run scoreboard players operation #mlv rpg.sys = #mlv_ddodol rpg.sys
execute if entity @s[tag=rpg_m_ddodol] run scoreboard players set #mlb rpg.sys 3
execute if entity @s[tag=rpg_m_dolmengi] run scoreboard players operation #mlv rpg.sys = #mlv_dolmengi rpg.sys
execute if entity @s[tag=rpg_m_dolmengi] run scoreboard players set #mlb rpg.sys 5
execute if entity @s[tag=rpg_m_dol] run scoreboard players operation #mlv rpg.sys = #mlv_dol rpg.sys
execute if entity @s[tag=rpg_m_dol] run scoreboard players set #mlb rpg.sys 10
execute if entity @s[tag=rpg_m_wolf] run scoreboard players operation #mlv rpg.sys = #mlv_wolf rpg.sys
execute if entity @s[tag=rpg_m_wolf] run scoreboard players set #mlb rpg.sys 15
execute if entity @s[tag=rpg_m_pir1] run scoreboard players operation #mlv rpg.sys = #mlv_pir1 rpg.sys
execute if entity @s[tag=rpg_m_pir1] run scoreboard players set #mlb rpg.sys 8
execute if entity @s[tag=rpg_m_pir2] run scoreboard players operation #mlv rpg.sys = #mlv_pir2 rpg.sys
execute if entity @s[tag=rpg_m_pir2] run scoreboard players set #mlb rpg.sys 10
execute if entity @s[tag=rpg_m_pir3] run scoreboard players operation #mlv rpg.sys = #mlv_pir3 rpg.sys
execute if entity @s[tag=rpg_m_pir3] run scoreboard players set #mlb rpg.sys 9
execute if entity @s[tag=rpg_m_pking] run scoreboard players operation #mlv rpg.sys = #mlv_pking rpg.sys
execute if entity @s[tag=rpg_m_pking] run scoreboard players set #mlb rpg.sys 20

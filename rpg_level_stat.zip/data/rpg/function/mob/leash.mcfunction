# 전투 중이면 아무리 멀어도 안 끌고 옵니다 (v35)
execute if score @s rpg.cbt matches 1.. run return 0
# 스폰 지점이 없는 몹(해적 왕이 부른 쫄병 · 즉시 소환)은 제외
execute if entity @s[tag=rpg_nolea] run return 0
# 보스는 15칸, 잡몹은 8칸을 넘어가면 스폰 지점으로 되돌립니다
scoreboard players operation #sid rpg.sys = @s rpg.sid
scoreboard players set #near rpg.sys 0
execute if entity @s[tag=rpg_boss] as @e[type=minecraft:marker,tag=rpg_sp,distance=..15] if score @s rpg.sid = #sid rpg.sys run scoreboard players set #near rpg.sys 1
execute unless entity @s[tag=rpg_boss] as @e[type=minecraft:marker,tag=rpg_sp,distance=..8] if score @s rpg.sid = #sid rpg.sys run scoreboard players set #near rpg.sys 1
execute if score #near rpg.sys matches 0 run function rpg:mob/leash_back

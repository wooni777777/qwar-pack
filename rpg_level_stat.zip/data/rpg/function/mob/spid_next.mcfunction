execute as @e[type=minecraft:marker,tag=rpg_sp] run function rpg:mob/spid_max
scoreboard players add #spid rpg.sys 1

summon minecraft:item_display ~ ~2.2 ~ {Tags:["rpg_rock","rpg_newrock"],item:{id:"minecraft:cobblestone",count:1},item_display:"none",billboard:"fixed",teleport_duration:1,view_range:2.5f,transformation:{translation:[0.0f,0.0f,0.0f],left_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[0.55f,0.55f,0.55f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}
execute as @e[tag=rpg_newrock] at @s facing entity @p[distance=..30,gamemode=!spectator] eyes run tp @s ~ ~ ~ ~ ~
scoreboard players set @e[tag=rpg_newrock,limit=1] rpg.cd 60
tag @e[tag=rpg_newrock] remove rpg_newrock
execute at @s run playsound minecraft:entity.snowball.throw hostile @a ~ ~ ~ 1.3 0.5
execute at @s run particle minecraft:poof ~ ~2 ~ 0.3 0.3 0.3 0.02 8 normal @a

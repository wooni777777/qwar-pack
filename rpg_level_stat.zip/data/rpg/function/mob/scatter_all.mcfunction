# 방금 떨어진 아이템을 전부 흩뿌린다 (내부용)
execute as @e[type=minecraft:item,distance=..3,nbt={Age:0s}] run function rpg:mob/scatter

execute as @e[type=minecraft:item,distance=..2.5,nbt={Age:0s}] run function rpg:mob/scatter

# v42 : 해적 왕 드롭 설정 바꾸기 (한 번 · 점수 + [저장] 해 둔 것 둘 다)
#   고정템 2 (경험치 책 1,500) -> 경험치 닭 5000 / 3 (경험치 책 1,000) -> 경험치 닭 1000 / 4 핵 -> 2 / 5 조각 -> 3
scoreboard players set #dsm rpg.sys 0
execute if score #dsk1k rpg.sys matches 4 if score #dsk1v rpg.sys matches 2 run scoreboard players set #dsm rpg.sys 5
execute if score #dsk1k rpg.sys matches 4 if score #dsk1v rpg.sys matches 3 run scoreboard players set #dsm rpg.sys 4
execute if score #dsm rpg.sys matches 4..5 run scoreboard players set #dsk1k rpg.sys 2
execute if score #dsm rpg.sys matches 4..5 run scoreboard players operation #dsk1v rpg.sys = #dsm rpg.sys
execute if score #dsk1k rpg.sys matches 4 if score #dsk1v rpg.sys matches 4 run scoreboard players set #dsk1v rpg.sys 2
execute if score #dsk1k rpg.sys matches 4 if score #dsk1v rpg.sys matches 5 run scoreboard players set #dsk1v rpg.sys 3
execute if data storage rpg:mobsave cfg{dsk1k:4,dsk1v:2} run data merge storage rpg:mobsave {cfg:{dsk1k:2,dsk1v:5}}
execute if data storage rpg:mobsave cfg{dsk1k:4,dsk1v:3} run data merge storage rpg:mobsave {cfg:{dsk1k:2,dsk1v:4}}
execute if data storage rpg:mobsave cfg{dsk1k:4,dsk1v:4} run data merge storage rpg:mobsave {cfg:{dsk1v:2}}
execute if data storage rpg:mobsave cfg{dsk1k:4,dsk1v:5} run data merge storage rpg:mobsave {cfg:{dsk1v:3}}
scoreboard players set #dsm rpg.sys 0
execute if score #dsk2k rpg.sys matches 4 if score #dsk2v rpg.sys matches 2 run scoreboard players set #dsm rpg.sys 5
execute if score #dsk2k rpg.sys matches 4 if score #dsk2v rpg.sys matches 3 run scoreboard players set #dsm rpg.sys 4
execute if score #dsm rpg.sys matches 4..5 run scoreboard players set #dsk2k rpg.sys 2
execute if score #dsm rpg.sys matches 4..5 run scoreboard players operation #dsk2v rpg.sys = #dsm rpg.sys
execute if score #dsk2k rpg.sys matches 4 if score #dsk2v rpg.sys matches 4 run scoreboard players set #dsk2v rpg.sys 2
execute if score #dsk2k rpg.sys matches 4 if score #dsk2v rpg.sys matches 5 run scoreboard players set #dsk2v rpg.sys 3
execute if data storage rpg:mobsave cfg{dsk2k:4,dsk2v:2} run data merge storage rpg:mobsave {cfg:{dsk2k:2,dsk2v:5}}
execute if data storage rpg:mobsave cfg{dsk2k:4,dsk2v:3} run data merge storage rpg:mobsave {cfg:{dsk2k:2,dsk2v:4}}
execute if data storage rpg:mobsave cfg{dsk2k:4,dsk2v:4} run data merge storage rpg:mobsave {cfg:{dsk2v:2}}
execute if data storage rpg:mobsave cfg{dsk2k:4,dsk2v:5} run data merge storage rpg:mobsave {cfg:{dsk2v:3}}
scoreboard players set #dsm rpg.sys 0
execute if score #dsk3k rpg.sys matches 4 if score #dsk3v rpg.sys matches 2 run scoreboard players set #dsm rpg.sys 5
execute if score #dsk3k rpg.sys matches 4 if score #dsk3v rpg.sys matches 3 run scoreboard players set #dsm rpg.sys 4
execute if score #dsm rpg.sys matches 4..5 run scoreboard players set #dsk3k rpg.sys 2
execute if score #dsm rpg.sys matches 4..5 run scoreboard players operation #dsk3v rpg.sys = #dsm rpg.sys
execute if score #dsk3k rpg.sys matches 4 if score #dsk3v rpg.sys matches 4 run scoreboard players set #dsk3v rpg.sys 2
execute if score #dsk3k rpg.sys matches 4 if score #dsk3v rpg.sys matches 5 run scoreboard players set #dsk3v rpg.sys 3
execute if data storage rpg:mobsave cfg{dsk3k:4,dsk3v:2} run data merge storage rpg:mobsave {cfg:{dsk3k:2,dsk3v:5}}
execute if data storage rpg:mobsave cfg{dsk3k:4,dsk3v:3} run data merge storage rpg:mobsave {cfg:{dsk3k:2,dsk3v:4}}
execute if data storage rpg:mobsave cfg{dsk3k:4,dsk3v:4} run data merge storage rpg:mobsave {cfg:{dsk3v:2}}
execute if data storage rpg:mobsave cfg{dsk3k:4,dsk3v:5} run data merge storage rpg:mobsave {cfg:{dsk3v:3}}
scoreboard players set #dsm rpg.sys 0
execute if score #dsk4k rpg.sys matches 4 if score #dsk4v rpg.sys matches 2 run scoreboard players set #dsm rpg.sys 5
execute if score #dsk4k rpg.sys matches 4 if score #dsk4v rpg.sys matches 3 run scoreboard players set #dsm rpg.sys 4
execute if score #dsm rpg.sys matches 4..5 run scoreboard players set #dsk4k rpg.sys 2
execute if score #dsm rpg.sys matches 4..5 run scoreboard players operation #dsk4v rpg.sys = #dsm rpg.sys
execute if score #dsk4k rpg.sys matches 4 if score #dsk4v rpg.sys matches 4 run scoreboard players set #dsk4v rpg.sys 2
execute if score #dsk4k rpg.sys matches 4 if score #dsk4v rpg.sys matches 5 run scoreboard players set #dsk4v rpg.sys 3
execute if data storage rpg:mobsave cfg{dsk4k:4,dsk4v:2} run data merge storage rpg:mobsave {cfg:{dsk4k:2,dsk4v:5}}
execute if data storage rpg:mobsave cfg{dsk4k:4,dsk4v:3} run data merge storage rpg:mobsave {cfg:{dsk4k:2,dsk4v:4}}
execute if data storage rpg:mobsave cfg{dsk4k:4,dsk4v:4} run data merge storage rpg:mobsave {cfg:{dsk4v:2}}
execute if data storage rpg:mobsave cfg{dsk4k:4,dsk4v:5} run data merge storage rpg:mobsave {cfg:{dsk4v:3}}
scoreboard players set #dsm rpg.sys 0
execute if score #dsk5k rpg.sys matches 4 if score #dsk5v rpg.sys matches 2 run scoreboard players set #dsm rpg.sys 5
execute if score #dsk5k rpg.sys matches 4 if score #dsk5v rpg.sys matches 3 run scoreboard players set #dsm rpg.sys 4
execute if score #dsm rpg.sys matches 4..5 run scoreboard players set #dsk5k rpg.sys 2
execute if score #dsm rpg.sys matches 4..5 run scoreboard players operation #dsk5v rpg.sys = #dsm rpg.sys
execute if score #dsk5k rpg.sys matches 4 if score #dsk5v rpg.sys matches 4 run scoreboard players set #dsk5v rpg.sys 2
execute if score #dsk5k rpg.sys matches 4 if score #dsk5v rpg.sys matches 5 run scoreboard players set #dsk5v rpg.sys 3
execute if data storage rpg:mobsave cfg{dsk5k:4,dsk5v:2} run data merge storage rpg:mobsave {cfg:{dsk5k:2,dsk5v:5}}
execute if data storage rpg:mobsave cfg{dsk5k:4,dsk5v:3} run data merge storage rpg:mobsave {cfg:{dsk5k:2,dsk5v:4}}
execute if data storage rpg:mobsave cfg{dsk5k:4,dsk5v:4} run data merge storage rpg:mobsave {cfg:{dsk5v:2}}
execute if data storage rpg:mobsave cfg{dsk5k:4,dsk5v:5} run data merge storage rpg:mobsave {cfg:{dsk5v:3}}
scoreboard players set #dsm rpg.sys 0
execute if score #dsk6k rpg.sys matches 4 if score #dsk6v rpg.sys matches 2 run scoreboard players set #dsm rpg.sys 5
execute if score #dsk6k rpg.sys matches 4 if score #dsk6v rpg.sys matches 3 run scoreboard players set #dsm rpg.sys 4
execute if score #dsm rpg.sys matches 4..5 run scoreboard players set #dsk6k rpg.sys 2
execute if score #dsm rpg.sys matches 4..5 run scoreboard players operation #dsk6v rpg.sys = #dsm rpg.sys
execute if score #dsk6k rpg.sys matches 4 if score #dsk6v rpg.sys matches 4 run scoreboard players set #dsk6v rpg.sys 2
execute if score #dsk6k rpg.sys matches 4 if score #dsk6v rpg.sys matches 5 run scoreboard players set #dsk6v rpg.sys 3
execute if data storage rpg:mobsave cfg{dsk6k:4,dsk6v:2} run data merge storage rpg:mobsave {cfg:{dsk6k:2,dsk6v:5}}
execute if data storage rpg:mobsave cfg{dsk6k:4,dsk6v:3} run data merge storage rpg:mobsave {cfg:{dsk6k:2,dsk6v:4}}
execute if data storage rpg:mobsave cfg{dsk6k:4,dsk6v:4} run data merge storage rpg:mobsave {cfg:{dsk6v:2}}
execute if data storage rpg:mobsave cfg{dsk6k:4,dsk6v:5} run data merge storage rpg:mobsave {cfg:{dsk6v:3}}
scoreboard players set #dsm rpg.sys 0
execute if score #dsk7k rpg.sys matches 4 if score #dsk7v rpg.sys matches 2 run scoreboard players set #dsm rpg.sys 5
execute if score #dsk7k rpg.sys matches 4 if score #dsk7v rpg.sys matches 3 run scoreboard players set #dsm rpg.sys 4
execute if score #dsm rpg.sys matches 4..5 run scoreboard players set #dsk7k rpg.sys 2
execute if score #dsm rpg.sys matches 4..5 run scoreboard players operation #dsk7v rpg.sys = #dsm rpg.sys
execute if score #dsk7k rpg.sys matches 4 if score #dsk7v rpg.sys matches 4 run scoreboard players set #dsk7v rpg.sys 2
execute if score #dsk7k rpg.sys matches 4 if score #dsk7v rpg.sys matches 5 run scoreboard players set #dsk7v rpg.sys 3
execute if data storage rpg:mobsave cfg{dsk7k:4,dsk7v:2} run data merge storage rpg:mobsave {cfg:{dsk7k:2,dsk7v:5}}
execute if data storage rpg:mobsave cfg{dsk7k:4,dsk7v:3} run data merge storage rpg:mobsave {cfg:{dsk7k:2,dsk7v:4}}
execute if data storage rpg:mobsave cfg{dsk7k:4,dsk7v:4} run data merge storage rpg:mobsave {cfg:{dsk7v:2}}
execute if data storage rpg:mobsave cfg{dsk7k:4,dsk7v:5} run data merge storage rpg:mobsave {cfg:{dsk7v:3}}
scoreboard players set #dsm rpg.sys 0
execute if score #dsk8k rpg.sys matches 4 if score #dsk8v rpg.sys matches 2 run scoreboard players set #dsm rpg.sys 5
execute if score #dsk8k rpg.sys matches 4 if score #dsk8v rpg.sys matches 3 run scoreboard players set #dsm rpg.sys 4
execute if score #dsm rpg.sys matches 4..5 run scoreboard players set #dsk8k rpg.sys 2
execute if score #dsm rpg.sys matches 4..5 run scoreboard players operation #dsk8v rpg.sys = #dsm rpg.sys
execute if score #dsk8k rpg.sys matches 4 if score #dsk8v rpg.sys matches 4 run scoreboard players set #dsk8v rpg.sys 2
execute if score #dsk8k rpg.sys matches 4 if score #dsk8v rpg.sys matches 5 run scoreboard players set #dsk8v rpg.sys 3
execute if data storage rpg:mobsave cfg{dsk8k:4,dsk8v:2} run data merge storage rpg:mobsave {cfg:{dsk8k:2,dsk8v:5}}
execute if data storage rpg:mobsave cfg{dsk8k:4,dsk8v:3} run data merge storage rpg:mobsave {cfg:{dsk8k:2,dsk8v:4}}
execute if data storage rpg:mobsave cfg{dsk8k:4,dsk8v:4} run data merge storage rpg:mobsave {cfg:{dsk8v:2}}
execute if data storage rpg:mobsave cfg{dsk8k:4,dsk8v:5} run data merge storage rpg:mobsave {cfg:{dsk8v:3}}
scoreboard players set #dsv42 rpg.sys 1

scoreboard players remove #mlv_wolf rpg.sys 1
execute if score #mlv_wolf rpg.sys matches ..0 run scoreboard players set #mlv_wolf rpg.sys 1
function rpg:mob/open

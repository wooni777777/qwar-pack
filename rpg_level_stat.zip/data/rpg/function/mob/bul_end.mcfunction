particle minecraft:smoke ~ ~ ~ 0.05 0.05 0.05 0.02 5 normal @a
particle minecraft:block{block_state:{Name:"minecraft:black_concrete"}} ~ ~ ~ 0.05 0.05 0.05 0 4 normal @a
playsound minecraft:block.stone.hit hostile @a ~ ~ ~ 0.6 1.6
scoreboard players set #bhit rpg.sys 2
kill @s

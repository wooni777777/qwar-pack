scoreboard players remove #dr_d4n rpg.sys 1
execute if score #dr_d4n rpg.sys matches ..0 run scoreboard players set #dr_d4n rpg.sys 0
function rpg:mob/drop_d

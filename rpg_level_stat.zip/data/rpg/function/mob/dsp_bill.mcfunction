# 수표 값에 맞는 아이템을 고른다 (내부용)
execute if score #rv rpg.sys matches 1 run function rpg:mob/dsp_bill1 with storage rpg:mob g
execute if score #rv rpg.sys matches 2 run function rpg:mob/dsp_bill2 with storage rpg:mob g
execute if score #rv rpg.sys matches 3 run function rpg:mob/dsp_bill3 with storage rpg:mob g
execute if score #rv rpg.sys matches 4 run function rpg:mob/dsp_bill4 with storage rpg:mob g
execute if score #rv rpg.sys matches 5 run function rpg:mob/dsp_bill5 with storage rpg:mob g
execute if score #rv rpg.sys matches 6 run function rpg:mob/dsp_bill6 with storage rpg:mob g
execute if score #rv rpg.sys matches 7 run function rpg:mob/dsp_bill7 with storage rpg:mob g
execute if score #rv rpg.sys matches 8 run function rpg:mob/dsp_bill8 with storage rpg:mob g

scoreboard players add #sx rpg.sys 1
loot spawn ~ ~0.7 ~ loot rpg:mob/star1
particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.5 0.4 0.3 30 normal @a
playsound minecraft:entity.player.levelup hostile @a ~ ~ ~ 1 1.9
execute store result score #sr rpg.sys run random value 1..100
execute if score #sx rpg.sys matches ..29 if score #sr rpg.sys matches ..20 run function rpg:mob/star_extra

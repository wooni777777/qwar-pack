# 화난 해적 스폰 지점을 이 자리에 만든다 (메시지 없음)
function rpg:mob/spid_next
summon minecraft:marker ~ ~ ~ {Tags:["rpg_sp","rpg_sp_pir2","rpg_newsp"]}
scoreboard players operation @e[tag=rpg_newsp,limit=1] rpg.sid = #spid rpg.sys
scoreboard players set @e[tag=rpg_newsp,limit=1] rpg.cd 0
tag @e[tag=rpg_newsp] remove rpg_newsp

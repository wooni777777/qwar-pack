# 개수 -1 (내부용)
$scoreboard players remove #ds$(b)$(s)n rpg.sys 1
$execute if score #ds$(b)$(s)n rpg.sys matches ..-1 run scoreboard players set #ds$(b)$(s)n rpg.sys 0
$execute if score #ds$(b)$(s)n rpg.sys matches 65.. run scoreboard players set #ds$(b)$(s)n rpg.sys 64

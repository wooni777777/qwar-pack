# 경험치 조각 를 바닥에 떨군다
$summon minecraft:item ~ ~0.6 ~ {Item:{id:"minecraft:amethyst_shard",count:$(n),components:{"minecraft:custom_data":{rpg_exp:1,rpg_bossdrop:1},"minecraft:item_name":{text:"경험치 조각",color:"green",bold:true},"minecraft:lore":[{text:"주우면 경험치가 들어옵니다",color:"gray",italic:false}],"minecraft:enchantment_glint_override":true}}}

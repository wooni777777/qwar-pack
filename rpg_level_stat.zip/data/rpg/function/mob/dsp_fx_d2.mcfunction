# 경험치 조각 를 가장 가까운 플레이어에게 준다
$give @a[tag=rpg_rwd,limit=1] minecraft:amethyst_shard[minecraft:custom_data={rpg_exp:1,rpg_bossdrop:1},minecraft:item_name={text:"경험치 조각",color:"green",bold:true},minecraft:lore=[{text:"주우면 경험치가 들어옵니다",color:"gray",italic:false}],minecraft:enchantment_glint_override=true] $(n)

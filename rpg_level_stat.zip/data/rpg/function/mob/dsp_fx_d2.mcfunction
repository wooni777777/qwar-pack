# 경험치 조각 를 가장 가까운 플레이어에게 (v41 · 매크로 n)
$give @a[tag=rpg_rwd,limit=1] minecraft:amethyst_shard[minecraft:custom_data={rpg_exp:1},minecraft:item_name={text:"경험치 조각",color:"green",bold:true},minecraft:lore=[{text:"1개당 경험치 10",color:"gray",italic:false},{text:"받는 즉시 경험치로 바뀝니다",color:"dark_gray",italic:false}],minecraft:enchantment_glint_override=true] $(n)

scoreboard players remove @s rpg.anim 1
execute if score @s rpg.anim matches 2 run function rpg:mob/anim_pose_a
execute if score @s rpg.anim matches ..0 run tag @s remove rpg_atk

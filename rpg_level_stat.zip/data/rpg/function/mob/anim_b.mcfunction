scoreboard players set #anim rpg.sys 0
execute as @e[tag=rpg_mob,tag=!rpg_dead,tag=!rpg_atk] run function rpg:mob/anim_pose_b

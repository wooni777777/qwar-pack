# 해적 왕 고정템 이름 (내부용)
execute if score #rk rpg.sys matches 4 if score #rv rpg.sys matches 1 run data modify storage rpg:mob r.vn set value "네더별"
execute if score #rk rpg.sys matches 4 if score #rv rpg.sys matches 2 run data modify storage rpg:mob r.vn set value "경험치 책 1,500"
execute if score #rk rpg.sys matches 4 if score #rv rpg.sys matches 3 run data modify storage rpg:mob r.vn set value "경험치 책 1,000"

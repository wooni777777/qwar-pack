execute as @e[type=minecraft:marker,tag=rpg_sp,distance=..8] run function rpg:mob/point_rm1
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"8칸 안의 스폰 지점을 제거했습니다.","color":"white"}]

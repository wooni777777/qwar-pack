# [드롭템 설정] 버튼 처리 (내부용)
scoreboard players operation #mc rpg.sys = @s rpg.mdr
scoreboard players operation #md rpg.sys = #mc rpg.sys
scoreboard players operation #md rpg.sys %= #c10 rpg.sys
scoreboard players operation #mc rpg.sys /= #c10 rpg.sys
scoreboard players operation #mf rpg.sys = #mc rpg.sys
scoreboard players operation #mf rpg.sys %= #c10 rpg.sys
scoreboard players operation #mc rpg.sys /= #c10 rpg.sys
scoreboard players operation #ms rpg.sys = #mc rpg.sys
scoreboard players operation #ms rpg.sys %= #c10 rpg.sys
scoreboard players operation #mc rpg.sys /= #c10 rpg.sys
scoreboard players operation #mb rpg.sys = #mc rpg.sys
execute unless score #ms rpg.sys matches 1..8 run return fail
data modify storage rpg:mob e set value {b:"d",s:1,fx:2}
execute if score #mb rpg.sys matches 2 run data modify storage rpg:mob e set value {b:"w",s:1,fx:1}
execute if score #mb rpg.sys matches 3 run data modify storage rpg:mob e set value {b:"k",s:1,fx:3}
execute store result storage rpg:mob e.s int 1 run scoreboard players get #ms rpg.sys
execute if score #mf rpg.sys matches 1 if score #md rpg.sys matches 2 run function rpg:mob/ds_ku with storage rpg:mob e
execute if score #mf rpg.sys matches 1 if score #md rpg.sys matches 1 run function rpg:mob/ds_kd with storage rpg:mob e
execute if score #mf rpg.sys matches 2 if score #md rpg.sys matches 2 run function rpg:mob/ds_vu with storage rpg:mob e
execute if score #mf rpg.sys matches 2 if score #md rpg.sys matches 1 run function rpg:mob/ds_vd with storage rpg:mob e
execute if score #mf rpg.sys matches 3 if score #md rpg.sys matches 2 run function rpg:mob/ds_nu with storage rpg:mob e
execute if score #mf rpg.sys matches 3 if score #md rpg.sys matches 1 run function rpg:mob/ds_nd with storage rpg:mob e
execute if score #mf rpg.sys matches 4 if score #md rpg.sys matches 2 run function rpg:mob/ds_pu with storage rpg:mob e
execute if score #mf rpg.sys matches 4 if score #md rpg.sys matches 1 run function rpg:mob/ds_pd with storage rpg:mob e
execute if score #mb rpg.sys matches 1 run function rpg:mob/drop_d
execute if score #mb rpg.sys matches 2 run function rpg:mob/drop_w
execute if score #mb rpg.sys matches 3 run function rpg:mob/drop_k
playsound minecraft:ui.button.click player @s ~ ~ ~ 0.4 1.6
return 1

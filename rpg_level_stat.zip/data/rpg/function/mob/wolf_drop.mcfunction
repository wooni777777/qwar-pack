scoreboard players set #sx rpg.sys 0
loot spawn ~ ~0.7 ~ loot rpg:mob/star3
scoreboard players set #sr rpg.sys 0
execute store result score #sr rpg.sys run random value 1..100
execute if score #sr rpg.sys matches ..30 run function rpg:mob/star_extra

$data modify entity @s text set value ["",{"text":"$(nm)","color":"$(cl)","bold":true},{"text":"  "},{"text":"$(hp)","color":"red"},{"text":" / ","color":"dark_gray"},{"text":"$(mx)","color":"gray"}]

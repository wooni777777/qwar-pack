execute at @s rotated ~ 0 run function rpg:mob/preview_go

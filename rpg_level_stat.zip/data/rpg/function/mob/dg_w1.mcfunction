# 잠꾸러기 늑대 - 늑대의 별
$summon minecraft:item ~ ~0.6 ~ {Item:{id:"minecraft:nether_star",count:$(n),components:{"minecraft:custom_data":{rpg_bossdrop:1},"minecraft:item_name":{text:"늑대의 별",color:"gold",bold:true},"minecraft:lore":[{text:"필드 보스 [잠꾸러기 늑대] 가 남긴 결정",color:"gray",italic:false}],"minecraft:enchantment_glint_override":true}}}

# 해적 왕의 핵 를 가장 가까운 플레이어에게 (v42 · 매크로 n)
$execute as @a[tag=rpg_rwd,limit=1] run function rpg:mob/core_give_pking {n:$(n)}

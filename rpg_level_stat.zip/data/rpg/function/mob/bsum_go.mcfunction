# 보스 소환템으로 보스 1마리 소환 (v39 · 내부용 · 스폰 지점 없음 -> 끌려가지 않음)
$function rpg:mob/spawn_$(t)
scoreboard players set @e[tag=rpg_new,limit=1,sort=nearest] rpg.sid -999
tag @e[tag=rpg_new] add rpg_nolea
tag @e[tag=rpg_new] add rpg_summoned
execute as @e[tag=rpg_new,limit=1,sort=nearest] run function rpg:mob/lv_go
tag @e[tag=rpg_new] remove rpg_new
particle minecraft:reverse_portal ~ ~1 ~ 0.6 1 0.6 0.05 80 normal @a
playsound minecraft:entity.wither.spawn hostile @a ~ ~ ~ 0.6 1.3
$tellraw @a[distance=..64] [{"text":"[보스 소환] ","color":"dark_red","bold":true},{"selector":"@s","color":"yellow"},{"text":" 님이 ","color":"white"},{"text":"$(nm)","color":"dark_red","bold":true},{"text":" 을(를) 불러냈습니다!","color":"white"}]

# 같은 스폰 지점 몹이 겹쳐 늘어났을 때 가장 가까운 한 마리만 남기고 정리
execute as @e[tag=rpg_mob,tag=!rpg_dead,distance=..20,sort=nearest] if score @s rpg.sid = #sid rpg.sys run function rpg:mob/keep_first
execute as @e[tag=rpg_mob,tag=!rpg_dead,tag=!rpg_keep,distance=..20] if score @s rpg.sid = #sid rpg.sys run function rpg:mob/rm_mob
tag @e[tag=rpg_keep] remove rpg_keep

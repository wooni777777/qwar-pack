scoreboard players remove #mlv_pir1 rpg.sys 1
execute if score #mlv_pir1 rpg.sys matches ..0 run scoreboard players set #mlv_pir1 rpg.sys 1
function rpg:mob/open

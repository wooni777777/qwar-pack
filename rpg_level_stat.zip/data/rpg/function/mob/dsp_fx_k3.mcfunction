# 경험치 책 1,000 를 바닥에 떨군다
$summon minecraft:item ~ ~0.6 ~ {Item:{id:"minecraft:book",count:$(n),components:{"minecraft:custom_data":{rpg_book:1000,rpg_bossdrop:1},"minecraft:item_name":{text:"경험치 책 1,000",color:"aqua",bold:true},"minecraft:lore":[{text:"우클릭하면 경험치 1,000",color:"gray",italic:false}],"minecraft:enchantment_glint_override":true}}}

# 경험치 책 1,000 를 가장 가까운 플레이어에게 준다
$give @a[tag=rpg_rwd,limit=1] minecraft:book[minecraft:custom_data={rpg_book:1000,rpg_bossdrop:1},minecraft:item_name={text:"경험치 책 1,000",color:"aqua",bold:true},minecraft:lore=[{text:"우클릭하면 경험치 1,000",color:"gray",italic:false}],minecraft:enchantment_glint_override=true] $(n)

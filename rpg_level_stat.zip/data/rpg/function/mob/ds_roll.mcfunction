# 드롭 슬롯 하나를 굴린다 (내부용 · 보스 자리에서 실행)
#   function rpg:mob/ds_roll {b:"d",s:1}
$execute if score #ds$(b)$(s)k rpg.sys matches ..0 run return 0
$execute if score #ds$(b)$(s)n rpg.sys matches ..0 run return 0
execute store result score #dr rpg.sys run random value 1..100
$execute if score #dr rpg.sys > #ds$(b)$(s)p rpg.sys run return 0
$scoreboard players operation #rk rpg.sys = #ds$(b)$(s)k rpg.sys
$scoreboard players operation #rv rpg.sys = #ds$(b)$(s)v rpg.sys
$scoreboard players operation #rn rpg.sys = #ds$(b)$(s)n rpg.sys
execute store result storage rpg:mob g.n int 1 run scoreboard players get #rn rpg.sys
execute if score #rk rpg.sys matches 1 run function rpg:mob/dsp_bill
execute if score #rk rpg.sys matches 2 run function rpg:mob/dsp_chick
execute if score #rk rpg.sys matches 3 run function rpg:mob/dsp_cry
$execute if score #rk rpg.sys matches 4 run function rpg:mob/dsp_fx_$(b)
return 1

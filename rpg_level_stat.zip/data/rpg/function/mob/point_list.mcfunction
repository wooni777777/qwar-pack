tag @s add rpg_lister
tellraw @s {"text":"━━━━━  스폰 지점 (불러온 청크 기준)  ━━━━━","color":"dark_gray"}
execute as @e[type=minecraft:marker,tag=rpg_sp] at @s run function rpg:mob/point_l1
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}
tag @s remove rpg_lister

# 0.3칸 전진하고 그 자리에서 검사 (재귀 · 내부용)
execute unless entity @s run return 0
execute at @s run tp @s ^ ^ ^0.3
execute at @s run function rpg:mob/rock_step
scoreboard players remove #rst rpg.sys 1
execute if entity @s if score #rst rpg.sys matches 1.. run function rpg:mob/rock_move

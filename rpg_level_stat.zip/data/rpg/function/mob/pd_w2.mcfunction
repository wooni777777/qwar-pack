scoreboard players remove #dr_w2p rpg.sys 5
execute if score #dr_w2p rpg.sys matches ..0 run scoreboard players set #dr_w2p rpg.sys 0
function rpg:mob/drop_w

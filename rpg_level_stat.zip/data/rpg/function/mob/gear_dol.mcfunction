# 돌 몸 (v39 · 내부용 · 소환 직후 rpg_new 에게)
#   머리 슬롯 = 3D 머리 모델 (고개를 돌리면 같이 돕니다)
#   가슴 = 몸통 + 두 팔 (장비 레이어)  /  신발 = 두 다리 (바깥 레이어 · 돌이라 두껍게)
#   본체가 투명이어도 입힌 장비는 보이기 때문에, 스켈레톤이 걷고 팔을 휘두르는 대로 똑같이 움직입니다.
item replace entity @e[tag=rpg_new,limit=1] armor.head with minecraft:paper[minecraft:item_model="rpg:dol_head"]
item replace entity @e[tag=rpg_new,limit=1] armor.chest with minecraft:paper[minecraft:item_model="rpg:empty",minecraft:equippable={slot:"chest",asset_id:"rpg:mob_dol"}]
item replace entity @e[tag=rpg_new,limit=1] armor.feet with minecraft:paper[minecraft:item_model="rpg:empty",minecraft:equippable={slot:"feet",asset_id:"rpg:mob_dol"}]

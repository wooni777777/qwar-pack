execute as @e[tag=rpg_mob,tag=!rpg_dead,tag=!rpg_atk] run function rpg:mob/anim_pose_a

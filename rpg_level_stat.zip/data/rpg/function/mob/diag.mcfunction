scoreboard players set #d1 rpg.sys 0
scoreboard players set #d2 rpg.sys 0
scoreboard players set #d3 rpg.sys 0
scoreboard players set #d4 rpg.sys 0
scoreboard players set #d5 rpg.sys 0
execute store result score #d1 rpg.sys if entity @e[type=minecraft:marker,tag=rpg_sp]
execute store result score #d2 rpg.sys if entity @e[tag=rpg_mob]
execute store result score #d3 rpg.sys if entity @e[type=minecraft:item_display,tag=rpg_mdisp]
execute store result score #d4 rpg.sys if entity @e[type=minecraft:text_display,tag=rpg_mtext]
execute as @e[type=minecraft:item_display,tag=rpg_mdisp] on vehicle run scoreboard players add #d5 rpg.sys 1
tellraw @s {"text":"━━━━━  몬스터 진단 (불러온 청크)  ━━━━━","color":"dark_gray"}
tellraw @s ["",{"text":"  스폰 지점 : ","color":"gray"},{"score":{"name":"#d1","objective":"rpg.sys"},"color":"yellow"}]
tellraw @s ["",{"text":"  살아있는 몹 : ","color":"gray"},{"score":{"name":"#d2","objective":"rpg.sys"},"color":"yellow"}]
tellraw @s ["",{"text":"  모델 : ","color":"gray"},{"score":{"name":"#d3","objective":"rpg.sys"},"color":"yellow"},{"text":"   (그 중 몹에 탑승 중 : ","color":"dark_gray"},{"score":{"name":"#d5","objective":"rpg.sys"},"color":"yellow"},{"text":")","color":"dark_gray"}]
tellraw @s ["",{"text":"  이름표 : ","color":"gray"},{"score":{"name":"#d4","objective":"rpg.sys"},"color":"yellow"}]
scoreboard players set #ry rpg.sys 0
scoreboard players set #rp rpg.sys 0
execute as @e[type=minecraft:item_display,tag=rpg_mdisp,limit=1] store result score #ry rpg.sys run data get entity @s Rotation[0] 1
execute as @e[type=minecraft:item_display,tag=rpg_mdisp,limit=1] store result score #rp rpg.sys run data get entity @s Rotation[1] 1
tellraw @s ["",{"text":"  모델 각도 : 좌우 ","color":"gray"},{"score":{"name":"#ry","objective":"rpg.sys"},"color":"yellow"},{"text":"  /  위아래 ","color":"gray"},{"score":{"name":"#rp","objective":"rpg.sys"},"color":"yellow"},{"text":"   (둘 다 0 이어야 정상)","color":"dark_gray"}]
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}

scoreboard players set #mtimer rpg.sys 0
# 스폰 지점 처리
execute as @e[type=minecraft:marker,tag=rpg_sp] at @s run function rpg:mob/sp_check
execute as @e[tag=rpg_mob,tag=!rpg_dead,scores={rpg.cbt=1..}] run scoreboard players remove @s rpg.cbt 1
# 잠꾸러기 늑대는 늘 화난 상태로 둔다
execute as @e[tag=rpg_m_wolf,tag=!rpg_dead] at @s run function rpg:mob/wolf_anger
# 스폰 지점에서 너무 멀어진 몹은 되돌린다
execute as @e[tag=rpg_mob,tag=!rpg_dead] at @s run function rpg:mob/leash
# 새로 스폰된 모델에 저장된 바라보기 설정 적용
execute as @e[tag=rpg_mdisp,tag=rpg_bbnew] run function rpg:mob/bb_apply with storage rpg:main bb
function rpg:mob/bb_fix with storage rpg:main bb
# 이름 + 체력 갱신
execute as @e[tag=rpg_mob,tag=!rpg_dead] at @s run function rpg:mob/hp_text
execute as @e[tag=rpg_dying] run function rpg:mob/dying_tick
# 주인이 사라진 모델 / 이름표 정리
execute as @e[type=minecraft:item_display,tag=rpg_mdisp,tag=!rpg_preview,tag=!rpg_dying] at @s unless entity @e[tag=rpg_mob,distance=..4] run function rpg:mob/orphan
execute as @e[type=minecraft:text_display,tag=rpg_mtext] at @s unless entity @e[tag=rpg_mob,distance=..4] run function rpg:mob/orphan
# 해적 왕 : 1초마다 (쫄병 소환 · 근접 공격)
execute as @e[tag=rpg_m_pking,tag=!rpg_dead] at @s run function rpg:mob/pk_sec

# 보스 : 2초마다
scoreboard players add #btimer rpg.sys 1
execute if score #btimer rpg.sys matches 2.. run function rpg:mob/boss_all

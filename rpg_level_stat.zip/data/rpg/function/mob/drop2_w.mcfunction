# 잠꾸러기 늑대 드롭 (개수 · 확률 · 종류는 [드롭템 설정] 에서)
function rpg:mob/ds_roll {b:"w",s:1}
function rpg:mob/ds_roll {b:"w",s:2}
function rpg:mob/ds_roll {b:"w",s:3}
function rpg:mob/ds_roll {b:"w",s:4}
function rpg:mob/ds_roll {b:"w",s:5}
function rpg:mob/ds_roll {b:"w",s:6}
function rpg:mob/ds_roll {b:"w",s:7}
function rpg:mob/ds_roll {b:"w",s:8}

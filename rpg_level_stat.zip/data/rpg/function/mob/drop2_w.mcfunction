# 잠꾸러기 늑대 드롭 (개수·확률은 [드롭템 설정] 에서 조절)
scoreboard players set #dr rpg.sys 0
execute store result score #dr rpg.sys run random value 1..100
execute if score #dr rpg.sys <= #dr_w1p rpg.sys if score #dr_w1n rpg.sys matches 1.. run function rpg:mob/dgo_w1
scoreboard players set #dr rpg.sys 0
execute store result score #dr rpg.sys run random value 1..100
execute if score #dr rpg.sys <= #dr_w2p rpg.sys if score #dr_w2n rpg.sys matches 1.. run function rpg:mob/dgo_w2

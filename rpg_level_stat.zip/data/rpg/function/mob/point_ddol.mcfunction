function rpg:mob/sp_ddol
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"똘","color":"gray","bold":true},{"text":" 스폰 지점을 이 자리에 만들었습니다.","color":"white"}]
playsound minecraft:block.beacon.activate player @s ~ ~ ~ 1 1.6

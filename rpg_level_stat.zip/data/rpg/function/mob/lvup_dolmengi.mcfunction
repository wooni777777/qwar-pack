scoreboard players add #mlv_dolmengi rpg.sys 1
execute if score #mlv_dolmengi rpg.sys matches 200.. run scoreboard players set #mlv_dolmengi rpg.sys 200
function rpg:mob/open

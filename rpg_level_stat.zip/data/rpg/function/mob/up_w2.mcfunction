scoreboard players add #dr_w2n rpg.sys 1
execute if score #dr_w2n rpg.sys matches 64.. run scoreboard players set #dr_w2n rpg.sys 64
function rpg:mob/drop_w

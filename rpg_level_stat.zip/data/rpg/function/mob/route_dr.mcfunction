# [드롭템 설정] 클릭 처리
execute unless entity @s[tag=op] run function rpg:menu/noperm
execute unless entity @s[tag=op] run scoreboard players set @s rpg.mdr 0
execute unless entity @s[tag=op] run return 0
execute if score @s rpg.mdr matches 1 run function rpg:mob/save_all
execute if score @s rpg.mdr matches 2 run function rpg:mob/drop_d
execute if score @s rpg.mdr matches 3 run function rpg:mob/drop_w
execute if score @s rpg.mdr matches 4 run function rpg:mob/drop_k
execute if score @s rpg.mdr matches 101 run function rpg:mob/dn_d1
execute if score @s rpg.mdr matches 201 run function rpg:mob/up_d1
execute if score @s rpg.mdr matches 301 run function rpg:mob/pd_d1
execute if score @s rpg.mdr matches 401 run function rpg:mob/pu_d1
execute if score @s rpg.mdr matches 102 run function rpg:mob/dn_d2
execute if score @s rpg.mdr matches 202 run function rpg:mob/up_d2
execute if score @s rpg.mdr matches 302 run function rpg:mob/pd_d2
execute if score @s rpg.mdr matches 402 run function rpg:mob/pu_d2
execute if score @s rpg.mdr matches 103 run function rpg:mob/dn_d3
execute if score @s rpg.mdr matches 203 run function rpg:mob/up_d3
execute if score @s rpg.mdr matches 303 run function rpg:mob/pd_d3
execute if score @s rpg.mdr matches 403 run function rpg:mob/pu_d3
execute if score @s rpg.mdr matches 104 run function rpg:mob/dn_d4
execute if score @s rpg.mdr matches 204 run function rpg:mob/up_d4
execute if score @s rpg.mdr matches 304 run function rpg:mob/pd_d4
execute if score @s rpg.mdr matches 404 run function rpg:mob/pu_d4
execute if score @s rpg.mdr matches 105 run function rpg:mob/dn_w1
execute if score @s rpg.mdr matches 205 run function rpg:mob/up_w1
execute if score @s rpg.mdr matches 305 run function rpg:mob/pd_w1
execute if score @s rpg.mdr matches 405 run function rpg:mob/pu_w1
execute if score @s rpg.mdr matches 106 run function rpg:mob/dn_w2
execute if score @s rpg.mdr matches 206 run function rpg:mob/up_w2
execute if score @s rpg.mdr matches 306 run function rpg:mob/pd_w2
execute if score @s rpg.mdr matches 406 run function rpg:mob/pu_w2
execute if score @s rpg.mdr matches 107 run function rpg:mob/dn_k1
execute if score @s rpg.mdr matches 207 run function rpg:mob/up_k1
execute if score @s rpg.mdr matches 307 run function rpg:mob/pd_k1
execute if score @s rpg.mdr matches 407 run function rpg:mob/pu_k1
execute if score @s rpg.mdr matches 108 run function rpg:mob/dn_k2
execute if score @s rpg.mdr matches 208 run function rpg:mob/up_k2
execute if score @s rpg.mdr matches 308 run function rpg:mob/pd_k2
execute if score @s rpg.mdr matches 408 run function rpg:mob/pu_k2
execute if score @s rpg.mdr matches 109 run function rpg:mob/dn_k3
execute if score @s rpg.mdr matches 209 run function rpg:mob/up_k3
execute if score @s rpg.mdr matches 309 run function rpg:mob/pd_k3
execute if score @s rpg.mdr matches 409 run function rpg:mob/pu_k3
execute if score @s rpg.mdr matches 110 run function rpg:mob/dn_k4
execute if score @s rpg.mdr matches 210 run function rpg:mob/up_k4
execute if score @s rpg.mdr matches 310 run function rpg:mob/pd_k4
execute if score @s rpg.mdr matches 410 run function rpg:mob/pu_k4
execute if score @s rpg.mdr matches 111 run function rpg:mob/dn_k5
execute if score @s rpg.mdr matches 211 run function rpg:mob/up_k5
execute if score @s rpg.mdr matches 311 run function rpg:mob/pd_k5
execute if score @s rpg.mdr matches 411 run function rpg:mob/pu_k5
execute if score @s rpg.mdr matches 112 run function rpg:mob/dn_k6
execute if score @s rpg.mdr matches 212 run function rpg:mob/up_k6
execute if score @s rpg.mdr matches 312 run function rpg:mob/pd_k6
execute if score @s rpg.mdr matches 412 run function rpg:mob/pu_k6
scoreboard players set @s rpg.mdr 0
scoreboard players enable @s rpg.mdr

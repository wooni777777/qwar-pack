# [드롭템 설정] 클릭 처리
execute unless entity @s[tag=op] run function rpg:menu/noperm
execute unless entity @s[tag=op] run scoreboard players set @s rpg.mdr 0
execute unless entity @s[tag=op] run return 0
execute if score @s rpg.mdr matches 1 run function rpg:mob/save_all
execute if score @s rpg.mdr matches 2 run function rpg:mob/drop_d
execute if score @s rpg.mdr matches 3 run function rpg:mob/drop_w
execute if score @s rpg.mdr matches 4 run function rpg:mob/drop_k
execute if score @s rpg.mdr matches 1111..3842 run function rpg:mob/ds_edit
scoreboard players set @s rpg.mdr 0
scoreboard players enable @s rpg.mdr

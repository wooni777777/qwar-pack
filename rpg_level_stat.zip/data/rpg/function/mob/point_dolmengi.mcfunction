function rpg:mob/spid_next
summon minecraft:marker ~ ~ ~ {Tags:["rpg_sp","rpg_sp_dolmengi","rpg_newsp"]}
scoreboard players operation @e[tag=rpg_newsp,limit=1] rpg.sid = #spid rpg.sys
scoreboard players set @e[tag=rpg_newsp,limit=1] rpg.cd 0
tag @e[tag=rpg_newsp] remove rpg_newsp
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"돌맹이","color":"yellow","bold":true},{"text":" 스폰 지점을 이 자리에 만들었습니다.","color":"white"}]
playsound minecraft:block.beacon.activate player @s ~ ~ ~ 1 1.6

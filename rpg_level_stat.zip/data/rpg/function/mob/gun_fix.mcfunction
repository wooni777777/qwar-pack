# 이미 나와 있던 총든 해적에게 권총 쥐여 주기 (v41 · 내부용)
item replace entity @s weapon.mainhand with minecraft:bow[minecraft:item_model="rpg:pir_pistol"]
tag @s add rpg_gun41

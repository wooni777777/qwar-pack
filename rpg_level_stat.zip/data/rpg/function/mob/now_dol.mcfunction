# 돌 를 지금 이 자리에 한 마리 소환 (스폰 지점 없음)
function rpg:mob/spawn_dol
scoreboard players set @e[tag=rpg_new,limit=1,sort=nearest] rpg.sid -999
tag @e[tag=rpg_new] add rpg_nolea
execute as @e[tag=rpg_new,limit=1,sort=nearest] run function rpg:mob/lv_go
tag @e[tag=rpg_new] remove rpg_new

# 늑대 최대체력 확인 (v39 · 내부용)
execute store result score #fwm rpg.sys run attribute @s minecraft:max_health base get 1
execute if score #fwm rpg.sys matches 1024.. run return 0
attribute @s minecraft:max_health base set 1024
effect give @s minecraft:instant_health 1 8 true
scoreboard players set @s rpg.mlh -1
scoreboard players set #wfix rpg.sys 1

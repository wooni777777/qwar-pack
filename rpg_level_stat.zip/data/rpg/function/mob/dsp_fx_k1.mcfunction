# 네더의 별 를 가장 가까운 플레이어에게 (v42 · 매크로 n)
$execute as @a[tag=rpg_rwd,limit=1] run function rpg:war/star_give {n:$(n)}

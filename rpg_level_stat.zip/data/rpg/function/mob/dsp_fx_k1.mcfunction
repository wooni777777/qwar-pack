# 네더별 를 가장 가까운 플레이어에게 준다
$give @a[tag=rpg_rwd,limit=1] minecraft:nether_star[minecraft:custom_data={rpg_bossdrop:1},minecraft:item_name={text:"네더별",color:"dark_red",bold:true},minecraft:lore=[{text:"해적 왕이 남긴 별",color:"gray",italic:false}],minecraft:enchantment_glint_override=true] $(n)

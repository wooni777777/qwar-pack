# 네더별 를 바닥에 떨군다
$summon minecraft:item ~ ~0.6 ~ {Item:{id:"minecraft:nether_star",count:$(n),components:{"minecraft:custom_data":{rpg_bossdrop:1},"minecraft:item_name":{text:"네더별",color:"dark_red",bold:true},"minecraft:lore":[{text:"해적 왕이 남긴 별",color:"gray",italic:false}],"minecraft:enchantment_glint_override":true}}}

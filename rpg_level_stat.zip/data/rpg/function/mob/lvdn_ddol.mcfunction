scoreboard players remove #mlv_ddol rpg.sys 1
execute if score #mlv_ddol rpg.sys matches ..0 run scoreboard players set #mlv_ddol rpg.sys 1
function rpg:mob/open

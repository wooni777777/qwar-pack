particle minecraft:poof ~ ~ ~ 0.25 0.25 0.25 0.04 14 normal @a
particle minecraft:crit ~ ~ ~ 0.3 0.3 0.3 0.15 12 normal @a
playsound minecraft:block.stone.break hostile @a ~ ~ ~ 1.2 0.7
kill @s

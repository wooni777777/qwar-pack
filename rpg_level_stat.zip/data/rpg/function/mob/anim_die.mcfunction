function rpg:mob/anim_pose_d
execute on passengers if entity @s[tag=rpg_mdisp] run tag @s add rpg_dying
execute on passengers if entity @s[tag=rpg_mdisp] run scoreboard players set @s rpg.cd 3
execute on passengers if entity @s[tag=rpg_mtext] run kill @s

scoreboard players operation #sid rpg.sys = @s rpg.sid
execute if entity @s[tag=rpg_sp_ddol] run function rpg:mob/spawn_ddol
execute if entity @s[tag=rpg_sp_ddodol] run function rpg:mob/spawn_ddodol
execute if entity @s[tag=rpg_sp_dolmengi] run function rpg:mob/spawn_dolmengi
execute if entity @s[tag=rpg_sp_dol] run function rpg:mob/spawn_dol
execute if entity @s[tag=rpg_sp_wolf] run function rpg:mob/spawn_wolf
scoreboard players operation @e[tag=rpg_new,limit=1] rpg.sid = #sid rpg.sys
tag @e[tag=rpg_new] remove rpg_new
execute if entity @s[tag=rpg_sp_dol] run scoreboard players operation @s rpg.cd = #boss_cd rpg.sys
execute if entity @s[tag=rpg_sp_wolf] run scoreboard players operation @s rpg.cd = #boss_cd rpg.sys
execute unless entity @s[tag=rpg_sp_dol] unless entity @s[tag=rpg_sp_wolf] run scoreboard players operation @s rpg.cd = #mob_cd rpg.sys

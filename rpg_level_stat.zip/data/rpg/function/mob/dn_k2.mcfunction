scoreboard players remove #dr_k2n rpg.sys 1
execute if score #dr_k2n rpg.sys matches ..0 run scoreboard players set #dr_k2n rpg.sys 0
function rpg:mob/drop_k

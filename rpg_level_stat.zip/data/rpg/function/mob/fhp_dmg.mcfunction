# 이번 틱에 받은 피해만큼 가짜 피를 깎는다 (0.01 단위까지 모아서 계산)
scoreboard players operation @s rpg.mfr += #fd rpg.sys
scoreboard players operation #fdi rpg.sys = @s rpg.mfr
scoreboard players operation #fdi rpg.sys /= #c100 rpg.sys
scoreboard players operation #fdm rpg.sys = #fdi rpg.sys
scoreboard players operation #fdm rpg.sys *= #c100 rpg.sys
scoreboard players operation @s rpg.mfr -= #fdm rpg.sys
scoreboard players operation @s rpg.mhp -= #fdi rpg.sys
execute if score @s rpg.mhp matches ..0 run function rpg:mob/fdie

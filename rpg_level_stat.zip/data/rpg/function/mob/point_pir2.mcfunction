function rpg:mob/sp_pir2
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"화난 해적","color":"red","bold":true},{"text":" 스폰 지점을 이 자리에 만들었습니다.","color":"white"}]
playsound minecraft:block.beacon.activate player @s ~ ~ ~ 1 1.6

scoreboard players remove #dr_k6n rpg.sys 1
execute if score #dr_k6n rpg.sys matches ..0 run scoreboard players set #dr_k6n rpg.sys 0
function rpg:mob/drop_k

# 또돌맹  |  체력 100 / 공격력 9 / 이동속도 0.23   (이 숫자만 고치면 됩니다)
# 모델 높이가 어긋나면 item_display 의 translation 두 번째 숫자 (-0.862)
# 이름표 높이는 text_display 의 translation 두 번째 숫자 (0.42) 를 조절하세요.
# 모델/이름표는 소환 NBT 의 Passengers 로 한 번에 붙기 때문에 절대 중복 생성되지 않습니다.
# 모델이 바라보는 방식은 게임 안에서 바로 바꿀 수 있습니다 :
#   /function rpg:mob/bb_c  (기본) 항상 정면으로 플레이어를 바라봄
#   /function rpg:mob/bb_v        좌우만 따라감
#   /function rpg:mob/bb_h        한쪽만 바라봄
#   /function rpg:mob/bb_f        완전 고정
summon minecraft:zombie ~ ~ ~ {Tags:["rpg_mob","rpg_m_ddodol","rpg_new"],CustomName:{text:"또돌맹",color:"gray",bold:true},CustomNameVisible:0b,PersistenceRequired:1b,Silent:1b,CanPickUpLoot:0b,DeathLootTable:"minecraft:empty",Passengers:[{id:"minecraft:item_display",Tags:["rpg_mdisp"],Rotation:[0.0f,0.0f],item:{id:"minecraft:stone",count:1,components:{"minecraft:item_model":"rpg:ddodol"}},item_display:"fixed",billboard:"fixed",view_range:1.6f,shadow_radius:0.38f,shadow_strength:0.6f,transformation:{translation:[0.0f,-0.862f,0.0f],left_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.2f,1.2f,1.2f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}},{id:"minecraft:text_display",Tags:["rpg_mtext"],Rotation:[0.0f,0.0f],billboard:"center",alignment:"center",see_through:false,background:1073741824,view_range:1.5f,text:{text:"또돌맹",color:"gray",bold:true},transformation:{translation:[0.0f,0.42f,0.0f],left_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[0.7f,0.7f,0.7f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}]}
effect give @e[tag=rpg_new] minecraft:invisibility infinite 0 true
attribute @e[tag=rpg_new,limit=1] minecraft:max_health base set 100
attribute @e[tag=rpg_new,limit=1] minecraft:attack_damage base set 9
attribute @e[tag=rpg_new,limit=1] minecraft:movement_speed base set 0.23
attribute @e[tag=rpg_new,limit=1] minecraft:follow_range base set 28
attribute @e[tag=rpg_new,limit=1] minecraft:knockback_resistance base set 0.3
attribute @e[tag=rpg_new,limit=1] minecraft:scale base set 0.8
attribute @e[tag=rpg_new,limit=1] minecraft:spawn_reinforcements base set 0
# 햇빛 화상 방지용 투명 아이템 (리소스팩에서 안 보이게 처리됨)
function rpg:mob/head_ddodol
data modify entity @e[tag=rpg_new,limit=1] drop_chances set value {head:0.0f,chest:0.0f,legs:0.0f,feet:0.0f,mainhand:0.0f,offhand:0.0f}
data modify entity @e[tag=rpg_new,limit=1] Health set value 100.0f
scoreboard players set @e[tag=rpg_new,limit=1] rpg.php 100
scoreboard players set @e[tag=rpg_new,limit=1] rpg.cbt 0
particle minecraft:poof ~ ~0.4 ~ 0.25 0.25 0.25 0.01 6 normal @a
playsound minecraft:block.stone.place block @a ~ ~ ~ 0.8 0.6

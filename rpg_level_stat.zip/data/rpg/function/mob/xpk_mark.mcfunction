# 죽은 몹 자리에 표식 (v41 · 내부용) — 1초 뒤 나오는 바닐라 경험치 구슬을 치웁니다
summon minecraft:marker ~ ~ ~ {Tags:["rpg_xpk","rpg_xpkn"]}
scoreboard players set @e[type=minecraft:marker,tag=rpg_xpkn] rpg.cd 50
tag @e[type=minecraft:marker,tag=rpg_xpkn] remove rpg_xpkn

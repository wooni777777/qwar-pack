$attribute @s minecraft:max_health base set $(h)
$attribute @s minecraft:attack_damage base set $(a)

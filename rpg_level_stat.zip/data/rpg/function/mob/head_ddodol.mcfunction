item replace entity @e[tag=rpg_new,limit=1] armor.head with minecraft:carrot[minecraft:item_model="rpg:empty"]

# 해적 왕 근접 공격
tag @s add rpg_pkcur
execute store result storage rpg:mob pk.d int 1 run attribute @s minecraft:attack_damage get 1
function rpg:mob/pk_hit with storage rpg:mob pk
tag @s remove rpg_pkcur
playsound minecraft:entity.player.attack.sweep hostile @a ~ ~ ~ 1.3 0.6
particle minecraft:sweep_attack ~ ~1 ~ 0.7 0.4 0.7 0 3 normal @a

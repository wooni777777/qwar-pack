# 크리스탈 값에 맞는 아이템을 고른다 (내부용)
execute if score #rv rpg.sys matches 1 run function rpg:mob/dsp_cry1 with storage rpg:mob g
execute if score #rv rpg.sys matches 2 run function rpg:mob/dsp_cry2 with storage rpg:mob g
execute if score #rv rpg.sys matches 3 run function rpg:mob/dsp_cry3 with storage rpg:mob g
execute if score #rv rpg.sys matches 4 run function rpg:mob/dsp_cry4 with storage rpg:mob g
execute if score #rv rpg.sys matches 5 run function rpg:mob/dsp_cry5 with storage rpg:mob g
execute if score #rv rpg.sys matches 6 run function rpg:mob/dsp_cry6 with storage rpg:mob g
execute if score #rv rpg.sys matches 7 run function rpg:mob/dsp_cry7 with storage rpg:mob g
execute if score #rv rpg.sys matches 8 run function rpg:mob/dsp_cry8 with storage rpg:mob g
execute if score #rv rpg.sys matches 9 run function rpg:mob/dsp_cry9 with storage rpg:mob g
execute if score #rv rpg.sys matches 10 run function rpg:mob/dsp_cry10 with storage rpg:mob g
execute if score #rv rpg.sys matches 11 run function rpg:mob/dsp_cry11 with storage rpg:mob g
execute if score #rv rpg.sys matches 12 run function rpg:mob/dsp_cry12 with storage rpg:mob g

# 잡몹 처치 돈 (v39 · as 몹) — 레벨 비례, 수표 동전(1원/10원/100원) 으로 가장 가까운 플레이어에게
#   돈 = (레벨² + 12 × 레벨 − 1) ÷ 8
#     1렙 1원 · 2렙 3원 · 3렙 5원 · 5렙 10원 · 8렙 19원 · 10렙 27원 · 15렙 50원 · 20렙 79원 · 30렙 157원
#   해적(눈다친 · 화난 · 총든)은 × 1.5
#   전체 배율 : /scoreboard players set #mob_money rpg.sys 150   (150 = 1.5배, 기본 100)
function rpg:mob/lv_get
scoreboard players set #k12 rpg.sys 12
scoreboard players set #k8 rpg.sys 8
scoreboard players set #k3 rpg.sys 3
scoreboard players set #k2 rpg.sys 2
scoreboard players operation #pm rpg.sys = #mlv rpg.sys
scoreboard players operation #pm rpg.sys *= #mlv rpg.sys
scoreboard players operation #pt rpg.sys = #mlv rpg.sys
scoreboard players operation #pt rpg.sys *= #k12 rpg.sys
scoreboard players operation #pm rpg.sys += #pt rpg.sys
scoreboard players remove #pm rpg.sys 1
scoreboard players operation #pm rpg.sys /= #k8 rpg.sys
execute if entity @s[tag=rpg_m_pir1] run scoreboard players operation #pm rpg.sys *= #k3 rpg.sys
execute if entity @s[tag=rpg_m_pir1] run scoreboard players operation #pm rpg.sys /= #k2 rpg.sys
execute if entity @s[tag=rpg_m_pir2] run scoreboard players operation #pm rpg.sys *= #k3 rpg.sys
execute if entity @s[tag=rpg_m_pir2] run scoreboard players operation #pm rpg.sys /= #k2 rpg.sys
execute if entity @s[tag=rpg_m_pir3] run scoreboard players operation #pm rpg.sys *= #k3 rpg.sys
execute if entity @s[tag=rpg_m_pir3] run scoreboard players operation #pm rpg.sys /= #k2 rpg.sys
scoreboard players operation #pm rpg.sys *= #mob_money rpg.sys
scoreboard players operation #pm rpg.sys /= #c100 rpg.sys
execute if score #pm rpg.sys matches ..0 run scoreboard players set #pm rpg.sys 1
# 100원 / 10원 / 1원 동전으로 나눠서
scoreboard players operation #p3 rpg.sys = #pm rpg.sys
scoreboard players operation #p3 rpg.sys /= #c100 rpg.sys
scoreboard players operation #p2 rpg.sys = #pm rpg.sys
scoreboard players operation #p2 rpg.sys %= #c100 rpg.sys
scoreboard players operation #p2 rpg.sys /= #c10 rpg.sys
scoreboard players operation #p1 rpg.sys = #pm rpg.sys
scoreboard players operation #p1 rpg.sys %= #c10 rpg.sys
execute store result storage rpg:mob pay.n int 1 run scoreboard players get #p3 rpg.sys
execute if score #p3 rpg.sys matches 1.. run function rpg:mob/coin3 with storage rpg:mob pay
execute store result storage rpg:mob pay.n int 1 run scoreboard players get #p2 rpg.sys
execute if score #p2 rpg.sys matches 1.. run function rpg:mob/coin2 with storage rpg:mob pay
execute store result storage rpg:mob pay.n int 1 run scoreboard players get #p1 rpg.sys
execute if score #p1 rpg.sys matches 1.. run function rpg:mob/coin1 with storage rpg:mob pay

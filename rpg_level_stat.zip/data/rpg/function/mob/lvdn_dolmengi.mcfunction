scoreboard players remove #mlv_dolmengi rpg.sys 1
execute if score #mlv_dolmengi rpg.sys matches ..0 run scoreboard players set #mlv_dolmengi rpg.sys 1
function rpg:mob/open

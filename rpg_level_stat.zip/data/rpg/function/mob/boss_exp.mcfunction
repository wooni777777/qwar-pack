# 보스 처치 경험치 (근처 플레이어 모두 · 내부용)
execute as @a[distance=..48,gamemode=!spectator] run scoreboard players operation @s rpg.exp += #exp_boss rpg.sys
execute as @a[distance=..48,gamemode=!spectator] run function rpg:exp/check

# 경험치 닭 값에 맞는 아이템을 고른다 (내부용)
execute if score #rv rpg.sys matches 1 run function rpg:mob/dsp_chick1 with storage rpg:mob g
execute if score #rv rpg.sys matches 2 run function rpg:mob/dsp_chick2 with storage rpg:mob g
execute if score #rv rpg.sys matches 3 run function rpg:mob/dsp_chick3 with storage rpg:mob g
execute if score #rv rpg.sys matches 4 run function rpg:mob/dsp_chick4 with storage rpg:mob g
execute if score #rv rpg.sys matches 5 run function rpg:mob/dsp_chick5 with storage rpg:mob g

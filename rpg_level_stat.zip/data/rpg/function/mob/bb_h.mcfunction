data modify storage rpg:main bb.v set value "horizontal"
execute as @e[tag=rpg_mdisp,tag=!rpg_hum] run data modify entity @s billboard set value "horizontal"
execute as @e[tag=rpg_mdisp,tag=!rpg_hum] run data modify entity @s Rotation set value [0.0f,0.0f]
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"모델 방향 : ","color":"white"},{"text":"horizontal","color":"aqua","bold":true},{"text":" - 좌우로 안 돌고 한쪽만 바라봄","color":"gray"}]

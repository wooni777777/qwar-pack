# 해적 왕 - 네더별
$summon minecraft:item ~ ~0.6 ~ {Item:{id:"minecraft:nether_star",count:$(n)}}

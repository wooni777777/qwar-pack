# 해적 쫄병 처치 보상
give @s paper[minecraft:custom_data={rpg_bill:10},minecraft:item_model="rpg:bill_2",minecraft:item_name={"text":"10원","color":"gray","bold":true},minecraft:lore=[{"text":"q후계자 전쟁 수표","color":"dark_gray","italic":false},{"text":"우클릭하면 소지금으로 들어갑니다","color":"gray","italic":false}],minecraft:consumable={consume_seconds:0.25f,animation:"none",sound:"minecraft:item.book.page_turn",has_consume_particles:false}] 3
execute at @s run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 0.8 1.5

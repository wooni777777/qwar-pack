# 주인 없는 모델/이름표 정리 (내부용) — 아직 몹에 타 있으면(죽는 중 포함) 남겨 둔다
execute on vehicle run return 0
kill @s

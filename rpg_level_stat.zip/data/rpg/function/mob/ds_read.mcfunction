$scoreboard players operation #rk rpg.sys = #ds$(b)$(s)k rpg.sys
$scoreboard players operation #rv rpg.sys = #ds$(b)$(s)v rpg.sys
$scoreboard players operation #rn rpg.sys = #ds$(b)$(s)n rpg.sys
$scoreboard players operation #rp rpg.sys = #ds$(b)$(s)p rpg.sys

# 쫄병 해적 1마리 (3종 중 무작위)
scoreboard players set #pkr rpg.sys 0
execute store result score #pkr rpg.sys run random value 1..3
execute if score #pkr rpg.sys matches 1 run function rpg:mob/spawn_pir1
execute if score #pkr rpg.sys matches 2 run function rpg:mob/spawn_pir2
execute if score #pkr rpg.sys matches 3 run function rpg:mob/spawn_pir3
# 스폰 지점이 없는 소환수 : 되돌리기/중복정리 대상에서 뺀다
scoreboard players set @e[tag=rpg_new,limit=1,sort=nearest] rpg.sid -999
tag @e[tag=rpg_new] add rpg_minion
tag @e[tag=rpg_new] add rpg_nolea
execute as @e[tag=rpg_new,limit=1,sort=nearest] run function rpg:mob/lv_go
tag @e[tag=rpg_new] remove rpg_new

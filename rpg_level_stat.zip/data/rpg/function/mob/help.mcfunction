tellraw @s {"text":"━━━━━━━  몬스터 명령어  ━━━━━━━","color":"dark_gray"}
tellraw @s ["",{"text":"  서 있는 자리에 스폰 지점 만들기 (중복 가능)","color":"gray"}]
tellraw @s ["",{"text":"  /function rpg:mob/point_ddol","color":"green"},{"text":"      똘 (1렙)","color":"gray"}]
tellraw @s ["",{"text":"  /function rpg:mob/point_ddodol","color":"green"},{"text":"    또돌맹 (3렙)","color":"gray"}]
tellraw @s ["",{"text":"  /function rpg:mob/point_dolmengi","color":"green"},{"text":"  돌맹이 (5렙)","color":"gray"}]
tellraw @s ["",{"text":"  /function rpg:mob/point_dol","color":"green"},{"text":"       돌 - 하위 보스 (10렙)","color":"gray"}]
tellraw @s " "
tellraw @s ["",{"text":"  /function rpg:mob/point_wolf","color":"green"},{"text":"      잠꾸러기 늑대 - 필드 보스","color":"gray"}]
tellraw @s " "
tellraw @s ["",{"text":"  /function rpg:mob/point_pir1","color":"green"},{"text":"      눈다친 해적","color":"gray"}]
tellraw @s ["",{"text":"  /function rpg:mob/point_pir2","color":"green"},{"text":"      화난 해적","color":"gray"}]
tellraw @s ["",{"text":"  /function rpg:mob/point_pir3","color":"green"},{"text":"      총든 해적","color":"gray"}]
tellraw @s ["",{"text":"  /function rpg:mob/point_pking","color":"green"},{"text":"     해적 왕 - 필드 보스 (HP 500)","color":"gray"}]
tellraw @s " "
tellraw @s ["",{"text":"  /function rpg:mob/point_list","color":"aqua"},{"text":"      스폰 지점 목록","color":"gray"}]
tellraw @s ["",{"text":"  /function rpg:mob/point_remove","color":"aqua"},{"text":"    8칸 안 스폰 지점 삭제","color":"gray"}]
tellraw @s ["",{"text":"  /function rpg:mob/kill_all","color":"aqua"},{"text":"       몬스터/모델 정리 (겹쳤을 때)","color":"gray"}]
tellraw @s ["",{"text":"  /function rpg:mob/wipe","color":"red"},{"text":"           몬스터 + 스폰 지점 전부 제거","color":"gray"}]
tellraw @s ["",{"text":"  /function rpg:mob/preview","color":"light_purple"},{"text":"       모델 4종 미리보기 세우기","color":"gray"}]
tellraw @s ["",{"text":"  /function rpg:mob/preview_off","color":"light_purple"},{"text":"   미리보기 치우기","color":"gray"}]
tellraw @s ["",{"text":"  /function rpg:mob/diag","color":"yellow"},{"text":"          몹/모델 상태 진단","color":"gray"}]
tellraw @s " "
tellraw @s ["",{"text":"  모델이 바라보는 방식 (바로 적용됨)","color":"gray"}]
tellraw @s ["",{"text":"  /function rpg:mob/bb_h","color":"aqua"},{"text":"  한쪽만 바라봄        ","color":"gray"},{"text":"/function rpg:mob/bb_v","color":"aqua"},{"text":"  좌우만 따라감 (누울 수 있음)","color":"gray"}]
tellraw @s ["",{"text":"  /function rpg:mob/bb_c","color":"aqua"},{"text":"  항상 정면 추적 (기본) ","color":"gray"},{"text":"/function rpg:mob/bb_f","color":"aqua"},{"text":"  완전 고정","color":"gray"}]
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}

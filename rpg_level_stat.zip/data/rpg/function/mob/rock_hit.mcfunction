scoreboard players set #bhas rpg.sys 0
execute if entity @e[tag=rpg_boss,tag=!rpg_dead,distance=..40] run scoreboard players set #bhas rpg.sys 1
execute if score #bhas rpg.sys matches 1 run damage @a[distance=..1.9,gamemode=!spectator] 14 rpg:rock by @e[tag=rpg_boss,tag=!rpg_dead,limit=1,sort=nearest]
execute if score #bhas rpg.sys matches 0 run damage @a[distance=..1.9,gamemode=!spectator] 14 rpg:rock
function rpg:mob/rock_end

# 돌이 터진다 — 닿은 플레이어와 엔티티 전부에게 피해 (내부용)
scoreboard players set #bhas rpg.sys 0
execute if entity @e[tag=rpg_boss,tag=!rpg_dead,distance=..48] run scoreboard players set #bhas rpg.sys 1
execute if score #bhas rpg.sys matches 1 run damage @a[distance=..2.4,gamemode=!spectator] 14 rpg:rock by @e[tag=rpg_boss,tag=!rpg_dead,limit=1,sort=nearest]
execute if score #bhas rpg.sys matches 0 run damage @a[distance=..2.4,gamemode=!spectator] 14 rpg:rock
execute as @e[distance=..2.4,tag=!rpg_mob,tag=!rpg_rock,tag=!rpg_model,tag=!rpg_mtext,tag=!rpg_npcE,tag=!god,type=!minecraft:marker,type=!minecraft:item_display,type=!minecraft:text_display,type=!minecraft:block_display,type=!minecraft:interaction,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:player] run damage @s 14 rpg:rock
function rpg:mob/rock_end

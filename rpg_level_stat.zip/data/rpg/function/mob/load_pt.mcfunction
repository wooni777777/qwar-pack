# 저장된 스폰 지점을 하나씩 꺼내 다시 만든다 (재귀)
execute unless data storage rpg:mobsave work[0] run return 0
data modify storage rpg:mobsave one set from storage rpg:mobsave work[0]
function rpg:mob/load_one with storage rpg:mobsave one
data remove storage rpg:mobsave work[0]
scoreboard players add #spn rpg.sys 1
function rpg:mob/load_pt

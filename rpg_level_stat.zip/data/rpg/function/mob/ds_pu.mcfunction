# 확률 +5 (내부용)
$scoreboard players add #ds$(b)$(s)p rpg.sys 5
$execute if score #ds$(b)$(s)p rpg.sys matches ..-1 run scoreboard players set #ds$(b)$(s)p rpg.sys 0
$execute if score #ds$(b)$(s)p rpg.sys matches 101.. run scoreboard players set #ds$(b)$(s)p rpg.sys 100

kill @e[type=minecraft:marker,tag=rpg_sp_pir1,distance=..8]
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"눈다친 해적","color":"gray","bold":true},{"text":" 스폰 지점을 8칸 안에서 제거했습니다.","color":"white"}]
playsound minecraft:block.beacon.deactivate player @s ~ ~ ~ 1 1.6

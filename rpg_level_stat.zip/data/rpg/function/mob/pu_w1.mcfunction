scoreboard players add #dr_w1p rpg.sys 5
execute if score #dr_w1p rpg.sys matches 100.. run scoreboard players set #dr_w1p rpg.sys 100
function rpg:mob/drop_w

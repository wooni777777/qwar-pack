# 처치 보상 수표 (인벤이 꽉 차면 바닥에 떨어집니다)
give @s paper[minecraft:custom_data={rpg_bill:1},minecraft:item_name={"text":"1원","color":"white","bold":true},minecraft:lore=[{"text":"q후계자 전쟁 수표","color":"dark_gray","italic":false},{"text":"우클릭하면 소지금으로 들어갑니다","color":"gray","italic":false}],minecraft:consumable={consume_seconds:0.25f,animation:"none",sound:"minecraft:item.book.page_turn",has_consume_particles:false}] 5
execute at @s run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 0.8 1.5

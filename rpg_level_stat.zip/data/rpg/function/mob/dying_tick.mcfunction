scoreboard players remove @s rpg.cd 1
execute if score @s rpg.cd matches ..0 run kill @s

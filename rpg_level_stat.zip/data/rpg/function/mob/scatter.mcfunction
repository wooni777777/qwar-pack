execute store result score #sd rpg.sys run random value 1..8
execute if score #sd rpg.sys matches 1 run data merge entity @s {Motion:[0.42d,0.45d,0.00d],PickupDelay:20s}
execute if score #sd rpg.sys matches 2 run data merge entity @s {Motion:[0.30d,0.45d,0.30d],PickupDelay:20s}
execute if score #sd rpg.sys matches 3 run data merge entity @s {Motion:[0.00d,0.45d,0.42d],PickupDelay:20s}
execute if score #sd rpg.sys matches 4 run data merge entity @s {Motion:[-0.30d,0.45d,0.30d],PickupDelay:20s}
execute if score #sd rpg.sys matches 5 run data merge entity @s {Motion:[-0.42d,0.45d,0.00d],PickupDelay:20s}
execute if score #sd rpg.sys matches 6 run data merge entity @s {Motion:[-0.30d,0.45d,-0.30d],PickupDelay:20s}
execute if score #sd rpg.sys matches 7 run data merge entity @s {Motion:[0.00d,0.45d,-0.42d],PickupDelay:20s}
execute if score #sd rpg.sys matches 8 run data merge entity @s {Motion:[0.30d,0.45d,-0.30d],PickupDelay:20s}

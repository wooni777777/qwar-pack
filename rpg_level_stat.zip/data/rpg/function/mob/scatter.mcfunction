# 떨어진 아이템 하나를 사방으로 튕긴다 (내부용)
execute store result score #sd rpg.sys run random value 1..12
execute if score #sd rpg.sys matches 1 run data merge entity @s {Motion:[0.58d,0.52d,0.00d],PickupDelay:20s}
execute if score #sd rpg.sys matches 2 run data merge entity @s {Motion:[0.41d,0.50d,0.41d],PickupDelay:20s}
execute if score #sd rpg.sys matches 3 run data merge entity @s {Motion:[0.00d,0.56d,0.58d],PickupDelay:20s}
execute if score #sd rpg.sys matches 4 run data merge entity @s {Motion:[-0.41d,0.50d,0.41d],PickupDelay:20s}
execute if score #sd rpg.sys matches 5 run data merge entity @s {Motion:[-0.58d,0.52d,0.00d],PickupDelay:20s}
execute if score #sd rpg.sys matches 6 run data merge entity @s {Motion:[-0.41d,0.50d,-0.41d],PickupDelay:20s}
execute if score #sd rpg.sys matches 7 run data merge entity @s {Motion:[0.00d,0.56d,-0.58d],PickupDelay:20s}
execute if score #sd rpg.sys matches 8 run data merge entity @s {Motion:[0.41d,0.50d,-0.41d],PickupDelay:20s}
execute if score #sd rpg.sys matches 9 run data merge entity @s {Motion:[0.24d,0.62d,0.58d],PickupDelay:20s}
execute if score #sd rpg.sys matches 10 run data merge entity @s {Motion:[-0.58d,0.62d,0.24d],PickupDelay:20s}
execute if score #sd rpg.sys matches 11 run data merge entity @s {Motion:[0.58d,0.62d,-0.24d],PickupDelay:20s}
execute if score #sd rpg.sys matches 12 run data merge entity @s {Motion:[-0.24d,0.62d,-0.58d],PickupDelay:20s}

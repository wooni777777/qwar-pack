tag @s add rpg_lister
tellraw @s ["",{"text":"━━━━━  ","color":"dark_gray"},{"text":"총든 해적","color":"dark_aqua","bold":true},{"text":"  스폰 지점  ━━━━━","color":"dark_gray"}]
execute as @e[type=minecraft:marker,tag=rpg_sp_pir3] at @s run function rpg:mob/point_l1
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}
tag @s remove rpg_lister

# 지금 자리에서 맞았는지 (v41 · as 총알 at 총알)
particle minecraft:smoke ~ ~ ~ 0 0 0 0 1 normal @a
scoreboard players operation #bd rpg.sys = @s rpg.bdmg
execute if score #bd rpg.sys matches ..0 run scoreboard players set #bd rpg.sys 1
execute positioned ~-0.5 ~-0.5 ~-0.5 as @a[dx=0,dy=0,dz=0,gamemode=!spectator,gamemode=!creative,limit=1] at @s run function rpg:mob/bul_hit
execute if score #bhit rpg.sys matches 1 run return run kill @s
execute unless block ~ ~ ~ #rpg:pass run function rpg:mob/bul_end

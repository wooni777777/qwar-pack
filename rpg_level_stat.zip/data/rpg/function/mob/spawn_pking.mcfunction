# 해적 왕  |  체력 500 / 공격력 30 / 이동속도 0.28   (이 숫자만 고치면 됩니다)
# 몸 (v39) : 모델을 머리 위에 태우지 않고, 스켈레톤 머리/팔/다리에 직접 입힙니다.
#   머리 = rpg:pir_king_head (머리 슬롯)  ·  몸/팔/다리 = 장비 rpg:mob_pir_king  ->  function rpg:mob/gear_pking
# 이름표 높이는 text_display 의 translation 두 번째 숫자 (0.784) 입니다.
summon minecraft:skeleton ~ ~ ~ {Tags:["rpg_mob","rpg_m_pking","rpg_new","rpg_boss"],CustomName:{text:"해적 왕",color:"dark_red",bold:true},CustomNameVisible:0b,PersistenceRequired:1b,Silent:1b,CanPickUpLoot:0b,DeathLootTable:"minecraft:empty",Passengers:[{id:"minecraft:text_display",Tags:["rpg_mtext"],Rotation:[0.0f,0.0f],billboard:"center",alignment:"center",see_through:false,background:1073741824,view_range:1.5f,text:{text:"해적 왕",color:"dark_red",bold:true},transformation:{translation:[0.0f,0.784f,0.0f],left_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}]}
# 본체는 투명 효과 (F3+B 히트박스로 맞출 곳이 보입니다)
effect give @e[tag=rpg_new] minecraft:invisibility 999999 1 true
# 진짜 피는 1024 로 두고 (매 틱 다시 채움), 실제 체력은 가짜 피 rpg.mmx / rpg.mhp 로 셉니다 (v39)
attribute @e[tag=rpg_new,limit=1] minecraft:max_health base set 1024
attribute @e[tag=rpg_new,limit=1] minecraft:attack_damage base set 30
attribute @e[tag=rpg_new,limit=1] minecraft:movement_speed base set 0.28
attribute @e[tag=rpg_new,limit=1] minecraft:follow_range base set 40
attribute @e[tag=rpg_new,limit=1] minecraft:knockback_resistance base set 0.85
attribute @e[tag=rpg_new,limit=1] minecraft:scale base set 1.3
# 몸 : 머리 = 3D 머리 모델(머리 슬롯) / 몸·팔·다리 = 장비 레이어 (v39) — 햇빛 화상도 막아 줍니다
function rpg:mob/gear_pking
# 총(활) - 모델은 리소스팩에서 안 보이게 처리됩니다
item replace entity @e[tag=rpg_new,limit=1] weapon.mainhand with minecraft:bow[minecraft:item_model="rpg:empty"]
data modify entity @e[tag=rpg_new,limit=1] drop_chances set value {head:0.0f,chest:0.0f,legs:0.0f,feet:0.0f,mainhand:0.0f,offhand:0.0f}
data modify entity @e[tag=rpg_new,limit=1] Health set value 1024.0f
scoreboard players set @e[tag=rpg_new,limit=1] rpg.php 500
scoreboard players set @e[tag=rpg_new,limit=1] rpg.mmx 500
scoreboard players set @e[tag=rpg_new,limit=1] rpg.mhp 500
scoreboard players set @e[tag=rpg_new,limit=1] rpg.mlh -1
scoreboard players set @e[tag=rpg_new,limit=1] rpg.mfr 0
scoreboard players set @e[tag=rpg_new,limit=1] rpg.cbt 0
scoreboard players set @e[tag=rpg_new,limit=1] rpg.pkT 0
scoreboard players set @e[tag=rpg_new,limit=1] rpg.pkF 0
particle minecraft:soul ~ ~1 ~ 0.6 0.9 0.6 0.02 40 normal @a
playsound minecraft:entity.ender_dragon.growl hostile @a ~ ~ ~ 1.4 1.5

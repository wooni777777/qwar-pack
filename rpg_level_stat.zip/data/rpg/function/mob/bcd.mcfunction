# 보스 생성 쿨 바꾸기 (v46 · 내부용 · 매크로 b = dol/wolf/pking · op = add/remove · d = 분)
$scoreboard players $(op) #bcd_$(b) rpg.sys $(d)
$execute if score #bcd_$(b) rpg.sys matches ..-1 run scoreboard players set #bcd_$(b) rpg.sys 0
$execute if score #bcd_$(b) rpg.sys matches 1000.. run scoreboard players set #bcd_$(b) rpg.sys 999
# 이미 죽어서 기다리는 지점도 새 쿨보다 많이 남았으면 줄임
$scoreboard players operation #bcs rpg.sys = #bcd_$(b) rpg.sys
scoreboard players operation #bcs rpg.sys *= #c60 rpg.sys
$execute as @e[type=minecraft:marker,tag=rpg_sp_$(b)] if score @s rpg.cd > #bcs rpg.sys run scoreboard players operation @s rpg.cd = #bcs rpg.sys
function rpg:mob/open

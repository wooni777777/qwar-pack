# 잠꾸러기 늑대를 근처 플레이어에게 화나게 만든다 (내부용)
execute unless entity @a[distance=..40,gamemode=!spectator] run return 0
# 이미 충분히 화나 있으면 건드리지 않는다 (v39 : /data 를 덜 쓰기 위해)
scoreboard players set #wat rpg.sys 0
execute store result score #wat rpg.sys run data get entity @s AngerTime
execute if score #wat rpg.sys matches 200.. run return 0
data modify entity @s AngerTime set value 1200
data modify entity @s AngryAt set from entity @p[distance=..40,gamemode=!spectator] UUID
# /data 를 쓰면 늑대 최대체력이 8 로 돌아갈 수 있어서 바로 되돌린다 (v39 · 가짜 피는 그대로)
attribute @s minecraft:max_health base set 1024
effect give @s minecraft:instant_health 1 8 true
scoreboard players set @s rpg.mlh -1

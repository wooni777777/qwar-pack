# 잠꾸러기 늑대를 근처 플레이어에게 화나게 만든다 (내부용)
execute unless entity @a[distance=..40,gamemode=!spectator] run return 0
data modify entity @s AngerTime set value 1200
data modify entity @s AngryAt set from entity @p[distance=..40,gamemode=!spectator] UUID

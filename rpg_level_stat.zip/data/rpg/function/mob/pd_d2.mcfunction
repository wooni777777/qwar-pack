scoreboard players remove #dr_d2p rpg.sys 5
execute if score #dr_d2p rpg.sys matches ..0 run scoreboard players set #dr_d2p rpg.sys 0
function rpg:mob/drop_d

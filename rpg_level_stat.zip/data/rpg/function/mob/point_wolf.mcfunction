function rpg:mob/sp_wolf
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"잠꾸러기 늑대","color":"gold","bold":true},{"text":" 스폰 지점을 이 자리에 만들었습니다.","color":"white"}]
playsound minecraft:block.beacon.activate player @s ~ ~ ~ 1 1.6

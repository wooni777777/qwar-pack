function rpg:mob/sp_wolf
playsound minecraft:block.beacon.activate player @s ~ ~ ~ 1 1.6

# 개수 바꾸기 (0 ~ 64)
$scoreboard players add #ds$(b)$(s)n rpg.sys $(st)
$execute if score #ds$(b)$(s)n rpg.sys matches ..-1 run scoreboard players set #ds$(b)$(s)n rpg.sys 0
$execute if score #ds$(b)$(s)n rpg.sys matches 65.. run scoreboard players set #ds$(b)$(s)n rpg.sys 64

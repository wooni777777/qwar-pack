# 돌 - 돌의 핵
$summon minecraft:item ~ ~0.6 ~ {Item:{id:"minecraft:nether_star",count:$(n),components:{"minecraft:custom_data":{rpg_bossdrop:1},"minecraft:item_name":{text:"돌의 핵",color:"aqua",bold:true},"minecraft:lore":[{text:"하위 보스 [돌] 이 남긴 결정",color:"gray",italic:false}],"minecraft:enchantment_glint_override":true}}}

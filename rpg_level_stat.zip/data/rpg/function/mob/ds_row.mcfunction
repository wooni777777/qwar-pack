# 드롭 슬롯 한 줄을 그린다 (내부용)
function rpg:mob/ds_read with storage rpg:mob r
function rpg:mob/ds_name
$function rpg:mob/ds_name_$(b)
function rpg:mob/ds_row2 with storage rpg:mob r

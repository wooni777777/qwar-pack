scoreboard players operation #sid rpg.sys = @s rpg.sid
execute as @e[tag=rpg_mob] if score @s rpg.sid = #sid rpg.sys run function rpg:mob/rm_mob
kill @s

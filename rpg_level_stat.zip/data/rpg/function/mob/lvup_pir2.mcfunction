scoreboard players add #mlv_pir2 rpg.sys 1
execute if score #mlv_pir2 rpg.sys matches 200.. run scoreboard players set #mlv_pir2 rpg.sys 200
function rpg:mob/open

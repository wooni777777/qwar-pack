# 해적 왕 : 1초마다 (쫄병 소환 · 근접 공격)
scoreboard players set #pkh rpg.sys 0
execute store result score #pkh rpg.sys run data get entity @s Health 1
execute store result score #pkm rpg.sys run attribute @s minecraft:max_health get 1
# 근처에 플레이어가 있어야 "전투 중"
scoreboard players set #pkp rpg.sys 0
execute if entity @a[distance=..24,gamemode=!spectator] run scoreboard players set #pkp rpg.sys 1
# 비전투 + 풀피 -> 다음 전투를 위해 첫 소환 깃발을 되돌린다
execute if score #pkp rpg.sys matches 0 if score #pkh rpg.sys >= #pkm rpg.sys run scoreboard players set @s rpg.pkF 0
execute if score #pkp rpg.sys matches 0 run scoreboard players set @s rpg.pkT 0
execute if score #pkp rpg.sys matches 0 run return 0
# 지금 살아 있는 쫄병 수
scoreboard players set #pkc rpg.sys 0
execute store result score #pkc rpg.sys if entity @e[tag=rpg_minion,tag=!rpg_m_pking,tag=!rpg_dead,distance=..48]
scoreboard players add @s rpg.pkT 1
scoreboard players set #pkgo rpg.sys 0
# (1) 전투 시작 첫 소환 - 기준은 "풀피인가"
execute if score @s rpg.pkF matches 0 if score #pkh rpg.sys >= #pkm rpg.sys run scoreboard players set #pkgo rpg.sys 1
execute if score @s rpg.pkF matches 0 if score #pkh rpg.sys >= #pkm rpg.sys run scoreboard players set @s rpg.pkF 1
# (2) 그 뒤로는 pk_sum 초마다
execute if score @s rpg.pkT >= #pk_sum rpg.sys run scoreboard players set #pkgo rpg.sys 1
execute if score #pkgo rpg.sys matches 1 run scoreboard players set @s rpg.pkT 0
execute if score #pkgo rpg.sys matches 1 if score #pkc rpg.sys < #pk_cap rpg.sys run function rpg:mob/pk_call
# (3) 근접 공격 (1초에 1번)
execute if entity @a[distance=..3.5,gamemode=!spectator] run function rpg:mob/pk_melee

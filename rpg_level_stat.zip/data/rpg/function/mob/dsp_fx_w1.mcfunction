# 늑대의 별 를 바닥에 떨군다
$summon minecraft:item ~ ~0.6 ~ {Item:{id:"minecraft:nether_star",count:$(n),components:{"minecraft:custom_data":{rpg_bossdrop:1},"minecraft:item_name":{text:"늑대의 별",color:"gold",bold:true},"minecraft:lore":[{text:"잠꾸러기 늑대가 남긴 별",color:"gray",italic:false}],"minecraft:enchantment_glint_override":true}}}

# 허수아비 1틱 (v50 · 내부용 · as at 허수아비) — 3초(60틱) 동안 안 맞으면 풀피
# v56 : 중력 (대쉬 · 끌어당기기 중이 아니면 발밑이 빌 때 떨어짐)
execute unless score @s rpg.dsh matches 1.. unless score @s rpg.dshd matches 1.. run function rpg:sc/grav
execute if score @s rpg.mhp >= @s rpg.mmx run return 0
scoreboard players operation #sct rpg.sys = #gtick rpg.sys
scoreboard players operation #sct rpg.sys -= @s rpg.scl
execute if score #sct rpg.sys matches 60.. run function rpg:sc/full

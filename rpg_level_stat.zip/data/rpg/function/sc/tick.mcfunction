# 허수아비 1틱 (v50 · 내부용 · as at 허수아비) — 3초(60틱) 동안 안 맞으면 풀피
execute if score @s rpg.mhp >= @s rpg.mmx run return 0
scoreboard players operation #sct rpg.sys = #gtick rpg.sys
scoreboard players operation #sct rpg.sys -= @s rpg.scl
execute if score #sct rpg.sys matches 60.. run function rpg:sc/full

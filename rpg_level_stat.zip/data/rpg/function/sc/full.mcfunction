# 허수아비 풀피 (v50 · 내부용 · as at 허수아비) — 회복한 양을 초록 숫자로 (= 그동안 받은 피해)
scoreboard players operation #sch rpg.sys = @s rpg.mmx
scoreboard players operation #sch rpg.sys -= @s rpg.mhp
scoreboard players operation @s rpg.mhp = @s rpg.mmx
scoreboard players set @s rpg.mfr 0
execute store result storage rpg:dn h.n int 1 run scoreboard players get #sch rpg.sys
function rpg:sc/heal_num with storage rpg:dn h
function rpg:mob/hp_text
particle minecraft:happy_villager ~ ~1.2 ~ 0.4 0.6 0.4 0 12 normal @a
playsound minecraft:entity.player.levelup block @a ~ ~ ~ 0.5 1.8

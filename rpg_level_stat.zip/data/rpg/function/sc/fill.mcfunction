# 허수아비 진짜 피를 최대로 (v50 · 내부용 · as 허수아비 · 매 틱) — 한 방에 진짜로 죽지 않게
execute store result score #scm rpg.sys run attribute @s minecraft:max_health get 100
execute store result entity @s Health float 0.01 run scoreboard players get #scm rpg.sys
scoreboard players operation @s rpg.mlh = #scm rpg.sys

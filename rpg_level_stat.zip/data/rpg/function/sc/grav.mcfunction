# 허수아비 중력 (v56 · 내부용 · as at 허수아비)
#   움직이지 않게 NoAI 로 두었기 때문에 바닐라 중력이 없습니다 → 발밑이 비어 있으면 직접 떨어뜨립니다
#   속도 rpg.scv (0.01칸/틱) : 매 틱 +8 (바닐라 중력 0.08) · 최대 300 · 0.25칸씩 내려가다 막히면 그 블록 위에 섬
execute unless block ~ ~-0.05 ~ #rpg:ray_pass run return run scoreboard players set @s rpg.scv 0
scoreboard players add @s rpg.scv 8
execute if score @s rpg.scv matches 301.. run scoreboard players set @s rpg.scv 300
scoreboard players operation #scg rpg.sys = @s rpg.scv
function rpg:sc/grav_step

# 초록 회복 숫자 1틱 (v50 · 내부용 · as at 숫자)
scoreboard players remove @s rpg.dnt 1
execute if score @s rpg.dnt matches 58 run tp @s ~ ~0.7 ~
execute if score @s rpg.dnt matches ..0 run kill @s

# DPS 액션바 (v50 · as 플레이어) — 허수아비를 마지막으로 때린 지 3초 안이면 보여 주고 1 (hud/tick 은 그동안 체력바 대신 이것)
#   DPS = 받은 피해 합 ÷ (첫 타 ~ 마지막 타 시간 · 최소 1초)
scoreboard players operation #dt rpg.sys = #gtick rpg.sys
scoreboard players operation #dt rpg.sys -= @s rpg.dpsl
execute if score #dt rpg.sys matches 60.. run scoreboard players set @s rpg.dpsl 0
execute unless score @s rpg.dpsl matches 1.. run return fail
scoreboard players operation #el rpg.sys = @s rpg.dpsl
scoreboard players operation #el rpg.sys -= @s rpg.dpss
scoreboard players add #el rpg.sys 1
execute if score #el rpg.sys matches ..19 run scoreboard players set #el rpg.sys 20
scoreboard players operation #dv rpg.sys = @s rpg.dpsd
scoreboard players operation #dv rpg.sys *= #c20 rpg.sys
scoreboard players operation #dv rpg.sys *= #c10 rpg.sys
scoreboard players operation #dv rpg.sys /= #el rpg.sys
scoreboard players operation @s rpg.dpsv = #dv rpg.sys
scoreboard players operation @s rpg.dpsv /= #c10 rpg.sys
scoreboard players operation @s rpg.dpsv2 = #dv rpg.sys
scoreboard players operation @s rpg.dpsv2 %= #c10 rpg.sys
title @s actionbar ["",{"text":"DPS ","color":"gray"},{"score":{"name":"@s","objective":"rpg.dpsv"},"color":"white"},{"text":".","color":"white"},{"score":{"name":"@s","objective":"rpg.dpsv2"},"color":"white"}]
return 1

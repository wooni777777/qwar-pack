# 초록 회복 숫자 (v50 · 내부용 · 매크로 n) — 3초 동안 천천히 떠오름
$summon minecraft:text_display ~ ~2.4 ~ {Tags:["rpg_scn","rpg_scnN"],billboard:"center",see_through:false,shadow:true,background:0,view_range:1.0f,teleport_duration:40,text:{text:"+$(n)",color:"#55FF55",bold:true},transformation:{left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[0.0f,0.0f,0.0f],scale:[1.6f,1.6f,1.6f]}}
scoreboard players set @e[type=minecraft:text_display,tag=rpg_scnN] rpg.dnt 60
tag @e[type=minecraft:text_display,tag=rpg_scnN] remove rpg_scnN

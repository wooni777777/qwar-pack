# 허수아비를 때린 플레이어 DPS 누적 (v50 · 내부용 · as 플레이어 · #scd = 이번 틱 피해)
#   3초 넘게 안 때렸으면 새로 셈
scoreboard players operation #dt rpg.sys = #gtick rpg.sys
scoreboard players operation #dt rpg.sys -= @s rpg.dpsl
execute unless score @s rpg.dpsl matches 1.. run scoreboard players set #dt rpg.sys 9999
execute if score #dt rpg.sys matches 60.. run scoreboard players set @s rpg.dpsd 0
execute if score #dt rpg.sys matches 60.. run scoreboard players operation @s rpg.dpss = #gtick rpg.sys
scoreboard players operation @s rpg.dpsd += #scd rpg.sys
scoreboard players operation @s rpg.dpsl = #gtick rpg.sys
function rpg:sc/dps_on

# 허수아비가 맞음 (v50 · 내부용 · as at 허수아비 · mob/fhp_dmg · #fdi = 이번 틱 피해)
scoreboard players operation @s rpg.scl = #gtick rpg.sys
scoreboard players operation #scd rpg.sys = #fdi rpg.sys
execute on attacker if entity @s[type=minecraft:player] run function rpg:sc/dps_add
# HP 가 0 이 되면 바로 풀피 (허수아비는 안 죽음)
execute if score @s rpg.mhp matches ..0 run function rpg:sc/full
function rpg:mob/hp_text

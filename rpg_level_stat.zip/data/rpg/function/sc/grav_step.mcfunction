# (v56 · 내부용 · as 허수아비) #scg 만큼(0.01칸) 0.25칸씩 내려감 · 발밑이 막히면 블록 윗면에 붙이고 멈춤
execute if score #scg rpg.sys matches ..0 run return 0
execute at @s unless block ~ ~-0.25 ~ #rpg:ray_pass align y run tp @s ~ ~ ~
execute at @s unless block ~ ~-0.25 ~ #rpg:ray_pass run return run scoreboard players set @s rpg.scv 0
execute at @s run tp @s ~ ~-0.25 ~
scoreboard players remove #scg rpg.sys 25
execute if score #scg rpg.sys matches 1.. run function rpg:sc/grav_step

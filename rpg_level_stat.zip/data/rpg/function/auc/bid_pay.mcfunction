scoreboard players operation @s money -= @s rpg.abidv
scoreboard players operation @s rpg.abidL = @s rpg.abidi
execute if score @s rpg.abidi matches 1 run scoreboard players operation @s rpg.abid1 += @s rpg.abidv
execute if score @s rpg.abidi matches 1 if score @s rpg.abid1 > #auc_top1 rpg.sys run function rpg:auc/top1
execute if score @s rpg.abidi matches 2 run scoreboard players operation @s rpg.abid2 += @s rpg.abidv
execute if score @s rpg.abidi matches 2 if score @s rpg.abid2 > #auc_top2 rpg.sys run function rpg:auc/top2
execute if score @s rpg.abidi matches 3 run scoreboard players operation @s rpg.abid3 += @s rpg.abidv
execute if score @s rpg.abidi matches 3 if score @s rpg.abid3 > #auc_top3 rpg.sys run function rpg:auc/top3
execute if score @s rpg.abidi matches 4 run scoreboard players operation @s rpg.abid4 += @s rpg.abidv
execute if score @s rpg.abidi matches 4 if score @s rpg.abid4 > #auc_top4 rpg.sys run function rpg:auc/top4
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"입찰했습니다. 입찰금은 돌려받을 수 없습니다.","color":"gold"}]
execute at @s run playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 1 1.4
scoreboard players set @s rpg.abidv 0
function rpg:auc/bid_show

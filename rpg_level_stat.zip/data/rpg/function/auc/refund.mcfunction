scoreboard players set #rf rpg.sys 0
scoreboard players operation #rf rpg.sys += @s rpg.abid1
scoreboard players operation #rf rpg.sys += @s rpg.abid2
scoreboard players operation #rf rpg.sys += @s rpg.abid3
scoreboard players operation #rf rpg.sys += @s rpg.abid4
execute if score #rf rpg.sys matches ..0 run return 0
scoreboard players operation @s money += #rf rpg.sys
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"경매가 취소되어 입찰금 ","color":"green"},{"color":"gold","bold":true,"score":{"name":"#rf","objective":"rpg.sys"}},{"text":"원 을 전액 돌려받았습니다.","color":"green"}]
execute at @s run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 1 1.2

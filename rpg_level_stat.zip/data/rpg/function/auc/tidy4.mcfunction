data remove storage rpg:auc i4
scoreboard players set #auc_min4 rpg.sys 0
scoreboard players set #auc_top4 rpg.sys 0
scoreboard players set @a rpg.abid4 0
execute as @a[scores={rpg.abidL=4}] run scoreboard players set @s rpg.abidL 0
tag @a remove auc_win4
kill @e[tag=rpg_auc_h4]

data remove storage rpg:auc i2
data modify storage rpg:auc i2 set from storage rpg:auc i3
data remove storage rpg:auc i3
scoreboard players operation #auc_min2 rpg.sys = #auc_min3 rpg.sys
scoreboard players operation #auc_top2 rpg.sys = #auc_top3 rpg.sys
execute as @a run scoreboard players operation @s rpg.abid2 = @s rpg.abid3
tag @a remove auc_win2
execute as @a[tag=auc_win3] run tag @s add auc_win2
tag @a remove auc_win3
tag @e[tag=rpg_auc_h3] add rpg_auc_h2
tag @e[tag=rpg_auc_h2] remove rpg_auc_h3
execute as @a[scores={rpg.abidL=3}] run scoreboard players set @s rpg.abidL 2

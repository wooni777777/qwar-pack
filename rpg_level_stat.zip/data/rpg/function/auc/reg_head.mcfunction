data modify storage rpg:auc m set value {components:{}}
data modify storage rpg:auc m.id set from entity @s SelectedItem.id
data modify storage rpg:auc m.count set from entity @s SelectedItem.count
execute if data entity @s SelectedItem.components run data modify storage rpg:auc m.components set from entity @s SelectedItem.components
function rpg:auc/reg_line with storage rpg:auc m

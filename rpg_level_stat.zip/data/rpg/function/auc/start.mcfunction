execute if score #auc_n rpg.sys matches 0 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"등록된 물품이 없습니다.","color":"red"}]
execute if score #auc_n rpg.sys matches 0 run return 0
execute if score #auc_run rpg.sys matches 1 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"이미 경매가 진행 중입니다.","color":"red"}]
execute if score #auc_run rpg.sys matches 1 run return 0
scoreboard players set #auc_run rpg.sys 1
scoreboard players set #auc_pause rpg.sys 0
scoreboard players set #auc_time rpg.sys 36000
execute if score #auc_bb rpg.sys matches 0 run bossbar add rpg:auction {"text":"-{낙찰}-","color":"red","bold":true}
scoreboard players set #auc_bb rpg.sys 1
bossbar set rpg:auction color red
bossbar set rpg:auction style notched_10
bossbar set rpg:auction max 36000
bossbar set rpg:auction value 36000
bossbar set rpg:auction players @a
bossbar set rpg:auction visible true
tellraw @a " "
tellraw @a [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"【경매】","color":"yellow","bold":true},{"text":"가 열렸습니다","color":"white"}]
tellraw @a " "
execute as @a at @s run playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1 1

scoreboard players enable @s rpg.auc
execute if score #auc_n rpg.sys matches 0 run tellraw @s ["", {"text": "   등록된 물품이 없습니다", "color": "gray"}]
execute if score #auc_n rpg.sys matches 1.. run function rpg:auc/row1
execute if score #auc_n rpg.sys matches 2.. run function rpg:auc/row2
execute if score #auc_n rpg.sys matches 3.. run function rpg:auc/row3
execute if score #auc_n rpg.sys matches 4.. run function rpg:auc/row4

# ── 경매 상태 전부 초기화 ──
scoreboard players set #auc_run rpg.sys 0
scoreboard players set #auc_pause rpg.sys 0
scoreboard players set #auc_time rpg.sys 0
execute if score #auc_bb rpg.sys matches 1 run bossbar remove rpg:auction
scoreboard players set #auc_bb rpg.sys 0
scoreboard players set #auc_n rpg.sys 0
scoreboard players set @a rpg.abidi 0
scoreboard players set @a rpg.abidv 0
scoreboard players set @a rpg.abidL 0
scoreboard players set @a rpg.asort 0
scoreboard players set @a rpg.abid1 0
tag @a remove auc_win1
scoreboard players set #auc_min1 rpg.sys 0
scoreboard players set #auc_top1 rpg.sys 0
data remove storage rpg:auc i1
scoreboard players set @a rpg.abid2 0
tag @a remove auc_win2
scoreboard players set #auc_min2 rpg.sys 0
scoreboard players set #auc_top2 rpg.sys 0
data remove storage rpg:auc i2
scoreboard players set @a rpg.abid3 0
tag @a remove auc_win3
scoreboard players set #auc_min3 rpg.sys 0
scoreboard players set #auc_top3 rpg.sys 0
data remove storage rpg:auc i3
scoreboard players set @a rpg.abid4 0
tag @a remove auc_win4
scoreboard players set #auc_min4 rpg.sys 0
scoreboard players set #auc_top4 rpg.sys 0
data remove storage rpg:auc i4
kill @e[tag=rpg_auc_h]

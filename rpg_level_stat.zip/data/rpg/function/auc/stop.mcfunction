execute if score #auc_run rpg.sys matches 0 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"진행 중인 경매가 없습니다.","color":"red"}]
execute if score #auc_run rpg.sys matches 0 run return 0
scoreboard players operation #pp rpg.sys = #auc_pause rpg.sys
execute if score #pp rpg.sys matches 0 run scoreboard players set #auc_pause rpg.sys 1
execute if score #pp rpg.sys matches 0 run tellraw @a [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"【경매】","color":"yellow","bold":true},{"text":" 낙찰 시간이 멈췄습니다","color":"red"}]
execute if score #pp rpg.sys matches 1 run scoreboard players set #auc_pause rpg.sys 0
execute if score #pp rpg.sys matches 1 run tellraw @a [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"【경매】","color":"yellow","bold":true},{"text":" 낙찰 시간이 다시 흐릅니다","color":"green"}]

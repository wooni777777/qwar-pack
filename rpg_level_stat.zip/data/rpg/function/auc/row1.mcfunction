data modify storage rpg:auc m set value {n:1,components:{}}
data modify storage rpg:auc m.id set from storage rpg:auc i1.id
data modify storage rpg:auc m.count set from storage rpg:auc i1.count
execute if data storage rpg:auc i1.components run data modify storage rpg:auc m.components set from storage rpg:auc i1.components
execute store result storage rpg:auc m.min int 1 run scoreboard players get #auc_min1 rpg.sys
execute store result storage rpg:auc m.my int 1 run scoreboard players get @s rpg.abid1
function rpg:auc/rowshow with storage rpg:auc m

scoreboard players enable @s rpg.auc
scoreboard players set @s rpg.abidv 0
function rpg:auc/bid_show

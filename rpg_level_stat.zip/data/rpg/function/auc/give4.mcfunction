summon minecraft:item ~ ~0.6 ~ {Tags:["rpg_aucgive"],Item:{id:"minecraft:stone",count:1},PickupDelay:0s,Age:-32768s}
item replace entity @e[tag=rpg_aucgive,limit=1] contents from entity @e[tag=rpg_auc_h4,limit=1] weapon.mainhand
data modify entity @e[tag=rpg_aucgive,limit=1] Owner set from entity @s UUID
tag @e[tag=rpg_aucgive] remove rpg_aucgive
kill @e[tag=rpg_auc_h4]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1 1.2

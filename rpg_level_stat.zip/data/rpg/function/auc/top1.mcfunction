scoreboard players operation #auc_top1 rpg.sys = @s rpg.abid1
tag @a remove auc_win1
tag @s add auc_win1

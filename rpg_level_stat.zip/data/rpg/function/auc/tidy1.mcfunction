data remove storage rpg:auc i1
scoreboard players set #auc_min1 rpg.sys 0
scoreboard players set #auc_top1 rpg.sys 0
scoreboard players set @a rpg.abid1 0
execute as @a[scores={rpg.abidL=1}] run scoreboard players set @s rpg.abidL 0
tag @a remove auc_win1
kill @e[tag=rpg_auc_h1]

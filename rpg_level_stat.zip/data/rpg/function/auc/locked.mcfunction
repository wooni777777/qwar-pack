tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"이미 다른 물품에 입찰했습니다. 한 사람은 물품 1개에만 입찰할 수 있습니다.","color":"red"}]
execute at @s run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 1 0.6

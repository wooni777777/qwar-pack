tellraw @s ["", {"text": "   ── 물품 1 ──", "color": "aqua", "bold": true}]
execute unless entity @a[scores={rpg.abid1=1..}] run tellraw @s ["", {"text": "      입찰자가 없습니다", "color": "gray"}]
execute unless entity @a[scores={rpg.abid1=1..}] run return 0
execute as @a run scoreboard players operation @s rpg.asort = @s rpg.abid1
scoreboard players set #rank rpg.sys 0
function rpg:auc/rank
scoreboard players set @a rpg.asort 0

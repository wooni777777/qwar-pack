scoreboard players add #rank rpg.sys 1
scoreboard players set #mx rpg.sys 0
execute as @a[scores={rpg.asort=1..}] run scoreboard players operation #mx rpg.sys > @s rpg.asort
execute as @a[scores={rpg.asort=1..}] if score @s rpg.asort = #mx rpg.sys run function rpg:auc/rank_line
execute if score #rank rpg.sys matches ..9 if entity @a[scores={rpg.asort=1..}] run function rpg:auc/rank

data remove storage rpg:auc i1
data modify storage rpg:auc i1 set from storage rpg:auc i2
data remove storage rpg:auc i2
scoreboard players operation #auc_min1 rpg.sys = #auc_min2 rpg.sys
scoreboard players operation #auc_top1 rpg.sys = #auc_top2 rpg.sys
execute as @a run scoreboard players operation @s rpg.abid1 = @s rpg.abid2
tag @a remove auc_win1
execute as @a[tag=auc_win2] run tag @s add auc_win1
tag @a remove auc_win2
tag @e[tag=rpg_auc_h2] add rpg_auc_h1
tag @e[tag=rpg_auc_h1] remove rpg_auc_h2
execute as @a[scores={rpg.abidL=2}] run scoreboard players set @s rpg.abidL 1

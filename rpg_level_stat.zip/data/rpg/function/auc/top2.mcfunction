scoreboard players operation #auc_top2 rpg.sys = @s rpg.abid2
tag @a remove auc_win2
tag @s add auc_win2

scoreboard players set #auc_run rpg.sys 0
scoreboard players set #auc_pause rpg.sys 0
scoreboard players set #auc_time rpg.sys 0
execute if score #auc_bb rpg.sys matches 1 run bossbar remove rpg:auction
scoreboard players set #auc_bb rpg.sys 0
tellraw @a " "
tellraw @a [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"【경매】","color":"yellow","bold":true},{"text":"가 종료 되었습니다","color":"white"}]
tellraw @a " "
execute if score #auc_n rpg.sys matches 1.. run function rpg:auc/end1
execute if score #auc_n rpg.sys matches 2.. run function rpg:auc/end2
execute if score #auc_n rpg.sys matches 3.. run function rpg:auc/end3
execute if score #auc_n rpg.sys matches 4.. run function rpg:auc/end4
function rpg:auc/clear

$bossbar set rpg:auction name {"text":"-{낙찰}-  $(m):0$(s)","color":"red","bold":true}

execute if score #auc_run rpg.sys matches 0 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"진행 중인 경매가 없습니다.","color":"red"}]
execute if score #auc_run rpg.sys matches 0 run return 0
scoreboard players remove #auc_time rpg.sys 6000
execute if score #auc_time rpg.sys matches ..20 run scoreboard players set #auc_time rpg.sys 20
execute store result bossbar rpg:auction value run scoreboard players get #auc_time rpg.sys
tellraw @a [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"【경매】","color":"yellow","bold":true},{"text":" 낙찰 시간이 5분 줄었습니다","color":"gold"}]
function rpg:auc/sec
execute as @a at @s run playsound minecraft:block.note_block.pling player @s ~ ~ ~ 1 1.6

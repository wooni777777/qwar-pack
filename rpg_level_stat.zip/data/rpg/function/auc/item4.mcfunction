data modify storage rpg:auc m set value {n:4,components:{}}
data modify storage rpg:auc m.id set from storage rpg:auc i4.id
data modify storage rpg:auc m.count set from storage rpg:auc i4.count
execute if data storage rpg:auc i4.components run data modify storage rpg:auc m.components set from storage rpg:auc i4.components
execute store result storage rpg:auc m.min int 1 run scoreboard players get #auc_min4 rpg.sys
execute store result storage rpg:auc m.top int 1 run scoreboard players get #auc_top4 rpg.sys
execute if score #auc_top4 rpg.sys matches ..0 run data modify storage rpg:auc m.top set value 0
function rpg:auc/itemrow with storage rpg:auc m

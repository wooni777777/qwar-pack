scoreboard players enable @s rpg.auc
scoreboard players enable @s rpg.menu
scoreboard players set @s rpg.abidi 0
playsound minecraft:item.book.page_turn player @s ~ ~ ~ 1 1.2
tellraw @s " "
tellraw @s {"text": "━━━━━━━━━  경  매  ━━━━━━━━━", "color": "dark_gray"}
execute if entity @s[tag=op] run function rpg:auc/op_panel
execute unless entity @s[tag=op] if score #auc_run rpg.sys matches 0 run tellraw @s ["", {"text": "   경매가 시작되어있지 않습니다", "color": "red"}]
execute if score #auc_run rpg.sys matches 1 run function rpg:auc/list
execute if entity @s[tag=op] if score #auc_run rpg.sys matches 0 run function rpg:auc/list
tellraw @s {"text": "━━━━━━━━━━━━━━━━━━━━━━━━━━", "color": "dark_gray"}

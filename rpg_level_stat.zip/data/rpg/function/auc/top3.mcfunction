scoreboard players operation #auc_top3 rpg.sys = @s rpg.abid3
tag @a remove auc_win3
tag @s add auc_win3

# 낙찰자 발표 + 지급 (금액은 공개하지 않는다)
execute if score #auc_top4 rpg.sys matches ..0 run tellraw @a [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"【경매】 네번째 물품 가진 플레이어: ","color":"yellow"},{"text":"유찰 (입찰 없음)","color":"gray"}]
execute as @a[tag=auc_win4] run tellraw @a [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"【경매】 네번째 물품 가진 플레이어: ","color":"yellow"},{"selector":"@s","color":"white","bold":true}]
execute as @a[tag=auc_win4] at @s run function rpg:auc/give4
execute if score #auc_top4 rpg.sys matches 1.. unless entity @a[tag=auc_win4] run tellraw @a [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"【경매】 네번째 물품 낙찰자가 접속 중이 아니어서 보관됩니다","color":"yellow"}]
execute if score #auc_top4 rpg.sys matches ..0 run kill @e[tag=rpg_auc_h4]

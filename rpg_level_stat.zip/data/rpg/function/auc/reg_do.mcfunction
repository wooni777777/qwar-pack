scoreboard players add #auc_n rpg.sys 1
execute if score #auc_n rpg.sys matches 1 run function rpg:auc/reg1
execute if score #auc_n rpg.sys matches 2 run function rpg:auc/reg2
execute if score #auc_n rpg.sys matches 3 run function rpg:auc/reg3
execute if score #auc_n rpg.sys matches 4 run function rpg:auc/reg4
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"경매 물품을 등록했습니다.","color":"green"}]
execute at @s run playsound minecraft:block.beacon.power_select player @s ~ ~ ~ 1 1.4
function rpg:auc/open

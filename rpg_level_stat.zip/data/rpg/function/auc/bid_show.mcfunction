scoreboard players enable @s rpg.auc
playsound minecraft:item.book.page_turn player @s ~ ~ ~ 1 1.4
tellraw @s " "
tellraw @s {"text": "━━━━━━━━━  입  찰  ━━━━━━━━━", "color": "dark_gray"}
execute if score @s rpg.abidi matches 1 run function rpg:auc/bhead1
execute if score @s rpg.abidi matches 2 run function rpg:auc/bhead2
execute if score @s rpg.abidi matches 3 run function rpg:auc/bhead3
execute if score @s rpg.abidi matches 4 run function rpg:auc/bhead4
tellraw @s " "
tellraw @s ["", {"text": "   더할 금액 : ", "color": "gray"}]
tellraw @s ["", {"text": "   "}, {"text": "[ +1,000 ]", "color": "gold", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.auc set 31"}}, {"text": " "}, {"text": "[ +10,000 ]", "color": "gold", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.auc set 32"}}, {"text": " "}, {"text": "[ +100,000 ]", "color": "gold", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.auc set 33"}}, {"text": " "}, {"text": "[ +1,000,000 ]", "color": "gold", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.auc set 34"}}, {"text": " "}, {"text": "[ 초기화 ]", "color": "dark_gray", "click_event": {"action": "run_command", "command": "trigger rpg.auc set 39"}}]
tellraw @s " "
tellraw @s ["", {"text": "   총 가격: ", "color": "white", "bold": true}, {"color": "gold", "bold": true, "score": {"name": "@s", "objective": "rpg.abidv"}}, {"text": "원", "color": "gold"}]
tellraw @s ["", {"text": "   소지금 : ", "color": "dark_gray"}, {"color": "yellow", "score": {"name": "@s", "objective": "money"}}, {"text": "원", "color": "dark_gray"}]
tellraw @s " "
tellraw @s ["", {"text": "   "}, {"text": "[ 취소 ]", "color": "red", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.auc set 41"}}, {"text": "      "}, {"text": "[ 입 찰 ]", "color": "green", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.auc set 40"}, "hover_event": {"action": "show_text", "value": {"text": "누르면 즉시 결제됩니다. 환불되지 않습니다.", "color": "red"}}}]
tellraw @s ["", {"text": "   입찰금은 일시불이며 이기든 지든 돌려받지 못합니다.", "color": "dark_red"}]
tellraw @s {"text": "━━━━━━━━━━━━━━━━━━━━━━━━━━", "color": "dark_gray"}

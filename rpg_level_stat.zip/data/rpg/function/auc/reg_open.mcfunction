scoreboard players enable @s rpg.auc
scoreboard players set @s rpg.abidi 0
scoreboard players set @s rpg.aminv 0
function rpg:auc/reg_show

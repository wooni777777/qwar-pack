scoreboard players enable @s rpg.auc
playsound minecraft:item.book.page_turn player @s ~ ~ ~ 1 1.4
tellraw @s " "
tellraw @s {"text": "━━━━━━━  아이템 등록  ━━━━━━━", "color": "dark_gray"}
execute unless items entity @s weapon.mainhand * run tellraw @s ["", {"text": "   손에 아이템을 들어주세요", "color": "red"}]
execute if items entity @s weapon.mainhand * run function rpg:auc/reg_head
tellraw @s " "
tellraw @s ["", {"text": "   최소 금액 : ", "color": "gray"}]
tellraw @s ["", {"text": "   "}, {"text": "[ +1,000 ]", "color": "gold", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.auc set 31"}}, {"text": " "}, {"text": "[ +10,000 ]", "color": "gold", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.auc set 32"}}, {"text": " "}, {"text": "[ +100,000 ]", "color": "gold", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.auc set 33"}}, {"text": " "}, {"text": "[ +1,000,000 ]", "color": "gold", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.auc set 34"}}, {"text": " "}, {"text": "[ 초기화 ]", "color": "dark_gray", "click_event": {"action": "run_command", "command": "trigger rpg.auc set 39"}}]
tellraw @s " "
tellraw @s ["", {"text": "   최소 금액: ", "color": "white", "bold": true}, {"color": "gold", "bold": true, "score": {"name": "@s", "objective": "rpg.aminv"}}, {"text": "원", "color": "gold"}]
tellraw @s " "
tellraw @s ["", {"text": "   "}, {"text": "[ 취소 ]", "color": "red", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.auc set 41"}}, {"text": "      "}, {"text": "[ 등 록 ]", "color": "green", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.auc set 10"}}]
tellraw @s {"text": "━━━━━━━━━━━━━━━━━━━━━━━━━━", "color": "dark_gray"}

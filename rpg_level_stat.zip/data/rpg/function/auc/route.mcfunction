# ── 경매 트리거 라우팅 ──
execute if score @s rpg.auc matches 1 run function rpg:auc/open
execute if score @s rpg.auc matches 2 if entity @s[tag=op] run function rpg:auc/reg_open
execute if score @s rpg.auc matches 3 if entity @s[tag=op] run function rpg:auc/start
execute if score @s rpg.auc matches 4 if entity @s[tag=op] run function rpg:auc/stop
execute if score @s rpg.auc matches 5 if entity @s[tag=op] run function rpg:auc/status
execute if score @s rpg.auc matches 6 if entity @s[tag=op] run function rpg:auc/force
execute if score @s rpg.auc matches 7 if entity @s[tag=op] run function rpg:auc/cut5
execute if score @s rpg.auc matches 8 if entity @s[tag=op] run function rpg:auc/items
execute if score @s rpg.auc matches 10 if entity @s[tag=op] run function rpg:auc/reg_confirm
execute if score @s rpg.auc matches 61 if entity @s[tag=op] run function rpg:auc/rm1
execute if score @s rpg.auc matches 62 if entity @s[tag=op] run function rpg:auc/rm2
execute if score @s rpg.auc matches 63 if entity @s[tag=op] run function rpg:auc/rm3
execute if score @s rpg.auc matches 64 if entity @s[tag=op] run function rpg:auc/rm4
execute if score @s rpg.auc matches 51 if score #auc_run rpg.sys matches 1 if score #auc_n rpg.sys matches 1.. unless score @s rpg.abidL matches 1..4 run scoreboard players set @s rpg.abidi 1
execute if score @s rpg.auc matches 51 if score #auc_run rpg.sys matches 1 if score #auc_n rpg.sys matches 1.. if score @s rpg.abidL matches 1 run scoreboard players set @s rpg.abidi 1
execute if score @s rpg.auc matches 51 if score @s rpg.abidL matches 1..4 unless score @s rpg.abidL matches 1 run function rpg:auc/locked
execute if score @s rpg.auc matches 51 if score @s rpg.abidi matches 1 run function rpg:auc/bid_open
execute if score @s rpg.auc matches 52 if score #auc_run rpg.sys matches 1 if score #auc_n rpg.sys matches 2.. unless score @s rpg.abidL matches 1..4 run scoreboard players set @s rpg.abidi 2
execute if score @s rpg.auc matches 52 if score #auc_run rpg.sys matches 1 if score #auc_n rpg.sys matches 2.. if score @s rpg.abidL matches 2 run scoreboard players set @s rpg.abidi 2
execute if score @s rpg.auc matches 52 if score @s rpg.abidL matches 1..4 unless score @s rpg.abidL matches 2 run function rpg:auc/locked
execute if score @s rpg.auc matches 52 if score @s rpg.abidi matches 2 run function rpg:auc/bid_open
execute if score @s rpg.auc matches 53 if score #auc_run rpg.sys matches 1 if score #auc_n rpg.sys matches 3.. unless score @s rpg.abidL matches 1..4 run scoreboard players set @s rpg.abidi 3
execute if score @s rpg.auc matches 53 if score #auc_run rpg.sys matches 1 if score #auc_n rpg.sys matches 3.. if score @s rpg.abidL matches 3 run scoreboard players set @s rpg.abidi 3
execute if score @s rpg.auc matches 53 if score @s rpg.abidL matches 1..4 unless score @s rpg.abidL matches 3 run function rpg:auc/locked
execute if score @s rpg.auc matches 53 if score @s rpg.abidi matches 3 run function rpg:auc/bid_open
execute if score @s rpg.auc matches 54 if score #auc_run rpg.sys matches 1 if score #auc_n rpg.sys matches 4.. unless score @s rpg.abidL matches 1..4 run scoreboard players set @s rpg.abidi 4
execute if score @s rpg.auc matches 54 if score #auc_run rpg.sys matches 1 if score #auc_n rpg.sys matches 4.. if score @s rpg.abidL matches 4 run scoreboard players set @s rpg.abidi 4
execute if score @s rpg.auc matches 54 if score @s rpg.abidL matches 1..4 unless score @s rpg.abidL matches 4 run function rpg:auc/locked
execute if score @s rpg.auc matches 54 if score @s rpg.abidi matches 4 run function rpg:auc/bid_open
execute if score @s rpg.auc matches 31 if score @s rpg.abidi matches 1..4 run scoreboard players add @s rpg.abidv 1000
execute if score @s rpg.auc matches 31 if score @s rpg.abidi matches 0 if entity @s[tag=op] run scoreboard players add @s rpg.aminv 1000
execute if score @s rpg.auc matches 32 if score @s rpg.abidi matches 1..4 run scoreboard players add @s rpg.abidv 10000
execute if score @s rpg.auc matches 32 if score @s rpg.abidi matches 0 if entity @s[tag=op] run scoreboard players add @s rpg.aminv 10000
execute if score @s rpg.auc matches 33 if score @s rpg.abidi matches 1..4 run scoreboard players add @s rpg.abidv 100000
execute if score @s rpg.auc matches 33 if score @s rpg.abidi matches 0 if entity @s[tag=op] run scoreboard players add @s rpg.aminv 100000
execute if score @s rpg.auc matches 34 if score @s rpg.abidi matches 1..4 run scoreboard players add @s rpg.abidv 1000000
execute if score @s rpg.auc matches 34 if score @s rpg.abidi matches 0 if entity @s[tag=op] run scoreboard players add @s rpg.aminv 1000000
execute if score @s rpg.auc matches 39 if score @s rpg.abidi matches 1..4 run scoreboard players set @s rpg.abidv 0
execute if score @s rpg.auc matches 39 if score @s rpg.abidi matches 0 if entity @s[tag=op] run scoreboard players set @s rpg.aminv 0
execute if score @s rpg.auc matches 31..34 if score @s rpg.abidi matches 1..4 run function rpg:auc/bid_show
execute if score @s rpg.auc matches 31..34 if score @s rpg.abidi matches 0 if entity @s[tag=op] run function rpg:auc/reg_show
execute if score @s rpg.auc matches 39 if score @s rpg.abidi matches 1..4 run function rpg:auc/bid_show
execute if score @s rpg.auc matches 39 if score @s rpg.abidi matches 0 if entity @s[tag=op] run function rpg:auc/reg_show
execute if score @s rpg.auc matches 40 run function rpg:auc/bid_do
execute if score @s rpg.auc matches 41 run scoreboard players set @s rpg.abidi 0
execute if score @s rpg.auc matches 41 run function rpg:auc/open
scoreboard players set @s rpg.auc 0
scoreboard players enable @s rpg.auc

execute if score #auc_run rpg.sys matches 0 run return 0
scoreboard players operation #auc_s rpg.sys = #auc_time rpg.sys
scoreboard players operation #auc_s rpg.sys /= #c20 rpg.sys
scoreboard players operation #auc_m rpg.sys = #auc_s rpg.sys
scoreboard players operation #auc_m rpg.sys /= #c60 rpg.sys
scoreboard players operation #auc_s rpg.sys %= #c60 rpg.sys
execute store result storage rpg:auc t.m int 1 run scoreboard players get #auc_m rpg.sys
execute store result storage rpg:auc t.s int 1 run scoreboard players get #auc_s rpg.sys
execute if score #auc_pause rpg.sys matches 1 run bossbar set rpg:auction name {"text":"-{낙찰}-  일시 정지","color":"gray","bold":true}
execute if score #auc_pause rpg.sys matches 0 if score #auc_s rpg.sys matches 10.. run function rpg:auc/name with storage rpg:auc t
execute if score #auc_pause rpg.sys matches 0 if score #auc_s rpg.sys matches ..9 run function rpg:auc/name0 with storage rpg:auc t

execute if score #auc_run rpg.sys matches 1 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"경매 진행 중에는 물품을 뺄 수 없습니다. [경매 강제 종료] 를 쓰세요.","color":"red"}]
execute if score #auc_run rpg.sys matches 1 run return 0
execute if score #auc_n rpg.sys matches ..3 run return 0
# 물품을 제작자에게 돌려주고 보관용 거치대 제거
execute at @s run function rpg:auc/give4
scoreboard players remove #auc_n rpg.sys 1
function rpg:auc/tidy
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"물품을 경매에서 뺐습니다.","color":"green"}]
function rpg:auc/items

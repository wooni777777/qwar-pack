tellraw @s ["", {"text": "   ── 물품 2 ──", "color": "aqua", "bold": true}]
execute unless entity @a[scores={rpg.abid2=1..}] run tellraw @s ["", {"text": "      입찰자가 없습니다", "color": "gray"}]
execute unless entity @a[scores={rpg.abid2=1..}] run return 0
execute as @a run scoreboard players operation @s rpg.asort = @s rpg.abid2
scoreboard players set #rank rpg.sys 0
function rpg:auc/rank
scoreboard players set @a rpg.asort 0

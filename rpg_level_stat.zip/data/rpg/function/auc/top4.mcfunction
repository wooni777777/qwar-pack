scoreboard players operation #auc_top4 rpg.sys = @s rpg.abid4
tag @a remove auc_win4
tag @s add auc_win4

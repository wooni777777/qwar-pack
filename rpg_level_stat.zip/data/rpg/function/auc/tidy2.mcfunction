data remove storage rpg:auc i2
scoreboard players set #auc_min2 rpg.sys 0
scoreboard players set #auc_top2 rpg.sys 0
scoreboard players set @a rpg.abid2 0
execute as @a[scores={rpg.abidL=2}] run scoreboard players set @s rpg.abidL 0
tag @a remove auc_win2
kill @e[tag=rpg_auc_h2]

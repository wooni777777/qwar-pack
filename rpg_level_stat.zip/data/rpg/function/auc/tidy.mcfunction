execute if score #auc_n rpg.sys matches ..0 run function rpg:auc/tidy1
execute if score #auc_n rpg.sys matches ..1 run function rpg:auc/tidy2
execute if score #auc_n rpg.sys matches ..2 run function rpg:auc/tidy3
execute if score #auc_n rpg.sys matches ..3 run function rpg:auc/tidy4

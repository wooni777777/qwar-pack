data modify storage rpg:auc m set value {n:3,components:{}}
data modify storage rpg:auc m.id set from storage rpg:auc i3.id
data modify storage rpg:auc m.count set from storage rpg:auc i3.count
execute if data storage rpg:auc i3.components run data modify storage rpg:auc m.components set from storage rpg:auc i3.components
execute store result storage rpg:auc m.min int 1 run scoreboard players get #auc_min3 rpg.sys
execute store result storage rpg:auc m.my int 1 run scoreboard players get @s rpg.abid3
function rpg:auc/rowshow with storage rpg:auc m

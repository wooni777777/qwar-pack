$bossbar set rpg:auction name {"text":"-{낙찰}-  $(m):$(s)","color":"red","bold":true}

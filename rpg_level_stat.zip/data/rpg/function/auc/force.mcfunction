execute if score #auc_run rpg.sys matches 0 if score #auc_n rpg.sys matches ..0 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"종료할 경매가 없습니다.","color":"red"}]
execute if score #auc_run rpg.sys matches 0 if score #auc_n rpg.sys matches ..0 run return 0
# 1) 입찰금 환불
execute as @a run function rpg:auc/refund
# 2) 등록된 물품은 전부 제작자에게 돌려준다
execute if score #auc_n rpg.sys matches 1.. at @s run function rpg:auc/give1
execute if score #auc_n rpg.sys matches 2.. at @s run function rpg:auc/give2
execute if score #auc_n rpg.sys matches 3.. at @s run function rpg:auc/give3
execute if score #auc_n rpg.sys matches 4.. at @s run function rpg:auc/give4
# 3) 상태 초기화
function rpg:auc/clear
tellraw @a " "
tellraw @a [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"【경매】","color":"yellow","bold":true},{"text":"가 강제 종료되었습니다. 입찰금은 전액 환불되었습니다.","color":"red"}]
tellraw @a " "

# 물품 4 : 표시용 스냅샷 + 실물은 보관용 갑옷 거치대로 옮긴다
data modify storage rpg:auc i4 set from entity @s SelectedItem
execute unless entity @e[tag=rpg_auc_h4] run summon minecraft:armor_stand ~ ~-64 ~ {Tags:["rpg_auc_h4","rpg_auc_h"],Marker:1b,Invisible:1b,NoGravity:1b,Invulnerable:1b,PersistenceRequired:1b,Silent:1b}
item replace entity @e[tag=rpg_auc_h4,limit=1] weapon.mainhand from entity @s weapon.mainhand
scoreboard players operation #auc_min4 rpg.sys = @s rpg.aminv
scoreboard players operation #auc_top4 rpg.sys = @s rpg.aminv
scoreboard players remove #auc_top4 rpg.sys 1
scoreboard players set @a rpg.abid4 0
tag @a remove auc_win4
item replace entity @s weapon.mainhand with minecraft:air

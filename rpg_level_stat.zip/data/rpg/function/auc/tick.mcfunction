execute if score #auc_run rpg.sys matches 1 run bossbar set rpg:auction players @a
execute if score #auc_run rpg.sys matches 1 if score #auc_pause rpg.sys matches 0 run scoreboard players remove #auc_time rpg.sys 1
execute if score #auc_run rpg.sys matches 1 store result bossbar rpg:auction value run scoreboard players get #auc_time rpg.sys
execute if score #auc_run rpg.sys matches 1 if score #auc_time rpg.sys matches ..0 run function rpg:auc/end

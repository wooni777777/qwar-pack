data modify storage rpg:auc m set value {n:2,components:{}}
data modify storage rpg:auc m.id set from storage rpg:auc i2.id
data modify storage rpg:auc m.count set from storage rpg:auc i2.count
execute if data storage rpg:auc i2.components run data modify storage rpg:auc m.components set from storage rpg:auc i2.components
execute store result storage rpg:auc m.min int 1 run scoreboard players get #auc_min2 rpg.sys
execute store result storage rpg:auc m.my int 1 run scoreboard players get @s rpg.abid2
function rpg:auc/bhead with storage rpg:auc m

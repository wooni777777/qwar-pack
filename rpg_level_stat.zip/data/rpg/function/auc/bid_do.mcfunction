scoreboard players set #ok rpg.sys 0
execute if score #auc_run rpg.sys matches 0 run scoreboard players set #ok rpg.sys 1
execute if score #auc_run rpg.sys matches 0 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"경매가 시작되어있지 않습니다","color":"red"}]
execute if score @s rpg.abidv matches ..0 if score #ok rpg.sys matches 0 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"금액을 먼저 선택하세요.","color":"red"}]
execute if score @s rpg.abidv matches ..0 run scoreboard players set #ok rpg.sys 1
execute if score #ok rpg.sys matches 0 unless score @s money >= @s rpg.abidv run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"소지금이 부족합니다.","color":"red"}]
execute if score #ok rpg.sys matches 0 unless score @s money >= @s rpg.abidv run scoreboard players set #ok rpg.sys 1
# 최소 금액 확인 (기존 입찰 + 이번 금액)
scoreboard players operation #bt rpg.sys = @s rpg.abidv
execute if score @s rpg.abidi matches 1 run scoreboard players operation #bt rpg.sys += @s rpg.abid1
execute if score #ok rpg.sys matches 0 if score @s rpg.abidi matches 1 unless score #bt rpg.sys >= #auc_min1 rpg.sys run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"최소 금액보다 낮습니다.","color":"red"}]
execute if score @s rpg.abidi matches 1 unless score #bt rpg.sys >= #auc_min1 rpg.sys run scoreboard players set #ok rpg.sys 1
execute if score @s rpg.abidi matches 2 run scoreboard players operation #bt rpg.sys += @s rpg.abid2
execute if score #ok rpg.sys matches 0 if score @s rpg.abidi matches 2 unless score #bt rpg.sys >= #auc_min2 rpg.sys run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"최소 금액보다 낮습니다.","color":"red"}]
execute if score @s rpg.abidi matches 2 unless score #bt rpg.sys >= #auc_min2 rpg.sys run scoreboard players set #ok rpg.sys 1
execute if score @s rpg.abidi matches 3 run scoreboard players operation #bt rpg.sys += @s rpg.abid3
execute if score #ok rpg.sys matches 0 if score @s rpg.abidi matches 3 unless score #bt rpg.sys >= #auc_min3 rpg.sys run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"최소 금액보다 낮습니다.","color":"red"}]
execute if score @s rpg.abidi matches 3 unless score #bt rpg.sys >= #auc_min3 rpg.sys run scoreboard players set #ok rpg.sys 1
execute if score @s rpg.abidi matches 4 run scoreboard players operation #bt rpg.sys += @s rpg.abid4
execute if score #ok rpg.sys matches 0 if score @s rpg.abidi matches 4 unless score #bt rpg.sys >= #auc_min4 rpg.sys run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"최소 금액보다 낮습니다.","color":"red"}]
execute if score @s rpg.abidi matches 4 unless score #bt rpg.sys >= #auc_min4 rpg.sys run scoreboard players set #ok rpg.sys 1
execute if score #ok rpg.sys matches 0 run function rpg:auc/bid_pay
execute if score #ok rpg.sys matches 1 at @s run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 1 0.6

tag @s add auc_viewer
tellraw @s " "
tellraw @s {"text": "━━━━━━━  경매 현황  ━━━━━━━", "color": "dark_gray"}
execute if score #auc_n rpg.sys matches 0 run tellraw @s ["", {"text": "   등록된 물품이 없습니다", "color": "gray"}]
execute if score #auc_n rpg.sys matches 1.. run function rpg:auc/stat1
execute if score #auc_n rpg.sys matches 2.. run function rpg:auc/stat2
execute if score #auc_n rpg.sys matches 3.. run function rpg:auc/stat3
execute if score #auc_n rpg.sys matches 4.. run function rpg:auc/stat4
tellraw @s {"text": "━━━━━━━━━━━━━━━━━━━━━━━━━━", "color": "dark_gray"}
tag @s remove auc_viewer

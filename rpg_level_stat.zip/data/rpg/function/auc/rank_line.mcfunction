tellraw @a[tag=auc_viewer] ["", {"text": "      "}, {"score": {"name": "#rank", "objective": "rpg.sys"}, "color": "dark_gray"}, {"text": ". ", "color": "dark_gray"}, {"selector": "@s", "color": "white"}, {"text": "   ", "color": "dark_gray"}, {"score": {"name": "@s", "objective": "rpg.asort"}, "color": "gold"}, {"text": "원", "color": "dark_gray"}]
scoreboard players set @s rpg.asort 0

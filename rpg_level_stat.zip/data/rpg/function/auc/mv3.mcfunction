data remove storage rpg:auc i3
data modify storage rpg:auc i3 set from storage rpg:auc i4
data remove storage rpg:auc i4
scoreboard players operation #auc_min3 rpg.sys = #auc_min4 rpg.sys
scoreboard players operation #auc_top3 rpg.sys = #auc_top4 rpg.sys
execute as @a run scoreboard players operation @s rpg.abid3 = @s rpg.abid4
tag @a remove auc_win3
execute as @a[tag=auc_win4] run tag @s add auc_win3
tag @a remove auc_win4
tag @e[tag=rpg_auc_h4] add rpg_auc_h3
tag @e[tag=rpg_auc_h3] remove rpg_auc_h4
execute as @a[scores={rpg.abidL=4}] run scoreboard players set @s rpg.abidL 3

scoreboard players enable @s rpg.auc
playsound minecraft:item.book.page_turn player @s ~ ~ ~ 1 1.4
tellraw @s " "
tellraw @s {"text": "━━━━━━━  등록 물품  ━━━━━━━", "color": "dark_gray"}
execute if score #auc_n rpg.sys matches ..0 run tellraw @s ["", {"text": "   등록된 물품이 없습니다", "color": "gray"}]
execute if score #auc_n rpg.sys matches 1.. run function rpg:auc/item1
execute if score #auc_n rpg.sys matches 2.. run function rpg:auc/item2
execute if score #auc_n rpg.sys matches 3.. run function rpg:auc/item3
execute if score #auc_n rpg.sys matches 4.. run function rpg:auc/item4
tellraw @s " "
execute if score #auc_run rpg.sys matches 1 run tellraw @s ["", {"text": "   경매 진행 중에는 물품을 뺄 수 없습니다", "color": "dark_red"}]
tellraw @s ["", {"text": "   "}, {"text": "[ 돌아가기 ]", "color": "dark_gray", "click_event": {"action": "run_command", "command": "trigger rpg.auc set 1"}}]
tellraw @s {"text": "━━━━━━━━━━━━━━━━━━━━━━━━━━", "color": "dark_gray"}

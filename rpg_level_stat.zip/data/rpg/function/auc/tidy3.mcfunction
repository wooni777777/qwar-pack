data remove storage rpg:auc i3
scoreboard players set #auc_min3 rpg.sys 0
scoreboard players set #auc_top3 rpg.sys 0
scoreboard players set @a rpg.abid3 0
execute as @a[scores={rpg.abidL=3}] run scoreboard players set @s rpg.abidL 0
tag @a remove auc_win3
kill @e[tag=rpg_auc_h3]

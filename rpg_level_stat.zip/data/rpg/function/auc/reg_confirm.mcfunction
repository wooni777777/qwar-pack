scoreboard players set #ok rpg.sys 0
execute if score #auc_n rpg.sys matches 4.. run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"경매 물품은 최대 4개까지입니다.","color":"red"}]
execute if score #auc_n rpg.sys matches 4.. run scoreboard players set #ok rpg.sys 1
execute if score #auc_run rpg.sys matches 1 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"경매가 진행 중일 때는 등록할 수 없습니다.","color":"red"}]
execute if score #auc_run rpg.sys matches 1 run scoreboard players set #ok rpg.sys 1
execute unless items entity @s weapon.mainhand * run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"손에 아이템을 들어주세요.","color":"red"}]
execute unless items entity @s weapon.mainhand * run scoreboard players set #ok rpg.sys 1
execute if score @s rpg.aminv matches ..0 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"최소 금액을 정해주세요.","color":"red"}]
execute if score @s rpg.aminv matches ..0 run scoreboard players set #ok rpg.sys 1
execute if score #ok rpg.sys matches 0 run function rpg:auc/reg_do

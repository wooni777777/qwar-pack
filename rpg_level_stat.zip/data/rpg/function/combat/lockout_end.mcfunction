attribute @s minecraft:attack_damage modifier remove rpg:hitcd
scoreboard players set @s rpg.hcd -1

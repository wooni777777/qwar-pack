advancement revoke @s only rpg:combat/kill_player
function rpg:hid/on_kill_player
scoreboard players operation #kpid rpg.sys = @s rpg.pid
execute at @s run tellraw @a[nbt={Health:0.0f},distance=..16,limit=1,sort=nearest,scores={rpg.str=90..,rpg.revcd=..0}] [{"text":"[복수] ","color":"dark_red","bold":true},{"selector":"@s","color":"yellow"},{"text":"님에게 복수가 발동되었습니다","color":"white"}]
execute at @s as @a[nbt={Health:0.0f},distance=..16,limit=1,sort=nearest,scores={rpg.str=90..,rpg.revcd=..0}] run function rpg:passive/revenge_mark
execute if score @s rpg.dex matches 70.. run effect give @s minecraft:speed 8 0 true
execute if score @s rpg.dex matches 70.. run tellraw @s [{"text":"[패시브] ","color":"aqua","bold":true},{"text":"끈질긴 추격 - 신속 I 8초","color":"white"}]

# 이미 저항 효과로 줄어든 만큼은 빼고 되돌려 주기 (v48 · 내부용 · as 플레이어 · combat/on_damaged)
#   목표 경감 R% (#red) · 저항으로 이미 r% 줄어 받음 -> 받은 피해 중 되돌릴 % = 100 - (100 - R) x 100 / (100 - r)
scoreboard players set #rsr rpg.sys 0
execute if predicate rpg:res0 run scoreboard players set #rsr rpg.sys 20
execute if predicate rpg:res1 run scoreboard players set #rsr rpg.sys 40
execute if predicate rpg:res2 run scoreboard players set #rsr rpg.sys 60
execute if predicate rpg:res3 run scoreboard players set #rsr rpg.sys 80
execute if score #rsr rpg.sys matches 0 run return 0
execute if predicate rpg:res4 run return run scoreboard players set #red rpg.sys 0
scoreboard players set #rsq rpg.sys 100
scoreboard players operation #rsq rpg.sys -= #red rpg.sys
scoreboard players operation #rsq rpg.sys *= #c100 rpg.sys
scoreboard players set #rsx rpg.sys 100
scoreboard players operation #rsx rpg.sys -= #rsr rpg.sys
scoreboard players operation #rsq rpg.sys /= #rsx rpg.sys
scoreboard players set #red rpg.sys 100
scoreboard players operation #red rpg.sys -= #rsq rpg.sys
execute if score #red rpg.sys matches ..-1 run scoreboard players set #red rpg.sys 0

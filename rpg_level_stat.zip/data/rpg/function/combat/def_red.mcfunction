# 방어력 -> 피해 경감 % = def*100 / (def + #def_k)  (상한 없음 · 수확체감)
scoreboard players operation #dr rpg.sys = #dfx rpg.sys
scoreboard players operation #dr rpg.sys *= #c100 rpg.sys
scoreboard players operation #dd rpg.sys = #dfx rpg.sys
scoreboard players operation #dd rpg.sys += #def_k rpg.sys
scoreboard players operation #dr rpg.sys /= #dd rpg.sys
scoreboard players operation #red rpg.sys += #dr rpg.sys

# 받은 피해의 #red % 를 되돌려준다 (v44 고침)
#   즉시회복은 4 단위로만 차서, 예전엔 작은 피해(1~3)에 경감이 붙으면 오히려 피가 찼습니다.
#   이제 되돌려줄 양을 0.01 단위로 rpg.mtb 에 모았다가 4 가 될 때마다 4 씩 돌려줍니다 (평균은 정확히 #red %).
scoreboard players operation #mt rpg.sys = #d rpg.sys
scoreboard players operation #mt rpg.sys *= #red rpg.sys
scoreboard players operation @s rpg.mtb += #mt rpg.sys
execute if score @s rpg.mtb matches ..399 run return 0
scoreboard players operation #heal rpg.sys = @s rpg.mtb
scoreboard players operation #heal rpg.sys /= #c400 rpg.sys
scoreboard players operation #mt rpg.sys = #heal rpg.sys
scoreboard players operation #mt rpg.sys *= #c400 rpg.sys
scoreboard players operation @s rpg.mtb -= #mt rpg.sys
scoreboard players operation #heal rpg.sys *= #c4 rpg.sys
function rpg:util/heal

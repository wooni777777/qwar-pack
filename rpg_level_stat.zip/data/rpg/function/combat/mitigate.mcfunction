# 받은 피해의 #red % 를 즉시 되돌려준다
scoreboard players operation #heal rpg.sys = #d rpg.sys
scoreboard players operation #heal rpg.sys *= #red rpg.sys
scoreboard players operation #heal rpg.sys /= #c100 rpg.sys
function rpg:util/heal

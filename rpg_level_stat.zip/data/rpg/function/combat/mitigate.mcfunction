# 받은 피해의 #red % 를 되돌려준다 (v47 : 1 단위로 정확히)
#   되돌릴 양을 0.01 단위로 rpg.mtb 에 모아서 1 이 넘을 때마다 바로 회복 (즉시회복 덩어리 + 재생 1씩)
#   -> 방어력 · 전투태세 · 받피감 버프가 맞을 때마다 그대로 보입니다 (예전 : 4 가 모일 때까지 안 보였음)
scoreboard players operation #mt rpg.sys = #d rpg.sys
scoreboard players operation #mt rpg.sys *= #red rpg.sys
scoreboard players operation @s rpg.mtb += #mt rpg.sys
execute if score @s rpg.mtb matches ..99 run return 0
scoreboard players operation #heal rpg.sys = @s rpg.mtb
scoreboard players operation #heal rpg.sys /= #c100 rpg.sys
scoreboard players operation #mt rpg.sys = #heal rpg.sys
scoreboard players operation #mt rpg.sys *= #c100 rpg.sys
scoreboard players operation @s rpg.mtb -= #mt rpg.sys
function rpg:util/heal

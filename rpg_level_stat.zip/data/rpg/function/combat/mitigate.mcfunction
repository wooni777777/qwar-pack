# 받은 피해를 줄여 준다 = 그만큼 바로 되돌려 줌 (v49 · 내부용 · as 맞은 플레이어)
#   ① 방어력 : 방어력 x 0.5 만큼 (고정) — 단 이번 피해의 (100 - #def_min)% 까지만
#   ② 피해경감 % (#red) : ① 을 빼고 남은 피해에 적용
#   되돌릴 양을 0.01 단위로 rpg.mtb 에 모아서 1 이 넘을 때마다 바로 회복 (즉시회복 덩어리 + 재생 1씩)
scoreboard players operation #fl rpg.sys = #dfx rpg.sys
scoreboard players operation #fl rpg.sys *= #c50 rpg.sys
execute if score #fl rpg.sys matches ..-1 run scoreboard players set #fl rpg.sys 0
scoreboard players set #flx rpg.sys 100
scoreboard players operation #flx rpg.sys -= #def_min rpg.sys
execute if score #flx rpg.sys matches ..-1 run scoreboard players set #flx rpg.sys 0
scoreboard players operation #flx rpg.sys *= #d rpg.sys
execute if score #fl rpg.sys > #flx rpg.sys run scoreboard players operation #fl rpg.sys = #flx rpg.sys
scoreboard players operation #frs rpg.sys = #d rpg.sys
scoreboard players operation #frs rpg.sys *= #c100 rpg.sys
scoreboard players operation #frs rpg.sys -= #fl rpg.sys
execute if score #red rpg.sys matches ..-1 run scoreboard players set #red rpg.sys 0
scoreboard players operation #frs rpg.sys *= #red rpg.sys
scoreboard players operation #frs rpg.sys /= #c100 rpg.sys
scoreboard players operation #mt rpg.sys = #fl rpg.sys
scoreboard players operation #mt rpg.sys += #frs rpg.sys
execute if score #mt rpg.sys matches ..0 run return 0
scoreboard players operation @s rpg.mtb += #mt rpg.sys
execute if score @s rpg.mtb matches ..99 run return 0
scoreboard players operation #heal rpg.sys = @s rpg.mtb
scoreboard players operation #heal rpg.sys /= #c100 rpg.sys
scoreboard players operation #mt rpg.sys = #heal rpg.sys
scoreboard players operation #mt rpg.sys *= #c100 rpg.sys
scoreboard players operation @s rpg.mtb -= #mt rpg.sys
function rpg:util/heal

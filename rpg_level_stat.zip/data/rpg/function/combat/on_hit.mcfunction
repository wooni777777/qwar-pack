advancement revoke @s only rpg:combat/hit
execute unless entity @s[tag=rpg_stunned] if score @s rpg.busy matches ..0 if score @s rpg.hcd matches ..0 run function rpg:combat/hit_go

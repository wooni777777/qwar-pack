advancement revoke @s only rpg:combat/hit
# v47 : 방금 무언가를 때림 (리그 몹 손맛 · 화면 흔들림용)
scoreboard players operation @s rpg.hitt = #gtick rpg.sys
# v58 : 좌클릭(L-click) · [악마의 힘] 은신 풀림은 combat/lhit · combat/phit (진짜 평타 · 화살만 — 스킬 · 출혈 · 반사 · 처치 판정 피해는 제외)
# v58 : 막타 기록은 맞은 몬스터 쪽(mob/fhp_dmg · 방금 때린 공격자)에서 · 보스 · 잡몹 모두
# v45 : 봉인(noskill 1) 중이면 평타 처리 안 함
execute if score @s noskill matches 1 run return 0
execute unless entity @s[tag=rpg_stunned] if score @s rpg.busy matches ..0 if score @s rpg.hcd matches ..0 run function rpg:combat/hit_go

advancement revoke @s only rpg:combat/hit
# v45 : 봉인(noskill 1) 중이면 평타 처리 안 함
execute if score @s noskill matches 1 run return 0
execute unless entity @s[tag=rpg_stunned] if score @s rpg.busy matches ..0 if score @s rpg.hcd matches ..0 run function rpg:combat/hit_go

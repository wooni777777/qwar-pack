# 공격 락아웃 (A가 혼자 무한 연타하는 것 방지 / 다른 사람은 동시 타격 가능)
execute as @a[scores={rpg.hcd=1..}] run scoreboard players remove @s rpg.hcd 1
execute as @a[scores={rpg.hcd=0}] run function rpg:combat/lockout_end

# 전투 상태 타이머
execute as @a[scores={rpg.cbt=1..}] run scoreboard players remove @s rpg.cbt 1
execute as @a[scores={rpg.grace=1..}] run scoreboard players remove @s rpg.grace 1
execute as @a[scores={rpg.cmbt=1..}] run scoreboard players remove @s rpg.cmbt 1
execute as @a[scores={rpg.cmbt=0}] run function rpg:passive/combo_end

# 각종 지속시간
execute as @a[scores={rpg.rage=1..}] run scoreboard players remove @s rpg.rage 1
execute as @a[scores={rpg.rage=0}] run function rpg:passive/rage_end
execute as @a[scores={rpg.hide=1..}] run scoreboard players remove @s rpg.hide 1
execute as @a[scores={rpg.hide=0}] run function rpg:passive/hide_end
execute as @a[scores={rpg.will=1..}] run scoreboard players remove @s rpg.will 1
execute as @a[scores={rpg.will=0}] run scoreboard players set @s rpg.will -1
execute as @a[scores={rpg.rev=1..}] run scoreboard players remove @s rpg.rev 1
execute as @a[scores={rpg.cd60=1..}] run scoreboard players remove @s rpg.cd60 1
execute as @a[scores={rpg.cd900=1..}] run scoreboard players remove @s rpg.cd900 1
execute as @a[scores={rpg.cdw=1..}] run scoreboard players remove @s rpg.cdw 1
execute as @a[scores={rpg.revcd=1..}] run scoreboard players remove @s rpg.revcd 1
execute as @a[scores={rpg.lcd=1..}] run scoreboard players remove @s rpg.lcd 1
execute as @a[scores={rpg.scd=1..}] run scoreboard players remove @s rpg.scd 1

# 돌진 진행
execute as @a[scores={rpg.dsh=1..}] at @s run function rpg:fx/dash_tick
execute as @a[scores={rpg.dshf=1..}] run scoreboard players remove @s rpg.dshf 1
execute as @a[scores={rpg.dshf=1..,rpg.dsh=..0},nbt={OnGround:1b}] run scoreboard players set @s rpg.dshf 0
execute as @a[scores={rpg.dshf=0}] run function rpg:fx/dash_fall_end

# 도약 진행
execute as @a[scores={rpg.leap=1..}] at @s run function rpg:passive/leap_tick

# 피격 감지
execute as @a[scores={rpg.init=1,rpg.hp=1..}] at @s run function rpg:combat/dmg_check

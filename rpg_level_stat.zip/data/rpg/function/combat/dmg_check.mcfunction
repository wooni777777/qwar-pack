scoreboard players set #d rpg.sys 0
scoreboard players operation #d rpg.sys = @s rpg.php
scoreboard players operation #d rpg.sys -= @s rpg.hp
execute if score #d rpg.sys matches 1.. run function rpg:combat/on_damaged
# 회복까지 반영된 '지금' 체력을 직접 읽는다 (스코어보드는 한 틱 늦게 갱신됨)
execute store result score @s rpg.php run data get entity @s Health 1
scoreboard players operation @s rpg.hpnow = @s rpg.php
scoreboard players operation @s rpg.d_cur = @s rpg.php

# v51 : PVP 가 안 되는 플레이어에게 맞았으면 (화살 · 휩쓸기 등) 받은 피해를 그대로 되돌리고 끝
execute if function rpg:pvp/fb run return run function rpg:pvp/undo
# v47 : 나를 때린 리그 몹은 때리기 동작 (총든 해적은 쏘기 동작이 따로)
execute at @s on attacker if entity @s[tag=rpg_rig,tag=!rpg_gun41,distance=..6] run function rpg:rig/rq_atk
# v47 : 독 개구리에게 맞으면 독 3초
scoreboard players set #fpz rpg.sys 0
execute at @s on attacker if entity @s[tag=rpg_m_frog_p,distance=..4] unless entity @p[distance=..0.1,predicate=rpg:poisoned] run scoreboard players set #fpz rpg.sys 1
execute if score #fpz rpg.sys matches 1 run effect give @s minecraft:poison 3 0
scoreboard players set @s rpg.cbt 200
# 반사 API 용 : 이번에 받은 피해량을 기록
scoreboard players operation @s rpg.lastd = #d rpg.sys
scoreboard players operation @s rpg.lastdt = #gtick rpg.sys
# ── 받는 피해 줄이기 (v49) ──
#   방어력(#dfx)   : 1당 피해 -0.5 (고정 · combat/mitigate)
#   피해경감(#red) : 패시브 · 버프 · 균열 % (방어력과 따로 · 방어력으로 줄이고 남은 피해에)
scoreboard players set #red rpg.sys 0
scoreboard players set #dodge rpg.sys 0
# v44 : 방어 전투태세 겹만큼 이번 피해의 방어력에 더함
scoreboard players operation #dfx rpg.sys = @s rpg.def
execute if score @s rpg.sdA matches 1.. if score @s rpg.sdS matches 1.. run function rpg:stance/def_add
# v49 : [힘 100] 최후의 일격에 맞은 틱(과 다음 틱)은 방어력 무시
scoreboard players operation #igt rpg.sys = #gtick rpg.sys
scoreboard players operation #igt rpg.sys -= @s rpg.igd
execute if score #igt rpg.sys matches 0..1 run scoreboard players set #dfx rpg.sys 0
execute if score @s rpg.con matches 60.. run scoreboard players add #red rpg.sys 7
execute if score @s rpg.con matches 70.. run function rpg:passive/unyield
execute if score @s rpg.con matches 50.. run function rpg:passive/pain_used
execute if score @s rpg.p100 matches 3 if score @s rpg.con matches 100.. run function rpg:passive/undying
execute if score @s rpg.dex matches 70.. if score @s rpg.grace matches ..0 run function rpg:passive/dodge
function rpg:hid/on_damaged
execute if score #dodge rpg.sys matches 0 if score #red rpg.sys matches 86.. run scoreboard players set #red rpg.sys 85
# v44 : 받는 피해 감소 버프 · 스톤의 균열 (곱으로 더함)
execute if score @s rpg.bdt matches 1.. if score @s rpg.bdp matches 1.. run function rpg:buff/dr_add
execute if score @s rpg.rfn5 matches 1.. run function rpg:rift/dr_add
# 저항 효과(포션 · 공격 무시 등)로 이미 줄어든 만큼은 % 에서 빼기
function rpg:combat/res_adj
function rpg:combat/mitigate
# v45 : 데미지 숫자 (플레이어가 때린 피해)
function rpg:dmgn/pl
# ── 반응형 패시브 ──
execute if score @s rpg.con matches 90.. at @s run function rpg:passive/reflect
execute if score @s rpg.str matches 50.. run function rpg:passive/rage_check
# v44 : 피해를 받으면 전투태세 한 겹
function rpg:stance/gain

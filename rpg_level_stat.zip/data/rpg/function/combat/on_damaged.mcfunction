execute at @s as @e[tag=rpg_mob,tag=!rpg_dead,tag=!rpg_atk,distance=..4.5] run function rpg:mob/anim_hit
scoreboard players set @s rpg.cbt 200
# ── 피해 경감 합산 (#red %) ──
scoreboard players set #red rpg.sys 0
scoreboard players set #dodge rpg.sys 0
execute if score @s rpg.def matches 1.. run function rpg:combat/def_red
execute if score @s rpg.con matches 60.. run scoreboard players add #red rpg.sys 7
execute if score @s rpg.con matches 70.. run scoreboard players add #red rpg.sys 12
execute if score @s rpg.con matches 50.. run function rpg:passive/pain_used
execute if score @s rpg.con matches 100.. run function rpg:passive/undying
execute if score @s rpg.dex matches 100.. if score @s rpg.grace matches ..0 run function rpg:passive/dodge
execute if score #dodge rpg.sys matches 0 if score #red rpg.sys matches 86.. run scoreboard players set #red rpg.sys 85
execute if score #red rpg.sys matches 1.. run function rpg:combat/mitigate
# ── 반응형 패시브 ──
execute if score @s rpg.con matches 90.. at @s run function rpg:passive/reflect
execute if score @s rpg.str matches 50.. run function rpg:passive/rage_check

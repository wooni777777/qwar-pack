advancement revoke @s only rpg:combat/kill
function rpg:passive/on_kill
function rpg:hid/on_kill

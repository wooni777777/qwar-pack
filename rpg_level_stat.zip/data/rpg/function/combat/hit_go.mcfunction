scoreboard players set @s rpg.busy 1
scoreboard players set @s rpg.cbt 200

# 실제 공격력 = 스탯/패시브 계산값 + 손에 든 무기
scoreboard players set #atk rpg.sys 0
scoreboard players operation #atk rpg.sys = @s rpg.d_atk
scoreboard players set #wp rpg.sys 0
execute store result score #wp rpg.sys run attribute @s minecraft:attack_damage get 1
scoreboard players operation #atk rpg.sys += #wp rpg.sys

# 공격자 락아웃 10틱
scoreboard players set @s rpg.hcd 10
attribute @s minecraft:attack_damage modifier add rpg:hitcd -1 add_multiplied_total

# 이번 틱에 맞은 대상
execute at @s run tag @e[distance=0.1..7,nbt={HurtTime:10s},sort=nearest,limit=1] add rpg.tgt
execute if entity @e[tag=rpg.tgt] at @s run function rpg:passive/on_hit
tag @e[tag=rpg.tgt] remove rpg.tgt
scoreboard players set @s rpg.busy 0

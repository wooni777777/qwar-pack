# ── 얼음 충격파 ──
#   function rpg:fx/wave_ice {rad:8,spd:0.5,h:0.1,dense:24}
$function rpg:fx/wave {p:"minecraft:ominous_spawning",rad:$(rad),spd:$(spd),h:$(h),dense:$(dense)}
return 1

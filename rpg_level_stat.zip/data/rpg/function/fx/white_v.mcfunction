# 흰 세로 베기 — 인자 없이 그냥 실행
function rpg:fx/slash_dust {dir:"v",size:1.35,rad:1.7,h:1.15,spd:3,r1:1.00,g1:1.00,b1:1.00,r2:0.55,g2:0.75,b2:1.00}
return 1

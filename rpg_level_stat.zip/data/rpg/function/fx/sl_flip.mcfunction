# 베기 순서를 반대로 (12 - i)
scoreboard players set #fx12 rpg.sys 12
scoreboard players operation #fx12 rpg.sys -= #fxidx rpg.sys
scoreboard players operation #fxidx rpg.sys = #fx12 rpg.sys

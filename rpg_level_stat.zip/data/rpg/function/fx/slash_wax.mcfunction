# ── 3. wax_off ──
#   execute as @p at @s run function rpg:fx/slash_wax {dir:"d",rad:1.7,h:1.2,spd:3}
$data modify storage rpg:fx s set value {dir:"$(dir)",rad:$(rad),h:$(h),spd:$(spd),p:"minecraft:wax_off"}
function rpg:fx/sl_run
return 1

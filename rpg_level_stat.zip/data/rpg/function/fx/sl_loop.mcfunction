execute if score #fxn rpg.sys matches ..0 run return 0
execute if score @s rpg.fxi matches 13.. run return 0
scoreboard players operation #fxidx rpg.sys = @s rpg.fxi
execute if data storage rpg:fx s{rev:1} run function rpg:fx/sl_flip
execute store result storage rpg:fx s.i int 1 run scoreboard players get #fxidx rpg.sys
function rpg:fx/sl_draw with storage rpg:fx s
scoreboard players add @s rpg.fxi 1
scoreboard players remove #fxn rpg.sys 1
function rpg:fx/sl_loop

execute if score #fxn rpg.sys matches ..0 run return 0
execute if score @s rpg.fxi matches 13.. run return 0
execute store result storage rpg:fx s.i int 1 run scoreboard players get @s rpg.fxi
function rpg:fx/sl_draw with storage rpg:fx s
scoreboard players add @s rpg.fxi 1
scoreboard players remove #fxn rpg.sys 1
function rpg:fx/sl_loop

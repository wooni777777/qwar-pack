# green d 베기 — 인자 없이 그냥 실행
function rpg:fx/slash_dust {dir:"d",size:1.35,rad:1.7,h:1.15,fwd:0,spd:3,rev:0,r1:0.55,g1:1.00,b1:0.45,r2:0.15,g2:0.70,b2:0.20}
return 1

# gold v 베기 — 인자 없이 그냥 실행
function rpg:fx/slash_dust {dir:"v",size:1.35,rad:1.7,h:1.15,fwd:0,spd:3,rev:0,r1:1.00,g1:0.80,b1:0.15,r2:1.00,g2:1.00,b2:0.90}
return 1

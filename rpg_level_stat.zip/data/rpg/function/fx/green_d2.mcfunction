# 초록 ↗ 대각 베기 — 인자 없이 그냥 실행
function rpg:fx/slash_dust {dir:"d2",size:1.35,rad:1.7,h:1.15,spd:3,r1:0.40,g1:1.00,b1:0.40,r2:0.05,g2:0.55,b2:0.15}
return 1

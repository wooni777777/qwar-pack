# 보랏빛 가로 베기 — 인자 없이 그냥 실행
function rpg:fx/slash_dust {dir:"h",size:1.35,rad:1.7,h:1.15,spd:3,r1:0.70,g1:0.30,b1:1.00,r2:0.35,g2:0.10,b2:0.75}
return 1

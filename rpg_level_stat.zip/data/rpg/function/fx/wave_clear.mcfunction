# 진행 중인 충격파 전부 정리
kill @e[tag=rpg_wave]
return 1

scoreboard players remove @s rpg.dsh 1
# ── 수직 (직선 모드면 건너뜀) ──
execute if score @s rpg.dshl matches 1 run function rpg:fx/dash_vert
# ── 수평 : 0.35칸씩 잘라서 이동하므로 아무리 빨라도 벽을 뚫지 않는다 ──
scoreboard players operation #dn rpg.sys = @s rpg.dshp
scoreboard players operation #dn rpg.sys /= #c350 rpg.sys
execute if score #dn rpg.sys matches ..0 run scoreboard players set #dn rpg.sys 1
execute if score #dn rpg.sys matches 25.. run scoreboard players set #dn rpg.sys 25
function rpg:fx/dash_step
# ── 감속 ──
scoreboard players operation @s rpg.dshp *= #c9 rpg.sys
scoreboard players operation @s rpg.dshp /= #c10 rpg.sys
execute at @s run particle minecraft:cloud ~ ~0.15 ~ 0.22 0.06 0.22 0.006 3 normal @a
execute at @s run particle minecraft:crit ~ ~0.9 ~ 0.2 0.3 0.2 0.01 2 normal @a
execute if score @s rpg.dsh matches ..0 run function rpg:fx/dash_end

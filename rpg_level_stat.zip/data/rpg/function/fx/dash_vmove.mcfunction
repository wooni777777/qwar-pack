# 위아래로 막혀 있으면 움직이지 않는다
$execute at @s positioned ~ ~$(v) ~ if block ~ ~0.1 ~ #minecraft:replaceable if block ~ ~1.5 ~ #minecraft:replaceable run tp @s ~ ~ ~

execute store result storage rpg:dash d.v double 0.001 run scoreboard players get @s rpg.dshv
function rpg:fx/dash_vmove with storage rpg:dash d
# 중력
scoreboard players remove @s rpg.dshv 52
execute if score @s rpg.dshv matches ..-900 run scoreboard players set @s rpg.dshv -900

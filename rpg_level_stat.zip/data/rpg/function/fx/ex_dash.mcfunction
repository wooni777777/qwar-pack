# ════ 예제 3 · 돌진하고 잠시 뒤 베기 ════
#   실행 : execute as @p at @s run function rpg:fx/ex_dash
#   schedule 은 "누가" 를 기억하지 못하므로 태그로 표시해 두고 나중에 찾는다
function rpg:fx/dash {power:0.70,lift:0.38,ticks:12}
tag @s add fx_dashhit
schedule function rpg:fx/ex_dash_hit 8t replace
return 1

# ── 검 베기 엔진 (storage rpg:fx s 를 읽어서 그린다) ──
#   직접 부르지 마세요. rpg:fx/slash · slash_dust · slash_hit · slash_wax 가 부릅니다.
execute at @s run summon minecraft:marker ~ ~ ~ {Tags:["rpg_slash","rpg_slnew"]}
data modify entity @e[tag=rpg_slnew,limit=1] data set from storage rpg:fx s
data modify entity @e[tag=rpg_slnew,limit=1] Rotation set from entity @s Rotation
scoreboard players set @e[tag=rpg_slnew] rpg.fxi 0
execute store result score #fxsp rpg.sys run data get storage rpg:fx s.spd
execute if score #fxsp rpg.sys matches ..0 run scoreboard players set #fxsp rpg.sys 3
execute if score #fxsp rpg.sys matches 14.. run scoreboard players set #fxsp rpg.sys 13
scoreboard players operation @e[tag=rpg_slnew] rpg.fxs = #fxsp rpg.sys
tag @e[tag=rpg_slnew] remove rpg_slnew
return 1

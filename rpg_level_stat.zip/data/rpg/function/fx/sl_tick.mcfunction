data modify storage rpg:fx s set from entity @s data
scoreboard players operation #fxn rpg.sys = @s rpg.fxs
function rpg:fx/sl_loop
execute if score @s rpg.fxi matches 13.. run kill @s

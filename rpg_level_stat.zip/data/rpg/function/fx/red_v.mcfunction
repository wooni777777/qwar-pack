# 붉은 세로 베기 — 인자 없이 그냥 실행
function rpg:fx/slash_dust {dir:"v",size:1.35,rad:1.7,h:1.15,spd:3,r1:1.00,g1:0.15,b1:0.15,r2:1.00,g2:0.85,b2:0.30}
return 1

# ════ 예제 2 · 아머스탠드가 대신 베기 ════
execute at @s rotated ~ 0 run summon minecraft:armor_stand ^ ^ ^2 {Tags:["fx_stand"],Marker:1b,Invisible:1b,NoGravity:1b,Invulnerable:1b,Silent:1b}
execute at @e[tag=fx_stand,limit=1] rotated as @s run function rpg:fx/slash_dust {dir:"d",size:1.6,rad:1.9,h:1.2,fwd:0,spd:2,rev:0,r1:0.35,g1:0.85,b1:1.0,r2:0.10,g2:0.25,b2:0.90}
execute at @e[tag=fx_stand,limit=1] run function rpg:api/atk_hit {base:25,ratio:170,radius:4,max:"x"}
kill @e[tag=fx_stand]
return 1

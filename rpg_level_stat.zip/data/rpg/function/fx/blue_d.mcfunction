# 푸른 ↘ 대각 베기 — 인자 없이 그냥 실행
function rpg:fx/slash_dust {dir:"d",size:1.35,rad:1.7,h:1.15,spd:3,r1:0.25,g1:0.55,b1:1.00,r2:0.75,g2:0.95,b2:1.00}
return 1

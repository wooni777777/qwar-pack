scoreboard players set @s rpg.dsh -1
scoreboard players set @s rpg.dshp 0
scoreboard players set @s rpg.dshv 0
# 혹시 블록 안에 끼었으면 위로 밀어 올린다
scoreboard players set #dup rpg.sys 6
function rpg:fx/dash_unstuck
execute at @s run particle minecraft:cloud ~ ~0.2 ~ 0.3 0.1 0.3 0.01 8 normal @a

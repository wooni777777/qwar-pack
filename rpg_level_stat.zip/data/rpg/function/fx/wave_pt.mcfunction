$execute positioned ~ ~$(h) ~ rotated $(a) 0 positioned ^ ^ ^$(r) run particle $(p) ~ ~ ~ 0 0 0 0 1 force @a

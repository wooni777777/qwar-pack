execute as @a[tag=fx_dashhit] at @s run function rpg:fx/slash_dust {dir:"v",size:1.5,rad:1.8,h:1.2,spd:2,r1:1.0,g1:0.9,b1:0.35,r2:1.0,g2:0.35,b2:0.05}
execute as @a[tag=fx_dashhit] at @s run function rpg:api/atk_hit {base:30,ratio:180,radius:4}
tag @a remove fx_dashhit

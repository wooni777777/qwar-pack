# ── 1. dust_color_transition (색 조절 가능) ──
#   execute as @p at @s run function rpg:fx/slash_dust \
#     {dir:"h",size:1.4,rad:1.7,h:1.15,spd:3,r1:1.0,g1:0.15,b1:0.15,r2:1.0,g2:0.85,b2:0.30}
$data modify storage rpg:fx s set value {dir:"$(dir)",rad:$(rad),h:$(h),spd:$(spd),p:"minecraft:dust_color_transition{from_color:[$(r1),$(g1),$(b1)],to_color:[$(r2),$(g2),$(b2)],scale:$(size)}"}
function rpg:fx/sl_run
return 1

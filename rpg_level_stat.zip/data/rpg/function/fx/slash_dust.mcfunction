# ── 색을 직접 정하는 베기 (dust_color_transition) ──
#   function rpg:fx/slash_dust {dir:"h",size:1.35,rad:1.7,h:1.15,fwd:0,spd:3,rev:0,r1:1.0,g1:0.15,b1:0.15,r2:1.0,g2:0.85,b2:0.3}
#   dir  h 가로 · v 세로 · d 대각↘ · d2 대각↗
#   rad  베기 반지름(칸)     h    발끝 기준 높이(칸)
#   fwd  앞뒤 위치 조정 — 양수면 앞으로, 음수면 뒤로 (0 이면 그대로)
#   spd  1틱에 그리는 조각 수 (전체 13조각) — 1 느림 ~ 13 즉시
#   rev  0 이면 기본 순서, 1 이면 반대 순서
$data modify storage rpg:fx s set value {dir:"$(dir)",rad:$(rad),h:$(h),fwd:$(fwd),spd:$(spd),rev:$(rev),p:"minecraft:dust_color_transition{from_color:[$(r1),$(g1),$(b1)],to_color:[$(r2),$(g2),$(b2)],scale:$(size)}"}
function rpg:fx/sl_run
return 1

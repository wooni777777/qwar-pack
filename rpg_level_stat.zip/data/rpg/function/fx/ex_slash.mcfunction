# ════ 예제 1 · 베기 + 광역 피해 ════
#   execute as @p at @s run function rpg:fx/ex_slash
function rpg:fx/slash_dust {dir:"h",size:1.4,rad:1.7,h:1.15,spd:2,r1:1.0,g1:0.15,b1:0.15,r2:1.0,g2:0.85,b2:0.30}
function rpg:api/atk_hit {base:20,ratio:150,radius:3.5}
execute at @s run playsound minecraft:entity.player.attack.sweep player @a ~ ~ ~ 1 1.2
return 1

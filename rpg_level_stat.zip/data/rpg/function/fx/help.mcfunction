tellraw @s {"text":"━━━━━━━  이펙트 사용법  ━━━━━━━","color":"dark_gray"}
tellraw @s " "
tellraw @s ["",{"text":"  ① 먼저 확인","color":"yellow","bold":true},{"text":"   /function rpg:fx/demo","color":"green"}]
tellraw @s " "
tellraw @s ["",{"text":"  ② 베기 — 인자 없는 프리셋 24종","color":"yellow","bold":true},{"text":"   rpg:fx/<색>_<방향>","color":"gray"}]
tellraw @s ["",{"text":"     색 ","color":"gold"},{"text":"red blue gold purple green white","color":"gray"},{"text":"   방향 ","color":"gold"},{"text":"h v d d2","color":"gray"}]
tellraw @s " "
tellraw @s ["",{"text":"  ③ 베기 — 직접 조절 (인자 하나라도 빠지면 안 나옵니다)","color":"yellow","bold":true}]
tellraw @s ["",{"text":"  function rpg:fx/slash_dust {dir:\"h\",size:1.35,rad:1.7,h:1.15,fwd:0,spd:3,rev:0,r1:1.0,g1:0.15,b1:0.15,r2:1.0,g2:0.85,b2:0.3}","color":"aqua"}]
tellraw @s ["",{"text":"  function rpg:fx/slash {p:\"minecraft:flame\",dir:\"h\",rad:1.7,h:1.2,fwd:0,spd:3,rev:0}","color":"aqua"}]
tellraw @s ["",{"text":"     불 ","color":"gold"},{"text":"slash_fire","color":"gray"},{"text":"   폭발 ","color":"gold"},{"text":"slash_boom","color":"gray"},{"text":"   물 ","color":"gold"},{"text":"slash_water","color":"gray"},{"text":"   얼음 ","color":"gold"},{"text":"slash_ice","color":"gray"}]
tellraw @s " "
tellraw @s ["",{"text":"  ④ 베기 인자","color":"yellow","bold":true}]
tellraw @s ["",{"text":"     spd","color":"gold"},{"text":" 1 느림(0.65초) ~ 13 즉시   ","color":"gray"},{"text":"rev","color":"gold"},{"text":" 1 이면 베는 순서 반대","color":"gray"}]
tellraw @s ["",{"text":"     fwd","color":"gold"},{"text":" 앞뒤 위치 — 반지름이 커서 너무 앞이면 -0.5 처럼 음수를 넣으세요","color":"gray"}]
tellraw @s ["",{"text":"     dir","color":"gold"},{"text":" h 좌→우 · v 위→아래 · d 대각↘ · d2 대각↗  (rev:1 이면 전부 반대)","color":"gray"}]
tellraw @s " "
tellraw @s ["",{"text":"  ⑤ 원형 충격파","color":"yellow","bold":true},{"text":"   땅 내려찍기처럼 원이 퍼져나갑니다","color":"gray"}]
tellraw @s ["",{"text":"  function rpg:fx/wave {p:\"minecraft:flame\",rad:8,spd:0.5,h:0.1,dense:24}","color":"light_purple"}]
tellraw @s ["",{"text":"     rad","color":"gold"},{"text":" 어디까지   ","color":"gray"},{"text":"spd","color":"gold"},{"text":" 퍼지는 속도(1틱당 칸)   ","color":"gray"},{"text":"dense","color":"gold"},{"text":" 원의 점 개수","color":"gray"}]
tellraw @s ["",{"text":"     불 ","color":"gold"},{"text":"wave_fire","color":"gray"},{"text":"   폭발 ","color":"gold"},{"text":"wave_boom","color":"gray"},{"text":"   물 ","color":"gold"},{"text":"wave_water","color":"gray"},{"text":"   얼음 ","color":"gold"},{"text":"wave_ice","color":"gray"}]
tellraw @s " "
tellraw @s ["",{"text":"  ⑥ 돌진","color":"yellow","bold":true}]
tellraw @s ["",{"text":"  execute as @p at @s run function rpg:fx/dash {power:0.62,lift:0.42,ticks:11}","color":"light_purple"}]
tellraw @s ["",{"text":"     lift","color":"gold"},{"text":" 0 이면 직선 질주","color":"gray"}]
tellraw @s " "
tellraw @s ["",{"text":"  ⑦ 예제","color":"yellow","bold":true},{"text":"   rpg:fx/ex_slash · ex_stand · ex_dash","color":"green"}]
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}

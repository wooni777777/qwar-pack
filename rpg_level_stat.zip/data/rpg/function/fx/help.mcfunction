tellraw @s {"text":"━━━━━━━  이펙트 사용법  ━━━━━━━","color":"dark_gray"}
tellraw @s " "
tellraw @s ["",{"text":"  ① 먼저 이걸로 확인","color":"yellow","bold":true}]
tellraw @s ["",{"text":"  /function rpg:fx/demo","color":"green","bold":true},{"text":"   <- 인자 없음. 바로 보입니다","color":"gray"}]
tellraw @s " "
tellraw @s ["",{"text":"  ② 인자 없는 프리셋 24종","color":"yellow","bold":true},{"text":"   rpg:fx/<색>_<방향>","color":"gray"}]
tellraw @s ["",{"text":"  execute as @p at @s run function rpg:fx/red_h","color":"aqua"}]
tellraw @s ["",{"text":"     색   ","color":"gold"},{"text":"red · blue · gold · purple · green · white","color":"gray"}]
tellraw @s ["",{"text":"     방향 ","color":"gold"},{"text":"h 가로 · v 세로 · d 대각↘ · d2 대각↗","color":"gray"}]
tellraw @s " "
tellraw @s ["",{"text":"  ③ 직접 조절 — 인자를 하나라도 빼면 아무것도 안 나옵니다","color":"yellow","bold":true}]
tellraw @s ["",{"text":"  function rpg:fx/slash_dust {dir:\"h\",size:1.35,rad:1.7,h:1.15,spd:3,r1:1.0,g1:0.15,b1:0.15,r2:1.0,g2:0.85,b2:0.3}","color":"aqua"}]
tellraw @s ["",{"text":"  function rpg:fx/slash_hit {dir:\"v\",rad:1.8,h:1.2,spd:3}","color":"aqua"}]
tellraw @s ["",{"text":"  function rpg:fx/slash_wax {dir:\"d\",rad:1.7,h:1.2,spd:3}","color":"aqua"}]
tellraw @s ["",{"text":"  function rpg:fx/slash {p:\"minecraft:flame\",dir:\"d2\",rad:1.7,h:1.2,spd:3}","color":"aqua"}]
tellraw @s " "
tellraw @s ["",{"text":"  ④ 베는 속도 = spd","color":"yellow","bold":true},{"text":"   호 전체가 13조각, spd 는 1틱에 그리는 조각 수","color":"gray"}]
tellraw @s ["",{"text":"     spd:1","color":"gold"},{"text":" 13틱 0.65초 아주 느리게   ","color":"gray"},{"text":"spd:2","color":"gold"},{"text":" 7틱 0.35초 (추천)","color":"gray"}]
tellraw @s ["",{"text":"     spd:3","color":"gold"},{"text":" 5틱 0.25초 기본값        ","color":"gray"},{"text":"spd:13","color":"gold"},{"text":" 1틱 한 번에 전부","color":"gray"}]
tellraw @s " "
tellraw @s ["",{"text":"  ⑤ 돌진","color":"yellow","bold":true}]
tellraw @s ["",{"text":"  execute as @p at @s run function rpg:fx/dash {power:0.62,lift:0.42,ticks:11}","color":"light_purple"}]
tellraw @s ["",{"text":"     power","color":"gold"},{"text":" 0.4 약함 ~ 0.9 강함    ","color":"gray"},{"text":"lift","color":"gold"},{"text":" 0 이면 직선 질주    ","color":"gray"},{"text":"ticks","color":"gold"},{"text":" 11 ≈ 0.55초","color":"gray"}]
tellraw @s " "
tellraw @s ["",{"text":"  ⑥ 예제 (베기 + 피해)","color":"yellow","bold":true}]
tellraw @s ["",{"text":"  execute as @p at @s run function rpg:fx/ex_slash","color":"green"},{"text":"   베기 + 광역 피해","color":"gray"}]
tellraw @s ["",{"text":"  execute as @p at @s run function rpg:fx/ex_stand","color":"green"},{"text":"   아머스탠드가 대신 베기","color":"gray"}]
tellraw @s ["",{"text":"  execute as @p at @s run function rpg:fx/ex_dash","color":"green"},{"text":"    돌진 후 베기","color":"gray"}]
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}

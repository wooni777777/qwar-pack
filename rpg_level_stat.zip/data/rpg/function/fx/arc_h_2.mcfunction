$execute positioned ~ ~$(h) ~ rotated ~-40 0 positioned ^ ^ ^$(rad) run particle $(p) ~ ~ ~ 0 0 0 0 1 force @a
$execute positioned ~ ~$(h) ~ rotated ~-40 0 positioned ^ ^ ^$(rad) positioned ^ ^ ^-0.45 run particle $(p) ~ ~ ~ 0 0 0 0 1 force @a
$execute positioned ~ ~$(h) ~ rotated ~-40 0 positioned ^ ^ ^$(rad) positioned ^ ^ ^-0.9 run particle $(p) ~ ~ ~ 0 0 0 0 1 force @a

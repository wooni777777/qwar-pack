execute if score #dup rpg.sys matches ..0 run return 0
scoreboard players remove #dup rpg.sys 1
execute at @s if block ~ ~0.1 ~ #minecraft:replaceable if block ~ ~1.5 ~ #minecraft:replaceable run return 0
tp @s ~ ~1 ~
function rpg:fx/dash_unstuck

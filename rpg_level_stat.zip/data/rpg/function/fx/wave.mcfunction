# ── 원형 충격파 : 땅을 내려찍은 것처럼 원이 퍼져나간다 ──
#   execute as @p at @s run function rpg:fx/wave {p:"minecraft:flame",rad:8,spd:0.5,h:0.1,dense:24}
#   rad    어디까지 퍼질지 (칸)
#   spd    1틱에 퍼지는 거리 (0.5 = 1초에 10칸)
#   h      땅에서 띄울 높이 (칸)
#   dense  원 하나에 찍을 점 개수 (24 정도면 매끈)
$execute at @s run summon minecraft:marker ~ ~ ~ {Tags:["rpg_wave","rpg_wavN"],data:{p:"$(p)",rad:$(rad),spd:$(spd),h:$(h),dense:$(dense),r:0.0d}}
tag @e[tag=rpg_wavN] remove rpg_wavN
return 1

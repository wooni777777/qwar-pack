# ── 물 충격파 ──
#   function rpg:fx/wave_water {rad:8,spd:0.5,h:0.1,dense:24}
$function rpg:fx/wave {p:"minecraft:dripping_water",rad:$(rad),spd:$(spd),h:$(h),dense:$(dense)}
return 1

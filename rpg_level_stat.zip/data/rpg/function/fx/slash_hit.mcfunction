# ── 2. enchanted_hit ──
#   execute as @p at @s run function rpg:fx/slash_hit {dir:"v",rad:1.8,h:1.2,spd:3}
$data modify storage rpg:fx s set value {dir:"$(dir)",rad:$(rad),h:$(h),spd:$(spd),p:"minecraft:enchanted_hit"}
function rpg:fx/sl_run
return 1

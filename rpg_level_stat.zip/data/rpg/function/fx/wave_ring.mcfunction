execute if score #wn rpg.sys >= #wd rpg.sys run return 0
scoreboard players operation #wa rpg.sys = #wn rpg.sys
scoreboard players operation #wa rpg.sys *= #c360 rpg.sys
scoreboard players operation #wa rpg.sys /= #wd rpg.sys
execute store result storage rpg:fx w.a int 1 run scoreboard players get #wa rpg.sys
function rpg:fx/wave_pt with storage rpg:fx w
scoreboard players add #wn rpg.sys 1
function rpg:fx/wave_ring

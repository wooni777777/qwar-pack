# ── 검 베기 · 파티클 직접 지정 ──
#   execute as <시전자> at @s run function rpg:fx/slash {p:"minecraft:flame",dir:"h",rad:1.7,h:1.2,spd:3}
#   인자 5개를 전부 넣어야 합니다. 하나라도 빠지면 아무것도 안 나옵니다.
#     p   파티클 이름      dir  h 가로 / v 세로 / d 대각↘ / d2 대각↗
#     rad 반지름(칸)       h    발끝 기준 높이(칸)
#     spd 1틱에 그리는 조각 수 (전체 13조각) — 1 가장 느림(0.65초) ~ 13 즉시
$data modify storage rpg:fx s set value {dir:"$(dir)",rad:$(rad),h:$(h),spd:$(spd),p:"$(p)"}
function rpg:fx/sl_run
return 1

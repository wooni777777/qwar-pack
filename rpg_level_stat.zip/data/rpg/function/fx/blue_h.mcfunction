# blue h 베기 — 인자 없이 그냥 실행
function rpg:fx/slash_dust {dir:"h",size:1.35,rad:1.7,h:1.15,fwd:0,spd:3,rev:0,r1:0.35,g1:0.85,b1:1.00,r2:0.10,g2:0.25,b2:0.90}
return 1

# white d2 베기 — 인자 없이 그냥 실행
function rpg:fx/slash_dust {dir:"d2",size:1.35,rad:1.7,h:1.15,fwd:0,spd:3,rev:0,r1:1.00,g1:1.00,b1:1.00,r2:0.70,g2:0.75,b2:0.85}
return 1

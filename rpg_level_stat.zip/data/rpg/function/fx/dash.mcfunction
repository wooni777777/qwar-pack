# ── 돌진기 ──
#   execute as @p at @s run function rpg:fx/dash {power:0.62,lift:0.42,ticks:11}
#     power : 돌진 강도 (1틱당 전진 칸수. 크게 넣어도 0.35칸씩 잘라서 이동하므로 벽을 뚫지 않습니다)
#     lift  : 띄움 강도. 0 이면 위아래 움직임 없이 완전한 직선으로 돌진합니다
#     ticks : 지속 틱 (11 ≈ 0.55초)
$data modify storage rpg:dash in set value {p:$(power),l:$(lift),t:$(ticks)}
execute store result score #dp rpg.sys run data get storage rpg:dash in.p 1000
execute store result score #dl rpg.sys run data get storage rpg:dash in.l 1000
execute store result score #dt rpg.sys run data get storage rpg:dash in.t 1
execute if score #dt rpg.sys matches ..0 run scoreboard players set #dt rpg.sys 1
execute if score #dp rpg.sys matches ..0 run scoreboard players set #dp rpg.sys 100
scoreboard players operation @s rpg.dshp = #dp rpg.sys
scoreboard players operation @s rpg.dshv = #dl rpg.sys
scoreboard players operation @s rpg.dsh = #dt rpg.sys
scoreboard players set @s rpg.dshf 100
# lift 가 0 이면 직선 모드 (중력·수직 이동 없음)
scoreboard players set @s rpg.dshl 1
execute if score #dl rpg.sys matches 0 run scoreboard players set @s rpg.dshl 0
# 낙하 피해 면역 (착지하거나 5초 뒤 해제)
attribute @s minecraft:fall_damage_multiplier modifier remove rpg:dashfall
attribute @s minecraft:fall_damage_multiplier modifier add rpg:dashfall -1 add_multiplied_total
execute at @s run playsound minecraft:entity.player.attack.sweep player @a ~ ~ ~ 1 1.5
execute at @s anchored eyes run particle minecraft:sweep_attack ^ ^-0.3 ^1 0 0 0 0 1 normal @a
return run scoreboard players get @s rpg.dsh

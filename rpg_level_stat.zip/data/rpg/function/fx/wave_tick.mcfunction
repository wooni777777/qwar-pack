# 충격파 1틱 (내부용)
data modify storage rpg:fx w set from entity @s data
execute store result score #wr rpg.sys run data get storage rpg:fx w.r 100
execute store result score #wsp rpg.sys run data get storage rpg:fx w.spd 100
execute store result score #wrad rpg.sys run data get storage rpg:fx w.rad 100
execute if score #wsp rpg.sys matches ..0 run scoreboard players set #wsp rpg.sys 50
scoreboard players operation #wr rpg.sys += #wsp rpg.sys
execute if score #wr rpg.sys > #wrad rpg.sys run kill @s
execute if score #wr rpg.sys > #wrad rpg.sys run return 0
execute store result entity @s data.r double 0.01 run scoreboard players get #wr rpg.sys
execute store result storage rpg:fx w.r double 0.01 run scoreboard players get #wr rpg.sys
scoreboard players set #wd rpg.sys 24
execute store result score #wd rpg.sys run data get storage rpg:fx w.dense
execute if score #wd rpg.sys matches ..2 run scoreboard players set #wd rpg.sys 3
execute if score #wd rpg.sys matches 73.. run scoreboard players set #wd rpg.sys 72
scoreboard players set #wn rpg.sys 0
function rpg:fx/wave_ring

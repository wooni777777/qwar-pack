# ── 폭발 충격파 ──
#   function rpg:fx/wave_boom {rad:8,spd:0.5,h:0.1,dense:24}
$function rpg:fx/wave {p:"minecraft:explosion",rad:$(rad),spd:$(spd),h:$(h),dense:$(dense)}
return 1

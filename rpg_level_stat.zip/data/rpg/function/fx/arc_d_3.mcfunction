$execute positioned ~ ~$(h) ~ rotated ~-21 -21 positioned ^ ^ ^$(rad) run particle $(p) ~ ~ ~ 0 0 0 0 1 force @a
$execute positioned ~ ~$(h) ~ rotated ~-21 -21 positioned ^ ^ ^$(rad) positioned ^ ^ ^-0.45 run particle $(p) ~ ~ ~ 0 0 0 0 1 force @a
$execute positioned ~ ~$(h) ~ rotated ~-21 -21 positioned ^ ^ ^$(rad) positioned ^ ^ ^-0.9 run particle $(p) ~ ~ ~ 0 0 0 0 1 force @a

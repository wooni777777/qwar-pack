scoreboard players set @s rpg.dshf -1
attribute @s minecraft:fall_damage_multiplier modifier remove rpg:dashfall

# /function rpg:fx/demo  — 인자 없이 확인
execute as @s at @s run function rpg:fx/red_h
execute at @s run playsound minecraft:entity.player.attack.sweep player @a ~ ~ ~ 1 1.2
tellraw @s ["",{"text":"[FX] ","color":"aqua","bold":true},{"text":"붉은 가로 베기를 눈앞에 그렸습니다.","color":"white"}]
return 1

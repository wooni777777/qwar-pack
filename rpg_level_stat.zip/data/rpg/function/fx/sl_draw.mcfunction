$function rpg:fx/arc_$(dir)_$(i) with storage rpg:fx s

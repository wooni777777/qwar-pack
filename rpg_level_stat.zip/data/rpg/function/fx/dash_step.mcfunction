# 0.35칸 전진 (앞이 막혀 있으면 그 자리에서 멈춘다)
scoreboard players set #dok rpg.sys 1
execute at @s rotated ~ 0 positioned ^ ^ ^0.35 unless block ~ ~0.1 ~ #minecraft:replaceable run scoreboard players set #dok rpg.sys 0
execute at @s rotated ~ 0 positioned ^ ^ ^0.35 unless block ~ ~1.5 ~ #minecraft:replaceable run scoreboard players set #dok rpg.sys 0
execute if score #dok rpg.sys matches 1 at @s rotated ~ 0 positioned ^ ^ ^0.35 run tp @s ~ ~ ~
execute if score #dok rpg.sys matches 0 run scoreboard players set #dn rpg.sys 0
execute if score #dok rpg.sys matches 0 run scoreboard players set @s rpg.dsh 0
execute if score #dok rpg.sys matches 0 at @s run playsound minecraft:entity.zombie.attack_iron_door player @a ~ ~ ~ 0.6 1.8
scoreboard players remove #dn rpg.sys 1
execute if score #dn rpg.sys matches 1.. run function rpg:fx/dash_step

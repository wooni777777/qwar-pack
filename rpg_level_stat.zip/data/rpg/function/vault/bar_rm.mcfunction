execute if block ~ ~ ~ minecraft:barrel run setblock ~ ~ ~ minecraft:air
kill @s

# 눈앞 한 칸에 개인 창고 통을 놓는다 (다른 사람 통은 절대 건드리지 않는다)
function rpg:vault/pid
scoreboard players operation #mypid rpg.sys = @s rpg.pid
execute as @e[tag=rpg_vbar] if score @s rpg.pid = #mypid rpg.sys at @s run function rpg:vault/bar_tick
execute as @e[tag=rpg_vbar] if score @s rpg.pid = #mypid rpg.sys at @s run function rpg:vault/bar_rm
execute at @s rotated ~ 0 positioned ^ ^ ^1.4 align xyz if block ~ ~ ~ #minecraft:replaceable run function rpg:vault/place
execute at @s rotated ~ 0 positioned ^ ^ ^1.4 align xyz unless block ~ ~ ~ #minecraft:replaceable run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"눈앞이 막혀 있습니다. 열린 곳에서 여세요.","color":"red"}]

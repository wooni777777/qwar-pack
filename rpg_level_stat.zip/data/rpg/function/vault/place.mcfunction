setblock ~ ~ ~ minecraft:barrel[facing=up]
data merge block ~ ~ ~ {CustomName:{"text":"창고","color":"aqua","bold":true}}
execute store result storage rpg:tmp k.p int 1 run scoreboard players get @s rpg.pid
function rpg:vault/fill with storage rpg:tmp k
summon minecraft:marker ~ ~ ~ {Tags:["rpg_vbar","rpg_vnew"]}
scoreboard players operation @e[tag=rpg_vnew] rpg.pid = @s rpg.pid
tag @e[tag=rpg_vnew] remove rpg_vnew
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"눈앞에 창고를 열었습니다. 다 쓰면 [창고 닫기] 를 누르세요.","color":"aqua"}]
playsound minecraft:block.barrel.open player @s ~ ~ ~ 1 1.2

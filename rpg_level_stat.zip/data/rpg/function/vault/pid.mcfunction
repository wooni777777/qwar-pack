# 플레이어 고유번호 배정 (창고 저장 키)
execute unless score @s rpg.pid matches 1.. run scoreboard players add #pid_next rpg.sys 1
execute unless score @s rpg.pid matches 1.. run scoreboard players operation @s rpg.pid = #pid_next rpg.sys

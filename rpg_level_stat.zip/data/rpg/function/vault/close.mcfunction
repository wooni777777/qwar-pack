function rpg:vault/pid
scoreboard players operation #mypid rpg.sys = @s rpg.pid
scoreboard players set #vfound rpg.sys 0
execute as @e[tag=rpg_vbar] if score @s rpg.pid = #mypid rpg.sys run scoreboard players set #vfound rpg.sys 1
execute if score #vfound rpg.sys matches 0 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"열려 있는 창고가 없습니다.","color":"red"}]
execute if score #vfound rpg.sys matches 0 run return 0
execute as @e[tag=rpg_vbar] if score @s rpg.pid = #mypid rpg.sys at @s run function rpg:vault/bar_tick
execute as @e[tag=rpg_vbar] if score @s rpg.pid = #mypid rpg.sys at @s run function rpg:vault/bar_rm
playsound minecraft:block.barrel.close player @s ~ ~ ~ 1 1.2

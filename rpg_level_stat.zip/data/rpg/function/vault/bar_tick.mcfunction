# 창고 통 : 내용 저장 + 아무도 없으면 정리
execute store result storage rpg:tmp k.p int 1 run scoreboard players get @s rpg.pid
execute if block ~ ~ ~ minecraft:barrel run function rpg:vault/bar_save with storage rpg:tmp k
execute unless entity @a[distance=..9] run function rpg:vault/bar_rm
execute unless block ~ ~ ~ minecraft:barrel run kill @s

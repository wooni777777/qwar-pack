scoreboard players enable @s rpg.menu
scoreboard players enable @s rpg.vlt
playsound minecraft:item.book.page_turn player @s ~ ~ ~ 1 1.2
tellraw @s " "
tellraw @s {"text": "━━━━━━━━━  창  고  ━━━━━━━━━", "color": "dark_gray"}
tellraw @s ["", {"text": "   눈앞에 창고 통이 생깁니다. 우클릭해서 여세요.", "color": "gray"}]
tellraw @s ["", {"text": "   내용물은 서버에 저장되어 죽어도 사라지지 않습니다.", "color": "dark_gray"}]
tellraw @s ["", {"text": "   창고 안에 넣어 둔 돈은 죽어도 떨어지지 않습니다.", "color": "green"}]
tellraw @s " "
tellraw @s ["", {"text": "   "}, {"text": "[ 창고 열기 ]", "color": "aqua", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.vlt set 1"}}, {"text": "    "}, {"text": "[ 창고 닫기 ]", "color": "gold", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.vlt set 2"}, "hover_event": {"action": "show_text", "value": {"text": "저장하고 통을 치웁니다", "color": "gray"}}}]
tellraw @s {"text": "━━━━━━━━━━━━━━━━━━━━━━━━━━", "color": "dark_gray"}

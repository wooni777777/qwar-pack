$data modify storage rpg:vault v.p$(p) set from block ~ ~ ~ Items

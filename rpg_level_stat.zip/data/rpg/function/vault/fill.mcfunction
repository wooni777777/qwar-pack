$execute if data storage rpg:vault v.p$(p) run data modify block ~ ~ ~ Items set from storage rpg:vault v.p$(p)

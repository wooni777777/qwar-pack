execute if score @s rpg.vlt matches 1 at @s run function rpg:vault/open
execute if score @s rpg.vlt matches 2 at @s run function rpg:vault/close
scoreboard players set @s rpg.vlt 0
scoreboard players enable @s rpg.vlt

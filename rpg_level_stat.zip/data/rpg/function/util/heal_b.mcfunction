$effect give @s minecraft:instant_health 1 $(a) true
$scoreboard players remove @s rpg.hq $(v)

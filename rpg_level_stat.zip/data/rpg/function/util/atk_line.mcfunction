# 손에 든 아이템의 【공격력】 줄 번호를 직접 지정한다
#   function rpg:util/atk_line {i:4}
data modify storage rpg:util it set from entity @s SelectedItem
$data modify storage rpg:util it.components."minecraft:custom_data".atki set value $(i)
data modify storage rpg:enh it set from storage rpg:util it
function rpg:enh/put
$tellraw @s [{"text":"[설정] ","color":"gray"},{"text":"【공격력】 줄을 ","color":"red"},{"text":"$(i)","color":"white","bold":true},{"text":" 번으로 지정했습니다.","color":"red"}]
return 1

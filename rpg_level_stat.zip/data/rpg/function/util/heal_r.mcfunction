# 남은 1 ~ 3 회복 : 재생 VI (1틱에 1) (v47 · 내부용 · as 플레이어 · 매 틱)
#   다른 재생 효과(포션 · 황금사과)가 걸려 있으면 그걸 지우지 않게 즉시회복 덩어리로 돌림
execute if entity @s[tag=!rpg_rgn] if predicate rpg:regen_other run return run function rpg:util/heal_rfb
execute unless score @s rpg.hp matches 1.. run return run scoreboard players set @s rpg.hr1 0
tag @s add rpg_rgn
effect give @s minecraft:regeneration infinite 5 true
scoreboard players remove @s rpg.hr1 1

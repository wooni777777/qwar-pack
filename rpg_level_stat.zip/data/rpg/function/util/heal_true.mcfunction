function rpg:util/heal

# 쌓인 회복을 이번 틱에 한 덩어리 (v41 · 내부용)
execute if score @s rpg.hqt = #gtick rpg.sys run return 0
scoreboard players operation @s rpg.hqt = #gtick rpg.sys
execute if score @s rpg.hq matches 128.. run return run function rpg:util/heal_b {a:7,v:128}
execute if score @s rpg.hq matches 64.. run return run function rpg:util/heal_b {a:6,v:64}
execute if score @s rpg.hq matches 32.. run return run function rpg:util/heal_b {a:5,v:32}
execute if score @s rpg.hq matches 16.. run return run function rpg:util/heal_b {a:4,v:16}
execute if score @s rpg.hq matches 8.. run return run function rpg:util/heal_b {a:3,v:8}
execute if score @s rpg.hq matches 4.. run return run function rpg:util/heal_b {a:2,v:4}
execute if score @s rpg.hq matches 2.. run return run function rpg:util/heal_b {a:1,v:2}
execute if score @s rpg.hq matches 1.. run return run function rpg:util/heal_b {a:0,v:1}

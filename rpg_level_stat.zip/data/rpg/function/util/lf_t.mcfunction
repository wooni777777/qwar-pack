# (v43 · 내부용) 한 줄(ln)이 찾는 줄인지 -> #lf 1
#   글자 조각을 s 에 잘라 넣고 { s:"..." } 로 비교 (글자가 아니면 잘라지지 않아 s 가 없음 = 아님)
data remove storage rpg:lf s
data modify storage rpg:lf s set string storage rpg:lf ln 0 5
execute if score #lfm rpg.sys matches 1 if data storage rpg:lf {s:"【공격력】"} run scoreboard players set #lf rpg.sys 1
execute if score #lfm rpg.sys matches 2 if data storage rpg:lf {s:"【방어력】"} run scoreboard players set #lf rpg.sys 1
execute if score #lf rpg.sys matches 1 run return 1
data remove storage rpg:lf s
data modify storage rpg:lf s set string storage rpg:lf ln 0 4
execute if score #lfm rpg.sys matches 2 if data storage rpg:lf {s:"방어력 "} run scoreboard players set #lf rpg.sys 1
execute if score #lf rpg.sys matches 1 run return 1
data remove storage rpg:lf s
data modify storage rpg:lf s set string storage rpg:lf ln.text 0 5
execute if score #lfm rpg.sys matches 1 if data storage rpg:lf {s:"【공격력】"} run scoreboard players set #lf rpg.sys 1
execute if score #lfm rpg.sys matches 2 if data storage rpg:lf {s:"【방어력】"} run scoreboard players set #lf rpg.sys 1
execute if score #lf rpg.sys matches 1 run return 1
data remove storage rpg:lf s
data modify storage rpg:lf s set string storage rpg:lf ln.text 0 4
execute if score #lfm rpg.sys matches 2 if data storage rpg:lf {s:"방어력 "} run scoreboard players set #lf rpg.sys 1
execute if score #lf rpg.sys matches 1 run return 1
data remove storage rpg:lf s
data modify storage rpg:lf s set string storage rpg:lf ln.extra[0] 0 5
execute if score #lfm rpg.sys matches 1 if data storage rpg:lf {s:"【공격력】"} run scoreboard players set #lf rpg.sys 1
execute if score #lfm rpg.sys matches 2 if data storage rpg:lf {s:"【방어력】"} run scoreboard players set #lf rpg.sys 1
execute if score #lf rpg.sys matches 1 run return 1
data remove storage rpg:lf s
data modify storage rpg:lf s set string storage rpg:lf ln.extra[0] 0 4
execute if score #lfm rpg.sys matches 2 if data storage rpg:lf {s:"방어력 "} run scoreboard players set #lf rpg.sys 1
execute if score #lf rpg.sys matches 1 run return 1
data remove storage rpg:lf s
data modify storage rpg:lf s set string storage rpg:lf ln.extra[0].text 0 5
execute if score #lfm rpg.sys matches 1 if data storage rpg:lf {s:"【공격력】"} run scoreboard players set #lf rpg.sys 1
execute if score #lfm rpg.sys matches 2 if data storage rpg:lf {s:"【방어력】"} run scoreboard players set #lf rpg.sys 1
execute if score #lf rpg.sys matches 1 run return 1
data remove storage rpg:lf s
data modify storage rpg:lf s set string storage rpg:lf ln.extra[0].text 0 4
execute if score #lfm rpg.sys matches 2 if data storage rpg:lf {s:"방어력 "} run scoreboard players set #lf rpg.sys 1
execute if score #lf rpg.sys matches 1 run return 1
data remove storage rpg:lf s
data modify storage rpg:lf s set string storage rpg:lf ln.extra[1] 0 5
execute if score #lfm rpg.sys matches 1 if data storage rpg:lf {s:"【공격력】"} run scoreboard players set #lf rpg.sys 1
execute if score #lfm rpg.sys matches 2 if data storage rpg:lf {s:"【방어력】"} run scoreboard players set #lf rpg.sys 1
execute if score #lf rpg.sys matches 1 run return 1
data remove storage rpg:lf s
data modify storage rpg:lf s set string storage rpg:lf ln.extra[1] 0 4
execute if score #lfm rpg.sys matches 2 if data storage rpg:lf {s:"방어력 "} run scoreboard players set #lf rpg.sys 1
execute if score #lf rpg.sys matches 1 run return 1
data remove storage rpg:lf s
data modify storage rpg:lf s set string storage rpg:lf ln.extra[1].text 0 5
execute if score #lfm rpg.sys matches 1 if data storage rpg:lf {s:"【공격력】"} run scoreboard players set #lf rpg.sys 1
execute if score #lfm rpg.sys matches 2 if data storage rpg:lf {s:"【방어력】"} run scoreboard players set #lf rpg.sys 1
execute if score #lf rpg.sys matches 1 run return 1
data remove storage rpg:lf s
data modify storage rpg:lf s set string storage rpg:lf ln.extra[1].text 0 4
execute if score #lfm rpg.sys matches 2 if data storage rpg:lf {s:"방어력 "} run scoreboard players set #lf rpg.sys 1
execute if score #lf rpg.sys matches 1 run return 1

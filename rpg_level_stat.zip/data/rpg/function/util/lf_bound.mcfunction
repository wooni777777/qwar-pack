# (v43 · 내부용) #alx 가 부설명 줄 수를 넘으면 -1 (새 줄을 덧붙이게)
scoreboard players set #lfn rpg.sys 0
execute store result score #lfn rpg.sys run data get storage rpg:lf L
execute if score #alx rpg.sys >= #lfn rpg.sys run scoreboard players set #alx rpg.sys -1
execute if score #alx rpg.sys matches ..-2 run scoreboard players set #alx rpg.sys -1

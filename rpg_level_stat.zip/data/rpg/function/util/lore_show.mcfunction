# 손에 든 아이템의 부설명을 번호와 함께 보여준다
data modify storage rpg:util it set from entity @s SelectedItem
tellraw @s {"text":"━━━━━━  부설명 줄 번호  ━━━━━━","color":"dark_gray"}
execute unless data storage rpg:util it.components."minecraft:lore"[0] run tellraw @s {"text":"  부설명이 없습니다.","color":"red"}
execute if data storage rpg:util it.components."minecraft:lore"[0] run tellraw @s ["",{"text":"  [0]  ","color":"gold"},{"nbt":"it.components.\"minecraft:lore\"[0]","storage":"rpg:util","interpret":true}]
execute if data storage rpg:util it.components."minecraft:lore"[1] run tellraw @s ["",{"text":"  [1]  ","color":"gold"},{"nbt":"it.components.\"minecraft:lore\"[1]","storage":"rpg:util","interpret":true}]
execute if data storage rpg:util it.components."minecraft:lore"[2] run tellraw @s ["",{"text":"  [2]  ","color":"gold"},{"nbt":"it.components.\"minecraft:lore\"[2]","storage":"rpg:util","interpret":true}]
execute if data storage rpg:util it.components."minecraft:lore"[3] run tellraw @s ["",{"text":"  [3]  ","color":"gold"},{"nbt":"it.components.\"minecraft:lore\"[3]","storage":"rpg:util","interpret":true}]
execute if data storage rpg:util it.components."minecraft:lore"[4] run tellraw @s ["",{"text":"  [4]  ","color":"gold"},{"nbt":"it.components.\"minecraft:lore\"[4]","storage":"rpg:util","interpret":true}]
execute if data storage rpg:util it.components."minecraft:lore"[5] run tellraw @s ["",{"text":"  [5]  ","color":"gold"},{"nbt":"it.components.\"minecraft:lore\"[5]","storage":"rpg:util","interpret":true}]
execute if data storage rpg:util it.components."minecraft:lore"[6] run tellraw @s ["",{"text":"  [6]  ","color":"gold"},{"nbt":"it.components.\"minecraft:lore\"[6]","storage":"rpg:util","interpret":true}]
execute if data storage rpg:util it.components."minecraft:lore"[7] run tellraw @s ["",{"text":"  [7]  ","color":"gold"},{"nbt":"it.components.\"minecraft:lore\"[7]","storage":"rpg:util","interpret":true}]
execute if data storage rpg:util it.components."minecraft:lore"[8] run tellraw @s ["",{"text":"  [8]  ","color":"gold"},{"nbt":"it.components.\"minecraft:lore\"[8]","storage":"rpg:util","interpret":true}]
execute if data storage rpg:util it.components."minecraft:lore"[9] run tellraw @s ["",{"text":"  [9]  ","color":"gold"},{"nbt":"it.components.\"minecraft:lore\"[9]","storage":"rpg:util","interpret":true}]
execute if data storage rpg:util it.components."minecraft:lore"[10] run tellraw @s ["",{"text":"  [10]  ","color":"gold"},{"nbt":"it.components.\"minecraft:lore\"[10]","storage":"rpg:util","interpret":true}]
execute if data storage rpg:util it.components."minecraft:lore"[11] run tellraw @s ["",{"text":"  [11]  ","color":"gold"},{"nbt":"it.components.\"minecraft:lore\"[11]","storage":"rpg:util","interpret":true}]
execute if data storage rpg:util it.components."minecraft:lore"[12] run tellraw @s ["",{"text":"  [12]  ","color":"gold"},{"nbt":"it.components.\"minecraft:lore\"[12]","storage":"rpg:util","interpret":true}]
execute if data storage rpg:util it.components."minecraft:lore"[13] run tellraw @s ["",{"text":"  [13]  ","color":"gold"},{"nbt":"it.components.\"minecraft:lore\"[13]","storage":"rpg:util","interpret":true}]
execute if data storage rpg:util it.components."minecraft:lore"[14] run tellraw @s ["",{"text":"  [14]  ","color":"gold"},{"nbt":"it.components.\"minecraft:lore\"[14]","storage":"rpg:util","interpret":true}]
execute if data storage rpg:util it.components."minecraft:lore"[15] run tellraw @s ["",{"text":"  [15]  ","color":"gold"},{"nbt":"it.components.\"minecraft:lore\"[15]","storage":"rpg:util","interpret":true}]
execute if data storage rpg:util it.components."minecraft:custom_data".atki run tellraw @s ["",{"text":"  현재 지정된 【공격력】 줄 : ","color":"gray"},{"nbt":"it.components.\"minecraft:custom_data\".atki","storage":"rpg:util","color":"red"}]
execute if data storage rpg:util it.components."minecraft:custom_data".defi run tellraw @s ["",{"text":"  현재 지정된 【방어력】 줄 : ","color":"gray"},{"nbt":"it.components.\"minecraft:custom_data\".defi","storage":"rpg:util","color":"aqua"}]
tellraw @s ["",{"text":"  지정 ","color":"gray"},{"text":"function rpg:util/atk_line {i:4}","color":"aqua"},{"text":"  또는  ","color":"gray"},{"text":"function rpg:util/def_line {i:4}","color":"aqua"}]
tellraw @s {"text":"━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}

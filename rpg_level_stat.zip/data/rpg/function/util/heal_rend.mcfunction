# 1 단위 회복 끝 (v47 · 내부용) — 우리가 건 재생만 지움
tag @s remove rpg_rgn
effect clear @s minecraft:regeneration

# (v43 · 내부용) W 맨 앞 줄을 검사하고 하나씩 넘긴다
data remove storage rpg:lf ln
data modify storage rpg:lf ln set from storage rpg:lf W[0]
scoreboard players set #lf rpg.sys 0
function rpg:util/lf_t
execute if score #lf rpg.sys matches 1 run return run scoreboard players operation #alx rpg.sys = #lfk rpg.sys
data remove storage rpg:lf W[0]
scoreboard players add #lfk rpg.sys 1
execute if score #lfk rpg.sys matches ..63 if data storage rpg:lf W[0] run function rpg:util/lf_loop

# 손에 든 아이템의 【방어력】 줄 번호를 직접 지정한다
#   function rpg:util/def_line {i:4}
data modify storage rpg:util it set from entity @s SelectedItem
$data modify storage rpg:util it.components."minecraft:custom_data".defi set value $(i)
data modify storage rpg:enh it set from storage rpg:util it
function rpg:enh/put
$tellraw @s [{"text":"[설정] ","color":"gray"},{"text":"【방어력】 줄을 ","color":"aqua"},{"text":"$(i)","color":"white","bold":true},{"text":" 번으로 지정했습니다.","color":"aqua"}]
return 1

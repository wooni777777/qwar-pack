# 부설명(lore)에서 【공격력】 / 【방어력】 줄 찾기 (v43 · 내부용)
#   넣기 : storage rpg:lf L = 부설명 목록 · #lfm 1 = 공격력 / 2 = 방어력
#   결과 : #alx = 줄 번호 (0부터) · 못 찾으면 -1
#   줄 통째 글자 · text · extra[0] · extra[1] 어디에 있든 앞 글자로 찾습니다 (띄어쓰기 · 숫자 상관없음)
scoreboard players set #alx rpg.sys -1
scoreboard players set #lfk rpg.sys 0
data remove storage rpg:lf W
data modify storage rpg:lf W set from storage rpg:lf L
execute if data storage rpg:lf W[0] run function rpg:util/lf_loop
data remove storage rpg:lf W
data remove storage rpg:lf ln
data remove storage rpg:lf s

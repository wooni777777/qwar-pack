# (v47 · 내부용) 다른 재생 효과가 있어 1 단위 회복을 못 할 때 -> 4 단위 한 덩어리로
scoreboard players set @s rpg.hr1 0
scoreboard players add @s rpg.hq 1

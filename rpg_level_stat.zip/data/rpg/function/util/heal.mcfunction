# #heal rpg.sys 만큼 회복 (v41)
#  마인크래프트 즉시회복은 4 단위(4 x 2^단계)로만 회복되고, 같은 틱에 여러 번 주면 가장 큰 것 하나만 먹힙니다.
#  그래서 4 단위로 올림한 양을 rpg.hq 에 쌓아 두고, 한 틱에 한 덩어리씩 줍니다 (150 회복 = 128 + 16 + 8 -> 3틱).
scoreboard players operation #hq rpg.sys = #heal rpg.sys
scoreboard players add #hq rpg.sys 3
scoreboard players operation #hq rpg.sys /= #c4 rpg.sys
execute if score #hq rpg.sys matches ..0 run return 0
scoreboard players operation @s rpg.hq += #hq rpg.sys
execute if score @s rpg.hq matches 256.. run scoreboard players set @s rpg.hq 255
function rpg:util/heal_step

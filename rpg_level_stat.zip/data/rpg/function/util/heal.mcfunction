# #heal rpg.sys 만큼 회복 (v47 : 정확히 그만큼)
#  즉시회복은 4 단위(4 x 2^단계)로만 차서, 4 단위 덩어리는 즉시회복(rpg.hq · 한 틱에 한 덩어리)으로,
#  남는 1 ~ 3 은 재생 효과로 1틱에 1씩 채웁니다 (rpg.hr1) -> 예전처럼 "4 가 될 때까지 안 차다가 한 번에 4" 가 없습니다.
execute if score #heal rpg.sys matches ..0 run return 0
scoreboard players operation #hq rpg.sys = #heal rpg.sys
scoreboard players operation #hq rpg.sys /= #c4 rpg.sys
scoreboard players operation #hr rpg.sys = #heal rpg.sys
scoreboard players operation #hr rpg.sys %= #c4 rpg.sys
scoreboard players operation @s rpg.hq += #hq rpg.sys
execute if score @s rpg.hq matches 4096.. run scoreboard players set @s rpg.hq 4095
scoreboard players operation @s rpg.hr1 += #hr rpg.sys
execute if score @s rpg.hq matches 1.. run function rpg:util/heal_step

# #heal rpg.sys 만큼 회복 (즉각회복 이진 분해, 4 단위 정확도)
scoreboard players operation #hq rpg.sys = #heal rpg.sys
scoreboard players operation #hq rpg.sys /= #c4 rpg.sys
execute if score #hq rpg.sys matches 256.. run scoreboard players set #hq rpg.sys 255
scoreboard players operation #hm rpg.sys = #hq rpg.sys
scoreboard players operation #hm rpg.sys /= #b0 rpg.sys
scoreboard players operation #hm rpg.sys %= #c2 rpg.sys
execute if score #hm rpg.sys matches 1 run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation #hm rpg.sys = #hq rpg.sys
scoreboard players operation #hm rpg.sys /= #b1 rpg.sys
scoreboard players operation #hm rpg.sys %= #c2 rpg.sys
execute if score #hm rpg.sys matches 1 run effect give @s minecraft:instant_health 1 1 true
scoreboard players operation #hm rpg.sys = #hq rpg.sys
scoreboard players operation #hm rpg.sys /= #b2 rpg.sys
scoreboard players operation #hm rpg.sys %= #c2 rpg.sys
execute if score #hm rpg.sys matches 1 run effect give @s minecraft:instant_health 1 2 true
scoreboard players operation #hm rpg.sys = #hq rpg.sys
scoreboard players operation #hm rpg.sys /= #b3 rpg.sys
scoreboard players operation #hm rpg.sys %= #c2 rpg.sys
execute if score #hm rpg.sys matches 1 run effect give @s minecraft:instant_health 1 3 true
scoreboard players operation #hm rpg.sys = #hq rpg.sys
scoreboard players operation #hm rpg.sys /= #b4 rpg.sys
scoreboard players operation #hm rpg.sys %= #c2 rpg.sys
execute if score #hm rpg.sys matches 1 run effect give @s minecraft:instant_health 1 4 true
scoreboard players operation #hm rpg.sys = #hq rpg.sys
scoreboard players operation #hm rpg.sys /= #b5 rpg.sys
scoreboard players operation #hm rpg.sys %= #c2 rpg.sys
execute if score #hm rpg.sys matches 1 run effect give @s minecraft:instant_health 1 5 true
scoreboard players operation #hm rpg.sys = #hq rpg.sys
scoreboard players operation #hm rpg.sys /= #b6 rpg.sys
scoreboard players operation #hm rpg.sys %= #c2 rpg.sys
execute if score #hm rpg.sys matches 1 run effect give @s minecraft:instant_health 1 6 true
scoreboard players operation #hm rpg.sys = #hq rpg.sys
scoreboard players operation #hm rpg.sys /= #b7 rpg.sys
scoreboard players operation #hm rpg.sys %= #c2 rpg.sys
execute if score #hm rpg.sys matches 1 run effect give @s minecraft:instant_health 1 7 true

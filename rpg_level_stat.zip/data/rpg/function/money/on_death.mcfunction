# ── 죽으면 (소지금 + 인벤 수표) 의 10% 를 봉투로 떨어뜨린다 ──
# 인벤에 넣어둔 수표도 합산되므로 "인벤에 빼두고 죽기" 꼼수가 막힙니다
# (창고 안에 넣어 둔 돈은 합산되지 않습니다)
scoreboard players operation #tot rpg.sys = @s money
scoreboard players operation #tot rpg.sys += @s rpg.bills
execute if score #tot rpg.sys matches ..9 run return 0
# 인벤에 있던 수표는 소지금으로 흡수 (드랍된 수표 제거)
kill @e[type=minecraft:item,distance=..8,nbt={Item:{components:{"minecraft:custom_data":{rpg_bill:1}}}}]
kill @e[type=minecraft:item,distance=..8,nbt={Item:{components:{"minecraft:custom_data":{rpg_bill:2}}}}]
kill @e[type=minecraft:item,distance=..8,nbt={Item:{components:{"minecraft:custom_data":{rpg_bill:3}}}}]
kill @e[type=minecraft:item,distance=..8,nbt={Item:{components:{"minecraft:custom_data":{rpg_bill:4}}}}]
kill @e[type=minecraft:item,distance=..8,nbt={Item:{components:{"minecraft:custom_data":{rpg_bill:5}}}}]
kill @e[type=minecraft:item,distance=..8,nbt={Item:{components:{"minecraft:custom_data":{rpg_bill:6}}}}]
kill @e[type=minecraft:item,distance=..8,nbt={Item:{components:{"minecraft:custom_data":{rpg_bill:7}}}}]
kill @e[type=minecraft:item,distance=..8,nbt={Item:{components:{"minecraft:custom_data":{rpg_bill:8}}}}]
scoreboard players set @s rpg.bills 0
# 10% 계산
scoreboard players operation #cut rpg.sys = #tot rpg.sys
scoreboard players operation #cut rpg.sys /= #c10 rpg.sys
scoreboard players operation @s money = #tot rpg.sys
scoreboard players operation @s money -= #cut rpg.sys
# 봉투 생성
data modify storage rpg:tmp pouch set value {}
data modify storage rpg:tmp pouch.u set from entity @s UUID
function rpg:vault/pid
data modify storage rpg:tmp pouch.n set value "플레이어"
execute store result storage rpg:tmp pouch.p int 1 run scoreboard players get @s rpg.pid
function rpg:money/pouch_name with storage rpg:tmp pouch
scoreboard players set #psz rpg.sys 1
execute if score #cut rpg.sys matches 500.. run scoreboard players set #psz rpg.sys 2
execute if score #cut rpg.sys matches 50000.. run scoreboard players set #psz rpg.sys 3
execute if score #cut rpg.sys matches 5000000.. run scoreboard players set #psz rpg.sys 4
execute store result storage rpg:tmp pouch.sz int 1 run scoreboard players get #psz rpg.sys
execute store result storage rpg:tmp pouch.amt int 1 run scoreboard players get #cut rpg.sys
function rpg:money/pouch with storage rpg:tmp pouch
tellraw @s [{"text": "[q후계자 전쟁] ", "color": "gray"}, {"text": "죽어서 소지금의 10% (", "color": "red"}, {"color": "gold", "score": {"name": "#cut", "objective": "rpg.sys"}}, {"text": "원) 을 떨어뜨렸습니다.", "color": "red"}]

data modify storage rpg:tmp p set from entity @s Inventory[{components:{"minecraft:custom_data":{rpg_pouch:1}}}].components."minecraft:custom_data"
execute unless data storage rpg:tmp p run return 0
function rpg:money/pouch_add with storage rpg:tmp p
clear @s *[minecraft:custom_data~{rpg_pouch:1}] 1
execute at @s run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 1 1.6
execute if items entity @s container.* *[minecraft:custom_data~{rpg_pouch:1}] run function rpg:money/pouch_claim

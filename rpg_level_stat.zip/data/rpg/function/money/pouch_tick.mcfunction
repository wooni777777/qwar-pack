# 봉투를 주우면 소지금으로 전환
execute as @a if items entity @s container.* *[minecraft:custom_data~{rpg_pouch:1}] run function rpg:money/pouch_claim

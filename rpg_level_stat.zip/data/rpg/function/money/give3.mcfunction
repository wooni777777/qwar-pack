scoreboard players remove @s money 100
give @s paper[minecraft:custom_data={rpg_bill:100},minecraft:item_model="rpg:bill_3",minecraft:item_name={"text":"100원","color":"green","bold":true},minecraft:lore=[{"text":"q후계자 전쟁 수표","color":"dark_gray","italic":false},{"text":"우클릭하면 소지금으로 들어갑니다","color":"gray","italic":false}],minecraft:consumable={consume_seconds:0.25f,animation:"none",sound:"minecraft:item.book.page_turn",has_consume_particles:false}] 1
execute at @s run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 1 1.4

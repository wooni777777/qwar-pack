execute unless score @s money matches -2147483648.. run scoreboard players set @s money 0

scoreboard players set #ok rpg.sys 0
execute if score @s rpg.chk matches 1 if score @s money matches 1.. run function rpg:money/give1
execute if score @s rpg.chk matches 1 if score @s money matches 1.. run scoreboard players set #ok rpg.sys 1
execute if score @s rpg.chk matches 2 if score @s money matches 10.. run function rpg:money/give2
execute if score @s rpg.chk matches 2 if score @s money matches 10.. run scoreboard players set #ok rpg.sys 1
execute if score @s rpg.chk matches 3 if score @s money matches 100.. run function rpg:money/give3
execute if score @s rpg.chk matches 3 if score @s money matches 100.. run scoreboard players set #ok rpg.sys 1
execute if score @s rpg.chk matches 4 if score @s money matches 1000.. run function rpg:money/give4
execute if score @s rpg.chk matches 4 if score @s money matches 1000.. run scoreboard players set #ok rpg.sys 1
execute if score @s rpg.chk matches 5 if score @s money matches 10000.. run function rpg:money/give5
execute if score @s rpg.chk matches 5 if score @s money matches 10000.. run scoreboard players set #ok rpg.sys 1
execute if score @s rpg.chk matches 6 if score @s money matches 100000.. run function rpg:money/give6
execute if score @s rpg.chk matches 6 if score @s money matches 100000.. run scoreboard players set #ok rpg.sys 1
execute if score @s rpg.chk matches 7 if score @s money matches 1000000.. run function rpg:money/give7
execute if score @s rpg.chk matches 7 if score @s money matches 1000000.. run scoreboard players set #ok rpg.sys 1
execute if score @s rpg.chk matches 8 if score @s money matches 10000000.. run function rpg:money/give8
execute if score @s rpg.chk matches 8 if score @s money matches 10000000.. run scoreboard players set #ok rpg.sys 1
execute if score #ok rpg.sys matches 0 run tellraw @s ["", {"text":"[q후계자 전쟁] ","color":"gray"}, {"text": "돈이 부족합니다.", "color": "red"}]
execute if score #ok rpg.sys matches 0 at @s run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 1 0.6
scoreboard players set @s rpg.chk 0
scoreboard players enable @s rpg.chk

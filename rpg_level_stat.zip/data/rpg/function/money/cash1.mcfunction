advancement revoke @s only rpg:money/cash1
scoreboard players add @s money 1
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"1원","color":"gold"},{"text":"을 얻었습니다","color":"white"},{"text":"  (총 소지금: ","color":"gray"},{"score":{"name":"@s","objective":"money"},"color":"gray"},{"text":")","color":"gray"}]
execute at @s run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 1 1.6

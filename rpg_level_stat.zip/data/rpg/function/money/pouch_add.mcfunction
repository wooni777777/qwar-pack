$scoreboard players add @s money $(amt)
$tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"$(amt)원","color":"gold"},{"text":"을 얻었습니다","color":"white"},{"text":"  (총 소지금: ","color":"gray"},{"score":{"name":"@s","objective":"money"},"color":"gray"},{"text":")","color":"gray"}]

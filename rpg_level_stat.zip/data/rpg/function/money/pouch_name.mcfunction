$execute if data storage rpg:names p$(p) run data modify storage rpg:tmp pouch.n set from storage rpg:names p$(p)

# 인벤토리에 든 수표 총액을 rpg.bills 에 계산 (창고 안의 돈은 세지 않음)
scoreboard players set @s rpg.bills 0
scoreboard players set #bn rpg.sys 0
execute store result score #bn rpg.sys run clear @s *[minecraft:custom_data~{rpg_bill:1}] 0
scoreboard players set #bv rpg.sys 1
scoreboard players operation #bn rpg.sys *= #bv rpg.sys
scoreboard players operation @s rpg.bills += #bn rpg.sys
scoreboard players set #bn rpg.sys 0
execute store result score #bn rpg.sys run clear @s *[minecraft:custom_data~{rpg_bill:2}] 0
scoreboard players set #bv rpg.sys 10
scoreboard players operation #bn rpg.sys *= #bv rpg.sys
scoreboard players operation @s rpg.bills += #bn rpg.sys
scoreboard players set #bn rpg.sys 0
execute store result score #bn rpg.sys run clear @s *[minecraft:custom_data~{rpg_bill:3}] 0
scoreboard players set #bv rpg.sys 100
scoreboard players operation #bn rpg.sys *= #bv rpg.sys
scoreboard players operation @s rpg.bills += #bn rpg.sys
scoreboard players set #bn rpg.sys 0
execute store result score #bn rpg.sys run clear @s *[minecraft:custom_data~{rpg_bill:4}] 0
scoreboard players set #bv rpg.sys 1000
scoreboard players operation #bn rpg.sys *= #bv rpg.sys
scoreboard players operation @s rpg.bills += #bn rpg.sys
scoreboard players set #bn rpg.sys 0
execute store result score #bn rpg.sys run clear @s *[minecraft:custom_data~{rpg_bill:5}] 0
scoreboard players set #bv rpg.sys 10000
scoreboard players operation #bn rpg.sys *= #bv rpg.sys
scoreboard players operation @s rpg.bills += #bn rpg.sys
scoreboard players set #bn rpg.sys 0
execute store result score #bn rpg.sys run clear @s *[minecraft:custom_data~{rpg_bill:6}] 0
scoreboard players set #bv rpg.sys 100000
scoreboard players operation #bn rpg.sys *= #bv rpg.sys
scoreboard players operation @s rpg.bills += #bn rpg.sys
scoreboard players set #bn rpg.sys 0
execute store result score #bn rpg.sys run clear @s *[minecraft:custom_data~{rpg_bill:7}] 0
scoreboard players set #bv rpg.sys 1000000
scoreboard players operation #bn rpg.sys *= #bv rpg.sys
scoreboard players operation @s rpg.bills += #bn rpg.sys
scoreboard players set #bn rpg.sys 0
execute store result score #bn rpg.sys run clear @s *[minecraft:custom_data~{rpg_bill:8}] 0
scoreboard players set #bv rpg.sys 10000000
scoreboard players operation #bn rpg.sys *= #bv rpg.sys
scoreboard players operation @s rpg.bills += #bn rpg.sys

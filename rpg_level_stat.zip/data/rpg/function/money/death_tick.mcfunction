# 사망 감지 (minecraft.custom:deaths 증가)
execute as @a[scores={rpg.deaths=1..}] at @s run function rpg:money/on_death
scoreboard players set @a[scores={rpg.deaths=1..}] rpg.deaths 0
# 1초마다 인벤 수표 총액 갱신 / 창고 자동 저장
execute as @a run function rpg:money/count

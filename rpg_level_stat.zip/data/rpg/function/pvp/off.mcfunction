# (v51 · 내부용) PVP 시간 끝
scoreboard players set @s rpg.pvpt -1
tellraw @s [{"text": "[PVP] ", "color": "red", "bold": true}, {"text": "PVP 가 꺼졌습니다.", "color": "gray"}]
execute at @s run playsound minecraft:block.fire.extinguish player @s ~ ~ ~ 0.6 1.2
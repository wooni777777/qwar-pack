# PVP 되는 사이인지 (v51 · as 맞는 플레이어 · 때린 플레이어 = 태그 rpg_pva) — 되면 1 · 안 되면 실패
#   ① 같은 국가끼리는 언제나 X (평타 · 스킬 피해 · CC)
#   ② 전쟁 중에는 다른 국가끼리 언제나 O
#   ③ 평소에는 두 사람 모두 [10분 PVP 활성화] 가 켜져 있을 때만 O
#   (때린 사람을 모르면 · 나 자신이면 O)
execute unless entity @a[tag=rpg_pva] run return 1
execute if entity @s[tag=rpg_pva] run return 1
scoreboard players set #pvn rpg.sys 0
execute as @a[tag=rpg_pva,limit=1] if score @s rpg.natn matches 1.. run scoreboard players operation #pvn rpg.sys = @s rpg.natn
execute if score #pvn rpg.sys matches 1.. if score @s rpg.natn = #pvn rpg.sys run return fail
execute if score #war_run rpg.sys matches 1 run return 1
execute unless score @s rpg.pvpt matches 1.. run return fail
execute unless entity @a[tag=rpg_pva,limit=1,scores={rpg.pvpt=1..}] run return fail
return 1
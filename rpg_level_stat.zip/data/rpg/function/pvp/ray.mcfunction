# (v51 · 내부용 · as at 때리는 플레이어)
scoreboard players set #pvr rpg.sys 0
scoreboard players set #pvs rpg.sys 0
tag @s add rpg_pvme
execute anchored eyes positioned ^ ^ ^ anchored feet run function rpg:pvp/ray_step
tag @s remove rpg_pvme
execute if score #pvr rpg.sys matches 1 unless entity @s[tag=rpg_nopv] run function rpg:pvp/nopv_on
execute if score #pvr rpg.sys matches 0 if entity @s[tag=rpg_nopv] run function rpg:pvp/nopv_off
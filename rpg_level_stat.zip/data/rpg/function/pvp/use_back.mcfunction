# (v51 · 내부용 · 매크로 m) 못 쓰면 아이템을 돌려줌
function rpg:war/pvp_give
$tellraw @s [{"text":"[PVP] ","color":"red","bold":true},{"text":"$(m)","color":"red"},{"text":" (아이템을 돌려드렸습니다)","color":"gray"}]
execute at @s run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 0.7 0.6
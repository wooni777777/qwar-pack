# (v51 · 내부용 · 시선 위 한 점) — 그 점이 들어 있는 엔티티(히트박스)가 있으면 멈춤
scoreboard players add #pvs rpg.sys 1
execute as @e[dx=0,dy=0,dz=0,tag=!rpg_pvme,type=!#rpg:pvp_skip] positioned ~-0.99 ~-0.99 ~-0.99 if entity @s[dx=0,dy=0,dz=0] run tag @s add rpg_pvh
execute if entity @e[tag=rpg_pvh] run return run function rpg:pvp/ray_hit
execute if score #pvs rpg.sys matches ..24 positioned ^ ^ ^0.15 run function rpg:pvp/ray_step
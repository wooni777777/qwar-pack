# 10분 PVP 활성화를 썼다 (v51 · as 플레이어 · 발전과제 rpg:pvp/use)
advancement revoke @s only rpg:pvp/use
execute if score #war_run rpg.sys matches 1 run return run function rpg:pvp/use_back {m:"지금은 전쟁 중이라 PVP 가 이미 켜져 있습니다."}
execute if score @s rpg.pvpt matches 60.. run return run function rpg:pvp/use_back {m:"PVP 가 1분 넘게 남아 있어서 아직 쓸 수 없습니다. (1분 미만일 때 쓰면 +10분)"}
execute unless score @s rpg.pvpt matches 1.. run scoreboard players set @s rpg.pvpt 0
scoreboard players add @s rpg.pvpt 600
function rpg:pvp/left
tellraw @s [{"text": "[PVP] ", "color": "red", "bold": true}, {"text": "PVP 가 켜졌습니다.  남은 시간 ", "color": "white"}, {"score": {"name": "#pvm", "objective": "rpg.sys"}, "color": "yellow", "bold": true}, {"text": "분 ", "color": "yellow"}, {"score": {"name": "#pvs2", "objective": "rpg.sys"}, "color": "yellow"}, {"text": "초", "color": "yellow"}]
tellraw @s {"text": "   PVP 가 켜진 다른 국가 플레이어끼리만 서로 때릴 수 있습니다. (몬스터 공격은 그대로)", "color": "gray"}
execute at @s run playsound minecraft:entity.blaze.shoot player @s ~ ~ ~ 0.8 0.8
execute at @s run particle minecraft:flame ~ ~1 ~ 0.4 0.6 0.4 0.03 30 normal @a
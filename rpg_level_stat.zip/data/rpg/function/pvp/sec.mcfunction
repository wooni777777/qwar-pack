# PVP · 경험치 x2 남은 시간 (v51 · 1초마다 · 접속 중일 때만 줄어듦)
scoreboard players remove @a[scores={rpg.pvpt=1..}] rpg.pvpt 1
execute as @a[scores={rpg.pvpt=60}] run tellraw @s [{"text": "[PVP] ", "color": "red", "bold": true}, {"text": "PVP 가 1분 남았습니다. (지금 [10분 PVP 활성화]를 쓰면 +10분)", "color": "yellow"}]
execute as @a[scores={rpg.pvpt=0}] run function rpg:pvp/off
scoreboard players remove @a[scores={rpg.x2t=1..}] rpg.x2t 1
execute as @a[scores={rpg.x2t=60}] run tellraw @s [{"text": "[경험치] ", "color": "green", "bold": true}, {"text": "경험치 x2 가 1분 남았습니다.", "color": "yellow"}]
execute as @a[scores={rpg.x2t=0}] run function rpg:exp/x2_off
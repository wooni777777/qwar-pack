# (v51 · 내부용) 남은 PVP 시간 -> #pvm 분 #pvs2 초
scoreboard players operation #pvm rpg.sys = @s rpg.pvpt
scoreboard players operation #pvm rpg.sys /= #c60 rpg.sys
scoreboard players operation #pvs2 rpg.sys = @s rpg.pvpt
scoreboard players operation #pvs2 rpg.sys %= #c60 rpg.sys
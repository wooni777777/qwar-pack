# PVP 확인 · 스턴 (v51 · 내부용 · as 맞는 플레이어) — 주인 태그 플레이어 · 없으면 시전자(플레이어) · 안 되면 #pvx 1
scoreboard players set #pvx rpg.sys 0
tag @a[tag=rpg_snw,limit=1] add rpg_pva
execute unless entity @a[tag=rpg_pva] run tag @a[tag=rpg_snc,limit=1] add rpg_pva
execute unless function rpg:pvp/ok run scoreboard players set #pvx rpg.sys 1
tag @a[tag=rpg_pva] remove rpg_pva
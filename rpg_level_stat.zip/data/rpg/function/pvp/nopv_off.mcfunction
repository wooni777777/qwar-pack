# (v51 · 내부용) 평타 공격력 되돌림
tag @s remove rpg_nopv
attribute @s minecraft:attack_damage modifier remove rpg:nopvp
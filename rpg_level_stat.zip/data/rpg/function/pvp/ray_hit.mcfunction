# (v51 · 내부용) 처음 닿은 대상 — 플레이어고 PVP 가 안 되면 #pvr 1
execute as @e[tag=rpg_pvh,type=minecraft:player] run function rpg:pvp/g_pvme
execute if entity @e[tag=rpg_pvh,type=minecraft:player] if score #pvx rpg.sys matches 1 run scoreboard players set #pvr rpg.sys 1
tag @e[tag=rpg_pvh] remove rpg_pvh
return 1
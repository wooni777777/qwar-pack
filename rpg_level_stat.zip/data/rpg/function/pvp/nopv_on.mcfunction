# (v51 · 내부용) 평타 공격력 0
tag @s add rpg_nopv
attribute @s minecraft:attack_damage modifier remove rpg:nopvp
attribute @s minecraft:attack_damage modifier add rpg:nopvp -1 add_multiplied_total
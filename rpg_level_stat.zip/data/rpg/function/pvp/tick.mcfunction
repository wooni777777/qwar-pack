# PVP 평타 막기 (v51 · 매 틱)
#   플레이어 7칸 안에 다른 플레이어가 있으면 눈에서 시선 방향으로 약 3.7칸까지 훑어서
#   처음 닿는 대상이 "PVP 가 안 되는 플레이어" 면 평타 공격력 0 (rpg:nopvp) — 몬스터는 그대로 맞음
execute as @a[gamemode=!spectator] at @s if entity @a[distance=0.01..7,gamemode=!spectator] run function rpg:pvp/ray
execute as @a[tag=rpg_nopv] at @s unless entity @a[distance=0.01..7,gamemode=!spectator] run function rpg:pvp/nopv_off
execute as @a[tag=rpg_nopv,gamemode=spectator] run function rpg:pvp/nopv_off
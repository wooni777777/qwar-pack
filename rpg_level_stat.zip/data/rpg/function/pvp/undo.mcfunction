# (v51 · 내부용) 받은 피해 전부 되돌림
scoreboard players operation #heal rpg.sys = #d rpg.sys
function rpg:util/heal
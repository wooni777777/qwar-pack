# (v51 · 내부용 · as 맞은 플레이어 · combat/on_damaged) 방금 PVP 가 안 되는 플레이어에게 맞았나 — 맞았으면 1
tag @s add rpg_pvv
execute on attacker if entity @s[type=minecraft:player,tag=!rpg_pvv] run tag @s add rpg_pva
tag @s remove rpg_pvv
execute unless entity @a[tag=rpg_pva] run return fail
# 오래된 공격자 기록은 무시 (그 사람이 이번 틱 · 지난 틱에 무언가를 때렸을 때만)
scoreboard players operation #pvg rpg.sys = #gtick rpg.sys
execute as @a[tag=rpg_pva,limit=1] run scoreboard players operation #pvg rpg.sys -= @s rpg.hitt
execute unless score #pvg rpg.sys matches 0..1 run tag @a[tag=rpg_pva] remove rpg_pva
execute unless entity @a[tag=rpg_pva] run return fail
scoreboard players set #pvx rpg.sys 0
execute unless function rpg:pvp/ok run scoreboard players set #pvx rpg.sys 1
tag @a[tag=rpg_pva] remove rpg_pva
execute if score #pvx rpg.sys matches 1 run return 1
return fail
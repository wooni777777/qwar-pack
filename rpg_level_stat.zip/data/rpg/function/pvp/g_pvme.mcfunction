# PVP 확인 · 평타 막기 (시선) (v51 · 내부용 · as 맞는 플레이어) — 안 되면 #pvx 1
scoreboard players set #pvx rpg.sys 0
tag @a[tag=rpg_pvme,limit=1] add rpg_pva
execute unless function rpg:pvp/ok run scoreboard players set #pvx rpg.sys 1
tag @a[tag=rpg_pva] remove rpg_pva
# cow_c 미리보기 하나 (v47 · 자동 생성 · 내부용 · 이 자리)
summon minecraft:hoglin ~ ~ ~ {Tags:["rpg_preview","rpg_pvnew"],NoAI:1b,Silent:1b,Invulnerable:1b,PersistenceRequired:1b,NoGravity:1b,IsImmuneToZombification:1b}
attribute @n[tag=rpg_pvnew,distance=..0.1] minecraft:scale base set 0.9
effect give @n[tag=rpg_pvnew,distance=..0.1] minecraft:invisibility infinite 0 true
effect give @n[tag=rpg_pvnew,distance=..0.1] minecraft:fire_resistance infinite 0 true
execute as @n[tag=rpg_pvnew,distance=..0.1] at @s run rotate @s facing entity @p[distance=..40] feet
execute as @n[tag=rpg_pvnew,distance=..0.1] at @s run function rpg:rig/mk_cow_c
tag @e[tag=rpg_pvnew,distance=..0.1] remove rpg_pvnew

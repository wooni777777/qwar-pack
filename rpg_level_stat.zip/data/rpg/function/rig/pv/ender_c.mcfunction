# ender_c 미리보기 하나 (v47 · 자동 생성 · 내부용 · 이 자리)
summon minecraft:zombie ~ ~ ~ {Tags:["rpg_preview","rpg_pvnew"],NoAI:1b,Silent:1b,Invulnerable:1b,PersistenceRequired:1b,NoGravity:1b}
attribute @n[tag=rpg_pvnew,distance=..0.1] minecraft:scale base set 1.5
effect give @n[tag=rpg_pvnew,distance=..0.1] minecraft:invisibility infinite 0 true
effect give @n[tag=rpg_pvnew,distance=..0.1] minecraft:fire_resistance infinite 0 true
item replace entity @n[tag=rpg_pvnew,distance=..0.1] armor.head with minecraft:paper[minecraft:item_model="rpg:empty"]
execute as @n[tag=rpg_pvnew,distance=..0.1] at @s run rotate @s facing entity @p[distance=..40] feet
execute as @n[tag=rpg_pvnew,distance=..0.1] at @s run function rpg:rig/mk_ender_c
tag @e[tag=rpg_pvnew,distance=..0.1] remove rpg_pvnew

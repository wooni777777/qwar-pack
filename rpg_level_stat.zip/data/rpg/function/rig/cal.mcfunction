# 조각이 실제로 탄 높이(승객 자리)를 재서, 계산해 둔 높이(#a0_몹번호)와 다르면 그 몹 종류의 모든 프레임을 위아래로 옮김 (v47)
$execute if data storage rpg:rig c.k$(k) run return 0
$data modify storage rpg:rig c.k$(k) set value 1b
execute store result score #cmy rpg.sys run data get entity @s Pos[1] 10000
scoreboard players set #cpy rpg.sys -999999999
execute on passengers if entity @s[tag=rpg_rp0] store result score #cpy rpg.sys run data get entity @s Pos[1] 10000
execute if score #cpy rpg.sys matches -999999999 run return 0
scoreboard players operation #cpy rpg.sys -= #cmy rpg.sys
$scoreboard players operation #cpy rpg.sys -= #a0_$(k) rpg.sys
execute if score #cpy rpg.sys matches -40..40 run return 0
$function rpg:rig/cal_go {k:$(k)}

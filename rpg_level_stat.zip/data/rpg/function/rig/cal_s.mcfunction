$data modify storage rpg:rig ct set from storage rpg:rig d.k$(k).s$(s)
data modify storage rpg:rig co set value []
function rpg:rig/cal_f
$data modify storage rpg:rig d.k$(k).s$(s) set from storage rpg:rig co

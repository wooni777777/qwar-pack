# 리그 몹 한 마리 (v47 · 내부용 · as at rotated 몹 · 매 틱)
execute if score @s rpg.rga matches ..5 run scoreboard players add @s rpg.rga 1
# 처음 한 번 : 모델 높이 자동 보정 (몹 종류마다 한 번)
execute if score @s rpg.rga matches 2 run function rpg:rig/cal_chk
# 모델이 몹이 보는 방향을 봄 (위아래는 안 기울임)
execute rotated ~ 0 on passengers if entity @s[tag=rpg_rp] positioned as @s run rotate @s facing ^ ^ ^1
# 손맛 타이머 (멈춤 · 번쩍)
execute if score @s rpg.rhc matches 1.. run scoreboard players remove @s rpg.rhc 1
execute if score @s rpg.rgh matches 1.. run function rpg:rig/hs_tick
execute if score @s rpg.rgw matches 1.. run function rpg:rig/fl_tick
# 애니메이션
execute if score @s rpg.rgq matches 1.. run function rpg:rig/q
execute if score @s rpg.rgs matches 0..1 run function rpg:rig/base
scoreboard players remove @s rpg.rgt 1
execute if score @s rpg.rgt matches ..0 run function rpg:rig/next

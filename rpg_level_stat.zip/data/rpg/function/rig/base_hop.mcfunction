# 슬라임 · 개구리 : 뛰어오르는 순간 한 번 뜀 동작 (v47 · 내부용)
execute if score @s rpg.rgs matches 0 if predicate rpg:rig_up run function rpg:rig/go1h

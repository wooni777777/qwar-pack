# 멈춤 끝 -> 고무공처럼 튕겨 나감 (v47 · 내부용 · as 몹)
attribute @s minecraft:movement_speed modifier remove rpg:hst
execute unless entity @s[tag=rpg_rgb] run return 0
tag @s remove rpg_rgb
data modify storage rpg:rig mo set value [0.0d,0.0d,0.0d]
execute store result storage rpg:rig mo[0] double 0.000135 run scoreboard players get @s rpg.rmx
execute store result storage rpg:rig mo[2] double 0.000135 run scoreboard players get @s rpg.rmz
scoreboard players operation #rmy rpg.sys = @s rpg.rmy
execute if score #rmy rpg.sys matches ..0 run scoreboard players set #rmy rpg.sys 0
scoreboard players add #rmy rpg.sys 1200
execute if score #rmy rpg.sys matches 5001.. run scoreboard players set #rmy rpg.sys 5000
execute store result storage rpg:rig mo[1] double 0.0001 run scoreboard players get #rmy rpg.sys
data modify entity @s Motion set from storage rpg:rig mo

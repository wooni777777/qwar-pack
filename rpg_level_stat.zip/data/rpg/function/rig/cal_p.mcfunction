execute unless data storage rpg:rig cp[0] run return 0
execute store result score #cy rpg.sys run data get storage rpg:rig cp[0].transformation.translation[1] 10000
scoreboard players operation #cy rpg.sys -= #cpy rpg.sys
execute store result storage rpg:rig cp[0].transformation.translation[1] float 0.0001 run scoreboard players get #cy rpg.sys
data modify storage rpg:rig cf.p append from storage rpg:rig cp[0]
data remove storage rpg:rig cp[0]
function rpg:rig/cal_p

# 화면 흔들림 시작 (v47 · 내부용 · as 플레이어 · #rhs 1 = 세게)
execute if score @s rpg.shk matches 1.. run return 0
scoreboard players set @s rpg.shk 3
scoreboard players operation @s rpg.sha = #rhs rpg.sys

$data modify storage rpg:rig cur set from storage rpg:rig d.k$(k).s$(s)[$(f)]

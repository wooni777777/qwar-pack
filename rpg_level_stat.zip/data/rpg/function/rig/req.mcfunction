# 동작 요청 (v47 · 내부용 · as 몹 · #rrq = 상태 번호)
#   우선순위 : 죽음 9 > 스킬 5 > 맞음 4 > 때리기 · 쏘기 2 > 뜀 1 > 가만히 · 걷기 0  (낮은 건 높은 걸 못 끊음)
execute unless entity @s[tag=rpg_rig] run return 0
scoreboard players set #rrp rpg.sys 2
execute if score #rrq rpg.sys matches 3 run scoreboard players set #rrp rpg.sys 4
execute if score #rrq rpg.sys matches 7 run scoreboard players set #rrp rpg.sys 4
execute if score #rrq rpg.sys matches 4 run scoreboard players set #rrp rpg.sys 5
execute if score #rrq rpg.sys matches 5 run scoreboard players set #rrp rpg.sys 9
execute if score #rrp rpg.sys < @s rpg.rgp run return 0
execute if score #rrp rpg.sys < @s rpg.rgr run return 0
scoreboard players operation @s rpg.rgq = #rrq rpg.sys
scoreboard players operation @s rpg.rgr = #rrp rpg.sys

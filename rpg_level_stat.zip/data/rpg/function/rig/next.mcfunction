# 다음 프레임 (v47 · 내부용 · as 몹)
scoreboard players add @s rpg.rgf 1
function rpg:rig/ld
execute unless data storage rpg:rig cur run function rpg:rig/end
execute unless data storage rpg:rig cur run return run scoreboard players set @s rpg.rgt 20
execute store result score @s rpg.rgt run data get storage rpg:rig cur.d
execute if score @s rpg.rgt matches ..0 run scoreboard players set @s rpg.rgt 1
execute on passengers if entity @s[tag=rpg_rp] run function rpg:rig/pt

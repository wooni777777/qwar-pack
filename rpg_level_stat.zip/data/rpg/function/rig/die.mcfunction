# 리그 몹이 죽음 -> 빙빙 돌면서 작아짐 (v47 · 내부용 · as at 죽은 몹 · mob/on_death 에서)
execute if entity @s[type=minecraft:slime] run data modify entity @s Size set value 0
attribute @s minecraft:movement_speed modifier remove rpg:hst
scoreboard players set @s rpg.rgh 0
execute if score @s rpg.rgw matches 1.. on passengers if entity @s[tag=rpg_rp] run function rpg:rig/fl_off
scoreboard players set @s rpg.rgw 0
scoreboard players set @s rpg.rgs 5
scoreboard players set @s rpg.rgp 9
scoreboard players set @s rpg.rgq 0
scoreboard players set @s rpg.rgf -1
scoreboard players set @s rpg.rgt 0
execute on passengers if entity @s[tag=rpg_rp0] run tag @s add rpg_rpd
function rpg:rig/die_tick

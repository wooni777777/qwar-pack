# 프레임 불러오기 -> rpg:rig cur (v47 · 내부용 · 없으면 cur 도 없음)
execute store result storage rpg:rig a.k int 1 run scoreboard players get @s rpg.rgk
execute store result storage rpg:rig a.s int 1 run scoreboard players get @s rpg.rgs
execute store result storage rpg:rig a.f int 1 run scoreboard players get @s rpg.rgf
data remove storage rpg:rig cur
function rpg:rig/ld2 with storage rpg:rig a

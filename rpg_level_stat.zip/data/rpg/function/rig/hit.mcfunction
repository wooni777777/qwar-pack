# 몬스터가 맞음 -> 손맛 (v47 · 내부용 · as at 몹 · mob/fhp_dmg 에서 · #fd = 이번 틱 피해 x100)
#   6-1 멈춤 (약하게 1틱 · 세게 2틱 = 0.1초)  6-2 납작 -> 고무공처럼 튕김  6-3 화면 흔들림 · 하얗게 번쩍  6-4 하얀 파편 + 소리
#   출혈 · 독 같은 지속 피해(방금 때린 플레이어가 없음)는 번쩍만 합니다.
execute if entity @s[tag=rpg_dead] run return 0
function rpg:rig/fl_on
scoreboard players operation #rht rpg.sys = #gtick rpg.sys
scoreboard players remove #rht rpg.sys 1
scoreboard players set #rhp rpg.sys 0
execute as @a[distance=..24] if score @s rpg.hitt >= #rht rpg.sys run scoreboard players set #rhp rpg.sys 1
execute if score #rhp rpg.sys matches 0 run return 0
# 세기 : 최대체력의 8% 이상 또는 한 번에 30 이상이면 "세게"
scoreboard players operation #rpc rpg.sys = #fd rpg.sys
scoreboard players operation #rpc rpg.sys /= @s rpg.mmx
scoreboard players set #rhs rpg.sys 0
execute if score #rpc rpg.sys matches 8.. run scoreboard players set #rhs rpg.sys 1
execute if score #fd rpg.sys matches 3000.. run scoreboard players set #rhs rpg.sys 1
# 6-2 찌그러짐 애니메이션
execute if score #rhs rpg.sys matches 1 run scoreboard players set #rrq rpg.sys 3
execute if score #rhs rpg.sys matches 0 run scoreboard players set #rrq rpg.sys 7
function rpg:rig/req
# 6-1 멈춤 (8틱에 한 번까지)
execute if score #rig_stop rpg.sys matches 1 unless score @s rpg.rhc matches 1.. run function rpg:rig/hs_on
# 6-3 화면 흔들림 (몬스터 5칸 안 플레이어만)
execute if score #rig_shake rpg.sys matches 1 as @a[distance=..5,gamemode=!spectator] run function rpg:rig/shk_on
# 6-4 파편 + 소리
function rpg:rig/fx

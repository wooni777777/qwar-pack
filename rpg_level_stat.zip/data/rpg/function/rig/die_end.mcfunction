# 죽는 동작 끝 -> 조각 · 이름표 치움 (v47 · 내부용)
execute on passengers run kill @s

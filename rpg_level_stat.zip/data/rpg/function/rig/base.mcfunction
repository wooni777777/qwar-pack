# 가만히 <-> 걷기 (v47 · 내부용) — 멈췄다 걸었다 깜빡이지 않게 4틱 여유
execute if entity @s[tag=rpg_rghop] run return run function rpg:rig/base_hop
execute store success score #rmv rpg.sys if predicate rpg:rig_mv
execute if score #rmv rpg.sys matches 1 run scoreboard players set @s rpg.rgm 4
execute if score #rmv rpg.sys matches 0 if score @s rpg.rgm matches 1.. run scoreboard players remove @s rpg.rgm 1
execute if score @s rpg.rgm matches 1.. if score @s rpg.rgs matches 0 run function rpg:rig/go1
execute if score @s rpg.rgm matches ..0 if score @s rpg.rgs matches 1 run function rpg:rig/go0

# 몬스터 리그 (v47 · 매 틱) — 모델 방향 · 애니메이션 · 손맛(멈춤 · 번쩍 · 튕김 · 화면 흔들림)
execute as @e[tag=rpg_rig] at @s rotated as @s run function rpg:rig/mob
# 죽는 중인 몹 (@e 로 안 잡혀서 첫 조각에서 거꾸로 찾음)
execute as @e[type=minecraft:item_display,tag=rpg_rpd] on vehicle run function rpg:rig/die_tick
execute as @a[scores={rpg.shk=1..}] rotated as @s run function rpg:rig/shk_t
# v47 : 뛰어오른 보스 (개구리 왕 · 슬라임 킹) 착지 확인
execute as @e[tag=rpg_leap] at @s run function rpg:mob/leap_t

# slime_s 모델 조각 붙이기 (v47 · 자동 생성 · 내부용 · as at 몹)
#   조각(item_display)들은 몹에 승객으로 탑니다 -> 몹이 움직이면 그대로 같이 움직이고, 방향은 매 틱 몹을 따라 돕니다.
tag @s add rpg_rig
tag @s add rpg_rghop
scoreboard players set @s rpg.rgk 14
scoreboard players set @s rpg.rgs 0
scoreboard players set @s rpg.rgf -1
scoreboard players set @s rpg.rgt 2
scoreboard players set @s rpg.rgp 0
scoreboard players set @s rpg.rgq 0
scoreboard players set @s rpg.rgr 0
scoreboard players set @s rpg.rgw 0
scoreboard players set @s rpg.rgh 0
scoreboard players set @s rpg.rga 0
scoreboard players set @s rpg.rgm 0
scoreboard players set @s rpg.rhc 0
summon minecraft:item_display ~ ~ ~ {Tags:["rpg_rp","rpg_rpn","rpg_rp_core","rpg_rp0"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"rpg:rig/slime_s/core"}},item_display:"none",teleport_duration:2,view_range:1.2f,shadow_radius:0.5f,shadow_strength:0.8f,transformation:{translation:[0f,-0.5308f,0f],left_rotation:[0f,0f,0f,1f],scale:[1.0815f,1.0185f,1.0815f],right_rotation:[0f,0f,0f,1f]}}
ride @n[type=minecraft:item_display,tag=rpg_rpn,distance=..0.1] mount @s
tag @e[type=minecraft:item_display,tag=rpg_rpn,distance=..0.1] remove rpg_rpn
summon minecraft:item_display ~ ~ ~ {Tags:["rpg_rp","rpg_rpn","rpg_rp_outer"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"rpg:rig/slime_s/outer"}},item_display:"none",teleport_duration:2,view_range:1.2f,transformation:{translation:[0f,-0.5308f,0f],left_rotation:[0f,0f,0f,1f],scale:[1.0815f,1.0185f,1.0815f],right_rotation:[0f,0f,0f,1f]}}
ride @n[type=minecraft:item_display,tag=rpg_rpn,distance=..0.1] mount @s
tag @e[type=minecraft:item_display,tag=rpg_rpn,distance=..0.1] remove rpg_rpn
summon minecraft:item_display ~ ~ ~ {Tags:["rpg_rp","rpg_rpn","rpg_rp_weapon"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"rpg:rig/slime_s/weapon"}},item_display:"none",teleport_duration:2,view_range:1.2f,transformation:{translation:[-0.6083f,-0.5944f,0.1352f],left_rotation:[0f,0f,0f,1f],scale:[1.0815f,1.0185f,1.0815f],right_rotation:[0f,0f,0.2164f,0.9763f]}}
ride @n[type=minecraft:item_display,tag=rpg_rpn,distance=..0.1] mount @s
tag @e[type=minecraft:item_display,tag=rpg_rpn,distance=..0.1] remove rpg_rpn
execute if entity @s[tag=rpg_preview] on passengers run tag @s add rpg_preview

# 탈것(몹)이 없는 조각 정리 (v47 · 1초마다)
execute as @e[type=minecraft:item_display,tag=rpg_rp] unless predicate rpg:rig_ride run kill @s

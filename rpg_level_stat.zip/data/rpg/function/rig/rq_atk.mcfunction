# 때리기 동작 (v47 · as 몹)
scoreboard players set #rrq rpg.sys 2
function rpg:rig/req

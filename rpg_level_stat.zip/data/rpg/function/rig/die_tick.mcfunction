scoreboard players remove @s rpg.rgt 1
execute if score @s rpg.rgt matches ..0 run function rpg:rig/next

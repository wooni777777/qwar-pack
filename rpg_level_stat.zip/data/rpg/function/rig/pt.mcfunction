# 조각 하나에 이번 프레임 자세 넣기 (v47 · 내부용 · as 조각 · 탄 순서대로 하나씩 꺼냄)
data modify entity @s {} merge from storage rpg:rig cur.p[0]
data remove storage rpg:rig cur.p[0]

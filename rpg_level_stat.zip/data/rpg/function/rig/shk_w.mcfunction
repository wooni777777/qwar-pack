execute if score @s rpg.shk matches 3 run rotate @s ~0.5 ~-0.35
execute if score @s rpg.shk matches 2 run rotate @s ~-0.8 ~0.55
execute if score @s rpg.shk matches 1 run rotate @s ~0.3 ~-0.2

execute if score @s rpg.shk matches 3 run rotate @s ~1.2 ~-0.9
execute if score @s rpg.shk matches 2 run rotate @s ~-2.0 ~1.4
execute if score @s rpg.shk matches 1 run rotate @s ~0.8 ~-0.5

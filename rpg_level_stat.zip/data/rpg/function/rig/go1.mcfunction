scoreboard players set @s rpg.rgs 1
scoreboard players set @s rpg.rgf -1
scoreboard players set @s rpg.rgt 0

# 하얗게 번쩍 (v47 · 내부용 · as 몹 · 2틱)
execute unless score @s rpg.rgw matches 1.. on passengers if entity @s[tag=rpg_rp] run data merge entity @s {brightness:{sky:15,block:15},item:{components:{"minecraft:custom_model_data":{strings:["w"]}}}}
scoreboard players set @s rpg.rgw 2

# 늑대 보스가 처음 화냄 -> 울부짖는 동작 + 눈이 빨개짐 (v47 · 내부용 · as at 늑대)
function rpg:rig/rq_skl
playsound minecraft:entity.wolf.howl hostile @a ~ ~ ~ 1.6 0.7
execute on passengers if entity @s[tag=rpg_rp_head] run function rpg:rig/head_a

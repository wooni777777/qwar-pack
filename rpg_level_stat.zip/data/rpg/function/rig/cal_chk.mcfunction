# 모델 높이 자동 보정 확인 (v47 · 내부용 · as 몹 · 몹 종류마다 /reload 뒤 처음 한 번)
execute store result storage rpg:rig a.k int 1 run scoreboard players get @s rpg.rgk
function rpg:rig/cal with storage rpg:rig a

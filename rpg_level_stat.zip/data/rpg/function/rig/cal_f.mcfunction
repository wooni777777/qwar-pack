execute unless data storage rpg:rig ct[0] run return 0
data modify storage rpg:rig cf set from storage rpg:rig ct[0]
data remove storage rpg:rig ct[0]
data modify storage rpg:rig cp set from storage rpg:rig cf.p
data modify storage rpg:rig cf.p set value []
function rpg:rig/cal_p
data modify storage rpg:rig co append from storage rpg:rig cf
function rpg:rig/cal_f

# 멈춤 시작 (v47 · 내부용 · as 몹)
scoreboard players set @s rpg.rgh 1
execute if score #rhs rpg.sys matches 1 run scoreboard players set @s rpg.rgh 2
scoreboard players set @s rpg.rhc 8
attribute @s minecraft:movement_speed modifier remove rpg:hst
attribute @s minecraft:movement_speed modifier add rpg:hst -1 add_multiplied_total
# 받은 넉백을 잠깐 보관했다가 멈춤이 끝나면 더 세게 (늑대는 /data 를 쓰면 최대체력이 바뀌어서 · 보스는 안 튕김)
execute if entity @s[type=minecraft:wolf] run return 0
execute if entity @s[tag=rpg_boss] run return 0
execute if score #rig_bounce rpg.sys matches 0 run return 0
data modify storage rpg:rig mo set from entity @s Motion
execute store result score @s rpg.rmx run data get storage rpg:rig mo[0] 10000
execute store result score @s rpg.rmy run data get storage rpg:rig mo[1] 10000
execute store result score @s rpg.rmz run data get storage rpg:rig mo[2] 10000
data modify entity @s Motion set value [0.0d,0.0d,0.0d]
tag @s add rpg_rgb

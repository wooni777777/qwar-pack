# pking : 하얀 파편 (몸 크기만큼) + 맞는 소리 (v47 · 자동 생성)
particle minecraft:block{block_state:"minecraft:white_concrete"} ~ ~1.4 ~ 0.35 0.28 0.35 0.15 8 normal @a
execute if score #rhs rpg.sys matches 1 run particle minecraft:block{block_state:"minecraft:white_concrete"} ~ ~1.4 ~ 0.35 0.28 0.35 0.25 4 normal @a
playsound minecraft:entity.pillager.hurt hostile @a ~ ~ ~ 1 0.6
execute if score #rhs rpg.sys matches 1 run playsound minecraft:entity.player.attack.strong player @a ~ ~ ~ 0.6 0.8
execute if score #rhs rpg.sys matches 0 run playsound minecraft:entity.player.attack.weak player @a ~ ~ ~ 0.5 1.2

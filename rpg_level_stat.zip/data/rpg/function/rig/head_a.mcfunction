tag @s add rpg_rpa
data modify entity @s item.components."minecraft:custom_model_data" set value {strings:["a"]}

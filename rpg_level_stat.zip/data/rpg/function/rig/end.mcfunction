# 동작 하나가 끝남 (v47 · 내부용) — 가만히 · 걷기는 처음부터 다시, 나머지는 가만히 · 걷기로
execute if score @s rpg.rgs matches 5 run return run function rpg:rig/die_end
scoreboard players set @s rpg.rgf 0
execute if score @s rpg.rgs matches 2.. run function rpg:rig/to_base
execute if score @s rpg.rgs matches 1 if entity @s[tag=rpg_rghop] run function rpg:rig/to_base
function rpg:rig/ld

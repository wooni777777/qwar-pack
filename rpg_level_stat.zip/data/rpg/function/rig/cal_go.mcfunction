# (v47 · 내부용) 모든 상태의 프레임 높이를 #cpy (x0.0001 칸) 만큼 내림
$execute if data storage rpg:rig d.k$(k).s0 run function rpg:rig/cal_s {k:$(k),s:0}
$execute if data storage rpg:rig d.k$(k).s1 run function rpg:rig/cal_s {k:$(k),s:1}
$execute if data storage rpg:rig d.k$(k).s2 run function rpg:rig/cal_s {k:$(k),s:2}
$execute if data storage rpg:rig d.k$(k).s3 run function rpg:rig/cal_s {k:$(k),s:3}
$execute if data storage rpg:rig d.k$(k).s4 run function rpg:rig/cal_s {k:$(k),s:4}
$execute if data storage rpg:rig d.k$(k).s5 run function rpg:rig/cal_s {k:$(k),s:5}
$execute if data storage rpg:rig d.k$(k).s6 run function rpg:rig/cal_s {k:$(k),s:6}
$execute if data storage rpg:rig d.k$(k).s7 run function rpg:rig/cal_s {k:$(k),s:7}

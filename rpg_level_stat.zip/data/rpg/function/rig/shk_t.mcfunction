# 화면 흔들림 (v47 · 내부용 · as rotated 플레이어 · 3틱 · 합쳐서 원래 방향으로 돌아옴)
execute if score @s rpg.sha matches 1 run function rpg:rig/shk_s
execute unless score @s rpg.sha matches 1 run function rpg:rig/shk_w
scoreboard players remove @s rpg.shk 1

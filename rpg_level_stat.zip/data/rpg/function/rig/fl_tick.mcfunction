scoreboard players remove @s rpg.rgw 1
execute if score @s rpg.rgw matches ..0 on passengers if entity @s[tag=rpg_rp] run function rpg:rig/fl_off

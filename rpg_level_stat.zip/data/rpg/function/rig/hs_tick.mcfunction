scoreboard players remove @s rpg.rgh 1
execute if score @s rpg.rgh matches ..0 run function rpg:rig/hs_end

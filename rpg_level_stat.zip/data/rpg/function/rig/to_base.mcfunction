scoreboard players set @s rpg.rgs 0
scoreboard players set @s rpg.rgp 0
execute if entity @s[tag=!rpg_rghop] if score @s rpg.rgm matches 1.. run scoreboard players set @s rpg.rgs 1

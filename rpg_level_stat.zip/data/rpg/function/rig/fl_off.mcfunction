# 번쩍 끝 (v47 · 내부용 · as 조각) — 화난 늑대 머리는 빨간 눈으로
data remove entity @s brightness
data remove entity @s item.components."minecraft:custom_model_data"
execute if entity @s[tag=rpg_rpa] run data modify entity @s item.components."minecraft:custom_model_data" set value {strings:["a"]}

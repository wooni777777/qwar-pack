# 스킬 동작 (v47 · as 몹)
scoreboard players set #rrq rpg.sys 4
function rpg:rig/req

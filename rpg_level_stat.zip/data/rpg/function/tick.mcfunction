# 메뉴 / 스탯 투자 트리거 처리
execute as @a[scores={rpg.menu=1..}] at @s run function rpg:menu/route
execute as @a[scores={rpg.h7t=1..}] at @s run function rpg:hid/tgt_set
execute as @a[scores={menu=1..}] at @s run function rpg:menu/alias
execute as @a[scores={rpg.up=1..}] at @s run function rpg:stat/spend
execute as @a[scores={rpg.tp=1..}] at @s run function rpg:menu/tp_do
execute as @a[scores={rpg.chk=1..}] at @s run function rpg:money/issue
execute as @a[scores={rpg.shop=1..}] at @s run function rpg:shop/buy
execute as @a[scores={rpg.cry=1..}] at @s run function rpg:crystal/route
execute as @a[scores={rpg.eq=1..}] at @s run function rpg:equip/route
execute as @a[scores={rpg.q=1..}] at @s run function rpg:quest/route
execute as @a[scores={rpg.auc=1..}] at @s run function rpg:auc/route
execute as @a[scores={rpg.nat=1..}] at @s run function rpg:nation/route
execute as @a[scores={rpg.vlt=1..}] at @s run function rpg:vault/route
execute as @a[scores={rpg.rnd=1..}] at @s run function rpg:round/route
execute as @a[scores={rpg.npc=1..}] at @s run function rpg:npc/route
execute as @a[scores={rpg.enh=1..}] at @s run function rpg:enh/route

# 스킬 아이템 우클릭 (아이템은 소모되지 않고 자리에 그대로 남습니다)
execute as @a[scores={rpg.uleap=1..}] at @s run function rpg:passive/use_leap
execute as @a[scores={rpg.ustun=1..}] at @s run function rpg:passive/use_stun
execute as @e[type=minecraft:interaction,tag=rpg_shop_potion] at @s if data entity @s interaction run function rpg:shop/potion_click
execute as @e[type=minecraft:interaction,tag=rpg_shop_potion2] at @s if data entity @s interaction run function rpg:shop/potion_click2
execute as @e[type=minecraft:interaction,tag=rpg_shop_crystal] at @s if data entity @s interaction run function rpg:crystal/click
execute as @e[type=minecraft:interaction,tag=rpg_shop_enh] at @s if data entity @s interaction run function rpg:enh/click
execute as @e[type=minecraft:interaction,tag=rpg_shop_eq1] at @s if data entity @s interaction run function rpg:equip/click_str
execute as @e[type=minecraft:interaction,tag=rpg_shop_eq2] at @s if data entity @s interaction run function rpg:equip/click_dex
execute as @e[type=minecraft:interaction,tag=rpg_shop_eq3] at @s if data entity @s interaction run function rpg:equip/click_con
execute as @e[type=minecraft:interaction,tag=rpg_q_elder] at @s if data entity @s interaction run function rpg:quest/click_elder
execute as @e[type=minecraft:interaction,tag=rpg_q_dolsoi] at @s if data entity @s interaction run function rpg:quest/click_dolsoi

# 사신수 무기 효과
execute as @e[tag=rpg_slash] at @s run function rpg:fx/sl_tick
execute as @e[tag=rpg_dot] at @s run function rpg:api/dot_tick
function rpg:beast/tick

# 몬스터 사망 처리 / 경험치 조각 흡수
execute as @e[tag=rpg_mob,tag=!rpg_dead,nbt={DeathTime:1s}] at @s run function rpg:mob/on_death
execute as @e[tag=rpg_expchick,tag=!rpg_dead,nbt={DeathTime:1s}] at @s run function rpg:quest/chick_death
execute as @e[type=minecraft:item,nbt={Item:{components:{"minecraft:custom_data":{rpg_exp:1}}}}] at @s if entity @a[distance=..2,gamemode=!spectator] run function rpg:exp/shard_take

# 몹 처치 경험치
execute as @a[scores={rpg.kill=1..}] at @s run function rpg:exp/on_kill

# 사망 -> 리스폰 감지
execute as @a[scores={rpg.hp=0}] run scoreboard players set @s rpg.resp 1
execute as @a[scores={rpg.hp=1..,rpg.resp=1}] at @s run function rpg:core/respawn

execute as @e[tag=rpg_stunned] run function rpg:passive/stun_tick

# 전투 / 패시브
function rpg:combat/tick

scoreboard players add #timer rpg.sys 1
execute if score #timer rpg.sys matches 5 run function rpg:hud/all
execute if score #timer rpg.sys matches 10.. run function rpg:core/slow_tick

# 몬스터 애니메이션 / 보스 돌 투사체
execute as @e[type=minecraft:item_display,tag=rpg_rock] at @s run function rpg:mob/rock_tick
execute as @e[tag=rpg_atk] run function rpg:mob/anim_tick
scoreboard players add #anim rpg.sys 1
execute if score #anim rpg.sys matches 9 run function rpg:mob/anim_a
execute if score #anim rpg.sys matches 18.. run function rpg:mob/anim_b

# 몬스터 스포너 (1초마다)
scoreboard players add #mtimer rpg.sys 1
execute if score #mtimer rpg.sys matches 20.. run function rpg:mob/tick

# C+C (당근 낚싯대 더블 웅크리기) / 비행 / 경매
function rpg:sys/cc_tick
function rpg:sys/fly_tick
function rpg:auc/tick
scoreboard players add #auctm rpg.sys 1
function rpg:round/tick
execute if score #auctm rpg.sys matches 20.. run function rpg:auc/sec
execute if score #auctm rpg.sys matches 20.. run function rpg:round/sec
execute if score #auctm rpg.sys matches 20.. run scoreboard players set #auctm rpg.sys 0

# 국가 / 창고 / 사망 소지금 봉투
function rpg:money/pouch_tick
execute as @e[tag=rpg_vbar] at @s run function rpg:vault/bar_tick
scoreboard players add #dthtm rpg.sys 1
execute if score #dthtm rpg.sys matches 20.. run function rpg:money/death_tick
execute if score #dthtm rpg.sys matches 20.. run function rpg:sys/name_tick
execute if score #dthtm rpg.sys matches 20.. run scoreboard players set #dthtm rpg.sys 0

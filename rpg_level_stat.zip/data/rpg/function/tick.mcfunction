# 메뉴 / 스탯 투자 트리거 처리
execute as @a[scores={rpg.menu=1..}] at @s run function rpg:dlg/h {f:"menu/route",lo:-9,hi:-9,ob:"rpg.menu",tlo:-9,thi:-9}
# v50 : 허수아비 (3초 풀피 · 초록 숫자)
execute as @e[tag=rpg_m_scare,tag=!rpg_dead] at @s run function rpg:sc/tick
execute as @e[type=minecraft:text_display,tag=rpg_scn] at @s run function rpg:sc/num_t
# v50 : F (왼손 들기) 키 -> 스코어보드 F
function rpg:sys/f_tick
# v50 : 성 밭 (밟아서 흙이 되면 바로 경작지로)
execute as @e[type=minecraft:marker,tag=rpg_cag] at @s if entity @a[distance=..64] run function rpg:war/farm_fix
# v49 : [장비] 관리자 메뉴
execute as @a[scores={rpg.eqa=1..}] at @s run function rpg:dlg/h {f:"admin/eqa/route",lo:-9,hi:-9,ob:"rpg.eqa",tlo:-9,thi:-9}
# v51 : [아이템] 관리자 메뉴
execute as @a[scores={rpg.ita=1..}] at @s run function rpg:dlg/h {f:"admin/it/route",lo:-9,hi:-9,ob:"rpg.ita",tlo:-9,thi:-9}
execute as @a[nbt={DeathTime:1s}] run function rpg:hid/on_death
execute as @a[scores={rpg.h7t=1..}] at @s run function rpg:hid/tgt_set
execute as @a[scores={menu=1..}] at @s run function rpg:dlg/h {f:"menu/alias",lo:-9,hi:-9,ob:"menu",tlo:-9,thi:-9}
execute as @a[scores={rpg.up=1..}] at @s run function rpg:dlg/h2 {f:"stat/spend",r:"menu/stat"}
execute as @a[scores={rpg.tp=1..}] at @s run function rpg:dlg/h {f:"menu/tp_do",lo:-9,hi:-9,ob:"rpg.tp",tlo:-9,thi:-9}
execute as @a[scores={rpg.chk=1..}] at @s run function rpg:dlg/h {f:"money/issue",lo:-9,hi:-9,ob:"rpg.chk",tlo:-9,thi:-9}
execute as @a[scores={rpg.shop=1..}] at @s run function rpg:dlg/h {f:"shop/buy",lo:1,hi:3,ob:"rpg.shop",tlo:1,thi:99}
execute as @a[scores={rpg.cry=1..}] at @s run function rpg:dlg/h {f:"crystal/route",lo:4,hi:4,ob:"rpg.cry",tlo:1,thi:99}
execute as @a[scores={rpg.eq=1..}] at @s run function rpg:dlg/h {f:"equip/route",lo:12,hi:12,ob:"rpg.eq",tlo:1,thi:2147483647}
execute as @a[scores={rpg.q=1..}] at @s run function rpg:dlg/h {f:"quest/route",lo:-9,hi:-9,ob:"rpg.q",tlo:1,thi:1}
execute as @a[scores={rpg.auc=1..}] at @s run function rpg:dlg/h {f:"auc/route",lo:-9,hi:-9,ob:"rpg.auc",tlo:-9,thi:-9}
execute as @a[scores={rpg.nat=1..}] at @s run function rpg:dlg/h {f:"nation/route",lo:-9,hi:-9,ob:"rpg.nat",tlo:-9,thi:-9}
execute as @a[scores={rpg.vlt=1..}] at @s run function rpg:dlg/h {f:"vault/route",lo:-9,hi:-9,ob:"rpg.vlt",tlo:-9,thi:-9}
execute as @a[scores={rpg.rnd=1..}] at @s run function rpg:dlg/h {f:"round/route",lo:-9,hi:-9,ob:"rpg.rnd",tlo:-9,thi:-9}
execute as @a[scores={rpg.wmn=1..}] at @s run function rpg:dlg/h {f:"war/route",lo:-9,hi:-9,ob:"rpg.wmn",tlo:-9,thi:-9}
execute as @a[scores={rpg.wdc=1..}] at @s run function rpg:dlg/h {f:"war/route_dec",lo:-9,hi:-9,ob:"rpg.wdc",tlo:-9,thi:-9}
execute as @a[scores={rpg.npc=1..}] at @s run function rpg:dlg/h {f:"npc/route",lo:-9,hi:-9,ob:"rpg.npc",tlo:-9,thi:-9}
execute as @a[scores={rpg.enh=1..}] at @s run function rpg:dlg/h {f:"enh/route",lo:5,hi:5,ob:"rpg.enh",tlo:2,thi:9}
execute as @a[scores={rpg.mob=1..}] at @s run function rpg:dlg/h {f:"mob/route",lo:-9,hi:-9,ob:"rpg.mob",tlo:-9,thi:-9}
execute as @a[scores={rpg.mdr=1..}] at @s run function rpg:dlg/h {f:"mob/route_dr",lo:-9,hi:-9,ob:"rpg.mdr",tlo:-9,thi:-9}
execute as @a[scores={rpg.kw=1..}] at @s run function rpg:dlg/h {f:"kawa/route",lo:-9,hi:-9,ob:"rpg.kw",tlo:-9,thi:-9}
execute as @a[scores={rpg.fsh=1..}] at @s run function rpg:dlg/h {f:"fish/route",lo:10,hi:11,ob:"rpg.fsh",tlo:3,thi:5}
execute as @a[scores={rpg.wcs=1..}] at @s run function rpg:dlg/h {f:"war/route_cs",lo:-9,hi:-9,ob:"rpg.wcs",tlo:-9,thi:-9}
execute as @a[scores={rpg.wsh=1..}] at @s run function rpg:dlg/h {f:"war/route_sh",lo:6,hi:9,ob:"rpg.wsh",tlo:1,thi:99}
# 국가 신호기를 들고 있으면 보관 (우클릭하면 돌려주기 위해)
execute as @a if items entity @s weapon.mainhand minecraft:beacon[minecraft:custom_data~{rpg_nbeacon:1}] run function rpg:war/cs_hold
# 성 자리 미리보기
execute if score #g2 rpg.sys matches 0 as @a[tag=rpg_csprev] at @s run function rpg:war/cs_prev_tick
# 손에 든 물고기를 보관해 둔다 (우클릭하면 그대로 돌려주기 위해)
execute as @a if items entity @s weapon.mainhand #minecraft:fishes[minecraft:custom_data~{fishy:1}] run function rpg:fish/hold

# v40 : 당근 낚싯대 모양 아이템 (폭탄 · 국가 신호기 · 물고기)
execute as @a[scores={rpg.coas=1..}] at @s run function rpg:sys/coas
scoreboard players remove @a[scores={rpg.ucd=1..}] rpg.ucd 1
scoreboard players remove @a[scores={rpg.npcd=1..}] rpg.npcd 1
# v40 : 성 신호기 둘레 3x3 설치 금지 (2틱마다)
scoreboard players operation #g2 rpg.sys = #gtick rpg.sys
scoreboard players operation #g2 rpg.sys %= #k2 rpg.sys
execute if score #g2 rpg.sys matches 0 as @e[type=minecraft:marker,tag=rpg_cab] at @s run function rpg:war/np_chk
# 스킬 아이템 우클릭 (아이템은 소모되지 않고 자리에 그대로 남습니다)
# v51 · v56 : 뒤틀린 균류 낚싯대 스킬 아이템 (rpg.uleap) -> skill/use
tag @a[scores={rpg.uleap=1..}] add rpg_sku
# v57b : 제작자 Ctrl 스코어는 데이터팩이 건드리지 않음 (스킬 아이템은 rpg.uleap 로만 감지)
execute as @a[tag=rpg_sku] at @s run function rpg:skill/use
# v51 : PVP 평타 막기 (시선)
function rpg:pvp/tick
execute as @a[scores={rpg.ustun=1..}] at @s run function rpg:passive/use_stun
# v56 [타오르는 불꽃] 발동 중
execute as @a[scores={blaze-pas=2}] run function rpg:passive/blaze_tick
execute as @e[type=minecraft:interaction,tag=rpg_shop_potion] at @s if data entity @s interaction run function rpg:shop/potion_click
execute as @e[type=minecraft:interaction,tag=rpg_shop_potion2] at @s if data entity @s interaction run function rpg:shop/potion_click2
execute as @e[type=minecraft:interaction,tag=rpg_shop_potion3] at @s if data entity @s interaction run function rpg:shop/potion_click3
execute as @e[type=minecraft:interaction,tag=rpg_shop_crystal] at @s if data entity @s interaction run function rpg:crystal/click
execute as @e[type=minecraft:interaction,tag=rpg_shop_enh] at @s if data entity @s interaction run function rpg:enh/click
execute as @e[type=minecraft:interaction,tag=rpg_shop_rodenh] at @s if data entity @s interaction run function rpg:enh/rod_click
execute as @e[type=minecraft:interaction,tag=rpg_shop_siege] at @s if data entity @s interaction run function rpg:war/shop_siege_click
execute as @e[type=minecraft:interaction,tag=rpg_shop_build] at @s if data entity @s interaction run function rpg:war/shop_build_click
execute as @e[type=minecraft:interaction,tag=rpg_shop_supply] at @s if data entity @s interaction run function rpg:war/shop_supply_click
execute as @e[type=minecraft:interaction,tag=rpg_shop_war] at @s if data entity @s interaction run function rpg:war/shop_war_click
# v42 성 철문 비밀번호 · 신호기(맨손) · 치감 · 낚시 표식
execute as @e[type=minecraft:interaction,tag=rpg_cadoor] if data entity @s interaction at @s run function rpg:war/door_click
# v47 : 철문에서 멀어지면 비밀번호 입력 끝 (멀리서 못 맞추게)
execute as @a[scores={rpg.pwd=1..}] at @s run function rpg:war/pw_near
execute as @a[scores={rpg.pw=1..}] at @s run function rpg:war/pw_route
execute as @a[scores={rpg.pw=..-1}] at @s run function rpg:war/pw_route
execute as @a[tag=rpg_wadv,tag=!rpg_wbcn,gamemode=adventure] at @s if entity @e[type=minecraft:marker,tag=rpg_cab,distance=..7] run function rpg:war/bl_chk
execute as @a[tag=rpg_wbcn] at @s run function rpg:war/bl_chk
execute as @a[scores={rpg.bmn=1..}] at @s run function rpg:war/bcn_mined
scoreboard players remove @a[scores={rpg.cut=1..}] rpg.cut 1
execute if score #fbait rpg.sys matches 1.. run function rpg:fish/bait_clean
execute as @e[type=minecraft:interaction,tag=rpg_shop_fishrod] at @s if data entity @s interaction run function rpg:fish/rod_click
execute as @e[type=minecraft:interaction,tag=rpg_shop_fishbuy] at @s if data entity @s interaction run function rpg:fish/buy_click
execute as @e[type=minecraft:interaction,tag=rpg_shop_eq1] at @s if data entity @s interaction run function rpg:equip/click_str
execute as @e[type=minecraft:interaction,tag=rpg_shop_eq2] at @s if data entity @s interaction run function rpg:equip/click_dex
execute as @e[type=minecraft:interaction,tag=rpg_shop_eq3] at @s if data entity @s interaction run function rpg:equip/click_con
# v51 : 4~12월 장비 상인
execute as @e[type=minecraft:interaction,tag=rpg_shop_eq4] at @s if data entity @s interaction run function rpg:equip/click_str2
execute as @e[type=minecraft:interaction,tag=rpg_shop_eq5] at @s if data entity @s interaction run function rpg:equip/click_dex2
execute as @e[type=minecraft:interaction,tag=rpg_shop_eq6] at @s if data entity @s interaction run function rpg:equip/click_con2
execute as @e[type=minecraft:interaction,tag=rpg_q_elder] at @s if data entity @s interaction run function rpg:quest/click_elder
# v73 : 엑스트라 NPC (클릭 · 혼잣말 말풍선)
execute as @e[type=minecraft:interaction,tag=rpg_exm] at @s if data entity @s interaction run function rpg:npc/ex/click
function rpg:npc/ex/tick
execute as @e[type=minecraft:interaction,tag=rpg_q_dolsoi] at @s if data entity @s interaction run function rpg:quest/click_dolsoi
execute as @e[type=minecraft:interaction,tag=rpg_q_frog] at @s if data entity @s interaction run function rpg:quest/frog/click
execute as @e[type=minecraft:interaction,tag=rpg_q_slm] at @s if data entity @s interaction run function rpg:quest/slm/click
execute as @e[type=minecraft:interaction,tag=rpg_q_pur] at @s if data entity @s interaction run function rpg:quest/pur/click

# 사신수 무기 효과
execute as @e[tag=rpg_slash] at @s run function rpg:fx/sl_tick
execute as @e[tag=rpg_wave] at @s run function rpg:fx/wave_tick
execute as @e[tag=rpg_fw] at @s run function rpg:fx/fw_tick
execute as @e[tag=rpg_dot] at @s run function rpg:api/dot_tick
# 스킬 데미지 "잠깐 무적" 감소
execute as @e[tag=rpg_iv] run function rpg:api/iv_tick
function rpg:beast/tick

# 몬스터 사망 처리 / 경험치 조각 흡수
# v39 : 가짜 피 (진짜 피 1024 는 매 틱 다시 채움)
scoreboard players add #gtick rpg.sys 1
execute as @e[tag=rpg_mob,tag=!rpg_dead,tag=!rpg_fdie] at @s run function rpg:mob/fhp
# v39 : 죽는 중인 몹은 @e 로 안 잡혀서, 몹에 탄 이름표에서 거꾸로 찾는다 (이번 틱에 살아서 처리 안 된 몹 = 죽음)
execute as @e[type=minecraft:text_display,tag=rpg_mtext] on vehicle if entity @s[tag=rpg_mob,tag=!rpg_dead] unless score @s rpg.mlt = #gtick rpg.sys at @s run function rpg:mob/on_death
execute as @e[tag=rpg_expchick,tag=!rpg_dead,nbt={DeathTime:1s}] at @s run function rpg:quest/chick_death
execute as @e[type=minecraft:item,nbt={Item:{components:{"minecraft:custom_data":{rpg_exp:1}}}}] at @s if entity @a[distance=..2,gamemode=!spectator] run function rpg:exp/shard_take
execute as @e[type=minecraft:item,nbt={Item:{components:{"minecraft:custom_data":{rpg_exp:1b}}}}] at @s if entity @a[distance=..2,gamemode=!spectator] run function rpg:exp/shard_take

# 몹 처치 경험치
execute as @a[scores={rpg.kill=1..}] at @s run function rpg:exp/on_kill
# v41 : 나눠 주는 회복 (한 틱에 한 덩어리)
execute as @a[scores={rpg.hq=1..}] run function rpg:util/heal_step
# v47 : 1 단위 회복 (재생 VI) · 끝나면 재생 지움
execute as @a[tag=rpg_rgn] unless score @s rpg.hr1 matches 1.. run function rpg:util/heal_rend
execute as @a[scores={rpg.hr1=1..}] run function rpg:util/heal_r
# v41 : 이번 틱에 얻은 몹 경험치를 한 줄로  [XP]+10
execute as @a[scores={rpg.xpp=1..}] at @s run function rpg:exp/xp_flush

# v46 : 죽음 표시 (rpg_died · untag_dead 명령어용)
execute as @a[scores={rpg.dct=1..}] run function rpg:core/died_mark
execute as @a[tag=rpg_died] run function rpg:core/died_tick
# 사망 -> 리스폰 감지
execute as @a[scores={rpg.hp=0}] run scoreboard players set @s rpg.resp 1
execute as @a[scores={rpg.hp=1..,rpg.resp=1}] at @s run function rpg:core/respawn

execute as @e[tag=rpg_stunned] run function rpg:passive/stun_tick

# 전투 / 패시브
function rpg:combat/tick
# v44 : 버프 · 전투태세 · 출혈
function rpg:buff/tick
function rpg:stance/tick
# v45 : 공격 무시 · 봉인 · 스턴 · 은신 · 데미지 숫자
function rpg:ign/tick
function rpg:seal/tick
function rpg:stun/tick
function rpg:stl/tick
function rpg:dmgn/tick
function rpg:bleed/tick
# v47 : 띄우기
function rpg:lift/tick
# v58 : CC 기 · 뱀 스킬 · 악마의 힘 · 스킬 키 · 좌클릭 · 스킬 지속 파티클
function rpg:cc/tick
execute as @e[type=minecraft:marker,tag=rpg_sna] at @s run function rpg:fx/snk_tick
function rpg:skill/v58_tick
# v59 : 전직 NPC · 퀘스트
function rpg:job/tick
# v60 : NPC 바라보기 · 럭키 펀치 · 히든 책 등
function rpg:sys/v60_tick
function rpg:sys/v61_tick
# v59 : 런치 대쉬 (launch-command 모드)
execute as @e[tag=rpg_ln] at @s run function rpg:fx/ln_tick
# v46 : rpg:api/bolt 번개 정리 · 도는 파티클
execute as @e[type=minecraft:lightning_bolt,tag=rpg_bolt] run function rpg:api/bolt_tick
execute as @e[type=minecraft:marker,tag=rpg_orb] run function rpg:fx/orb_tick

scoreboard players add #timer rpg.sys 1
execute if score #timer rpg.sys matches 5 run function rpg:hud/all
execute if score #timer rpg.sys matches 10.. run function rpg:core/slow_tick

# 몬스터 애니메이션 / 보스 돌 투사체
execute as @e[type=minecraft:item_display,tag=rpg_rock] at @s run function rpg:mob/rock_tick
# v48 : 돌을 좌클릭하면 부서짐 · v49 : 판은 돌 앞쪽에 크게 · 시간 지나면 정리
execute as @e[type=minecraft:interaction,tag=rpg_rocki] if data entity @s attack run function rpg:mob/rock_break
execute as @e[type=minecraft:interaction,tag=rpg_rocki] run function rpg:mob/rocki_tick
# v41 : 총든 해적 총알 / 화살 -> 총알 / 죽은 몹 경험치 구슬 치우기
execute as @e[type=minecraft:arrow,tag=!rpg_arw] run function rpg:mob/arrow_chk
execute as @e[type=minecraft:block_display,tag=rpg_bul] at @s run function rpg:mob/bul_tick
execute as @e[type=minecraft:marker,tag=rpg_xpk] at @s run function rpg:mob/xpk_tick
# v47 : 몬스터 리그 (모델 조각 · 애니메이션 · 손맛) — 맞아서 전투 상태(12초)는 mob/fhp_dmg 가 처리
function rpg:rig/tick

# 몬스터 스포너 (1초마다)
scoreboard players add #mtimer rpg.sys 1
execute if score #mtimer rpg.sys matches 20.. run function rpg:mob/tick

# C+C (뒤틀린 균류 낚싯대 더블 웅크리기 · v56) / 비행 / 경매
function rpg:sys/cc_tick
function rpg:sys/fly_tick
function rpg:auc/tick
scoreboard players add #auctm rpg.sys 1
function rpg:round/tick
function rpg:war/tick
# v56 : 철문에 붙은 폭탄 (3초 뒤 폭발)
execute as @e[type=minecraft:marker,tag=rpg_bfuse] at @s run function rpg:war/bomb_fuse
execute if score #auctm rpg.sys matches 20.. run function rpg:auc/sec
execute if score #auctm rpg.sys matches 20.. run function rpg:round/sec
execute if score #auctm rpg.sys matches 20.. run function rpg:war/sec
# v51 : PVP · 경험치 x2 남은 시간
execute if score #auctm rpg.sys matches 20.. run function rpg:pvp/sec
execute if score #auctm rpg.sys matches 20.. run scoreboard players set #auctm rpg.sys 0

# 국가 / 창고 / 사망 소지금 봉투
function rpg:money/pouch_tick
execute as @e[tag=rpg_vbar] at @s run function rpg:vault/bar_tick
scoreboard players add #dthtm rpg.sys 1
execute if score #dthtm rpg.sys matches 20.. run function rpg:money/death_tick
execute if score #dthtm rpg.sys matches 20.. run function rpg:sys/name_tick
execute if score #dthtm rpg.sys matches 20.. run scoreboard players set #dthtm rpg.sys 0
# 카와의 명작 3D 갑옷을 몸에 붙인다
function rpg:kawa/tick
execute if score #kwtm rpg.sys matches 10 run function rpg:kawa/wear
execute if score #kwtm rpg.sys matches 60 run function rpg:kawa/wear

# 카와의 명작 복제본 정리 (5초마다)
scoreboard players add #kwtm rpg.sys 1
# v57 : 카와 복제본 정리(부위당 1개) 없앰 — 여러 개 꺼낼 수 있게
# execute if score #kwtm rpg.sys matches 100.. run function rpg:kawa/sweep
execute if score #kwtm rpg.sys matches 100.. run scoreboard players set #kwtm rpg.sys 0

# 히든 패시브 1초 처리
execute if score #htimer rpg.sys matches 20.. run function rpg:hid/sec_go
scoreboard players add #htimer rpg.sys 1

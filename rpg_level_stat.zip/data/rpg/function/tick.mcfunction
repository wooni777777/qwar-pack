# 메뉴 / 스탯 투자 트리거 처리
execute as @a[scores={rpg.menu=1..}] at @s run function rpg:menu/route
execute as @a[nbt={DeathTime:1s}] run function rpg:hid/on_death
execute as @a[scores={rpg.h7t=1..}] at @s run function rpg:hid/tgt_set
execute as @a[scores={menu=1..}] at @s run function rpg:menu/alias
execute as @a[scores={rpg.up=1..}] at @s run function rpg:stat/spend
execute as @a[scores={rpg.tp=1..}] at @s run function rpg:menu/tp_do
execute as @a[scores={rpg.chk=1..}] at @s run function rpg:money/issue
execute as @a[scores={rpg.shop=1..}] at @s run function rpg:shop/buy
execute as @a[scores={rpg.cry=1..}] at @s run function rpg:crystal/route
execute as @a[scores={rpg.eq=1..}] at @s run function rpg:equip/route
execute as @a[scores={rpg.q=1..}] at @s run function rpg:quest/route
execute as @a[scores={rpg.auc=1..}] at @s run function rpg:auc/route
execute as @a[scores={rpg.nat=1..}] at @s run function rpg:nation/route
execute as @a[scores={rpg.vlt=1..}] at @s run function rpg:vault/route
execute as @a[scores={rpg.rnd=1..}] at @s run function rpg:round/route
execute as @a[scores={rpg.wmn=1..}] at @s run function rpg:war/route
execute as @a[scores={rpg.wdc=1..}] at @s run function rpg:war/route_dec
execute as @a[scores={rpg.npc=1..}] at @s run function rpg:npc/route
execute as @a[scores={rpg.enh=1..}] at @s run function rpg:enh/route
execute as @a[scores={rpg.mob=1..}] at @s run function rpg:mob/route
execute as @a[scores={rpg.mdr=1..}] at @s run function rpg:mob/route_dr
execute as @a[scores={rpg.kw=1..}] at @s run function rpg:kawa/route
execute as @a[scores={rpg.fsh=1..}] at @s run function rpg:fish/route
execute as @a[scores={rpg.wcs=1..}] at @s run function rpg:war/route_cs
execute as @a[scores={rpg.wsh=1..}] at @s run function rpg:war/route_sh
# 국가 신호기를 들고 있으면 보관 (우클릭하면 돌려주기 위해)
execute as @a if items entity @s weapon.mainhand minecraft:beacon[minecraft:custom_data~{rpg_nbeacon:1}] run function rpg:war/cs_hold
# 성 자리 미리보기
execute if score #g2 rpg.sys matches 0 as @a[tag=rpg_csprev] at @s run function rpg:war/cs_prev_tick
# 손에 든 물고기를 보관해 둔다 (우클릭하면 그대로 돌려주기 위해)
execute as @a if items entity @s weapon.mainhand #minecraft:fishes[minecraft:custom_data~{fishy:1}] run function rpg:fish/hold

# v40 : 당근 낚싯대 모양 아이템 (폭탄 · 국가 신호기 · 물고기)
execute as @a[scores={rpg.coas=1..}] at @s run function rpg:sys/coas
scoreboard players remove @a[scores={rpg.ucd=1..}] rpg.ucd 1
scoreboard players remove @a[scores={rpg.npcd=1..}] rpg.npcd 1
# v40 : 성 신호기 둘레 3x3 설치 금지 (2틱마다)
scoreboard players operation #g2 rpg.sys = #gtick rpg.sys
scoreboard players operation #g2 rpg.sys %= #k2 rpg.sys
execute if score #g2 rpg.sys matches 0 as @e[type=minecraft:marker,tag=rpg_cab] at @s run function rpg:war/np_chk
# 스킬 아이템 우클릭 (아이템은 소모되지 않고 자리에 그대로 남습니다)
execute as @a[scores={rpg.uleap=1..}] at @s run function rpg:passive/use_leap
execute as @a[scores={rpg.ustun=1..}] at @s run function rpg:passive/use_stun
execute as @e[type=minecraft:interaction,tag=rpg_shop_potion] at @s if data entity @s interaction run function rpg:shop/potion_click
execute as @e[type=minecraft:interaction,tag=rpg_shop_potion2] at @s if data entity @s interaction run function rpg:shop/potion_click2
execute as @e[type=minecraft:interaction,tag=rpg_shop_crystal] at @s if data entity @s interaction run function rpg:crystal/click
execute as @e[type=minecraft:interaction,tag=rpg_shop_enh] at @s if data entity @s interaction run function rpg:enh/click
execute as @e[type=minecraft:interaction,tag=rpg_shop_rodenh] at @s if data entity @s interaction run function rpg:enh/rod_click
execute as @e[type=minecraft:interaction,tag=rpg_shop_siege] at @s if data entity @s interaction run function rpg:war/shop_siege_click
execute as @e[type=minecraft:interaction,tag=rpg_shop_build] at @s if data entity @s interaction run function rpg:war/shop_build_click
execute as @e[type=minecraft:interaction,tag=rpg_shop_supply] at @s if data entity @s interaction run function rpg:war/shop_supply_click
execute as @e[type=minecraft:interaction,tag=rpg_shop_war] at @s if data entity @s interaction run function rpg:war/shop_war_click
execute as @e[type=minecraft:interaction,tag=rpg_shop_fishrod] at @s if data entity @s interaction run function rpg:fish/rod_click
execute as @e[type=minecraft:interaction,tag=rpg_shop_fishbuy] at @s if data entity @s interaction run function rpg:fish/buy_click
execute as @e[type=minecraft:interaction,tag=rpg_shop_eq1] at @s if data entity @s interaction run function rpg:equip/click_str
execute as @e[type=minecraft:interaction,tag=rpg_shop_eq2] at @s if data entity @s interaction run function rpg:equip/click_dex
execute as @e[type=minecraft:interaction,tag=rpg_shop_eq3] at @s if data entity @s interaction run function rpg:equip/click_con
execute as @e[type=minecraft:interaction,tag=rpg_q_elder] at @s if data entity @s interaction run function rpg:quest/click_elder
execute as @e[type=minecraft:interaction,tag=rpg_q_dolsoi] at @s if data entity @s interaction run function rpg:quest/click_dolsoi

# 사신수 무기 효과
execute as @e[tag=rpg_slash] at @s run function rpg:fx/sl_tick
execute as @e[tag=rpg_wave] at @s run function rpg:fx/wave_tick
execute as @e[tag=rpg_fw] at @s run function rpg:fx/fw_tick
execute as @e[tag=rpg_dot] at @s run function rpg:api/dot_tick
# 스킬 데미지 "잠깐 무적" 감소
execute as @e[tag=rpg_iv] run function rpg:api/iv_tick
function rpg:beast/tick

# 몬스터 사망 처리 / 경험치 조각 흡수
# v39 : 가짜 피 (진짜 피 1024 는 매 틱 다시 채움)
scoreboard players add #gtick rpg.sys 1
execute as @e[tag=rpg_mob,tag=!rpg_dead,tag=!rpg_fdie] at @s run function rpg:mob/fhp
# v39 : 죽는 중인 몹은 @e 로 안 잡혀서, 몹에 탄 이름표에서 거꾸로 찾는다 (이번 틱에 살아서 처리 안 된 몹 = 죽음)
execute as @e[type=minecraft:text_display,tag=rpg_mtext] on vehicle if entity @s[tag=rpg_mob,tag=!rpg_dead] unless score @s rpg.mlt = #gtick rpg.sys at @s run function rpg:mob/on_death
execute as @e[tag=rpg_expchick,tag=!rpg_dead,nbt={DeathTime:1s}] at @s run function rpg:quest/chick_death
execute as @e[type=minecraft:item,nbt={Item:{components:{"minecraft:custom_data":{rpg_exp:1}}}}] at @s if entity @a[distance=..2,gamemode=!spectator] run function rpg:exp/shard_take

# 몹 처치 경험치
execute as @a[scores={rpg.kill=1..}] at @s run function rpg:exp/on_kill

# 사망 -> 리스폰 감지
execute as @a[scores={rpg.hp=0}] run scoreboard players set @s rpg.resp 1
execute as @a[scores={rpg.hp=1..,rpg.resp=1}] at @s run function rpg:core/respawn

execute as @e[tag=rpg_stunned] run function rpg:passive/stun_tick

# 전투 / 패시브
function rpg:combat/tick

scoreboard players add #timer rpg.sys 1
execute if score #timer rpg.sys matches 5 run function rpg:hud/all
execute if score #timer rpg.sys matches 10.. run function rpg:core/slow_tick

# 몬스터 애니메이션 / 보스 돌 투사체
execute as @e[type=minecraft:item_display,tag=rpg_rock] at @s run function rpg:mob/rock_tick
execute as @e[tag=rpg_atk] run function rpg:mob/anim_tick
# 몬스터 모델을 실체가 보는 방향으로 (v35)
execute as @e[tag=rpg_mob,tag=!rpg_dead] run function rpg:mob/face
# 맞은 몬스터는 12초간 전투 상태 (그동안은 스폰 지점으로 안 끌려갑니다)
execute as @e[tag=rpg_mob,tag=!rpg_dead,nbt={HurtTime:10s}] run scoreboard players set @s rpg.cbt 12
scoreboard players add #anim rpg.sys 1
execute if score #anim rpg.sys matches 9 run function rpg:mob/anim_a
execute if score #anim rpg.sys matches 18.. run function rpg:mob/anim_b

# 몬스터 스포너 (1초마다)
scoreboard players add #mtimer rpg.sys 1
execute if score #mtimer rpg.sys matches 20.. run function rpg:mob/tick

# C+C (당근 낚싯대 더블 웅크리기) / 비행 / 경매
function rpg:sys/cc_tick
function rpg:sys/fly_tick
function rpg:auc/tick
scoreboard players add #auctm rpg.sys 1
function rpg:round/tick
function rpg:war/tick
execute if score #auctm rpg.sys matches 20.. run function rpg:auc/sec
execute if score #auctm rpg.sys matches 20.. run function rpg:round/sec
execute if score #auctm rpg.sys matches 20.. run function rpg:war/sec
execute if score #auctm rpg.sys matches 20.. run scoreboard players set #auctm rpg.sys 0

# 국가 / 창고 / 사망 소지금 봉투
function rpg:money/pouch_tick
execute as @e[tag=rpg_vbar] at @s run function rpg:vault/bar_tick
scoreboard players add #dthtm rpg.sys 1
execute if score #dthtm rpg.sys matches 20.. run function rpg:money/death_tick
execute if score #dthtm rpg.sys matches 20.. run function rpg:sys/name_tick
execute if score #dthtm rpg.sys matches 20.. run scoreboard players set #dthtm rpg.sys 0
# 카와의 명작 3D 갑옷을 몸에 붙인다
function rpg:kawa/tick
execute if score #kwtm rpg.sys matches 10 run function rpg:kawa/wear
execute if score #kwtm rpg.sys matches 60 run function rpg:kawa/wear

# 카와의 명작 복제본 정리 (5초마다)
scoreboard players add #kwtm rpg.sys 1
execute if score #kwtm rpg.sys matches 100.. run function rpg:kawa/sweep
execute if score #kwtm rpg.sys matches 100.. run scoreboard players set #kwtm rpg.sys 0

# 히든 패시브 1초 처리
execute if score #htimer rpg.sys matches 20.. run function rpg:hid/sec_go
scoreboard players add #htimer rpg.sys 1

# ============================================================
#  RPG 레벨/스탯 시스템 - 스코어보드 등록
# ============================================================
scoreboard objectives add rpg.lv dummy {"text":"레벨","color":"gold"}
scoreboard objectives add rpg.exp dummy {"text":"경험치","color":"green"}
scoreboard objectives add rpg.need dummy {"text":"필요 경험치","color":"dark_green"}
scoreboard objectives add rpg.sp dummy {"text":"자유 스탯","color":"yellow"}
scoreboard objectives add rpg.str dummy {"text":"힘","color":"red"}
scoreboard objectives add rpg.dex dummy {"text":"민첩","color":"aqua"}
scoreboard objectives add rpg.con dummy {"text":"체력","color":"green"}

# 표시용(계산 결과) - 패시브 조건 판정에 그대로 써도 됩니다
scoreboard objectives add rpg.d_atk dummy {"text":"총 공격력","color":"red"}
scoreboard objectives add rpg.d_hp dummy {"text":"총 최대체력","color":"green"}
scoreboard objectives add rpg.d_spd dummy {"text":"이동속도(%)","color":"aqua"}
scoreboard objectives add rpg.d_cur dummy {"text":"현재 체력","color":"red"}
scoreboard objectives add rpg.d_max dummy {"text":"최대 체력","color":"red"}

# 내부용
scoreboard objectives add rpg.t_atk dummy
scoreboard objectives add rpg.t_hp dummy
scoreboard objectives add rpg.t_spd dummy
scoreboard objectives add rpg.a_atk dummy
scoreboard objectives add rpg.a_hp dummy
scoreboard objectives add rpg.a_spd dummy
scoreboard objectives add rpg.dirty dummy
scoreboard objectives add rpg.slot dummy
scoreboard objectives add rpg.init dummy
scoreboard objectives add rpg.resp dummy
scoreboard objectives add rpg.xpo dummy
scoreboard objectives add rpg.bid dummy
scoreboard objectives add rpg.a_cur dummy
scoreboard objectives add rpg.a_max dummy
scoreboard objectives add rpg.a_exp dummy
scoreboard objectives add rpg.a_sp dummy
scoreboard objectives add rpg.php dummy
scoreboard objectives add rpg.cbt dummy
scoreboard objectives add rpg.hcd dummy
scoreboard objectives add rpg.combo dummy
scoreboard objectives add rpg.cmbt dummy
scoreboard objectives add rpg.stun dummy
scoreboard objectives add rpg.rage dummy
scoreboard objectives add rpg.hide dummy
scoreboard objectives add rpg.will dummy
scoreboard objectives add rpg.leap dummy
scoreboard objectives add rpg.regen dummy
scoreboard objectives add rpg.pid dummy
scoreboard objectives add rpg.rev dummy
scoreboard objectives add rpg.revt dummy
scoreboard objectives add rpg.cd60 dummy
scoreboard objectives add rpg.cd900 dummy
scoreboard objectives add rpg.p_atk dummy
scoreboard objectives add rpg.p_hp dummy
scoreboard objectives add rpg.p_spd dummy
scoreboard objectives add rpg.p_mul dummy
scoreboard objectives add rpg.war dummy
scoreboard objectives add rpg.busy dummy
scoreboard objectives add rpg.grace dummy
scoreboard objectives add rpg.tmax dummy {"text":"최대 체력","color":"red"}
scoreboard objectives add rpg.hpnow dummy {"text":"현재 체력","color":"red"}
scoreboard objectives add rpg.absorb dummy
scoreboard objectives add rpg.lastdmg dummy
scoreboard objectives add rpg.hpsc dummy
scoreboard objectives add rpg.crit dummy {"text":"크리티컬(1000분율)","color":"red"}
scoreboard objectives add rpg.cmb2 dummy
scoreboard objectives add rpg.cdw dummy
scoreboard objectives add rpg.revcd dummy
scoreboard objectives add rpg.sys dummy
scoreboard objectives add rpg.mig dummy
scoreboard objectives add rpg.lcd dummy
scoreboard objectives add rpg.scd dummy
scoreboard objectives add rpg.uleap minecraft.used:minecraft.warped_fungus_on_a_stick
scoreboard objectives add rpg.ustun minecraft.used:minecraft.warped_fungus_on_a_stick
scoreboard objectives add rpg.sid dummy
scoreboard objectives add rpg.cd dummy
scoreboard objectives add rpg.anim dummy
scoreboard objectives add rpg.shopt dummy
scoreboard objectives add rpg.stunt dummy
scoreboard objectives add rpg.q_tuto dummy {"text":"튜토리얼 퀘스트","color":"yellow"}
scoreboard objectives add rpg.q_main dummy {"text":"메인 퀘스트","color":"yellow"}
scoreboard objectives add rpg.qc dummy {"text":"퀘스트 진행도","color":"yellow"}
scoreboard objectives add rpg.q trigger
scoreboard objectives add rpg.menu trigger
scoreboard objectives add rpg.up trigger
scoreboard objectives add rpg.tp trigger
scoreboard objectives add money dummy {"text": " 소지금", "color": "gold", "bold": true}
scoreboard objectives add rpg.chk trigger
scoreboard objectives add rpg.shop trigger
scoreboard objectives add rpg.cry trigger
scoreboard objectives add rpg.eq trigger
scoreboard objectives add rpg.eqs dummy
scoreboard objectives add rpg.eqt dummy
# 구버전 팀/개인 사이드바 정리 (닉네임 색이 팀 색으로 바뀌던 문제)
scoreboard objectives setdisplay sidebar.team.black
team remove rpg.s0
scoreboard objectives remove rpg.m0
scoreboard objectives setdisplay sidebar.team.dark_blue
team remove rpg.s1
scoreboard objectives remove rpg.m1
scoreboard objectives setdisplay sidebar.team.dark_green
team remove rpg.s2
scoreboard objectives remove rpg.m2
scoreboard objectives setdisplay sidebar.team.dark_aqua
team remove rpg.s3
scoreboard objectives remove rpg.m3
scoreboard objectives setdisplay sidebar.team.dark_red
team remove rpg.s4
scoreboard objectives remove rpg.m4
scoreboard objectives setdisplay sidebar.team.dark_purple
team remove rpg.s5
scoreboard objectives remove rpg.m5
scoreboard objectives setdisplay sidebar.team.gold
team remove rpg.s6
scoreboard objectives remove rpg.m6
scoreboard objectives setdisplay sidebar.team.gray
team remove rpg.s7
scoreboard objectives remove rpg.m7
scoreboard objectives setdisplay sidebar.team.dark_gray
team remove rpg.s8
scoreboard objectives remove rpg.m8
scoreboard objectives setdisplay sidebar.team.blue
team remove rpg.s9
scoreboard objectives remove rpg.m9
scoreboard objectives setdisplay sidebar.team.green
team remove rpg.s10
scoreboard objectives remove rpg.m10
scoreboard objectives setdisplay sidebar.team.aqua
team remove rpg.s11
scoreboard objectives remove rpg.m11
scoreboard objectives setdisplay sidebar.team.red
team remove rpg.s12
scoreboard objectives remove rpg.m12
scoreboard objectives setdisplay sidebar.team.light_purple
team remove rpg.s13
scoreboard objectives remove rpg.m13
scoreboard objectives setdisplay sidebar.team.yellow
team remove rpg.s14
scoreboard objectives remove rpg.m14
scoreboard objectives setdisplay sidebar.team.white
team remove rpg.s15
scoreboard objectives remove rpg.m15
scoreboard objectives setdisplay sidebar
scoreboard objectives add menu trigger {"text":"메뉴 열기"}
scoreboard objectives add C+C dummy {"text":"C+C","color":"aqua"}
scoreboard objectives add fly dummy {"text":"비행","color":"aqua"}
scoreboard objectives add rpg.cct dummy
scoreboard objectives add rpg.snkS dummy
scoreboard objectives add rpg.snkP dummy
scoreboard objectives add rpg.snkN dummy
scoreboard objectives add rpg.snkT dummy
scoreboard objectives add rpg.grav dummy
scoreboard objectives add rpg.auc trigger
scoreboard objectives add rpg.abidi dummy
scoreboard objectives add rpg.abidv dummy
scoreboard objectives add rpg.aminv dummy
scoreboard objectives add rpg.asort dummy
scoreboard objectives add rpg.abid1 dummy
scoreboard objectives add rpg.abid2 dummy
scoreboard objectives add rpg.abid3 dummy
scoreboard objectives add rpg.abid4 dummy
scoreboard objectives add rpg.abidL dummy
scoreboard objectives add rpg.qcat dummy
scoreboard objectives add rpg.qord dummy
scoreboard objectives add rpg.qo1 dummy
scoreboard objectives add rpg.qo2 dummy
scoreboard objectives add rpg.pow dummy
scoreboard objectives add rpg.def dummy {"text":"방어력","color":"aqua"}
scoreboard objectives add rpg.d_def dummy {"text":"피해 경감(%)","color":"aqua"}
scoreboard objectives add rpg.rnd trigger
scoreboard objectives add rpg.npc trigger
scoreboard objectives add rpg.enh trigger
scoreboard objectives add rpg.enhM dummy
scoreboard objectives add rpg.spD dummy
scoreboard objectives add rpg.spL dummy
scoreboard objectives add rpg.spDu dummy
scoreboard objectives add rpg.spLu dummy
scoreboard objectives add rpg.dsh dummy
scoreboard objectives add rpg.dshp dummy
scoreboard objectives add rpg.dshv dummy
scoreboard objectives add rpg.dshf dummy
scoreboard objectives add rpg.dshl dummy
scoreboard objectives add rpg.fxi dummy
scoreboard objectives add rpg.h7t trigger
scoreboard objectives add rpg.h1 dummy
scoreboard objectives add rpg.h1c dummy
scoreboard objectives add rpg.h5 dummy
scoreboard objectives add rpg.h5c dummy
scoreboard objectives add rpg.h6t dummy
scoreboard objectives add rpg.h6s dummy
scoreboard objectives add rpg.h7cd dummy
scoreboard objectives add rpg.h15 dummy
scoreboard objectives add rpg.h15t dummy
scoreboard objectives add rpg.h18cd dummy
scoreboard objectives add rpg.hdead dummy
scoreboard objectives add rpg.h7id dummy
scoreboard objectives add rpg.h7set dummy
scoreboard objectives add rpg.h7cd dummy
scoreboard objectives add rpg.fxs dummy
scoreboard objectives add rpg.nat trigger
scoreboard objectives add rpg.natn dummy {"text":"국가","color":"white"}
scoreboard objectives add rpg.vlt trigger
scoreboard objectives add rpg.bills dummy
scoreboard objectives add rpg.nmok dummy
scoreboard objectives add rpg.nmt dummy
scoreboard objectives add rpg.deaths minecraft.custom:minecraft.deaths
scoreboard objectives add rpg.kill minecraft.custom:minecraft.mob_kills
scoreboard objectives add rpg.pkT dummy
scoreboard objectives add rpg.pkF dummy
scoreboard objectives add rpg.mob trigger
scoreboard objectives add rpg.mdr trigger
execute unless score #mlv_ddol rpg.sys matches 1.. run scoreboard players set #mlv_ddol rpg.sys 1
execute unless score #mlv_ddodol rpg.sys matches 1.. run scoreboard players set #mlv_ddodol rpg.sys 3
execute unless score #mlv_dolmengi rpg.sys matches 1.. run scoreboard players set #mlv_dolmengi rpg.sys 5
execute unless score #mlv_dol rpg.sys matches 1.. run scoreboard players set #mlv_dol rpg.sys 10
execute unless score #mlv_wolf rpg.sys matches 1.. run scoreboard players set #mlv_wolf rpg.sys 15
execute unless score #mlv_pir1 rpg.sys matches 1.. run scoreboard players set #mlv_pir1 rpg.sys 8
execute unless score #mlv_pir2 rpg.sys matches 1.. run scoreboard players set #mlv_pir2 rpg.sys 10
execute unless score #mlv_pir3 rpg.sys matches 1.. run scoreboard players set #mlv_pir3 rpg.sys 9
execute unless score #mlv_pking rpg.sys matches 1.. run scoreboard players set #mlv_pking rpg.sys 20
# ── 보스 드롭 슬롯 기본값 (v35) ──
execute unless score #dsd1k rpg.sys matches -2147483648.. run scoreboard players set #dsd1k rpg.sys 4
execute unless score #dsd1v rpg.sys matches -2147483648.. run scoreboard players set #dsd1v rpg.sys 1
execute unless score #dsd1n rpg.sys matches -2147483648.. run scoreboard players set #dsd1n rpg.sys 1
execute unless score #dsd1p rpg.sys matches -2147483648.. run scoreboard players set #dsd1p rpg.sys 100
execute unless score #dsd2k rpg.sys matches -2147483648.. run scoreboard players set #dsd2k rpg.sys 4
execute unless score #dsd2v rpg.sys matches -2147483648.. run scoreboard players set #dsd2v rpg.sys 2
execute unless score #dsd2n rpg.sys matches -2147483648.. run scoreboard players set #dsd2n rpg.sys 30
execute unless score #dsd2p rpg.sys matches -2147483648.. run scoreboard players set #dsd2p rpg.sys 100
execute unless score #dsd3k rpg.sys matches -2147483648.. run scoreboard players set #dsd3k rpg.sys 3
execute unless score #dsd3v rpg.sys matches -2147483648.. run scoreboard players set #dsd3v rpg.sys 1
execute unless score #dsd3n rpg.sys matches -2147483648.. run scoreboard players set #dsd3n rpg.sys 2
execute unless score #dsd3p rpg.sys matches -2147483648.. run scoreboard players set #dsd3p rpg.sys 100
execute unless score #dsd4k rpg.sys matches -2147483648.. run scoreboard players set #dsd4k rpg.sys 3
execute unless score #dsd4v rpg.sys matches -2147483648.. run scoreboard players set #dsd4v rpg.sys 1
execute unless score #dsd4n rpg.sys matches -2147483648.. run scoreboard players set #dsd4n rpg.sys 1
execute unless score #dsd4p rpg.sys matches -2147483648.. run scoreboard players set #dsd4p rpg.sys 20
execute unless score #dsd5k rpg.sys matches -2147483648.. run scoreboard players set #dsd5k rpg.sys 1
execute unless score #dsd5v rpg.sys matches -2147483648.. run scoreboard players set #dsd5v rpg.sys 3
execute unless score #dsd5n rpg.sys matches -2147483648.. run scoreboard players set #dsd5n rpg.sys 2
execute unless score #dsd5p rpg.sys matches -2147483648.. run scoreboard players set #dsd5p rpg.sys 100
execute unless score #dsd6k rpg.sys matches -2147483648.. run scoreboard players set #dsd6k rpg.sys 1
execute unless score #dsd6v rpg.sys matches -2147483648.. run scoreboard players set #dsd6v rpg.sys 2
execute unless score #dsd6n rpg.sys matches -2147483648.. run scoreboard players set #dsd6n rpg.sys 5
execute unless score #dsd6p rpg.sys matches -2147483648.. run scoreboard players set #dsd6p rpg.sys 100
execute unless score #dsd7k rpg.sys matches -2147483648.. run scoreboard players set #dsd7k rpg.sys 0
execute unless score #dsd7v rpg.sys matches -2147483648.. run scoreboard players set #dsd7v rpg.sys 1
execute unless score #dsd7n rpg.sys matches -2147483648.. run scoreboard players set #dsd7n rpg.sys 0
execute unless score #dsd7p rpg.sys matches -2147483648.. run scoreboard players set #dsd7p rpg.sys 0
execute unless score #dsd8k rpg.sys matches -2147483648.. run scoreboard players set #dsd8k rpg.sys 0
execute unless score #dsd8v rpg.sys matches -2147483648.. run scoreboard players set #dsd8v rpg.sys 1
execute unless score #dsd8n rpg.sys matches -2147483648.. run scoreboard players set #dsd8n rpg.sys 0
execute unless score #dsd8p rpg.sys matches -2147483648.. run scoreboard players set #dsd8p rpg.sys 0
execute unless score #dsw1k rpg.sys matches -2147483648.. run scoreboard players set #dsw1k rpg.sys 4
execute unless score #dsw1v rpg.sys matches -2147483648.. run scoreboard players set #dsw1v rpg.sys 1
execute unless score #dsw1n rpg.sys matches -2147483648.. run scoreboard players set #dsw1n rpg.sys 3
execute unless score #dsw1p rpg.sys matches -2147483648.. run scoreboard players set #dsw1p rpg.sys 100
execute unless score #dsw2k rpg.sys matches -2147483648.. run scoreboard players set #dsw2k rpg.sys 4
execute unless score #dsw2v rpg.sys matches -2147483648.. run scoreboard players set #dsw2v rpg.sys 1
execute unless score #dsw2n rpg.sys matches -2147483648.. run scoreboard players set #dsw2n rpg.sys 1
execute unless score #dsw2p rpg.sys matches -2147483648.. run scoreboard players set #dsw2p rpg.sys 30
execute unless score #dsw3k rpg.sys matches -2147483648.. run scoreboard players set #dsw3k rpg.sys 1
execute unless score #dsw3v rpg.sys matches -2147483648.. run scoreboard players set #dsw3v rpg.sys 4
execute unless score #dsw3n rpg.sys matches -2147483648.. run scoreboard players set #dsw3n rpg.sys 1
execute unless score #dsw3p rpg.sys matches -2147483648.. run scoreboard players set #dsw3p rpg.sys 100
execute unless score #dsw4k rpg.sys matches -2147483648.. run scoreboard players set #dsw4k rpg.sys 2
execute unless score #dsw4v rpg.sys matches -2147483648.. run scoreboard players set #dsw4v rpg.sys 3
execute unless score #dsw4n rpg.sys matches -2147483648.. run scoreboard players set #dsw4n rpg.sys 1
execute unless score #dsw4p rpg.sys matches -2147483648.. run scoreboard players set #dsw4p rpg.sys 100
execute unless score #dsw5k rpg.sys matches -2147483648.. run scoreboard players set #dsw5k rpg.sys 0
execute unless score #dsw5v rpg.sys matches -2147483648.. run scoreboard players set #dsw5v rpg.sys 1
execute unless score #dsw5n rpg.sys matches -2147483648.. run scoreboard players set #dsw5n rpg.sys 0
execute unless score #dsw5p rpg.sys matches -2147483648.. run scoreboard players set #dsw5p rpg.sys 0
execute unless score #dsw6k rpg.sys matches -2147483648.. run scoreboard players set #dsw6k rpg.sys 0
execute unless score #dsw6v rpg.sys matches -2147483648.. run scoreboard players set #dsw6v rpg.sys 1
execute unless score #dsw6n rpg.sys matches -2147483648.. run scoreboard players set #dsw6n rpg.sys 0
execute unless score #dsw6p rpg.sys matches -2147483648.. run scoreboard players set #dsw6p rpg.sys 0
execute unless score #dsw7k rpg.sys matches -2147483648.. run scoreboard players set #dsw7k rpg.sys 0
execute unless score #dsw7v rpg.sys matches -2147483648.. run scoreboard players set #dsw7v rpg.sys 1
execute unless score #dsw7n rpg.sys matches -2147483648.. run scoreboard players set #dsw7n rpg.sys 0
execute unless score #dsw7p rpg.sys matches -2147483648.. run scoreboard players set #dsw7p rpg.sys 0
execute unless score #dsw8k rpg.sys matches -2147483648.. run scoreboard players set #dsw8k rpg.sys 0
execute unless score #dsw8v rpg.sys matches -2147483648.. run scoreboard players set #dsw8v rpg.sys 1
execute unless score #dsw8n rpg.sys matches -2147483648.. run scoreboard players set #dsw8n rpg.sys 0
execute unless score #dsw8p rpg.sys matches -2147483648.. run scoreboard players set #dsw8p rpg.sys 0
execute unless score #dsk1k rpg.sys matches -2147483648.. run scoreboard players set #dsk1k rpg.sys 3
execute unless score #dsk1v rpg.sys matches -2147483648.. run scoreboard players set #dsk1v rpg.sys 2
execute unless score #dsk1n rpg.sys matches -2147483648.. run scoreboard players set #dsk1n rpg.sys 2
execute unless score #dsk1p rpg.sys matches -2147483648.. run scoreboard players set #dsk1p rpg.sys 100
execute unless score #dsk2k rpg.sys matches -2147483648.. run scoreboard players set #dsk2k rpg.sys 4
execute unless score #dsk2v rpg.sys matches -2147483648.. run scoreboard players set #dsk2v rpg.sys 2
execute unless score #dsk2n rpg.sys matches -2147483648.. run scoreboard players set #dsk2n rpg.sys 1
execute unless score #dsk2p rpg.sys matches -2147483648.. run scoreboard players set #dsk2p rpg.sys 100
execute unless score #dsk3k rpg.sys matches -2147483648.. run scoreboard players set #dsk3k rpg.sys 4
execute unless score #dsk3v rpg.sys matches -2147483648.. run scoreboard players set #dsk3v rpg.sys 1
execute unless score #dsk3n rpg.sys matches -2147483648.. run scoreboard players set #dsk3n rpg.sys 5
execute unless score #dsk3p rpg.sys matches -2147483648.. run scoreboard players set #dsk3p rpg.sys 100
execute unless score #dsk4k rpg.sys matches -2147483648.. run scoreboard players set #dsk4k rpg.sys 3
execute unless score #dsk4v rpg.sys matches -2147483648.. run scoreboard players set #dsk4v rpg.sys 2
execute unless score #dsk4n rpg.sys matches -2147483648.. run scoreboard players set #dsk4n rpg.sys 1
execute unless score #dsk4p rpg.sys matches -2147483648.. run scoreboard players set #dsk4p rpg.sys 20
execute unless score #dsk5k rpg.sys matches -2147483648.. run scoreboard players set #dsk5k rpg.sys 4
execute unless score #dsk5v rpg.sys matches -2147483648.. run scoreboard players set #dsk5v rpg.sys 1
execute unless score #dsk5n rpg.sys matches -2147483648.. run scoreboard players set #dsk5n rpg.sys 3
execute unless score #dsk5p rpg.sys matches -2147483648.. run scoreboard players set #dsk5p rpg.sys 20
execute unless score #dsk6k rpg.sys matches -2147483648.. run scoreboard players set #dsk6k rpg.sys 4
execute unless score #dsk6v rpg.sys matches -2147483648.. run scoreboard players set #dsk6v rpg.sys 3
execute unless score #dsk6n rpg.sys matches -2147483648.. run scoreboard players set #dsk6n rpg.sys 1
execute unless score #dsk6p rpg.sys matches -2147483648.. run scoreboard players set #dsk6p rpg.sys 50
execute unless score #dsk7k rpg.sys matches -2147483648.. run scoreboard players set #dsk7k rpg.sys 1
execute unless score #dsk7v rpg.sys matches -2147483648.. run scoreboard players set #dsk7v rpg.sys 4
execute unless score #dsk7n rpg.sys matches -2147483648.. run scoreboard players set #dsk7n rpg.sys 2
execute unless score #dsk7p rpg.sys matches -2147483648.. run scoreboard players set #dsk7p rpg.sys 100
execute unless score #dsk8k rpg.sys matches -2147483648.. run scoreboard players set #dsk8k rpg.sys 1
execute unless score #dsk8v rpg.sys matches -2147483648.. run scoreboard players set #dsk8v rpg.sys 3
execute unless score #dsk8n rpg.sys matches -2147483648.. run scoreboard players set #dsk8n rpg.sys 5
execute unless score #dsk8p rpg.sys matches -2147483648.. run scoreboard players set #dsk8p rpg.sys 100
execute unless score #dr_d1n rpg.sys matches 0.. run scoreboard players set #dr_d1n rpg.sys 1
execute unless score #dr_d1p rpg.sys matches 0.. run scoreboard players set #dr_d1p rpg.sys 100
execute unless score #dr_d2n rpg.sys matches 0.. run scoreboard players set #dr_d2n rpg.sys 30
execute unless score #dr_d2p rpg.sys matches 0.. run scoreboard players set #dr_d2p rpg.sys 100
execute unless score #dr_d3n rpg.sys matches 0.. run scoreboard players set #dr_d3n rpg.sys 2
execute unless score #dr_d3p rpg.sys matches 0.. run scoreboard players set #dr_d3p rpg.sys 100
execute unless score #dr_d4n rpg.sys matches 0.. run scoreboard players set #dr_d4n rpg.sys 1
execute unless score #dr_d4p rpg.sys matches 0.. run scoreboard players set #dr_d4p rpg.sys 20
execute unless score #dr_w1n rpg.sys matches 0.. run scoreboard players set #dr_w1n rpg.sys 3
execute unless score #dr_w1p rpg.sys matches 0.. run scoreboard players set #dr_w1p rpg.sys 100
execute unless score #dr_w2n rpg.sys matches 0.. run scoreboard players set #dr_w2n rpg.sys 1
execute unless score #dr_w2p rpg.sys matches 0.. run scoreboard players set #dr_w2p rpg.sys 30
execute unless score #dr_k1n rpg.sys matches 0.. run scoreboard players set #dr_k1n rpg.sys 2
execute unless score #dr_k1p rpg.sys matches 0.. run scoreboard players set #dr_k1p rpg.sys 100
execute unless score #dr_k2n rpg.sys matches 0.. run scoreboard players set #dr_k2n rpg.sys 1
execute unless score #dr_k2p rpg.sys matches 0.. run scoreboard players set #dr_k2p rpg.sys 100
execute unless score #dr_k3n rpg.sys matches 0.. run scoreboard players set #dr_k3n rpg.sys 5
execute unless score #dr_k3p rpg.sys matches 0.. run scoreboard players set #dr_k3p rpg.sys 100
execute unless score #dr_k4n rpg.sys matches 0.. run scoreboard players set #dr_k4n rpg.sys 1
execute unless score #dr_k4p rpg.sys matches 0.. run scoreboard players set #dr_k4p rpg.sys 20
execute unless score #dr_k5n rpg.sys matches 0.. run scoreboard players set #dr_k5n rpg.sys 3
execute unless score #dr_k5p rpg.sys matches 0.. run scoreboard players set #dr_k5p rpg.sys 20
execute unless score #dr_k6n rpg.sys matches 0.. run scoreboard players set #dr_k6n rpg.sys 1
execute unless score #dr_k6p rpg.sys matches 0.. run scoreboard players set #dr_k6p rpg.sys 50
scoreboard objectives add rpg.kw trigger
execute unless score #kw_h rpg.sys matches 0.. run scoreboard players set #kw_h rpg.sys 0
execute unless score #kw_c rpg.sys matches 0.. run scoreboard players set #kw_c rpg.sys 0
execute unless score #kw_l rpg.sys matches 0.. run scoreboard players set #kw_l rpg.sys 0
execute unless score #kw_b rpg.sys matches 0.. run scoreboard players set #kw_b rpg.sys 0
scoreboard objectives add rpg.iv dummy
scoreboard objectives add rpg.dshg dummy
scoreboard objectives add rpg.dshc dummy
scoreboard objectives add rpg.dshd dummy
scoreboard objectives add rpg.kwby dummy
scoreboard objectives add rpg.wmn trigger
scoreboard objectives add rpg.dshb dummy
scoreboard objectives add rpg.yaw dummy
scoreboard objectives add rpg.d_shp dummy {"text":"스탯 최대체력","color":"green"}
scoreboard objectives add rpg.d_cri dummy
scoreboard objectives add rpg.d_cr2 dummy
scoreboard objectives add rpg.fsh trigger
scoreboard objectives add rpg.fsel dummy
scoreboard objectives add rpg.fpend dummy
scoreboard objectives add rpg.xstr dummy {"text":"추가 힘","color":"red"}
scoreboard objectives add rpg.xdex dummy {"text":"추가 민첩","color":"aqua"}
scoreboard objectives add rpg.xcon dummy {"text":"추가 체력","color":"green"}
scoreboard objectives add rpg.fk1 dummy
scoreboard objectives add rpg.fk2 dummy
scoreboard objectives add rpg.fk3 dummy
scoreboard objectives add rpg.fk4 dummy
scoreboard objectives add rpg.fk5 dummy
scoreboard objectives add rpg.fk6 dummy
scoreboard objectives add rpg.fk7 dummy
scoreboard objectives add rpg.fk8 dummy
scoreboard objectives add rpg.fk9 dummy
scoreboard objectives add rpg.fk10 dummy
scoreboard objectives add rpg.fk11 dummy
scoreboard objectives add rpg.fk12 dummy
scoreboard objectives add rpg.fk13 dummy
scoreboard objectives add rpg.fk14 dummy
scoreboard objectives add rpg.fk15 dummy
scoreboard objectives add rpg.fk16 dummy
scoreboard objectives add rpg.fk17 dummy
scoreboard objectives add rpg.fk18 dummy
scoreboard objectives add rpg.fk19 dummy
scoreboard objectives add rpg.fk20 dummy
scoreboard objectives add rpg.fk21 dummy
scoreboard objectives add rpg.fk22 dummy
scoreboard objectives add rpg.fk23 dummy
scoreboard objectives add rpg.fk24 dummy
scoreboard objectives add rpg.fk25 dummy
scoreboard objectives add rpg.fk26 dummy
scoreboard objectives add rpg.fk27 dummy
scoreboard objectives add rpg.fk28 dummy
scoreboard objectives add rpg.fk29 dummy
scoreboard objectives add rpg.fk30 dummy
scoreboard objectives add rpg.fk31 dummy
scoreboard objectives add rpg.fk32 dummy
scoreboard objectives add rpg.fk33 dummy
scoreboard objectives add rpg.fk34 dummy
scoreboard objectives add rpg.fk35 dummy
scoreboard objectives add rpg.fk36 dummy
scoreboard objectives add rpg.fk37 dummy
scoreboard objectives add rpg.fk38 dummy
scoreboard objectives add rpg.fk39 dummy
scoreboard objectives add rpg.fk40 dummy
scoreboard objectives add rpg.fs1 dummy
scoreboard objectives add rpg.fs2 dummy
scoreboard objectives add rpg.fs3 dummy
scoreboard objectives add rpg.fs4 dummy
scoreboard objectives add rpg.fs5 dummy
scoreboard objectives add rpg.fs6 dummy
scoreboard objectives add rpg.fs7 dummy
scoreboard objectives add rpg.fs8 dummy
scoreboard objectives add rpg.fs9 dummy
scoreboard objectives add rpg.fs10 dummy
scoreboard objectives add rpg.fsv dummy
scoreboard objectives add rpg.wdc trigger
scoreboard objectives add rpg.wdp dummy
scoreboard objectives add rpg.wcs trigger
scoreboard objectives add rpg.wsh trigger
# v39 가짜 피 : 지금 / 최대 / 지난 틱 진짜 피(x100) / 소수점 누적 / 마지막으로 살아 있던 틱
scoreboard objectives add rpg.mhp dummy
scoreboard objectives add rpg.mmx dummy
scoreboard objectives add rpg.mlh dummy
scoreboard objectives add rpg.mfr dummy
scoreboard objectives add rpg.mlt dummy
# v40 : 당근 낚싯대 우클릭 (폭탄 · 국가 신호기 · 물고기) / 성
scoreboard objectives add rpg.coas minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add rpg.ucd dummy
scoreboard objectives add rpg.bcd dummy
scoreboard objectives add rpg.npcd dummy
scoreboard objectives add rpg.csid dummy
scoreboard objectives add rpg.csn dummy
scoreboard objectives add rpg.csk dummy
scoreboard objectives add rpg.cshp dummy
scoreboard objectives add rpg.cbid dummy
scoreboard objectives add rpg.erod dummy
scoreboard objectives add rpg.bht dummy
# v41
scoreboard objectives add rpg.xpp dummy
scoreboard objectives add rpg.hq dummy
scoreboard objectives add rpg.hqt dummy
scoreboard objectives add rpg.bkt dummy
scoreboard objectives add rpg.lskp dummy
scoreboard objectives add rpg.lskt dummy
scoreboard objectives add rpg.nref dummy
scoreboard objectives add rpg.bdmg dummy
scoreboard objectives add rpg.d_at2 dummy
scoreboard objectives add rpg.d_df2 dummy
# 총든 해적 총알 피해 = 공격력 x #gun_pct %  (기본 100)
execute unless score #gun_pct rpg.sys matches 1.. run scoreboard players set #gun_pct rpg.sys 100
scoreboard players set #k90 rpg.sys 90
scoreboard players set #k4 rpg.sys 4
scoreboard players set #k2 rpg.sys 2
# 성 신호기 내구도 (좌클릭 몇 번) : /scoreboard players set #cs_bhp rpg.sys 60
execute unless score #cs_bhp rpg.sys matches 1.. run scoreboard players set #cs_bhp rpg.sys 60
# v40 : 예전(v38) 성 기록은 새 방식과 맞지 않아 한 번 지웁니다 (블록은 그대로)
execute unless score #csv rpg.sys matches 40 run function rpg:war/cs_remove
scoreboard players set #csv rpg.sys 40
# v39 잡몹 돈 배율 (%) : /scoreboard players set #mob_money rpg.sys 150
execute unless score #mob_money rpg.sys matches 1.. run scoreboard players set #mob_money rpg.sys 100
execute unless score #war_run rpg.sys matches 0.. run scoreboard players set #war_run rpg.sys 0
execute unless score #war_pause rpg.sys matches 0.. run scoreboard players set #war_pause rpg.sys 0
execute unless score #war_bb rpg.sys matches 0.. run scoreboard players set #war_bb rpg.sys 0
execute unless score #war_prot rpg.sys matches 0.. run scoreboard players set #war_prot rpg.sys 1
# ── 국가 성 (2단계) ──
execute unless score #cs1x rpg.sys matches -2147483648.. run scoreboard players set #cs1x rpg.sys 0
execute unless score #cs1y rpg.sys matches -2147483648.. run scoreboard players set #cs1y rpg.sys 0
execute unless score #cs1z rpg.sys matches -2147483648.. run scoreboard players set #cs1z rpg.sys 0
execute unless score #cs1on rpg.sys matches -2147483648.. run scoreboard players set #cs1on rpg.sys 0
execute unless score #cs2x rpg.sys matches -2147483648.. run scoreboard players set #cs2x rpg.sys 0
execute unless score #cs2y rpg.sys matches -2147483648.. run scoreboard players set #cs2y rpg.sys 0
execute unless score #cs2z rpg.sys matches -2147483648.. run scoreboard players set #cs2z rpg.sys 0
execute unless score #cs2on rpg.sys matches -2147483648.. run scoreboard players set #cs2on rpg.sys 0
execute unless score #cs3x rpg.sys matches -2147483648.. run scoreboard players set #cs3x rpg.sys 0
execute unless score #cs3y rpg.sys matches -2147483648.. run scoreboard players set #cs3y rpg.sys 0
execute unless score #cs3z rpg.sys matches -2147483648.. run scoreboard players set #cs3z rpg.sys 0
execute unless score #cs3on rpg.sys matches -2147483648.. run scoreboard players set #cs3on rpg.sys 0
execute unless score #cs4x rpg.sys matches -2147483648.. run scoreboard players set #cs4x rpg.sys 0
execute unless score #cs4y rpg.sys matches -2147483648.. run scoreboard players set #cs4y rpg.sys 0
execute unless score #cs4z rpg.sys matches -2147483648.. run scoreboard players set #cs4z rpg.sys 0
execute unless score #cs4on rpg.sys matches -2147483648.. run scoreboard players set #cs4on rpg.sys 0
execute unless score #cs5x rpg.sys matches -2147483648.. run scoreboard players set #cs5x rpg.sys 0
execute unless score #cs5y rpg.sys matches -2147483648.. run scoreboard players set #cs5y rpg.sys 0
execute unless score #cs5z rpg.sys matches -2147483648.. run scoreboard players set #cs5z rpg.sys 0
execute unless score #cs5on rpg.sys matches -2147483648.. run scoreboard players set #cs5on rpg.sys 0
execute unless score #cs6x rpg.sys matches -2147483648.. run scoreboard players set #cs6x rpg.sys 0
execute unless score #cs6y rpg.sys matches -2147483648.. run scoreboard players set #cs6y rpg.sys 0
execute unless score #cs6z rpg.sys matches -2147483648.. run scoreboard players set #cs6z rpg.sys 0
execute unless score #cs6on rpg.sys matches -2147483648.. run scoreboard players set #cs6on rpg.sys 0
execute unless score #cs7x rpg.sys matches -2147483648.. run scoreboard players set #cs7x rpg.sys 0
execute unless score #cs7y rpg.sys matches -2147483648.. run scoreboard players set #cs7y rpg.sys 0
execute unless score #cs7z rpg.sys matches -2147483648.. run scoreboard players set #cs7z rpg.sys 0
execute unless score #cs7on rpg.sys matches -2147483648.. run scoreboard players set #cs7on rpg.sys 0
execute unless score #cs8x rpg.sys matches -2147483648.. run scoreboard players set #cs8x rpg.sys 0
execute unless score #cs8y rpg.sys matches -2147483648.. run scoreboard players set #cs8y rpg.sys 0
execute unless score #cs8z rpg.sys matches -2147483648.. run scoreboard players set #cs8z rpg.sys 0
execute unless score #cs8on rpg.sys matches -2147483648.. run scoreboard players set #cs8on rpg.sys 0
execute unless score #wd12 rpg.sys matches 0.. run scoreboard players set #wd12 rpg.sys 0
execute unless score #wd13 rpg.sys matches 0.. run scoreboard players set #wd13 rpg.sys 0
execute unless score #wd14 rpg.sys matches 0.. run scoreboard players set #wd14 rpg.sys 0
execute unless score #wd15 rpg.sys matches 0.. run scoreboard players set #wd15 rpg.sys 0
execute unless score #wd16 rpg.sys matches 0.. run scoreboard players set #wd16 rpg.sys 0
execute unless score #wd17 rpg.sys matches 0.. run scoreboard players set #wd17 rpg.sys 0
execute unless score #wd18 rpg.sys matches 0.. run scoreboard players set #wd18 rpg.sys 0
execute unless score #wd21 rpg.sys matches 0.. run scoreboard players set #wd21 rpg.sys 0
execute unless score #wd23 rpg.sys matches 0.. run scoreboard players set #wd23 rpg.sys 0
execute unless score #wd24 rpg.sys matches 0.. run scoreboard players set #wd24 rpg.sys 0
execute unless score #wd25 rpg.sys matches 0.. run scoreboard players set #wd25 rpg.sys 0
execute unless score #wd26 rpg.sys matches 0.. run scoreboard players set #wd26 rpg.sys 0
execute unless score #wd27 rpg.sys matches 0.. run scoreboard players set #wd27 rpg.sys 0
execute unless score #wd28 rpg.sys matches 0.. run scoreboard players set #wd28 rpg.sys 0
execute unless score #wd31 rpg.sys matches 0.. run scoreboard players set #wd31 rpg.sys 0
execute unless score #wd32 rpg.sys matches 0.. run scoreboard players set #wd32 rpg.sys 0
execute unless score #wd34 rpg.sys matches 0.. run scoreboard players set #wd34 rpg.sys 0
execute unless score #wd35 rpg.sys matches 0.. run scoreboard players set #wd35 rpg.sys 0
execute unless score #wd36 rpg.sys matches 0.. run scoreboard players set #wd36 rpg.sys 0
execute unless score #wd37 rpg.sys matches 0.. run scoreboard players set #wd37 rpg.sys 0
execute unless score #wd38 rpg.sys matches 0.. run scoreboard players set #wd38 rpg.sys 0
execute unless score #wd41 rpg.sys matches 0.. run scoreboard players set #wd41 rpg.sys 0
execute unless score #wd42 rpg.sys matches 0.. run scoreboard players set #wd42 rpg.sys 0
execute unless score #wd43 rpg.sys matches 0.. run scoreboard players set #wd43 rpg.sys 0
execute unless score #wd45 rpg.sys matches 0.. run scoreboard players set #wd45 rpg.sys 0
execute unless score #wd46 rpg.sys matches 0.. run scoreboard players set #wd46 rpg.sys 0
execute unless score #wd47 rpg.sys matches 0.. run scoreboard players set #wd47 rpg.sys 0
execute unless score #wd48 rpg.sys matches 0.. run scoreboard players set #wd48 rpg.sys 0
execute unless score #wd51 rpg.sys matches 0.. run scoreboard players set #wd51 rpg.sys 0
execute unless score #wd52 rpg.sys matches 0.. run scoreboard players set #wd52 rpg.sys 0
execute unless score #wd53 rpg.sys matches 0.. run scoreboard players set #wd53 rpg.sys 0
execute unless score #wd54 rpg.sys matches 0.. run scoreboard players set #wd54 rpg.sys 0
execute unless score #wd56 rpg.sys matches 0.. run scoreboard players set #wd56 rpg.sys 0
execute unless score #wd57 rpg.sys matches 0.. run scoreboard players set #wd57 rpg.sys 0
execute unless score #wd58 rpg.sys matches 0.. run scoreboard players set #wd58 rpg.sys 0
execute unless score #wd61 rpg.sys matches 0.. run scoreboard players set #wd61 rpg.sys 0
execute unless score #wd62 rpg.sys matches 0.. run scoreboard players set #wd62 rpg.sys 0
execute unless score #wd63 rpg.sys matches 0.. run scoreboard players set #wd63 rpg.sys 0
execute unless score #wd64 rpg.sys matches 0.. run scoreboard players set #wd64 rpg.sys 0
execute unless score #wd65 rpg.sys matches 0.. run scoreboard players set #wd65 rpg.sys 0
execute unless score #wd67 rpg.sys matches 0.. run scoreboard players set #wd67 rpg.sys 0
execute unless score #wd68 rpg.sys matches 0.. run scoreboard players set #wd68 rpg.sys 0
execute unless score #wd71 rpg.sys matches 0.. run scoreboard players set #wd71 rpg.sys 0
execute unless score #wd72 rpg.sys matches 0.. run scoreboard players set #wd72 rpg.sys 0
execute unless score #wd73 rpg.sys matches 0.. run scoreboard players set #wd73 rpg.sys 0
execute unless score #wd74 rpg.sys matches 0.. run scoreboard players set #wd74 rpg.sys 0
execute unless score #wd75 rpg.sys matches 0.. run scoreboard players set #wd75 rpg.sys 0
execute unless score #wd76 rpg.sys matches 0.. run scoreboard players set #wd76 rpg.sys 0
execute unless score #wd78 rpg.sys matches 0.. run scoreboard players set #wd78 rpg.sys 0
execute unless score #wd81 rpg.sys matches 0.. run scoreboard players set #wd81 rpg.sys 0
execute unless score #wd82 rpg.sys matches 0.. run scoreboard players set #wd82 rpg.sys 0
execute unless score #wd83 rpg.sys matches 0.. run scoreboard players set #wd83 rpg.sys 0
execute unless score #wd84 rpg.sys matches 0.. run scoreboard players set #wd84 rpg.sys 0
execute unless score #wd85 rpg.sys matches 0.. run scoreboard players set #wd85 rpg.sys 0
execute unless score #wd86 rpg.sys matches 0.. run scoreboard players set #wd86 rpg.sys 0
execute unless score #wd87 rpg.sys matches 0.. run scoreboard players set #wd87 rpg.sys 0
scoreboard objectives add rpg.hp health

# 게이지바 문자 테이블 (리소스팩 rpg_hud 폰트)
data modify storage rpg:main hpb set value ["","","","","","","","","","","","","","","","","","","","",""]
data modify storage rpg:main xpb set value ["","","","","","","","","","","","","","","","","","","","",""]

execute unless data storage rpg:main bb.v run data modify storage rpg:main bb.v set value "fixed"
# 전쟁터 범위 (시작 113 -60 54 / 끝 912 60 853)
execute unless data storage rpg:war fld run data modify storage rpg:war fld set value {x:113,y:-60,z:54,dx:799,dy:120,dz:799}
data modify storage rpg:main hud.hc set value ""
data modify storage rpg:main hud.xc set value ""

function rpg:config
execute unless score #spid rpg.sys matches 0.. run scoreboard players set #spid rpg.sys 0
# 몹 모델 구조가 바뀌면 한 번만 전체 청소 (겹쳐 쌓인 모델 제거)
execute unless score #mver rpg.sys matches 12.. run data modify storage rpg:main bb.v set value "fixed"
# v39 : 2족 몹 몸(장비식) + 가짜 피 로 바뀌어서 한 번 전체 청소 -> 스폰 지점에서 새로 나옵니다
execute unless score #mver rpg.sys matches 13 run function rpg:mob/reset_all
scoreboard players set #mver rpg.sys 13

# 구버전 보스바 정리 (한 번만)
execute unless score #ver rpg.sys matches 2 run function rpg:admin/clear_bars
scoreboard players set #ver rpg.sys 2

# 경매 / 비행 / C+C 트리거 활성화
scoreboard players enable @a rpg.auc
scoreboard players add @a rpg.abidL 0
scoreboard players add @a rpg.qcat 1
scoreboard players add @a rpg.qord 0

# 국가 팀 (최초 1회)
execute unless score #natset rpg.sys matches 1 run function rpg:nation/setup
scoreboard players set #natset rpg.sys 1
scoreboard players enable @a rpg.nat
scoreboard players enable @a rpg.vlt

# 시스템 점수 초기화 (없으면 조건문이 통째로 실패합니다)
scoreboard players add #auc_bb rpg.sys 0
scoreboard players add #auc_run rpg.sys 0
scoreboard players add #auc_pause rpg.sys 0
scoreboard players add #auc_n rpg.sys 0
scoreboard players add #auc_time rpg.sys 0
scoreboard players add #rnd_run rpg.sys 0
scoreboard players add #rnd_pause rpg.sys 0
scoreboard players add #rnd_time rpg.sys 0
scoreboard players add #rnd_max rpg.sys 0
scoreboard players add #rnd_bb rpg.sys 0
scoreboard players add @a rpg.def 0
scoreboard players enable @a rpg.rnd
scoreboard players enable @a rpg.npc
scoreboard players enable @a rpg.enh
scoreboard players add @a rpg.enhM 0
scoreboard players add @a rpg.spD 0
scoreboard players add @a rpg.spL 0
# 강화 확률 기본값 (1000 = 100%)
execute unless data storage rpg:enh cfg.v run data remove storage rpg:enh cfg
execute unless data storage rpg:enh cfg.v run data modify storage rpg:enh cfg set value {v:2,req:{}}
scoreboard players add #e_base rpg.sys 0
execute if score #e_base rpg.sys matches 0 run scoreboard players set #e_base rpg.sys 900
execute unless score #e_dec rpg.sys matches -2147483648.. run scoreboard players set #e_dec rpg.sys 40
scoreboard players add #e_dfrom rpg.sys 0
execute if score #e_dfrom rpg.sys matches 0 run scoreboard players set #e_dfrom rpg.sys 7
execute unless score #e_dinc rpg.sys matches -2147483648.. run scoreboard players set #e_dinc rpg.sys 25
scoreboard players add #e_mul rpg.sys 0
scoreboard players add @a rpg.dsh 0
scoreboard players add @a rpg.dshf 0
scoreboard players add #pid_next rpg.sys 0
scoreboard players add @a fly 0
scoreboard players add @a rpg.grav 0
scoreboard players add @a C+C 0
scoreboard players add @a rpg.bills 0
function rpg:nation/fix
# ── v42 ──
scoreboard objectives add rpg.mdb dummy
scoreboard objectives add rpg.cut dummy
scoreboard objectives add rpg.bmn minecraft.mined:minecraft.beacon
scoreboard objectives add rpg.pw trigger
scoreboard objectives add rpg.pwd dummy
scoreboard objectives add rpg.pwm dummy
scoreboard objectives add rpg.pwp dummy
scoreboard objectives add rpg.pwt dummy
scoreboard objectives add rpg.pwl dummy
scoreboard objectives add rpg.pwv dummy
scoreboard objectives add rpg.dop dummy
# 스킬로 죽을 때 바닐라 사망 메시지 숨김용 (국가 없는 사람)
team add rpg_dmh
team modify rpg_dmh deathMessageVisibility never
# 강화 설정 무기 / 낚싯대 분리 — 처음 한 번은 지금 설정을 둘 다에 복사
execute unless data storage rpg:enh cw run data modify storage rpg:enh cw set from storage rpg:enh cfg
execute unless data storage rpg:enh cr run data modify storage rpg:enh cr set from storage rpg:enh cfg
execute unless score #ew_base rpg.sys matches -2147483648.. run scoreboard players operation #ew_base rpg.sys = #e_base rpg.sys
execute unless score #ew_dec rpg.sys matches -2147483648.. run scoreboard players operation #ew_dec rpg.sys = #e_dec rpg.sys
execute unless score #ew_dfrom rpg.sys matches -2147483648.. run scoreboard players operation #ew_dfrom rpg.sys = #e_dfrom rpg.sys
execute unless score #ew_dinc rpg.sys matches -2147483648.. run scoreboard players operation #ew_dinc rpg.sys = #e_dinc rpg.sys
execute unless score #ew_mul rpg.sys matches -2147483648.. run scoreboard players operation #ew_mul rpg.sys = #e_mul rpg.sys
execute unless score #er_base rpg.sys matches -2147483648.. run scoreboard players operation #er_base rpg.sys = #e_base rpg.sys
execute unless score #er_dec rpg.sys matches -2147483648.. run scoreboard players operation #er_dec rpg.sys = #e_dec rpg.sys
execute unless score #er_dfrom rpg.sys matches -2147483648.. run scoreboard players operation #er_dfrom rpg.sys = #e_dfrom rpg.sys
execute unless score #er_dinc rpg.sys matches -2147483648.. run scoreboard players operation #er_dinc rpg.sys = #e_dinc rpg.sys
execute unless score #er_mul rpg.sys matches -2147483648.. run scoreboard players operation #er_mul rpg.sys = #e_mul rpg.sys
# 해적 왕 드롭 : 경험치 책 -> 경험치 닭 (한 번)
execute unless score #dsv42 rpg.sys matches 1 run function rpg:mob/ds_mig42
# ── v43 ──
# 성 표식 유효 번호 (이 번호보다 작은 성 표식은 옛것 -> 치움)
execute unless score #cbmin rpg.sys matches -2147483648.. run scoreboard players set #cbmin rpg.sys 0
execute unless score #orc rpg.sys matches -2147483648.. run scoreboard players set #orc rpg.sys 0
# 지은 성 목록 (초기화 때 철거용) : 처음 한 번은 지금 등록된 성으로 채움
execute unless score #csv43 rpg.sys matches 1 run function rpg:war/built_seed
scoreboard players set #csv43 rpg.sys 1
# 성 철거가 도중에 멈췄으면 이어서
execute if data storage rpg:war wq[0] run schedule function rpg:war/wipe_next 40t replace
execute unless data storage rpg:war wq[0] if data storage rpg:war wfl[0] run schedule function rpg:war/wipe_next 40t replace
# ── v44 버프 ──
scoreboard objectives add rpg.bgd dummy
scoreboard objectives add rpg.bdt dummy
scoreboard objectives add rpg.bdp dummy
scoreboard objectives add rpg.bcc dummy
execute unless score #c20 rpg.sys matches 20 run scoreboard players set #c20 rpg.sys 20
# ── v44 전투태세 · 백어택 ──
scoreboard objectives add rpg.sdA dummy
scoreboard objectives add rpg.sdM dummy
scoreboard objectives add rpg.sdP dummy
scoreboard objectives add rpg.sdK dummy
scoreboard objectives add rpg.sdS dummy
scoreboard objectives add rpg.sdT dummy
scoreboard objectives add rpg.saA dummy
scoreboard objectives add rpg.saM dummy
scoreboard objectives add rpg.saP dummy
scoreboard objectives add rpg.saK dummy
scoreboard objectives add rpg.saS dummy
scoreboard objectives add rpg.saT dummy
scoreboard objectives add rpg.sgc dummy
scoreboard objectives add ac dummy
# 백어택 추가 피해 % (기본 100) : /scoreboard players set #ac_pct rpg.sys 150
execute unless score #ac_pct rpg.sys matches 1.. run scoreboard players set #ac_pct rpg.sys 100
# ── v44 출혈 ──
scoreboard objectives add rpg.blt dummy
scoreboard objectives add rpg.bli dummy
scoreboard objectives add rpg.blc dummy
scoreboard objectives add rpg.bld dummy
scoreboard objectives add rpg.blo dummy
# ── v44 균열 ──
scoreboard objectives add rpg.rf1 dummy
scoreboard objectives add rpg.rf2 dummy
scoreboard objectives add rpg.rf3 dummy
scoreboard objectives add rpg.rfn1 dummy
scoreboard objectives add rpg.rfn2 dummy
scoreboard objectives add rpg.rfn3 dummy
scoreboard objectives add rpg.rfn4 dummy
scoreboard objectives add rpg.rfn5 dummy
scoreboard objectives add rpg.rfn6 dummy
scoreboard objectives add rpg.rfn7 dummy
scoreboard objectives add rpg.rfn8 dummy
scoreboard objectives add rpg.rfb dummy
scoreboard objectives add rpg.rfg dummy
scoreboard objectives add rpg.rft dummy
scoreboard players set #c400 rpg.sys 400
execute unless score #c4 rpg.sys matches 4 run scoreboard players set #c4 rpg.sys 4
# 균열 효과 크기 (1개당) — 바꾸려면 /scoreboard players set #rf_atk rpg.sys 8  처럼
execute unless score #rf_atk rpg.sys matches 0.. run scoreboard players set #rf_atk rpg.sys 5
execute unless score #rf_spd rpg.sys matches 0.. run scoreboard players set #rf_spd rpg.sys 5
execute unless score #rf_hp rpg.sys matches 0.. run scoreboard players set #rf_hp rpg.sys 20
execute unless score #rf_def rpg.sys matches 0.. run scoreboard players set #rf_def rpg.sys 15
execute unless score #rf_dr rpg.sys matches 0.. run scoreboard players set #rf_dr rpg.sys 5
execute unless score #rf_ls rpg.sys matches 0.. run scoreboard players set #rf_ls rpg.sys 5
execute unless score #rf_cr rpg.sys matches 0.. run scoreboard players set #rf_cr rpg.sys 5
execute unless score #rf_rg rpg.sys matches 0.. run scoreboard players set #rf_rg rpg.sys 3
# ── v44 경감 모으기 ──
scoreboard objectives add rpg.mtb dummy
# ── v45 ──
scoreboard objectives add ignore dummy
scoreboard objectives add stdef dummy
scoreboard objectives add statk dummy
scoreboard objectives add rpg.dshx dummy
# 전투태세 세기 (전체 공통 · per 는 0.1 단위)
execute unless score #sd_max rpg.sys matches 1.. run scoreboard players set #sd_max rpg.sys 10
execute unless score #sd_per rpg.sys matches 0.. run scoreboard players set #sd_per rpg.sys 20
execute unless score #sd_keep rpg.sys matches 1.. run scoreboard players set #sd_keep rpg.sys 5
execute unless score #sa_max rpg.sys matches 1.. run scoreboard players set #sa_max rpg.sys 5
execute unless score #sa_per rpg.sys matches 0.. run scoreboard players set #sa_per rpg.sys 15
execute unless score #sa_keep rpg.sys matches 1.. run scoreboard players set #sa_keep rpg.sys 4
# ── v45 봉인 · 스턴 ──
scoreboard objectives add noskill dummy
scoreboard objectives add rpg.slT dummy
scoreboard objectives add rpg.slR dummy
scoreboard objectives add rpg.slm dummy
scoreboard objectives add rpg.snT dummy
scoreboard objectives add rpg.snX dummy
scoreboard objectives add rpg.snY dummy
scoreboard objectives add rpg.snZ dummy
# ── v45 은신 ──
scoreboard objectives add stealth dummy
# ── v45 데미지 숫자 · 힐 ──
scoreboard objectives add rpg.dcr dummy
scoreboard objectives add rpg.dnt dummy
scoreboard objectives add rpg.hln dummy
# ── v46 ──
scoreboard objectives add rpg.lastd dummy
scoreboard objectives add rpg.lastdt dummy
scoreboard objectives add rpg.dct minecraft.custom:minecraft.deaths
scoreboard objectives add rpg.dtt dummy
scoreboard objectives add rpg.mds dummy
scoreboard objectives add rpg.lbt dummy
scoreboard objectives add rpg.oid dummy
scoreboard objectives add rpg.ora dummy
scoreboard objectives add rpg.ort dummy
scoreboard players add #oid_next rpg.sys 0
# 패시브 발동 · 크리티컬 알림 (채팅 · 화면 아래) : 0 = 안 보임 (기본) · 1 = 보임
execute unless score #pmsg rpg.sys matches 0.. run scoreboard players set #pmsg rpg.sys 0
# 재생의 균열 1% -> 3% (한 번만 · 예전 기본값 1 이었던 서버)
execute unless score #v46 rpg.sys matches 1 if score #rf_rg rpg.sys matches 1 run scoreboard players set #rf_rg rpg.sys 3
scoreboard players set #v46 rpg.sys 1
scoreboard objectives add rpg.rflv dummy
# v46 보스 생성 쿨 (분) — 처음엔 예전 #boss_cd (초) 값으로
execute unless score #bcd_dol rpg.sys matches 0.. run scoreboard players operation #bcd_dol rpg.sys = #boss_cd rpg.sys
execute unless score #bcd_dol rpg.sys matches 0.. run scoreboard players set #bcd_dol rpg.sys 900
execute if score #bcd_dol rpg.sys matches 60.. unless score #bcd_m rpg.sys matches 1 run scoreboard players operation #bcd_dol rpg.sys /= #c60 rpg.sys
execute unless score #bcd_wolf rpg.sys matches 0.. run scoreboard players operation #bcd_wolf rpg.sys = #bcd_dol rpg.sys
execute unless score #bcd_pking rpg.sys matches 0.. run scoreboard players operation #bcd_pking rpg.sys = #bcd_dol rpg.sys
scoreboard players set #bcd_m rpg.sys 1
# v46 몬스터 : 플레이어 없으면 몇 초 뒤 사라질지 · 도는 파티클 속도
execute unless score #mob_desp rpg.sys matches 1.. run scoreboard players set #mob_desp rpg.sys 10
execute unless score #orb_spd rpg.sys matches 1.. run scoreboard players set #orb_spd rpg.sys 18
# ── v47 ──
scoreboard objectives add rpg.hr1 dummy
scoreboard objectives add rpg.lfT dummy
scoreboard objectives add rpg.lfH dummy
scoreboard objectives add rpg.lfY dummy
scoreboard objectives add rpg.wgt dummy
# ── v47 리그 ──
scoreboard objectives add rpg.rgk dummy
scoreboard objectives add rpg.rgs dummy
scoreboard objectives add rpg.rgf dummy
scoreboard objectives add rpg.rgt dummy
scoreboard objectives add rpg.rgp dummy
scoreboard objectives add rpg.rgq dummy
scoreboard objectives add rpg.rgr dummy
scoreboard objectives add rpg.rgw dummy
scoreboard objectives add rpg.rgh dummy
scoreboard objectives add rpg.rga dummy
scoreboard objectives add rpg.rgm dummy
scoreboard objectives add rpg.rhc dummy
scoreboard objectives add rpg.rmx dummy
scoreboard objectives add rpg.rmy dummy
scoreboard objectives add rpg.rmz dummy
scoreboard objectives add rpg.shk dummy
scoreboard objectives add rpg.sha dummy
scoreboard objectives add rpg.hitt dummy
# 손맛 설정 (1 켬 · 0 끔) : 멈춤 · 화면 흔들림 · 튕김
execute unless score #rig_stop rpg.sys matches 0.. run scoreboard players set #rig_stop rpg.sys 1
execute unless score #rig_shake rpg.sys matches 0.. run scoreboard players set #rig_shake rpg.sys 1
execute unless score #rig_bounce rpg.sys matches 0.. run scoreboard players set #rig_bounce rpg.sys 1
function rpg:rig/data
# ── v47 새 몬스터 ──
scoreboard objectives add rpg.mskT dummy
scoreboard objectives add rpg.mskL dummy
execute unless score #sl_pct rpg.sys matches 1.. run scoreboard players set #sl_pct rpg.sys 80
execute unless score #mlv_frog_g rpg.sys matches 1.. run scoreboard players set #mlv_frog_g rpg.sys 15
execute unless score #mlv_frog_p rpg.sys matches 1.. run scoreboard players set #mlv_frog_p rpg.sys 16
execute unless score #mlv_frog_k rpg.sys matches 1.. run scoreboard players set #mlv_frog_k rpg.sys 18
execute unless score #mlv_slime_n rpg.sys matches 1.. run scoreboard players set #mlv_slime_n rpg.sys 25
execute unless score #mlv_slime_s rpg.sys matches 1.. run scoreboard players set #mlv_slime_s rpg.sys 26
execute unless score #mlv_slime_b rpg.sys matches 1.. run scoreboard players set #mlv_slime_b rpg.sys 27
execute unless score #mlv_slime_k rpg.sys matches 1.. run scoreboard players set #mlv_slime_k rpg.sys 30
execute unless score #mlv_cow_c rpg.sys matches 1.. run scoreboard players set #mlv_cow_c rpg.sys 35
execute unless score #mlv_piglin_c rpg.sys matches 1.. run scoreboard players set #mlv_piglin_c rpg.sys 36
execute unless score #mlv_ender_c rpg.sys matches 1.. run scoreboard players set #mlv_ender_c rpg.sys 37
execute unless score #bcd_frog_k rpg.sys matches 0.. run scoreboard players operation #bcd_frog_k rpg.sys = #bcd_dol rpg.sys
execute unless score #bcd_slime_k rpg.sys matches 0.. run scoreboard players operation #bcd_slime_k rpg.sys = #bcd_dol rpg.sys
execute unless score #dsf1k rpg.sys matches -2147483648.. run scoreboard players set #dsf1k rpg.sys 4
execute unless score #dsf1v rpg.sys matches -2147483648.. run scoreboard players set #dsf1v rpg.sys 2
execute unless score #dsf1n rpg.sys matches -2147483648.. run scoreboard players set #dsf1n rpg.sys 1
execute unless score #dsf1p rpg.sys matches -2147483648.. run scoreboard players set #dsf1p rpg.sys 100
execute unless score #dsf2k rpg.sys matches -2147483648.. run scoreboard players set #dsf2k rpg.sys 2
execute unless score #dsf2v rpg.sys matches -2147483648.. run scoreboard players set #dsf2v rpg.sys 3
execute unless score #dsf2n rpg.sys matches -2147483648.. run scoreboard players set #dsf2n rpg.sys 1
execute unless score #dsf2p rpg.sys matches -2147483648.. run scoreboard players set #dsf2p rpg.sys 100
execute unless score #dsf3k rpg.sys matches -2147483648.. run scoreboard players set #dsf3k rpg.sys 3
execute unless score #dsf3v rpg.sys matches -2147483648.. run scoreboard players set #dsf3v rpg.sys 2
execute unless score #dsf3n rpg.sys matches -2147483648.. run scoreboard players set #dsf3n rpg.sys 3
execute unless score #dsf3p rpg.sys matches -2147483648.. run scoreboard players set #dsf3p rpg.sys 100
execute unless score #dsf4k rpg.sys matches -2147483648.. run scoreboard players set #dsf4k rpg.sys 3
execute unless score #dsf4v rpg.sys matches -2147483648.. run scoreboard players set #dsf4v rpg.sys 3
execute unless score #dsf4n rpg.sys matches -2147483648.. run scoreboard players set #dsf4n rpg.sys 1
execute unless score #dsf4p rpg.sys matches -2147483648.. run scoreboard players set #dsf4p rpg.sys 30
execute unless score #dsf5k rpg.sys matches -2147483648.. run scoreboard players set #dsf5k rpg.sys 1
execute unless score #dsf5v rpg.sys matches -2147483648.. run scoreboard players set #dsf5v rpg.sys 4
execute unless score #dsf5n rpg.sys matches -2147483648.. run scoreboard players set #dsf5n rpg.sys 1
execute unless score #dsf5p rpg.sys matches -2147483648.. run scoreboard players set #dsf5p rpg.sys 100
execute unless score #dsf6k rpg.sys matches -2147483648.. run scoreboard players set #dsf6k rpg.sys 4
execute unless score #dsf6v rpg.sys matches -2147483648.. run scoreboard players set #dsf6v rpg.sys 3
execute unless score #dsf6n rpg.sys matches -2147483648.. run scoreboard players set #dsf6n rpg.sys 40
execute unless score #dsf6p rpg.sys matches -2147483648.. run scoreboard players set #dsf6p rpg.sys 100
execute unless score #dsf7k rpg.sys matches -2147483648.. run scoreboard players set #dsf7k rpg.sys 4
execute unless score #dsf7v rpg.sys matches -2147483648.. run scoreboard players set #dsf7v rpg.sys 1
execute unless score #dsf7n rpg.sys matches -2147483648.. run scoreboard players set #dsf7n rpg.sys 1
execute unless score #dsf7p rpg.sys matches -2147483648.. run scoreboard players set #dsf7p rpg.sys 10
execute unless score #dsf8k rpg.sys matches -2147483648.. run scoreboard players set #dsf8k rpg.sys 0
execute unless score #dsf8v rpg.sys matches -2147483648.. run scoreboard players set #dsf8v rpg.sys 1
execute unless score #dsf8n rpg.sys matches -2147483648.. run scoreboard players set #dsf8n rpg.sys 0
execute unless score #dsf8p rpg.sys matches -2147483648.. run scoreboard players set #dsf8p rpg.sys 100
execute unless score #dss1k rpg.sys matches -2147483648.. run scoreboard players set #dss1k rpg.sys 4
execute unless score #dss1v rpg.sys matches -2147483648.. run scoreboard players set #dss1v rpg.sys 2
execute unless score #dss1n rpg.sys matches -2147483648.. run scoreboard players set #dss1n rpg.sys 1
execute unless score #dss1p rpg.sys matches -2147483648.. run scoreboard players set #dss1p rpg.sys 100
execute unless score #dss2k rpg.sys matches -2147483648.. run scoreboard players set #dss2k rpg.sys 2
execute unless score #dss2v rpg.sys matches -2147483648.. run scoreboard players set #dss2v rpg.sys 4
execute unless score #dss2n rpg.sys matches -2147483648.. run scoreboard players set #dss2n rpg.sys 1
execute unless score #dss2p rpg.sys matches -2147483648.. run scoreboard players set #dss2p rpg.sys 100
execute unless score #dss3k rpg.sys matches -2147483648.. run scoreboard players set #dss3k rpg.sys 3
execute unless score #dss3v rpg.sys matches -2147483648.. run scoreboard players set #dss3v rpg.sys 3
execute unless score #dss3n rpg.sys matches -2147483648.. run scoreboard players set #dss3n rpg.sys 3
execute unless score #dss3p rpg.sys matches -2147483648.. run scoreboard players set #dss3p rpg.sys 100
execute unless score #dss4k rpg.sys matches -2147483648.. run scoreboard players set #dss4k rpg.sys 3
execute unless score #dss4v rpg.sys matches -2147483648.. run scoreboard players set #dss4v rpg.sys 4
execute unless score #dss4n rpg.sys matches -2147483648.. run scoreboard players set #dss4n rpg.sys 1
execute unless score #dss4p rpg.sys matches -2147483648.. run scoreboard players set #dss4p rpg.sys 30
execute unless score #dss5k rpg.sys matches -2147483648.. run scoreboard players set #dss5k rpg.sys 1
execute unless score #dss5v rpg.sys matches -2147483648.. run scoreboard players set #dss5v rpg.sys 4
execute unless score #dss5n rpg.sys matches -2147483648.. run scoreboard players set #dss5n rpg.sys 2
execute unless score #dss5p rpg.sys matches -2147483648.. run scoreboard players set #dss5p rpg.sys 100
execute unless score #dss6k rpg.sys matches -2147483648.. run scoreboard players set #dss6k rpg.sys 4
execute unless score #dss6v rpg.sys matches -2147483648.. run scoreboard players set #dss6v rpg.sys 3
execute unless score #dss6n rpg.sys matches -2147483648.. run scoreboard players set #dss6n rpg.sys 60
execute unless score #dss6p rpg.sys matches -2147483648.. run scoreboard players set #dss6p rpg.sys 100
execute unless score #dss7k rpg.sys matches -2147483648.. run scoreboard players set #dss7k rpg.sys 4
execute unless score #dss7v rpg.sys matches -2147483648.. run scoreboard players set #dss7v rpg.sys 1
execute unless score #dss7n rpg.sys matches -2147483648.. run scoreboard players set #dss7n rpg.sys 1
execute unless score #dss7p rpg.sys matches -2147483648.. run scoreboard players set #dss7p rpg.sys 15
execute unless score #dss8k rpg.sys matches -2147483648.. run scoreboard players set #dss8k rpg.sys 0
execute unless score #dss8v rpg.sys matches -2147483648.. run scoreboard players set #dss8v rpg.sys 1
execute unless score #dss8n rpg.sys matches -2147483648.. run scoreboard players set #dss8n rpg.sys 0
execute unless score #dss8p rpg.sys matches -2147483648.. run scoreboard players set #dss8p rpg.sys 100
# ── v47 새 메인 퀘스트 ──
scoreboard objectives add rpg.q_frog dummy
scoreboard objectives add rpg.qc_frog dummy
scoreboard objectives add rpg.qo3 dummy
execute unless score #q_frog1_need rpg.sys matches 1.. run scoreboard players set #q_frog1_need rpg.sys 15
execute unless score #q_frog2_need rpg.sys matches 1.. run scoreboard players set #q_frog2_need rpg.sys 15
execute unless score #q_frog3_need rpg.sys matches 1.. run scoreboard players set #q_frog3_need rpg.sys 1
scoreboard objectives add rpg.q_slm dummy
scoreboard objectives add rpg.qc_slm dummy
scoreboard objectives add rpg.qo4 dummy
execute unless score #q_slm1_need rpg.sys matches 1.. run scoreboard players set #q_slm1_need rpg.sys 20
execute unless score #q_slm2_need rpg.sys matches 1.. run scoreboard players set #q_slm2_need rpg.sys 15
execute unless score #q_slm3_need rpg.sys matches 1.. run scoreboard players set #q_slm3_need rpg.sys 15
execute unless score #q_slm4_need rpg.sys matches 1.. run scoreboard players set #q_slm4_need rpg.sys 1
scoreboard objectives add rpg.q_pur dummy
scoreboard objectives add rpg.qc_pur dummy
scoreboard objectives add rpg.qo5 dummy
execute unless score #q_pur1_need rpg.sys matches 1.. run scoreboard players set #q_pur1_need rpg.sys 20
execute unless score #q_pur2_need rpg.sys matches 1.. run scoreboard players set #q_pur2_need rpg.sys 20
execute unless score #q_pur3_need rpg.sys matches 1.. run scoreboard players set #q_pur3_need rpg.sys 20
# ── v48 NPC 페이지 ──
scoreboard objectives add rpg.npcp dummy
# ── v49 방어력 · 장비 능력 · 최후의 일격 · 돌 · 대쉬 · 장비 메뉴 ──
scoreboard objectives add rpg.igd dummy
scoreboard objectives add rpg.e_atk dummy
scoreboard objectives add rpg.e_hp dummy
scoreboard objectives add rpg.e_spd dummy
scoreboard objectives add rpg.d_dfr dummy
scoreboard objectives add rpg.d_dfr2 dummy
scoreboard objectives add rpg.rkid dummy
scoreboard objectives add rpg.eqa trigger
scoreboard objectives add rpg.eqp dummy
execute unless score #def_min rpg.sys matches 0.. run scoreboard players set #def_min rpg.sys 20
# ── v49 대쉬 탈것 기본값 ──
execute unless score #dash_ride rpg.sys matches 0.. run scoreboard players set #dash_ride rpg.sys 1
# ── v50 자유 / 추가 스탯 · 100 패시브 · 허수아비 · DPS · F · 밭 ──
scoreboard objectives add rpg.xsp dummy {"text":"남은 추가 스탯","color":"yellow"}
scoreboard objectives add rpg.spm dummy
scoreboard objectives add rpg.p100 dummy
scoreboard objectives add rpg.xh4 dummy
scoreboard objectives add rpg.d_xp dummy
scoreboard objectives add rpg.d_xp2 dummy
scoreboard objectives add rpg.scl dummy
scoreboard objectives add rpg.dpsd dummy
scoreboard objectives add rpg.dpss dummy
scoreboard objectives add rpg.dpsl dummy
scoreboard objectives add rpg.dpsv dummy
scoreboard objectives add rpg.dpsv2 dummy
scoreboard objectives add F dummy {"text":"F","color":"aqua"}
scoreboard objectives add rpg.fft dummy
scoreboard objectives add rpg.dspd dummy
scoreboard objectives add rpg.dng dummy
scoreboard players add @a F 0
scoreboard players add @a rpg.xsp 0
# ── v50 몬스터 돈 5배 (한 번만 · 그 뒤로는 /scoreboard players set #mob_money rpg.sys <%> 로 바꿈) ──
execute unless score #v50money rpg.sys matches 1 run scoreboard players set #mob_money rpg.sys 500
scoreboard players set #v50money rpg.sys 1
# v51 (1) 스킬 아이템
# v57b : Ctrl 은 제작자 스코어 — 데이터팩이 만들거나 지우지 않음
scoreboard objectives add rpg.glp dummy
scoreboard objectives add rpg.gst dummy
scoreboard objectives add rpg.shcd dummy
scoreboard objectives add rpg.hrcd dummy
# v51 (2) PVP · 경험치 x2
scoreboard objectives add rpg.pvpt dummy
scoreboard objectives add rpg.x2t dummy
execute unless score #c60 rpg.sys matches 60 run scoreboard players set #c60 rpg.sys 60
execute unless score #c10 rpg.sys matches 10 run scoreboard players set #c10 rpg.sys 10
execute unless score #k2 rpg.sys matches 2 run scoreboard players set #k2 rpg.sys 2
# v51 (3) 그림자이동 · 영웅의 힘
scoreboard objectives add rpg.shp dummy
scoreboard objectives add rpg.shn dummy
scoreboard objectives add rpg.shy dummy
scoreboard objectives add rpg.hrt dummy
execute unless score #shadow_cd rpg.sys matches 1.. run scoreboard players set #shadow_cd rpg.sys 900
execute unless score #hero_cd rpg.sys matches 1.. run scoreboard players set #hero_cd rpg.sys 1200
execute unless score #hero_t rpg.sys matches 1.. run scoreboard players set #hero_t rpg.sys 60
# v51 (3b) 상수
execute unless score #c24 rpg.sys matches 24 run scoreboard players set #c24 rpg.sys 24
# v51 (4) 장비 상인 · 보스 · 아이템 메뉴
scoreboard objectives add rpg.eqr dummy
scoreboard objectives add rpg.lhp dummy
scoreboard objectives add rpg.ita trigger
execute unless score #c64 rpg.sys matches 64 run scoreboard players set #c64 rpg.sys 64
scoreboard players set #bdsc rpg.sys 0
# v51 (1b) 스킬 클릭 시각
scoreboard objectives add rpg.skt dummy
# ── v56 ──
# (8) 스킬 아이템 본체 = 뒤틀린 균류 낚싯대 : rpg.uleap 기준을 한 번만 바꿈 (v57b : Ctrl 은 제작자 것이라 안 건드림)
execute unless score #v56obj rpg.sys matches 1 run scoreboard objectives remove rpg.uleap
execute unless score #v56obj rpg.sys matches 1 run scoreboard objectives add rpg.uleap minecraft.used:minecraft.warped_fungus_on_a_stick
scoreboard players set #v56obj rpg.sys 1
# (2) 갑옷 강화 배율 · (5) 대쉬 중력 상수
execute unless score #c13 rpg.sys matches 13 run scoreboard players set #c13 rpg.sys 13
execute unless score #c115 rpg.sys matches 115 run scoreboard players set #c115 rpg.sys 115
execute unless score #c100 rpg.sys matches 100 run scoreboard players set #c100 rpg.sys 100
execute unless score #c52 rpg.sys matches 52 run scoreboard players set #c52 rpg.sys 52
execute unless score #c1000 rpg.sys matches 1000 run scoreboard players set #c1000 rpg.sys 1000
# (3) 허수아비 낙하 속도
scoreboard objectives add rpg.scv dummy
# (13) 블록 보호(모험 모드) 없앰 : 지금 모험 모드로 바뀐 사람 되돌림
scoreboard players set #war_prot rpg.sys 0
execute as @a[tag=rpg_wadv] run function rpg:war/adv_off
# (16) [타오르는 불꽃] 패시브
scoreboard objectives add blaze-pas dummy {"text":"타오르는 불꽃","color":"gold"}
scoreboard objectives modify blaze-pas displayname {"text":"타오르는 불꽃","color":"gold"}
scoreboard objectives add rpg.bzg dummy
scoreboard objectives add rpg.bzt dummy
execute unless score #c4 rpg.sys matches 4 run scoreboard players set #c4 rpg.sys 4
data modify storage rpg:main bzb set value ["   [불꽃 □□□□□□□□□□]","   [불꽃 ■□□□□□□□□□]","   [불꽃 ■■□□□□□□□□]","   [불꽃 ■■■□□□□□□□]","   [불꽃 ■■■■□□□□□□]","   [불꽃 ■■■■■□□□□□]","   [불꽃 ■■■■■■□□□□]","   [불꽃 ■■■■■■■□□□]","   [불꽃 ■■■■■■■■□□]","   [불꽃 ■■■■■■■■■□]","   [불꽃 ■■■■■■■■■■]"]
data modify storage rpg:main bza set value ["   [불꽃 발동 □□□□□□□□□□]","   [불꽃 발동 ■□□□□□□□□□]","   [불꽃 발동 ■■□□□□□□□□]","   [불꽃 발동 ■■■□□□□□□□]","   [불꽃 발동 ■■■■□□□□□□]","   [불꽃 발동 ■■■■■□□□□□]","   [불꽃 발동 ■■■■■■□□□□]","   [불꽃 발동 ■■■■■■■□□□]","   [불꽃 발동 ■■■■■■■■□□]","   [불꽃 발동 ■■■■■■■■■□]","   [불꽃 발동 ■■■■■■■■■■]"]
# (17) 폭탄 3초 뒤 폭발
scoreboard objectives add rpg.bft dummy
# (20) 국가 신호기 재고 (처음 한 번만 가득)
execute unless score #bcn_stock rpg.sys matches 0.. run scoreboard players operation #bcn_stock rpg.sys = #bcn_max rpg.sys
# ── v57 ──
# (5) 대쉬 감속 여부
scoreboard objectives add rpg.dshs dummy
# ── v58 ──
# (1) 몬스터 레벨 표시 · (4) 막타 보상
scoreboard objectives add rpg.mlvl dummy
# (2) CC 기 : 대상 번호 · 둔화 · 침묵 · 화면 흔들림 · 방어력 깎기 · 치감(%) · 시야 차단 · 소리 차단 · 끌기 · 불
scoreboard objectives add rpg.uid dummy
scoreboard objectives add rpg.csT dummy
scoreboard objectives add rpg.csP dummy
scoreboard objectives add rpg.cmT dummy
scoreboard objectives add rpg.chT dummy
scoreboard objectives add rpg.chP dummy
scoreboard objectives add rpg.chX dummy
scoreboard objectives add rpg.chY dummy
scoreboard objectives add rpg.cdT dummy
scoreboard objectives add rpg.cdP dummy
scoreboard objectives add rpg.cdF dummy
scoreboard objectives add rpg.cuT dummy
scoreboard objectives add rpg.cuP dummy
scoreboard objectives add rpg.cvT dummy
scoreboard objectives add rpg.cvP dummy
scoreboard objectives add rpg.caT dummy
scoreboard objectives add rpg.caP dummy
scoreboard objectives add rpg.caK dummy
scoreboard objectives add rpg.cpT dummy
scoreboard objectives add rpg.cpS dummy
scoreboard objectives add rpg.cpO dummy
scoreboard objectives add rpg.cpF dummy
scoreboard objectives add rpg.cfT dummy
scoreboard objectives add rpg.cfO dummy
scoreboard objectives add rpg.cfB dummy
scoreboard objectives add rpg.cfR dummy
scoreboard objectives add rpg.cfK dummy
#   침묵 = 제작자 스코어보드 X (이미 있으면 그대로 · 없을 때만 만듦)
scoreboard objectives add X dummy
# (3) 뱀 스킬
scoreboard objectives add rpg.snaT dummy
scoreboard objectives add rpg.snaL dummy
scoreboard objectives add rpg.snaY dummy
scoreboard objectives add rpg.snaS dummy
# (6) 좌클릭 (제작자 스코어보드 L-click · 없을 때만 만듦)
scoreboard objectives add L-click dummy
scoreboard objectives add rpg.lct dummy
scoreboard objectives add rpg.hitr dummy
# (7) 정밀사격
scoreboard objectives add ranger-pas dummy {"text":"정밀사격","color":"aqua"}
scoreboard objectives add rpg.prT dummy
scoreboard objectives add rpg.prc dummy
scoreboard objectives add rpg.prL dummy
data modify storage rpg:main hud.rp set value ""
data modify storage rpg:main prc0 set value [{"text":"   [정밀 ","color":"aqua"},{"score":{"name":"@s","objective":"rpg.prc"},"color":"white","bold":true},{"text":"/","color":"dark_gray"},{"score":{"name":"#prc_need","objective":"rpg.sys"},"color":"gray"},{"text":"]","color":"aqua"}]
data modify storage rpg:main prc1 set value [{"text":"   [정밀 준비!]","color":"aqua","bold":true}]
# (8) 악마의 힘
scoreboard objectives add rpg.dmcd dummy
scoreboard objectives add rpg.dmT dummy
scoreboard objectives add rpg.shfx dummy
# (11) 스킬 아이템을 키(명령어)로 : /trigger skill.leap 등
scoreboard objectives add skill.leap trigger
scoreboard objectives add skill.stun trigger
scoreboard objectives add skill.shadow trigger
scoreboard objectives add skill.hero trigger
scoreboard objectives add skill.demon trigger
# 상수
execute unless score #c360 rpg.sys matches 360 run scoreboard players set #c360 rpg.sys 360
execute unless score #c-1 rpg.sys matches -1 run scoreboard players set #c-1 rpg.sys -1
execute unless score #c350 rpg.sys matches 350 run scoreboard players set #c350 rpg.sys 350
execute unless score #uidc rpg.sys matches 1.. run scoreboard players set #uidc rpg.sys 0
function rpg:fx/snk_cfg
data modify storage rpg:cc lc set value {c1:[0.0,0.0,0.0],c2:[0.0,0.0,0.0],s:0.8}
# ── v59 ──
# (1) 런치 대쉬 (launch-command 모드)
scoreboard objectives add rpg.lnT dummy
scoreboard objectives add rpg.lnA dummy
scoreboard objectives add rpg.lnH dummy
scoreboard objectives add rpg.lnG dummy
scoreboard objectives add rpg.lnX dummy
scoreboard objectives add rpg.lnZ dummy
scoreboard objectives add rpg.lnV dummy
scoreboard objectives add rpg.lnY dummy
scoreboard objectives add rpg.lnS dummy
scoreboard objectives add rpg.lnF dummy
execute unless score #c98 rpg.sys matches 98 run scoreboard players set #c98 rpg.sys 98
data modify storage rpg:ln zero set value {x:0.0,y:0.0,z:0.0}
# (2) 전직 : 직업 번호 · 퀘스트 · 진행도 · NPC 대화 · 트리거 · NPC 직업 번호
scoreboard objectives add rpg.job dummy {"text":"직업","color":"gold"}
scoreboard objectives add rpg.jq dummy
scoreboard objectives add rpg.jqk dummy
scoreboard objectives add rpg.jnr dummy
scoreboard objectives add rpg.jnt dummy
scoreboard objectives add rpg.jt trigger
scoreboard objectives add rpg.jid dummy
function rpg:job/data
data modify storage rpg:main hud.jq set value ""
data modify storage rpg:main jqb set value [{"text":"   [전직 ","color":"gold"},{"score":{"name":"@s","objective":"rpg.jqk"},"color":"yellow","bold":true},{"text":"/","color":"dark_gray"},{"score":{"name":"#job_kills","objective":"rpg.sys"},"color":"gray"},{"text":"]","color":"gold"}]
# ── v60 ──
# (1) 런치 대쉬 slowdown "x" 방향 틀기 : 속력 · 진행 각도
scoreboard objectives add rpg.lnP dummy
scoreboard objectives add rpg.lnW dummy
execute unless score #c36000 rpg.sys matches 36000 run scoreboard players set #c36000 rpg.sys 36000
execute unless score #c85 rpg.sys matches 85 run scoreboard players set #c85 rpg.sys 85
# (7) 초기화 회차 : 접속 안 했던 사람 · 안 읽힌 창고 통 정리
scoreboard objectives add rpg.rse dummy
execute unless score #rsep rpg.sys matches -2147483648.. run scoreboard players set #rsep rpg.sys 0
# (v60) 히든 패시브 이름표 — 책 · 켜기/끄기 알림용
data modify storage rpg:hid d set value {"h1": {"n": 1, "nm": "붉은 피 냄새", "cl": "dark_red", "ds": "적을 죽일 때마다 공격력 +2  (누적 최대 100 · 회차당 10번)"}, "h2": {"n": 2, "nm": "욕심쟁이", "cl": "dark_red", "ds": "잡은 보스의 레벨에 따라 네더의 별을 얻는다"}, "h3": {"n": 3, "nm": "힘숨찐", "cl": "dark_red", "ds": "쓰지 않은 스탯 1개당 공격력 +3 · 최대 체력 +6  (제한 없음)"}, "h4": {"n": 4, "nm": "인생은 한방!", "cl": "dark_red", "ds": "레벨업마다 추가 스탯 +5   단, 죽으면 레벨·스탯이 초기화된다 (H4 로 받은 추가 스탯도)"}, "h5": {"n": 5, "nm": "익숙한 결말", "cl": "dark_red", "ds": "죽을 때마다 공격력 +3  (누적 최대 100 · 회차당 10번)"}, "h6": {"n": 6, "nm": "끊이지 않는 투쟁", "cl": "dark_red", "ds": "전투가 길어질수록 저항 +1  (5초마다 · 최대 +3)"}, "h7": {"n": 7, "nm": "한놈만", "cl": "dark_red", "ds": "지정한 목표를 죽이면 추가 스탯 +2  (쿨 10분 · 목표 재지정 30분)"}, "h8": {"n": 8, "nm": "최초의 인간", "cl": "dark_red", "ds": "??? (아직 공개되지 않음)"}, "h9": {"n": 9, "nm": "약자 멸시", "cl": "dark_red", "ds": "나보다 레벨이 낮은 대상에게 공격력 +20"}, "h10": {"n": 10, "nm": "최강자", "cl": "dark_red", "ds": "나보다 레벨 낮은 플레이어의 피해 50% 감소  ·  서버 최고 레벨이면 공격력 +80 · 최대 체력 +50"}, "h11": {"n": 11, "nm": "손재주", "cl": "dark_red", "ds": "일반 등급 무기 강화 성공 시 +5 · 갑옷 강화 성공 시 +3"}, "h12": {"n": 12, "nm": "보이지 않는 손", "cl": "red", "ds": "타격할 때마다 10% 확률로 상대 소지금의 5%를 훔친다"}, "h13": {"n": 13, "nm": "반칙", "cl": "red", "ds": "어디서든 텔포를 쓸 수 있다   단, 전쟁 중에는 잠긴다"}, "h14": {"n": 14, "nm": "행운의 여신은 나의 편", "cl": "red", "ds": "크리티컬 · 몹 드롭 · 보스 드롭 · 강화 확률 +3%"}, "h15": {"n": 15, "nm": "폭주족", "cl": "red", "ds": "계속 달리면 5초마다 공격력 +3 · 이동속도 +0.005  (최대 25스택)"}, "h16": {"n": 16, "nm": "방어는 최선의 공격", "cl": "red", "ds": "웅크린 상태에서 공격력 +20"}, "h17": {"n": 17, "nm": "거북!거북!", "cl": "red", "ds": "웅크린 상태로 맞으면 피해 3% 감소"}, "h18": {"n": 18, "nm": "빈틈", "cl": "red", "ds": "크리티컬이 터지면 최대 체력의 3% 회복  (쿨 3초)"}, "h19": {"n": 19, "nm": "유리대포", "cl": "red", "ds": "공격력 150%  ·  받는 피해 200%"}, "h20": {"n": 20, "nm": "럭키 펀치!", "cl": "red", "ds": "평타 타격 시 1~10 룰렛 (처음) · 숫자가 클수록 + 확률↑ (최대 숫자 = 무조건 + · 피해 100%) · + 면 추가 피해 / - 면 내가 그만큼 받음 · + 로 막타를 치면 최대 +10 (최대 1~777)"}}
# (9) 히든 패시브 H19 유리대포 · H20 럭키 펀치!
scoreboard objectives add rpg.h19b dummy
scoreboard objectives add rpg.l20 dummy
scoreboard objectives add rpg.l20n dummy
scoreboard objectives add rpg.l20s dummy
scoreboard objectives add rpg.l20d dummy
scoreboard objectives add rpg.l20t dummy
scoreboard objectives add rpg.l20a dummy
scoreboard objectives add rpg.l20f dummy
execute unless score #c99 rpg.sys matches 99 run scoreboard players set #c99 rpg.sys 99
# (10) NPC 창 (dialog) — 마지막으로 연 NPC 창 번호 · 모으기 표시
scoreboard objectives add rpg.dlgm dummy
scoreboard players set #dlgon rpg.sys 0
scoreboard players set #dlgq rpg.sys 0
# ── v61 ──
# (B13) 불 중첩 수 · (공통) 재접속 감지
scoreboard objectives add rpg.cfS dummy
scoreboard objectives add rpg.lvg minecraft.custom:minecraft.leave_game
# (B1) 번개 소리 같은 틱 1번 (시전자별)
scoreboard objectives add rpg.lbs dummy
# (B12) 타오르는 불꽃 : 스킬 적중 게이지 마지막 틱
scoreboard objectives add rpg.bzk dummy
# (B4) H20 럭키 펀치 : 내 최대 숫자 · 막타 확인 (맞은 대상 쪽 주인 · 틱)
scoreboard objectives add rpg.l20m dummy
scoreboard objectives add rpg.l20k dummy
scoreboard objectives add rpg.l20kt dummy
# (B8) [설정] 화면(0) / 채팅(1) · NPC 대사 한 글자씩(0) / 한 번에(1) — 플레이어마다 유지
scoreboard objectives add rpg.ui dummy
scoreboard objectives add rpg.uty dummy
# (B5) 강화 연타 막기
scoreboard objectives add rpg.enhc dummy
# (B6) NPC 대사 타이핑 진행 중 (1)
scoreboard objectives add rpg.dty dummy
# ── v70 ──
# 스킬 해금 단계 (0 = 1차만 · 1~4 = 2~5차 해금) — 이미 있으면 그대로 (월드 장치가 같은 이름을 쓸 수 있음)
scoreboard objectives add HG dummy
# 스킬 해금 퀘스트 : 진행 중 1 · 처치 수 · 목표 몬스터 번호 · 목표 수 · 받은 단계 (1~4)
scoreboard objectives add rpg.hgq dummy
scoreboard objectives add rpg.hgk dummy
scoreboard objectives add rpg.hgt dummy
scoreboard objectives add rpg.hgn dummy
scoreboard objectives add rpg.hgs dummy
# 전직 무기 기다림 (직업 번호)
scoreboard objectives add rpg.jwq dummy
function rpg:job/wp_data
function rpg:job/hq_data
scoreboard players set #jwbusy rpg.sys 0
data modify storage rpg:main jqb2 set value [{"text":"   [전직 목표 달성 → NPC 보고]","color":"green"}]
data modify storage rpg:main hgb set value [{"text":"   [해금 ","color":"aqua"},{"score":{"name":"@s","objective":"rpg.hgk"},"color":"yellow","bold":true},{"text":"/","color":"dark_gray"},{"score":{"name":"@s","objective":"rpg.hgn"},"color":"gray"},{"text":"]","color":"aqua"}]
data modify storage rpg:main hgb2 set value [{"text":"   [해금 목표 달성 → NPC 보고]","color":"green"}]
# v70 : 균열 창 글 표
function rpg:rift/w_data
# ── v72 ──
# [민첩 70] 잔상 쿨타임 (틱)
scoreboard objectives add rpg.dgcd dummy
# ── v73 ──
# [흑막의 대가] (직업 패시브 · 1 = 상시 켜짐) · 받는 피해 0.01 단위 모으기
scoreboard objectives add mgs-pas dummy {"text":"흑막의 대가","color":"light_purple"}
scoreboard objectives add rpg.mgsb dummy
# [국가] 창 명단 : 마지막으로 명단에 적은 국가 (rpg:nat r)
scoreboard objectives add rpg.pfn dummy
# 엑스트라 NPC (클릭 칸 rpg_exm 에 정해진 값 · 같은 NPC 의 세 엔티티 = 같은 rpg.exid)
scoreboard objectives add rpg.exid dummy
scoreboard objectives add rpg.exs dummy
scoreboard objectives add rpg.exn dummy
scoreboard objectives add rpg.ext dummy
scoreboard objectives add rpg.exy dummy
scoreboard objectives add rpg.exsc dummy
scoreboard objectives add rpg.exbt dummy
function rpg:npc/ex/data
function rpg:nation/pad_data

# ============================================================
#  RPG 레벨/스탯 시스템 - 스코어보드 등록
# ============================================================
scoreboard objectives add rpg.lv dummy {"text":"레벨","color":"gold"}
scoreboard objectives add rpg.exp dummy {"text":"경험치","color":"green"}
scoreboard objectives add rpg.need dummy {"text":"필요 경험치","color":"dark_green"}
scoreboard objectives add rpg.sp dummy {"text":"자유 스탯","color":"yellow"}
scoreboard objectives add rpg.str dummy {"text":"힘","color":"red"}
scoreboard objectives add rpg.dex dummy {"text":"민첩","color":"aqua"}
scoreboard objectives add rpg.con dummy {"text":"체력","color":"light_purple"}

# 표시용(계산 결과) - 패시브 조건 판정에 그대로 써도 됩니다
scoreboard objectives add rpg.d_atk dummy {"text":"총 공격력","color":"red"}
scoreboard objectives add rpg.d_hp dummy {"text":"총 최대체력","color":"light_purple"}
scoreboard objectives add rpg.d_spd dummy {"text":"이동속도(%)","color":"aqua"}
scoreboard objectives add rpg.d_cur dummy {"text":"현재 체력","color":"red"}
scoreboard objectives add rpg.d_max dummy {"text":"최대 체력","color":"red"}

# 내부용
scoreboard objectives add rpg.t_atk dummy
scoreboard objectives add rpg.t_hp dummy
scoreboard objectives add rpg.t_spd dummy
scoreboard objectives add rpg.a_atk dummy
scoreboard objectives add rpg.a_hp dummy
scoreboard objectives add rpg.a_spd dummy
scoreboard objectives add rpg.dirty dummy
scoreboard objectives add rpg.slot dummy
scoreboard objectives add rpg.init dummy
scoreboard objectives add rpg.resp dummy
scoreboard objectives add rpg.xpo dummy
scoreboard objectives add rpg.bid dummy
scoreboard objectives add rpg.a_cur dummy
scoreboard objectives add rpg.a_max dummy
scoreboard objectives add rpg.a_exp dummy
scoreboard objectives add rpg.a_sp dummy
scoreboard objectives add rpg.php dummy
scoreboard objectives add rpg.cbt dummy
scoreboard objectives add rpg.hcd dummy
scoreboard objectives add rpg.combo dummy
scoreboard objectives add rpg.cmbt dummy
scoreboard objectives add rpg.stun dummy
scoreboard objectives add rpg.rage dummy
scoreboard objectives add rpg.hide dummy
scoreboard objectives add rpg.will dummy
scoreboard objectives add rpg.leap dummy
scoreboard objectives add rpg.regen dummy
scoreboard objectives add rpg.pid dummy
scoreboard objectives add rpg.rev dummy
scoreboard objectives add rpg.revt dummy
scoreboard objectives add rpg.cd60 dummy
scoreboard objectives add rpg.cd900 dummy
scoreboard objectives add rpg.p_atk dummy
scoreboard objectives add rpg.p_hp dummy
scoreboard objectives add rpg.p_spd dummy
scoreboard objectives add rpg.p_mul dummy
scoreboard objectives add rpg.war dummy
scoreboard objectives add rpg.busy dummy
scoreboard objectives add rpg.grace dummy
scoreboard objectives add rpg.tmax dummy {"text":"최대 체력","color":"red"}
scoreboard objectives add rpg.hpnow dummy {"text":"현재 체력","color":"red"}
scoreboard objectives add rpg.absorb dummy
scoreboard objectives add rpg.lastdmg dummy
scoreboard objectives add rpg.hpsc dummy
scoreboard objectives add rpg.crit dummy {"text":"크리티컬(1000분율)","color":"red"}
scoreboard objectives add rpg.cmb2 dummy
scoreboard objectives add rpg.cdw dummy
scoreboard objectives add rpg.revcd dummy
scoreboard objectives add rpg.sys dummy
scoreboard objectives add rpg.mig dummy
scoreboard objectives add rpg.lcd dummy
scoreboard objectives add rpg.scd dummy
scoreboard objectives add rpg.uleap minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add rpg.ustun minecraft.used:minecraft.warped_fungus_on_a_stick
scoreboard objectives add rpg.sid dummy
scoreboard objectives add rpg.cd dummy
scoreboard objectives add rpg.anim dummy
scoreboard objectives add rpg.shopt dummy
scoreboard objectives add rpg.stunt dummy
scoreboard objectives add rpg.q_tuto dummy {"text":"튜토리얼 퀘스트","color":"yellow"}
scoreboard objectives add rpg.q_main dummy {"text":"메인 퀘스트","color":"yellow"}
scoreboard objectives add rpg.qc dummy {"text":"퀘스트 진행도","color":"yellow"}
scoreboard objectives add rpg.q trigger
scoreboard objectives add rpg.menu trigger
scoreboard objectives add rpg.up trigger
scoreboard objectives add rpg.tp trigger
scoreboard objectives add money dummy {"text": " 소지금", "color": "gold", "bold": true}
scoreboard objectives add rpg.chk trigger
scoreboard objectives add rpg.shop trigger
scoreboard objectives add rpg.cry trigger
scoreboard objectives add rpg.eq trigger
scoreboard objectives add rpg.eqs dummy
scoreboard objectives add rpg.eqt dummy
# 구버전 팀/개인 사이드바 정리 (닉네임 색이 팀 색으로 바뀌던 문제)
scoreboard objectives setdisplay sidebar.team.black
team remove rpg.s0
scoreboard objectives remove rpg.m0
scoreboard objectives setdisplay sidebar.team.dark_blue
team remove rpg.s1
scoreboard objectives remove rpg.m1
scoreboard objectives setdisplay sidebar.team.dark_green
team remove rpg.s2
scoreboard objectives remove rpg.m2
scoreboard objectives setdisplay sidebar.team.dark_aqua
team remove rpg.s3
scoreboard objectives remove rpg.m3
scoreboard objectives setdisplay sidebar.team.dark_red
team remove rpg.s4
scoreboard objectives remove rpg.m4
scoreboard objectives setdisplay sidebar.team.dark_purple
team remove rpg.s5
scoreboard objectives remove rpg.m5
scoreboard objectives setdisplay sidebar.team.gold
team remove rpg.s6
scoreboard objectives remove rpg.m6
scoreboard objectives setdisplay sidebar.team.gray
team remove rpg.s7
scoreboard objectives remove rpg.m7
scoreboard objectives setdisplay sidebar.team.dark_gray
team remove rpg.s8
scoreboard objectives remove rpg.m8
scoreboard objectives setdisplay sidebar.team.blue
team remove rpg.s9
scoreboard objectives remove rpg.m9
scoreboard objectives setdisplay sidebar.team.green
team remove rpg.s10
scoreboard objectives remove rpg.m10
scoreboard objectives setdisplay sidebar.team.aqua
team remove rpg.s11
scoreboard objectives remove rpg.m11
scoreboard objectives setdisplay sidebar.team.red
team remove rpg.s12
scoreboard objectives remove rpg.m12
scoreboard objectives setdisplay sidebar.team.light_purple
team remove rpg.s13
scoreboard objectives remove rpg.m13
scoreboard objectives setdisplay sidebar.team.yellow
team remove rpg.s14
scoreboard objectives remove rpg.m14
scoreboard objectives setdisplay sidebar.team.white
team remove rpg.s15
scoreboard objectives remove rpg.m15
scoreboard objectives setdisplay sidebar
scoreboard objectives add menu trigger {"text":"메뉴 열기"}
scoreboard objectives add C+C dummy {"text":"C+C","color":"aqua"}
scoreboard objectives add fly dummy {"text":"비행","color":"aqua"}
scoreboard objectives add rpg.cct dummy
scoreboard objectives add rpg.snkS dummy
scoreboard objectives add rpg.snkP dummy
scoreboard objectives add rpg.snkN dummy
scoreboard objectives add rpg.snkT dummy
scoreboard objectives add rpg.grav dummy
scoreboard objectives add rpg.auc trigger
scoreboard objectives add rpg.abidi dummy
scoreboard objectives add rpg.abidv dummy
scoreboard objectives add rpg.aminv dummy
scoreboard objectives add rpg.asort dummy
scoreboard objectives add rpg.abid1 dummy
scoreboard objectives add rpg.abid2 dummy
scoreboard objectives add rpg.abid3 dummy
scoreboard objectives add rpg.abid4 dummy
scoreboard objectives add rpg.abidL dummy
scoreboard objectives add rpg.qcat dummy
scoreboard objectives add rpg.qord dummy
scoreboard objectives add rpg.qo1 dummy
scoreboard objectives add rpg.qo2 dummy
scoreboard objectives add rpg.pow dummy
scoreboard objectives add rpg.def dummy {"text":"방어력","color":"aqua"}
scoreboard objectives add rpg.d_def dummy {"text":"피해 경감(%)","color":"aqua"}
scoreboard objectives add rpg.rnd trigger
scoreboard objectives add rpg.npc trigger
scoreboard objectives add rpg.enh trigger
scoreboard objectives add rpg.enhM dummy
scoreboard objectives add rpg.spD dummy
scoreboard objectives add rpg.spL dummy
scoreboard objectives add rpg.spDu dummy
scoreboard objectives add rpg.spLu dummy
scoreboard objectives add rpg.dsh dummy
scoreboard objectives add rpg.dshp dummy
scoreboard objectives add rpg.dshv dummy
scoreboard objectives add rpg.dshf dummy
scoreboard objectives add rpg.dshl dummy
scoreboard objectives add rpg.fxi dummy
scoreboard objectives add rpg.fxs dummy
scoreboard objectives add rpg.nat trigger
scoreboard objectives add rpg.vlt trigger
scoreboard objectives add rpg.bills dummy
scoreboard objectives add rpg.nmok dummy
scoreboard objectives add rpg.nmt dummy
scoreboard objectives add rpg.deaths minecraft.custom:minecraft.deaths
scoreboard objectives add rpg.kill minecraft.custom:minecraft.mob_kills
scoreboard objectives add rpg.hp health

# 게이지바 문자 테이블 (리소스팩 rpg_hud 폰트)
data modify storage rpg:main hpb set value ["","","","","","","","","","","","","","","","","","","","",""]
data modify storage rpg:main xpb set value ["","","","","","","","","","","","","","","","","","","","",""]

execute unless data storage rpg:main bb.v run data modify storage rpg:main bb.v set value "center"
data modify storage rpg:main hud.hc set value ""
data modify storage rpg:main hud.xc set value ""

function rpg:config
execute unless score #spid rpg.sys matches 0.. run scoreboard players set #spid rpg.sys 0
# 몹 모델 구조가 바뀌면 한 번만 전체 청소 (겹쳐 쌓인 모델 제거)
execute unless score #mver rpg.sys matches 11 run data modify storage rpg:main bb.v set value "center"
execute unless score #mver rpg.sys matches 11 run function rpg:mob/reset_all
scoreboard players set #mver rpg.sys 11

# 구버전 보스바 정리 (한 번만)
execute unless score #ver rpg.sys matches 2 run function rpg:admin/clear_bars
scoreboard players set #ver rpg.sys 2
tellraw @a [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"레벨/스탯 시스템이 로드되었습니다.","color":"white"}]

# 경매 / 비행 / C+C 트리거 활성화
scoreboard players enable @a rpg.auc
scoreboard players add @a rpg.abidL 0
scoreboard players add @a rpg.qcat 1
scoreboard players add @a rpg.qord 0

# 국가 팀 (최초 1회)
execute unless score #natset rpg.sys matches 1 run function rpg:nation/setup
scoreboard players set #natset rpg.sys 1
scoreboard players enable @a rpg.nat
scoreboard players enable @a rpg.vlt

# 시스템 점수 초기화 (없으면 조건문이 통째로 실패합니다)
scoreboard players add #auc_bb rpg.sys 0
scoreboard players add #auc_run rpg.sys 0
scoreboard players add #auc_pause rpg.sys 0
scoreboard players add #auc_n rpg.sys 0
scoreboard players add #auc_time rpg.sys 0
scoreboard players add #rnd_run rpg.sys 0
scoreboard players add #rnd_pause rpg.sys 0
scoreboard players add #rnd_time rpg.sys 0
scoreboard players add #rnd_max rpg.sys 0
scoreboard players add #rnd_bb rpg.sys 0
scoreboard players add @a rpg.def 0
scoreboard players enable @a rpg.rnd
scoreboard players enable @a rpg.npc
scoreboard players enable @a rpg.enh
scoreboard players add @a rpg.enhM 0
scoreboard players add @a rpg.spD 0
scoreboard players add @a rpg.spL 0
# 강화 확률 기본값 (1000 = 100%)
execute unless data storage rpg:enh cfg.v run data remove storage rpg:enh cfg
execute unless data storage rpg:enh cfg.v run data modify storage rpg:enh cfg set value {v:2,req:{}}
scoreboard players add #e_base rpg.sys 0
execute if score #e_base rpg.sys matches 0 run scoreboard players set #e_base rpg.sys 900
scoreboard players add #e_dec rpg.sys 0
execute if score #e_dec rpg.sys matches 0 run scoreboard players set #e_dec rpg.sys 40
scoreboard players add #e_dfrom rpg.sys 0
execute if score #e_dfrom rpg.sys matches 0 run scoreboard players set #e_dfrom rpg.sys 7
scoreboard players add #e_dinc rpg.sys 0
execute if score #e_dinc rpg.sys matches 0 run scoreboard players set #e_dinc rpg.sys 25
scoreboard players add @a rpg.dsh 0
scoreboard players add @a rpg.dshf 0
scoreboard players add #pid_next rpg.sys 0
scoreboard players add @a fly 0
scoreboard players add @a rpg.grav 0
scoreboard players add @a C+C 0
scoreboard players add @a rpg.bills 0
function rpg:nation/fix

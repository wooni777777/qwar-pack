# ============================================================
#  RPG 레벨/스탯 시스템 - 스코어보드 등록
# ============================================================
scoreboard objectives add rpg.lv dummy {"text":"레벨","color":"gold"}
scoreboard objectives add rpg.exp dummy {"text":"경험치","color":"green"}
scoreboard objectives add rpg.need dummy {"text":"필요 경험치","color":"dark_green"}
scoreboard objectives add rpg.sp dummy {"text":"자유 스탯","color":"yellow"}
scoreboard objectives add rpg.str dummy {"text":"힘","color":"red"}
scoreboard objectives add rpg.dex dummy {"text":"민첩","color":"aqua"}
scoreboard objectives add rpg.con dummy {"text":"체력","color":"green"}

# 표시용(계산 결과) - 패시브 조건 판정에 그대로 써도 됩니다
scoreboard objectives add rpg.d_atk dummy {"text":"총 공격력","color":"red"}
scoreboard objectives add rpg.d_hp dummy {"text":"총 최대체력","color":"green"}
scoreboard objectives add rpg.d_spd dummy {"text":"이동속도(%)","color":"aqua"}
scoreboard objectives add rpg.d_cur dummy {"text":"현재 체력","color":"red"}
scoreboard objectives add rpg.d_max dummy {"text":"최대 체력","color":"red"}

# 내부용
scoreboard objectives add rpg.t_atk dummy
scoreboard objectives add rpg.t_hp dummy
scoreboard objectives add rpg.t_spd dummy
scoreboard objectives add rpg.a_atk dummy
scoreboard objectives add rpg.a_hp dummy
scoreboard objectives add rpg.a_spd dummy
scoreboard objectives add rpg.dirty dummy
scoreboard objectives add rpg.slot dummy
scoreboard objectives add rpg.init dummy
scoreboard objectives add rpg.resp dummy
scoreboard objectives add rpg.xpo dummy
scoreboard objectives add rpg.bid dummy
scoreboard objectives add rpg.a_cur dummy
scoreboard objectives add rpg.a_max dummy
scoreboard objectives add rpg.a_exp dummy
scoreboard objectives add rpg.a_sp dummy
scoreboard objectives add rpg.php dummy
scoreboard objectives add rpg.cbt dummy
scoreboard objectives add rpg.hcd dummy
scoreboard objectives add rpg.combo dummy
scoreboard objectives add rpg.cmbt dummy
scoreboard objectives add rpg.stun dummy
scoreboard objectives add rpg.rage dummy
scoreboard objectives add rpg.hide dummy
scoreboard objectives add rpg.will dummy
scoreboard objectives add rpg.leap dummy
scoreboard objectives add rpg.regen dummy
scoreboard objectives add rpg.pid dummy
scoreboard objectives add rpg.rev dummy
scoreboard objectives add rpg.revt dummy
scoreboard objectives add rpg.cd60 dummy
scoreboard objectives add rpg.cd900 dummy
scoreboard objectives add rpg.p_atk dummy
scoreboard objectives add rpg.p_hp dummy
scoreboard objectives add rpg.p_spd dummy
scoreboard objectives add rpg.p_mul dummy
scoreboard objectives add rpg.war dummy
scoreboard objectives add rpg.busy dummy
scoreboard objectives add rpg.grace dummy
scoreboard objectives add rpg.tmax dummy {"text":"최대 체력","color":"red"}
scoreboard objectives add rpg.hpnow dummy {"text":"현재 체력","color":"red"}
scoreboard objectives add rpg.absorb dummy
scoreboard objectives add rpg.lastdmg dummy
scoreboard objectives add rpg.hpsc dummy
scoreboard objectives add rpg.crit dummy {"text":"크리티컬(1000분율)","color":"red"}
scoreboard objectives add rpg.cmb2 dummy
scoreboard objectives add rpg.cdw dummy
scoreboard objectives add rpg.revcd dummy
scoreboard objectives add rpg.sys dummy
scoreboard objectives add rpg.mig dummy
scoreboard objectives add rpg.lcd dummy
scoreboard objectives add rpg.scd dummy
scoreboard objectives add rpg.uleap minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add rpg.ustun minecraft.used:minecraft.warped_fungus_on_a_stick
scoreboard objectives add rpg.sid dummy
scoreboard objectives add rpg.cd dummy
scoreboard objectives add rpg.anim dummy
scoreboard objectives add rpg.shopt dummy
scoreboard objectives add rpg.stunt dummy
scoreboard objectives add rpg.q_tuto dummy {"text":"튜토리얼 퀘스트","color":"yellow"}
scoreboard objectives add rpg.q_main dummy {"text":"메인 퀘스트","color":"yellow"}
scoreboard objectives add rpg.qc dummy {"text":"퀘스트 진행도","color":"yellow"}
scoreboard objectives add rpg.q trigger
scoreboard objectives add rpg.menu trigger
scoreboard objectives add rpg.up trigger
scoreboard objectives add rpg.tp trigger
scoreboard objectives add money dummy {"text": " 소지금", "color": "gold", "bold": true}
scoreboard objectives add rpg.chk trigger
scoreboard objectives add rpg.shop trigger
scoreboard objectives add rpg.cry trigger
scoreboard objectives add rpg.eq trigger
scoreboard objectives add rpg.eqs dummy
scoreboard objectives add rpg.eqt dummy
# 구버전 팀/개인 사이드바 정리 (닉네임 색이 팀 색으로 바뀌던 문제)
scoreboard objectives setdisplay sidebar.team.black
team remove rpg.s0
scoreboard objectives remove rpg.m0
scoreboard objectives setdisplay sidebar.team.dark_blue
team remove rpg.s1
scoreboard objectives remove rpg.m1
scoreboard objectives setdisplay sidebar.team.dark_green
team remove rpg.s2
scoreboard objectives remove rpg.m2
scoreboard objectives setdisplay sidebar.team.dark_aqua
team remove rpg.s3
scoreboard objectives remove rpg.m3
scoreboard objectives setdisplay sidebar.team.dark_red
team remove rpg.s4
scoreboard objectives remove rpg.m4
scoreboard objectives setdisplay sidebar.team.dark_purple
team remove rpg.s5
scoreboard objectives remove rpg.m5
scoreboard objectives setdisplay sidebar.team.gold
team remove rpg.s6
scoreboard objectives remove rpg.m6
scoreboard objectives setdisplay sidebar.team.gray
team remove rpg.s7
scoreboard objectives remove rpg.m7
scoreboard objectives setdisplay sidebar.team.dark_gray
team remove rpg.s8
scoreboard objectives remove rpg.m8
scoreboard objectives setdisplay sidebar.team.blue
team remove rpg.s9
scoreboard objectives remove rpg.m9
scoreboard objectives setdisplay sidebar.team.green
team remove rpg.s10
scoreboard objectives remove rpg.m10
scoreboard objectives setdisplay sidebar.team.aqua
team remove rpg.s11
scoreboard objectives remove rpg.m11
scoreboard objectives setdisplay sidebar.team.red
team remove rpg.s12
scoreboard objectives remove rpg.m12
scoreboard objectives setdisplay sidebar.team.light_purple
team remove rpg.s13
scoreboard objectives remove rpg.m13
scoreboard objectives setdisplay sidebar.team.yellow
team remove rpg.s14
scoreboard objectives remove rpg.m14
scoreboard objectives setdisplay sidebar.team.white
team remove rpg.s15
scoreboard objectives remove rpg.m15
scoreboard objectives setdisplay sidebar
scoreboard objectives add menu trigger {"text":"메뉴 열기"}
scoreboard objectives add C+C dummy {"text":"C+C","color":"aqua"}
scoreboard objectives add fly dummy {"text":"비행","color":"aqua"}
scoreboard objectives add rpg.cct dummy
scoreboard objectives add rpg.snkS dummy
scoreboard objectives add rpg.snkP dummy
scoreboard objectives add rpg.snkN dummy
scoreboard objectives add rpg.snkT dummy
scoreboard objectives add rpg.grav dummy
scoreboard objectives add rpg.auc trigger
scoreboard objectives add rpg.abidi dummy
scoreboard objectives add rpg.abidv dummy
scoreboard objectives add rpg.aminv dummy
scoreboard objectives add rpg.asort dummy
scoreboard objectives add rpg.abid1 dummy
scoreboard objectives add rpg.abid2 dummy
scoreboard objectives add rpg.abid3 dummy
scoreboard objectives add rpg.abid4 dummy
scoreboard objectives add rpg.abidL dummy
scoreboard objectives add rpg.qcat dummy
scoreboard objectives add rpg.qord dummy
scoreboard objectives add rpg.qo1 dummy
scoreboard objectives add rpg.qo2 dummy
scoreboard objectives add rpg.pow dummy
scoreboard objectives add rpg.def dummy {"text":"방어력","color":"aqua"}
scoreboard objectives add rpg.d_def dummy {"text":"피해 경감(%)","color":"aqua"}
scoreboard objectives add rpg.rnd trigger
scoreboard objectives add rpg.npc trigger
scoreboard objectives add rpg.enh trigger
scoreboard objectives add rpg.enhM dummy
scoreboard objectives add rpg.spD dummy
scoreboard objectives add rpg.spL dummy
scoreboard objectives add rpg.spDu dummy
scoreboard objectives add rpg.spLu dummy
scoreboard objectives add rpg.dsh dummy
scoreboard objectives add rpg.dshp dummy
scoreboard objectives add rpg.dshv dummy
scoreboard objectives add rpg.dshf dummy
scoreboard objectives add rpg.dshl dummy
scoreboard objectives add rpg.fxi dummy
scoreboard objectives add rpg.h7t trigger
scoreboard objectives add rpg.h1 dummy
scoreboard objectives add rpg.h1c dummy
scoreboard objectives add rpg.h5 dummy
scoreboard objectives add rpg.h5c dummy
scoreboard objectives add rpg.h6t dummy
scoreboard objectives add rpg.h6s dummy
scoreboard objectives add rpg.h7cd dummy
scoreboard objectives add rpg.h15 dummy
scoreboard objectives add rpg.h15t dummy
scoreboard objectives add rpg.h18cd dummy
scoreboard objectives add rpg.hdead dummy
scoreboard objectives add rpg.h7id dummy
scoreboard objectives add rpg.h7set dummy
scoreboard objectives add rpg.h7cd dummy
scoreboard objectives add rpg.fxs dummy
scoreboard objectives add rpg.nat trigger
scoreboard objectives add rpg.natn dummy {"text":"국가","color":"white"}
scoreboard objectives add rpg.vlt trigger
scoreboard objectives add rpg.bills dummy
scoreboard objectives add rpg.nmok dummy
scoreboard objectives add rpg.nmt dummy
scoreboard objectives add rpg.deaths minecraft.custom:minecraft.deaths
scoreboard objectives add rpg.kill minecraft.custom:minecraft.mob_kills
scoreboard objectives add rpg.pkT dummy
scoreboard objectives add rpg.pkF dummy
scoreboard objectives add rpg.mob trigger
scoreboard objectives add rpg.mdr trigger
execute unless score #mlv_ddol rpg.sys matches 1.. run scoreboard players set #mlv_ddol rpg.sys 1
execute unless score #mlv_ddodol rpg.sys matches 1.. run scoreboard players set #mlv_ddodol rpg.sys 3
execute unless score #mlv_dolmengi rpg.sys matches 1.. run scoreboard players set #mlv_dolmengi rpg.sys 5
execute unless score #mlv_dol rpg.sys matches 1.. run scoreboard players set #mlv_dol rpg.sys 10
execute unless score #mlv_wolf rpg.sys matches 1.. run scoreboard players set #mlv_wolf rpg.sys 15
execute unless score #mlv_pir1 rpg.sys matches 1.. run scoreboard players set #mlv_pir1 rpg.sys 8
execute unless score #mlv_pir2 rpg.sys matches 1.. run scoreboard players set #mlv_pir2 rpg.sys 10
execute unless score #mlv_pir3 rpg.sys matches 1.. run scoreboard players set #mlv_pir3 rpg.sys 9
execute unless score #mlv_pking rpg.sys matches 1.. run scoreboard players set #mlv_pking rpg.sys 20
# ── 보스 드롭 슬롯 기본값 (v35) ──
execute unless score #dsd1k rpg.sys matches -2147483648.. run scoreboard players set #dsd1k rpg.sys 4
execute unless score #dsd1v rpg.sys matches -2147483648.. run scoreboard players set #dsd1v rpg.sys 1
execute unless score #dsd1n rpg.sys matches -2147483648.. run scoreboard players set #dsd1n rpg.sys 1
execute unless score #dsd1p rpg.sys matches -2147483648.. run scoreboard players set #dsd1p rpg.sys 100
execute unless score #dsd2k rpg.sys matches -2147483648.. run scoreboard players set #dsd2k rpg.sys 4
execute unless score #dsd2v rpg.sys matches -2147483648.. run scoreboard players set #dsd2v rpg.sys 2
execute unless score #dsd2n rpg.sys matches -2147483648.. run scoreboard players set #dsd2n rpg.sys 30
execute unless score #dsd2p rpg.sys matches -2147483648.. run scoreboard players set #dsd2p rpg.sys 100
execute unless score #dsd3k rpg.sys matches -2147483648.. run scoreboard players set #dsd3k rpg.sys 3
execute unless score #dsd3v rpg.sys matches -2147483648.. run scoreboard players set #dsd3v rpg.sys 1
execute unless score #dsd3n rpg.sys matches -2147483648.. run scoreboard players set #dsd3n rpg.sys 2
execute unless score #dsd3p rpg.sys matches -2147483648.. run scoreboard players set #dsd3p rpg.sys 100
execute unless score #dsd4k rpg.sys matches -2147483648.. run scoreboard players set #dsd4k rpg.sys 3
execute unless score #dsd4v rpg.sys matches -2147483648.. run scoreboard players set #dsd4v rpg.sys 1
execute unless score #dsd4n rpg.sys matches -2147483648.. run scoreboard players set #dsd4n rpg.sys 1
execute unless score #dsd4p rpg.sys matches -2147483648.. run scoreboard players set #dsd4p rpg.sys 20
execute unless score #dsd5k rpg.sys matches -2147483648.. run scoreboard players set #dsd5k rpg.sys 1
execute unless score #dsd5v rpg.sys matches -2147483648.. run scoreboard players set #dsd5v rpg.sys 3
execute unless score #dsd5n rpg.sys matches -2147483648.. run scoreboard players set #dsd5n rpg.sys 2
execute unless score #dsd5p rpg.sys matches -2147483648.. run scoreboard players set #dsd5p rpg.sys 100
execute unless score #dsd6k rpg.sys matches -2147483648.. run scoreboard players set #dsd6k rpg.sys 1
execute unless score #dsd6v rpg.sys matches -2147483648.. run scoreboard players set #dsd6v rpg.sys 2
execute unless score #dsd6n rpg.sys matches -2147483648.. run scoreboard players set #dsd6n rpg.sys 5
execute unless score #dsd6p rpg.sys matches -2147483648.. run scoreboard players set #dsd6p rpg.sys 100
execute unless score #dsd7k rpg.sys matches -2147483648.. run scoreboard players set #dsd7k rpg.sys 0
execute unless score #dsd7v rpg.sys matches -2147483648.. run scoreboard players set #dsd7v rpg.sys 1
execute unless score #dsd7n rpg.sys matches -2147483648.. run scoreboard players set #dsd7n rpg.sys 0
execute unless score #dsd7p rpg.sys matches -2147483648.. run scoreboard players set #dsd7p rpg.sys 0
execute unless score #dsd8k rpg.sys matches -2147483648.. run scoreboard players set #dsd8k rpg.sys 0
execute unless score #dsd8v rpg.sys matches -2147483648.. run scoreboard players set #dsd8v rpg.sys 1
execute unless score #dsd8n rpg.sys matches -2147483648.. run scoreboard players set #dsd8n rpg.sys 0
execute unless score #dsd8p rpg.sys matches -2147483648.. run scoreboard players set #dsd8p rpg.sys 0
execute unless score #dsw1k rpg.sys matches -2147483648.. run scoreboard players set #dsw1k rpg.sys 4
execute unless score #dsw1v rpg.sys matches -2147483648.. run scoreboard players set #dsw1v rpg.sys 1
execute unless score #dsw1n rpg.sys matches -2147483648.. run scoreboard players set #dsw1n rpg.sys 3
execute unless score #dsw1p rpg.sys matches -2147483648.. run scoreboard players set #dsw1p rpg.sys 100
execute unless score #dsw2k rpg.sys matches -2147483648.. run scoreboard players set #dsw2k rpg.sys 4
execute unless score #dsw2v rpg.sys matches -2147483648.. run scoreboard players set #dsw2v rpg.sys 1
execute unless score #dsw2n rpg.sys matches -2147483648.. run scoreboard players set #dsw2n rpg.sys 1
execute unless score #dsw2p rpg.sys matches -2147483648.. run scoreboard players set #dsw2p rpg.sys 30
execute unless score #dsw3k rpg.sys matches -2147483648.. run scoreboard players set #dsw3k rpg.sys 1
execute unless score #dsw3v rpg.sys matches -2147483648.. run scoreboard players set #dsw3v rpg.sys 4
execute unless score #dsw3n rpg.sys matches -2147483648.. run scoreboard players set #dsw3n rpg.sys 1
execute unless score #dsw3p rpg.sys matches -2147483648.. run scoreboard players set #dsw3p rpg.sys 100
execute unless score #dsw4k rpg.sys matches -2147483648.. run scoreboard players set #dsw4k rpg.sys 2
execute unless score #dsw4v rpg.sys matches -2147483648.. run scoreboard players set #dsw4v rpg.sys 3
execute unless score #dsw4n rpg.sys matches -2147483648.. run scoreboard players set #dsw4n rpg.sys 1
execute unless score #dsw4p rpg.sys matches -2147483648.. run scoreboard players set #dsw4p rpg.sys 100
execute unless score #dsw5k rpg.sys matches -2147483648.. run scoreboard players set #dsw5k rpg.sys 0
execute unless score #dsw5v rpg.sys matches -2147483648.. run scoreboard players set #dsw5v rpg.sys 1
execute unless score #dsw5n rpg.sys matches -2147483648.. run scoreboard players set #dsw5n rpg.sys 0
execute unless score #dsw5p rpg.sys matches -2147483648.. run scoreboard players set #dsw5p rpg.sys 0
execute unless score #dsw6k rpg.sys matches -2147483648.. run scoreboard players set #dsw6k rpg.sys 0
execute unless score #dsw6v rpg.sys matches -2147483648.. run scoreboard players set #dsw6v rpg.sys 1
execute unless score #dsw6n rpg.sys matches -2147483648.. run scoreboard players set #dsw6n rpg.sys 0
execute unless score #dsw6p rpg.sys matches -2147483648.. run scoreboard players set #dsw6p rpg.sys 0
execute unless score #dsw7k rpg.sys matches -2147483648.. run scoreboard players set #dsw7k rpg.sys 0
execute unless score #dsw7v rpg.sys matches -2147483648.. run scoreboard players set #dsw7v rpg.sys 1
execute unless score #dsw7n rpg.sys matches -2147483648.. run scoreboard players set #dsw7n rpg.sys 0
execute unless score #dsw7p rpg.sys matches -2147483648.. run scoreboard players set #dsw7p rpg.sys 0
execute unless score #dsw8k rpg.sys matches -2147483648.. run scoreboard players set #dsw8k rpg.sys 0
execute unless score #dsw8v rpg.sys matches -2147483648.. run scoreboard players set #dsw8v rpg.sys 1
execute unless score #dsw8n rpg.sys matches -2147483648.. run scoreboard players set #dsw8n rpg.sys 0
execute unless score #dsw8p rpg.sys matches -2147483648.. run scoreboard players set #dsw8p rpg.sys 0
execute unless score #dsk1k rpg.sys matches -2147483648.. run scoreboard players set #dsk1k rpg.sys 3
execute unless score #dsk1v rpg.sys matches -2147483648.. run scoreboard players set #dsk1v rpg.sys 2
execute unless score #dsk1n rpg.sys matches -2147483648.. run scoreboard players set #dsk1n rpg.sys 2
execute unless score #dsk1p rpg.sys matches -2147483648.. run scoreboard players set #dsk1p rpg.sys 100
execute unless score #dsk2k rpg.sys matches -2147483648.. run scoreboard players set #dsk2k rpg.sys 4
execute unless score #dsk2v rpg.sys matches -2147483648.. run scoreboard players set #dsk2v rpg.sys 2
execute unless score #dsk2n rpg.sys matches -2147483648.. run scoreboard players set #dsk2n rpg.sys 1
execute unless score #dsk2p rpg.sys matches -2147483648.. run scoreboard players set #dsk2p rpg.sys 100
execute unless score #dsk3k rpg.sys matches -2147483648.. run scoreboard players set #dsk3k rpg.sys 4
execute unless score #dsk3v rpg.sys matches -2147483648.. run scoreboard players set #dsk3v rpg.sys 1
execute unless score #dsk3n rpg.sys matches -2147483648.. run scoreboard players set #dsk3n rpg.sys 5
execute unless score #dsk3p rpg.sys matches -2147483648.. run scoreboard players set #dsk3p rpg.sys 100
execute unless score #dsk4k rpg.sys matches -2147483648.. run scoreboard players set #dsk4k rpg.sys 3
execute unless score #dsk4v rpg.sys matches -2147483648.. run scoreboard players set #dsk4v rpg.sys 2
execute unless score #dsk4n rpg.sys matches -2147483648.. run scoreboard players set #dsk4n rpg.sys 1
execute unless score #dsk4p rpg.sys matches -2147483648.. run scoreboard players set #dsk4p rpg.sys 20
execute unless score #dsk5k rpg.sys matches -2147483648.. run scoreboard players set #dsk5k rpg.sys 4
execute unless score #dsk5v rpg.sys matches -2147483648.. run scoreboard players set #dsk5v rpg.sys 1
execute unless score #dsk5n rpg.sys matches -2147483648.. run scoreboard players set #dsk5n rpg.sys 3
execute unless score #dsk5p rpg.sys matches -2147483648.. run scoreboard players set #dsk5p rpg.sys 20
execute unless score #dsk6k rpg.sys matches -2147483648.. run scoreboard players set #dsk6k rpg.sys 4
execute unless score #dsk6v rpg.sys matches -2147483648.. run scoreboard players set #dsk6v rpg.sys 3
execute unless score #dsk6n rpg.sys matches -2147483648.. run scoreboard players set #dsk6n rpg.sys 1
execute unless score #dsk6p rpg.sys matches -2147483648.. run scoreboard players set #dsk6p rpg.sys 50
execute unless score #dsk7k rpg.sys matches -2147483648.. run scoreboard players set #dsk7k rpg.sys 1
execute unless score #dsk7v rpg.sys matches -2147483648.. run scoreboard players set #dsk7v rpg.sys 4
execute unless score #dsk7n rpg.sys matches -2147483648.. run scoreboard players set #dsk7n rpg.sys 2
execute unless score #dsk7p rpg.sys matches -2147483648.. run scoreboard players set #dsk7p rpg.sys 100
execute unless score #dsk8k rpg.sys matches -2147483648.. run scoreboard players set #dsk8k rpg.sys 1
execute unless score #dsk8v rpg.sys matches -2147483648.. run scoreboard players set #dsk8v rpg.sys 3
execute unless score #dsk8n rpg.sys matches -2147483648.. run scoreboard players set #dsk8n rpg.sys 5
execute unless score #dsk8p rpg.sys matches -2147483648.. run scoreboard players set #dsk8p rpg.sys 100
execute unless score #dr_d1n rpg.sys matches 0.. run scoreboard players set #dr_d1n rpg.sys 1
execute unless score #dr_d1p rpg.sys matches 0.. run scoreboard players set #dr_d1p rpg.sys 100
execute unless score #dr_d2n rpg.sys matches 0.. run scoreboard players set #dr_d2n rpg.sys 30
execute unless score #dr_d2p rpg.sys matches 0.. run scoreboard players set #dr_d2p rpg.sys 100
execute unless score #dr_d3n rpg.sys matches 0.. run scoreboard players set #dr_d3n rpg.sys 2
execute unless score #dr_d3p rpg.sys matches 0.. run scoreboard players set #dr_d3p rpg.sys 100
execute unless score #dr_d4n rpg.sys matches 0.. run scoreboard players set #dr_d4n rpg.sys 1
execute unless score #dr_d4p rpg.sys matches 0.. run scoreboard players set #dr_d4p rpg.sys 20
execute unless score #dr_w1n rpg.sys matches 0.. run scoreboard players set #dr_w1n rpg.sys 3
execute unless score #dr_w1p rpg.sys matches 0.. run scoreboard players set #dr_w1p rpg.sys 100
execute unless score #dr_w2n rpg.sys matches 0.. run scoreboard players set #dr_w2n rpg.sys 1
execute unless score #dr_w2p rpg.sys matches 0.. run scoreboard players set #dr_w2p rpg.sys 30
execute unless score #dr_k1n rpg.sys matches 0.. run scoreboard players set #dr_k1n rpg.sys 2
execute unless score #dr_k1p rpg.sys matches 0.. run scoreboard players set #dr_k1p rpg.sys 100
execute unless score #dr_k2n rpg.sys matches 0.. run scoreboard players set #dr_k2n rpg.sys 1
execute unless score #dr_k2p rpg.sys matches 0.. run scoreboard players set #dr_k2p rpg.sys 100
execute unless score #dr_k3n rpg.sys matches 0.. run scoreboard players set #dr_k3n rpg.sys 5
execute unless score #dr_k3p rpg.sys matches 0.. run scoreboard players set #dr_k3p rpg.sys 100
execute unless score #dr_k4n rpg.sys matches 0.. run scoreboard players set #dr_k4n rpg.sys 1
execute unless score #dr_k4p rpg.sys matches 0.. run scoreboard players set #dr_k4p rpg.sys 20
execute unless score #dr_k5n rpg.sys matches 0.. run scoreboard players set #dr_k5n rpg.sys 3
execute unless score #dr_k5p rpg.sys matches 0.. run scoreboard players set #dr_k5p rpg.sys 20
execute unless score #dr_k6n rpg.sys matches 0.. run scoreboard players set #dr_k6n rpg.sys 1
execute unless score #dr_k6p rpg.sys matches 0.. run scoreboard players set #dr_k6p rpg.sys 50
scoreboard objectives add rpg.kw trigger
execute unless score #kw_h rpg.sys matches 0.. run scoreboard players set #kw_h rpg.sys 0
execute unless score #kw_c rpg.sys matches 0.. run scoreboard players set #kw_c rpg.sys 0
execute unless score #kw_l rpg.sys matches 0.. run scoreboard players set #kw_l rpg.sys 0
execute unless score #kw_b rpg.sys matches 0.. run scoreboard players set #kw_b rpg.sys 0
scoreboard objectives add rpg.iv dummy
scoreboard objectives add rpg.dshg dummy
scoreboard objectives add rpg.dshc dummy
scoreboard objectives add rpg.dshd dummy
scoreboard objectives add rpg.kwby dummy
scoreboard objectives add rpg.wmn trigger
scoreboard objectives add rpg.dshb dummy
scoreboard objectives add rpg.yaw dummy
scoreboard objectives add rpg.d_shp dummy {"text":"스탯 최대체력","color":"green"}
scoreboard objectives add rpg.d_cri dummy
scoreboard objectives add rpg.d_cr2 dummy
scoreboard objectives add rpg.fsh trigger
scoreboard objectives add rpg.fsel dummy
scoreboard objectives add rpg.fpend dummy
scoreboard objectives add rpg.xstr dummy {"text":"추가 힘","color":"red"}
scoreboard objectives add rpg.xdex dummy {"text":"추가 민첩","color":"aqua"}
scoreboard objectives add rpg.xcon dummy {"text":"추가 체력","color":"green"}
scoreboard objectives add rpg.fk1 dummy
scoreboard objectives add rpg.fk2 dummy
scoreboard objectives add rpg.fk3 dummy
scoreboard objectives add rpg.fk4 dummy
scoreboard objectives add rpg.fk5 dummy
scoreboard objectives add rpg.fk6 dummy
scoreboard objectives add rpg.fk7 dummy
scoreboard objectives add rpg.fk8 dummy
scoreboard objectives add rpg.fk9 dummy
scoreboard objectives add rpg.fk10 dummy
scoreboard objectives add rpg.fk11 dummy
scoreboard objectives add rpg.fk12 dummy
scoreboard objectives add rpg.fk13 dummy
scoreboard objectives add rpg.fk14 dummy
scoreboard objectives add rpg.fk15 dummy
scoreboard objectives add rpg.fk16 dummy
scoreboard objectives add rpg.fk17 dummy
scoreboard objectives add rpg.fk18 dummy
scoreboard objectives add rpg.fk19 dummy
scoreboard objectives add rpg.fk20 dummy
scoreboard objectives add rpg.fk21 dummy
scoreboard objectives add rpg.fk22 dummy
scoreboard objectives add rpg.fk23 dummy
scoreboard objectives add rpg.fk24 dummy
scoreboard objectives add rpg.fk25 dummy
scoreboard objectives add rpg.fk26 dummy
scoreboard objectives add rpg.fk27 dummy
scoreboard objectives add rpg.fk28 dummy
scoreboard objectives add rpg.fk29 dummy
scoreboard objectives add rpg.fk30 dummy
scoreboard objectives add rpg.fk31 dummy
scoreboard objectives add rpg.fk32 dummy
scoreboard objectives add rpg.fk33 dummy
scoreboard objectives add rpg.fk34 dummy
scoreboard objectives add rpg.fk35 dummy
scoreboard objectives add rpg.fk36 dummy
scoreboard objectives add rpg.fk37 dummy
scoreboard objectives add rpg.fk38 dummy
scoreboard objectives add rpg.fk39 dummy
scoreboard objectives add rpg.fk40 dummy
scoreboard objectives add rpg.fs1 dummy
scoreboard objectives add rpg.fs2 dummy
scoreboard objectives add rpg.fs3 dummy
scoreboard objectives add rpg.fs4 dummy
scoreboard objectives add rpg.fs5 dummy
scoreboard objectives add rpg.fs6 dummy
scoreboard objectives add rpg.fs7 dummy
scoreboard objectives add rpg.fs8 dummy
scoreboard objectives add rpg.fs9 dummy
scoreboard objectives add rpg.fs10 dummy
scoreboard objectives add rpg.fsv dummy
scoreboard objectives add rpg.wdc trigger
scoreboard objectives add rpg.wdp dummy
scoreboard objectives add rpg.wcs trigger
scoreboard objectives add rpg.wsh trigger
# v39 가짜 피 : 지금 / 최대 / 지난 틱 진짜 피(x100) / 소수점 누적 / 마지막으로 살아 있던 틱
scoreboard objectives add rpg.mhp dummy
scoreboard objectives add rpg.mmx dummy
scoreboard objectives add rpg.mlh dummy
scoreboard objectives add rpg.mfr dummy
scoreboard objectives add rpg.mlt dummy
# v40 : 당근 낚싯대 우클릭 (폭탄 · 국가 신호기 · 물고기) / 성
scoreboard objectives add rpg.coas minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add rpg.ucd dummy
scoreboard objectives add rpg.bcd dummy
scoreboard objectives add rpg.npcd dummy
scoreboard objectives add rpg.csid dummy
scoreboard objectives add rpg.csn dummy
scoreboard objectives add rpg.csk dummy
scoreboard objectives add rpg.cshp dummy
scoreboard objectives add rpg.cbid dummy
scoreboard objectives add rpg.erod dummy
scoreboard objectives add rpg.bht dummy
scoreboard players set #k90 rpg.sys 90
scoreboard players set #k4 rpg.sys 4
scoreboard players set #k2 rpg.sys 2
# 성 신호기 내구도 (좌클릭 몇 번) : /scoreboard players set #cs_bhp rpg.sys 60
execute unless score #cs_bhp rpg.sys matches 1.. run scoreboard players set #cs_bhp rpg.sys 60
# v40 : 예전(v38) 성 기록은 새 방식과 맞지 않아 한 번 지웁니다 (블록은 그대로)
execute unless score #csv rpg.sys matches 40 run function rpg:war/cs_remove
scoreboard players set #csv rpg.sys 40
# v39 잡몹 돈 배율 (%) : /scoreboard players set #mob_money rpg.sys 150
execute unless score #mob_money rpg.sys matches 1.. run scoreboard players set #mob_money rpg.sys 100
execute unless score #war_run rpg.sys matches 0.. run scoreboard players set #war_run rpg.sys 0
execute unless score #war_pause rpg.sys matches 0.. run scoreboard players set #war_pause rpg.sys 0
execute unless score #war_bb rpg.sys matches 0.. run scoreboard players set #war_bb rpg.sys 0
execute unless score #war_prot rpg.sys matches 0.. run scoreboard players set #war_prot rpg.sys 1
# ── 국가 성 (2단계) ──
execute unless score #cs1x rpg.sys matches -2147483648.. run scoreboard players set #cs1x rpg.sys 0
execute unless score #cs1y rpg.sys matches -2147483648.. run scoreboard players set #cs1y rpg.sys 0
execute unless score #cs1z rpg.sys matches -2147483648.. run scoreboard players set #cs1z rpg.sys 0
execute unless score #cs1on rpg.sys matches -2147483648.. run scoreboard players set #cs1on rpg.sys 0
execute unless score #cs2x rpg.sys matches -2147483648.. run scoreboard players set #cs2x rpg.sys 0
execute unless score #cs2y rpg.sys matches -2147483648.. run scoreboard players set #cs2y rpg.sys 0
execute unless score #cs2z rpg.sys matches -2147483648.. run scoreboard players set #cs2z rpg.sys 0
execute unless score #cs2on rpg.sys matches -2147483648.. run scoreboard players set #cs2on rpg.sys 0
execute unless score #cs3x rpg.sys matches -2147483648.. run scoreboard players set #cs3x rpg.sys 0
execute unless score #cs3y rpg.sys matches -2147483648.. run scoreboard players set #cs3y rpg.sys 0
execute unless score #cs3z rpg.sys matches -2147483648.. run scoreboard players set #cs3z rpg.sys 0
execute unless score #cs3on rpg.sys matches -2147483648.. run scoreboard players set #cs3on rpg.sys 0
execute unless score #cs4x rpg.sys matches -2147483648.. run scoreboard players set #cs4x rpg.sys 0
execute unless score #cs4y rpg.sys matches -2147483648.. run scoreboard players set #cs4y rpg.sys 0
execute unless score #cs4z rpg.sys matches -2147483648.. run scoreboard players set #cs4z rpg.sys 0
execute unless score #cs4on rpg.sys matches -2147483648.. run scoreboard players set #cs4on rpg.sys 0
execute unless score #cs5x rpg.sys matches -2147483648.. run scoreboard players set #cs5x rpg.sys 0
execute unless score #cs5y rpg.sys matches -2147483648.. run scoreboard players set #cs5y rpg.sys 0
execute unless score #cs5z rpg.sys matches -2147483648.. run scoreboard players set #cs5z rpg.sys 0
execute unless score #cs5on rpg.sys matches -2147483648.. run scoreboard players set #cs5on rpg.sys 0
execute unless score #cs6x rpg.sys matches -2147483648.. run scoreboard players set #cs6x rpg.sys 0
execute unless score #cs6y rpg.sys matches -2147483648.. run scoreboard players set #cs6y rpg.sys 0
execute unless score #cs6z rpg.sys matches -2147483648.. run scoreboard players set #cs6z rpg.sys 0
execute unless score #cs6on rpg.sys matches -2147483648.. run scoreboard players set #cs6on rpg.sys 0
execute unless score #cs7x rpg.sys matches -2147483648.. run scoreboard players set #cs7x rpg.sys 0
execute unless score #cs7y rpg.sys matches -2147483648.. run scoreboard players set #cs7y rpg.sys 0
execute unless score #cs7z rpg.sys matches -2147483648.. run scoreboard players set #cs7z rpg.sys 0
execute unless score #cs7on rpg.sys matches -2147483648.. run scoreboard players set #cs7on rpg.sys 0
execute unless score #cs8x rpg.sys matches -2147483648.. run scoreboard players set #cs8x rpg.sys 0
execute unless score #cs8y rpg.sys matches -2147483648.. run scoreboard players set #cs8y rpg.sys 0
execute unless score #cs8z rpg.sys matches -2147483648.. run scoreboard players set #cs8z rpg.sys 0
execute unless score #cs8on rpg.sys matches -2147483648.. run scoreboard players set #cs8on rpg.sys 0
execute unless score #wd12 rpg.sys matches 0.. run scoreboard players set #wd12 rpg.sys 0
execute unless score #wd13 rpg.sys matches 0.. run scoreboard players set #wd13 rpg.sys 0
execute unless score #wd14 rpg.sys matches 0.. run scoreboard players set #wd14 rpg.sys 0
execute unless score #wd15 rpg.sys matches 0.. run scoreboard players set #wd15 rpg.sys 0
execute unless score #wd16 rpg.sys matches 0.. run scoreboard players set #wd16 rpg.sys 0
execute unless score #wd17 rpg.sys matches 0.. run scoreboard players set #wd17 rpg.sys 0
execute unless score #wd18 rpg.sys matches 0.. run scoreboard players set #wd18 rpg.sys 0
execute unless score #wd21 rpg.sys matches 0.. run scoreboard players set #wd21 rpg.sys 0
execute unless score #wd23 rpg.sys matches 0.. run scoreboard players set #wd23 rpg.sys 0
execute unless score #wd24 rpg.sys matches 0.. run scoreboard players set #wd24 rpg.sys 0
execute unless score #wd25 rpg.sys matches 0.. run scoreboard players set #wd25 rpg.sys 0
execute unless score #wd26 rpg.sys matches 0.. run scoreboard players set #wd26 rpg.sys 0
execute unless score #wd27 rpg.sys matches 0.. run scoreboard players set #wd27 rpg.sys 0
execute unless score #wd28 rpg.sys matches 0.. run scoreboard players set #wd28 rpg.sys 0
execute unless score #wd31 rpg.sys matches 0.. run scoreboard players set #wd31 rpg.sys 0
execute unless score #wd32 rpg.sys matches 0.. run scoreboard players set #wd32 rpg.sys 0
execute unless score #wd34 rpg.sys matches 0.. run scoreboard players set #wd34 rpg.sys 0
execute unless score #wd35 rpg.sys matches 0.. run scoreboard players set #wd35 rpg.sys 0
execute unless score #wd36 rpg.sys matches 0.. run scoreboard players set #wd36 rpg.sys 0
execute unless score #wd37 rpg.sys matches 0.. run scoreboard players set #wd37 rpg.sys 0
execute unless score #wd38 rpg.sys matches 0.. run scoreboard players set #wd38 rpg.sys 0
execute unless score #wd41 rpg.sys matches 0.. run scoreboard players set #wd41 rpg.sys 0
execute unless score #wd42 rpg.sys matches 0.. run scoreboard players set #wd42 rpg.sys 0
execute unless score #wd43 rpg.sys matches 0.. run scoreboard players set #wd43 rpg.sys 0
execute unless score #wd45 rpg.sys matches 0.. run scoreboard players set #wd45 rpg.sys 0
execute unless score #wd46 rpg.sys matches 0.. run scoreboard players set #wd46 rpg.sys 0
execute unless score #wd47 rpg.sys matches 0.. run scoreboard players set #wd47 rpg.sys 0
execute unless score #wd48 rpg.sys matches 0.. run scoreboard players set #wd48 rpg.sys 0
execute unless score #wd51 rpg.sys matches 0.. run scoreboard players set #wd51 rpg.sys 0
execute unless score #wd52 rpg.sys matches 0.. run scoreboard players set #wd52 rpg.sys 0
execute unless score #wd53 rpg.sys matches 0.. run scoreboard players set #wd53 rpg.sys 0
execute unless score #wd54 rpg.sys matches 0.. run scoreboard players set #wd54 rpg.sys 0
execute unless score #wd56 rpg.sys matches 0.. run scoreboard players set #wd56 rpg.sys 0
execute unless score #wd57 rpg.sys matches 0.. run scoreboard players set #wd57 rpg.sys 0
execute unless score #wd58 rpg.sys matches 0.. run scoreboard players set #wd58 rpg.sys 0
execute unless score #wd61 rpg.sys matches 0.. run scoreboard players set #wd61 rpg.sys 0
execute unless score #wd62 rpg.sys matches 0.. run scoreboard players set #wd62 rpg.sys 0
execute unless score #wd63 rpg.sys matches 0.. run scoreboard players set #wd63 rpg.sys 0
execute unless score #wd64 rpg.sys matches 0.. run scoreboard players set #wd64 rpg.sys 0
execute unless score #wd65 rpg.sys matches 0.. run scoreboard players set #wd65 rpg.sys 0
execute unless score #wd67 rpg.sys matches 0.. run scoreboard players set #wd67 rpg.sys 0
execute unless score #wd68 rpg.sys matches 0.. run scoreboard players set #wd68 rpg.sys 0
execute unless score #wd71 rpg.sys matches 0.. run scoreboard players set #wd71 rpg.sys 0
execute unless score #wd72 rpg.sys matches 0.. run scoreboard players set #wd72 rpg.sys 0
execute unless score #wd73 rpg.sys matches 0.. run scoreboard players set #wd73 rpg.sys 0
execute unless score #wd74 rpg.sys matches 0.. run scoreboard players set #wd74 rpg.sys 0
execute unless score #wd75 rpg.sys matches 0.. run scoreboard players set #wd75 rpg.sys 0
execute unless score #wd76 rpg.sys matches 0.. run scoreboard players set #wd76 rpg.sys 0
execute unless score #wd78 rpg.sys matches 0.. run scoreboard players set #wd78 rpg.sys 0
execute unless score #wd81 rpg.sys matches 0.. run scoreboard players set #wd81 rpg.sys 0
execute unless score #wd82 rpg.sys matches 0.. run scoreboard players set #wd82 rpg.sys 0
execute unless score #wd83 rpg.sys matches 0.. run scoreboard players set #wd83 rpg.sys 0
execute unless score #wd84 rpg.sys matches 0.. run scoreboard players set #wd84 rpg.sys 0
execute unless score #wd85 rpg.sys matches 0.. run scoreboard players set #wd85 rpg.sys 0
execute unless score #wd86 rpg.sys matches 0.. run scoreboard players set #wd86 rpg.sys 0
execute unless score #wd87 rpg.sys matches 0.. run scoreboard players set #wd87 rpg.sys 0
scoreboard objectives add rpg.hp health

# 게이지바 문자 테이블 (리소스팩 rpg_hud 폰트)
data modify storage rpg:main hpb set value ["","","","","","","","","","","","","","","","","","","","",""]
data modify storage rpg:main xpb set value ["","","","","","","","","","","","","","","","","","","","",""]

execute unless data storage rpg:main bb.v run data modify storage rpg:main bb.v set value "fixed"
# 전쟁터 범위 (시작 113 -60 54 / 끝 912 60 853)
execute unless data storage rpg:war fld run data modify storage rpg:war fld set value {x:113,y:-60,z:54,dx:799,dy:120,dz:799}
data modify storage rpg:main hud.hc set value ""
data modify storage rpg:main hud.xc set value ""

function rpg:config
execute unless score #spid rpg.sys matches 0.. run scoreboard players set #spid rpg.sys 0
# 몹 모델 구조가 바뀌면 한 번만 전체 청소 (겹쳐 쌓인 모델 제거)
execute unless score #mver rpg.sys matches 12.. run data modify storage rpg:main bb.v set value "fixed"
# v39 : 2족 몹 몸(장비식) + 가짜 피 로 바뀌어서 한 번 전체 청소 -> 스폰 지점에서 새로 나옵니다
execute unless score #mver rpg.sys matches 13 run function rpg:mob/reset_all
scoreboard players set #mver rpg.sys 13

# 구버전 보스바 정리 (한 번만)
execute unless score #ver rpg.sys matches 2 run function rpg:admin/clear_bars
scoreboard players set #ver rpg.sys 2
tellraw @a [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"레벨/스탯 시스템이 로드되었습니다.","color":"white"}]

# 경매 / 비행 / C+C 트리거 활성화
scoreboard players enable @a rpg.auc
scoreboard players add @a rpg.abidL 0
scoreboard players add @a rpg.qcat 1
scoreboard players add @a rpg.qord 0

# 국가 팀 (최초 1회)
execute unless score #natset rpg.sys matches 1 run function rpg:nation/setup
scoreboard players set #natset rpg.sys 1
scoreboard players enable @a rpg.nat
scoreboard players enable @a rpg.vlt

# 시스템 점수 초기화 (없으면 조건문이 통째로 실패합니다)
scoreboard players add #auc_bb rpg.sys 0
scoreboard players add #auc_run rpg.sys 0
scoreboard players add #auc_pause rpg.sys 0
scoreboard players add #auc_n rpg.sys 0
scoreboard players add #auc_time rpg.sys 0
scoreboard players add #rnd_run rpg.sys 0
scoreboard players add #rnd_pause rpg.sys 0
scoreboard players add #rnd_time rpg.sys 0
scoreboard players add #rnd_max rpg.sys 0
scoreboard players add #rnd_bb rpg.sys 0
scoreboard players add @a rpg.def 0
scoreboard players enable @a rpg.rnd
scoreboard players enable @a rpg.npc
scoreboard players enable @a rpg.enh
scoreboard players add @a rpg.enhM 0
scoreboard players add @a rpg.spD 0
scoreboard players add @a rpg.spL 0
# 강화 확률 기본값 (1000 = 100%)
execute unless data storage rpg:enh cfg.v run data remove storage rpg:enh cfg
execute unless data storage rpg:enh cfg.v run data modify storage rpg:enh cfg set value {v:2,req:{}}
scoreboard players add #e_base rpg.sys 0
execute if score #e_base rpg.sys matches 0 run scoreboard players set #e_base rpg.sys 900
scoreboard players add #e_dec rpg.sys 0
execute if score #e_dec rpg.sys matches 0 run scoreboard players set #e_dec rpg.sys 40
scoreboard players add #e_dfrom rpg.sys 0
execute if score #e_dfrom rpg.sys matches 0 run scoreboard players set #e_dfrom rpg.sys 7
scoreboard players add #e_dinc rpg.sys 0
execute if score #e_dinc rpg.sys matches 0 run scoreboard players set #e_dinc rpg.sys 25
scoreboard players add #e_mul rpg.sys 0
scoreboard players add @a rpg.dsh 0
scoreboard players add @a rpg.dshf 0
scoreboard players add #pid_next rpg.sys 0
scoreboard players add @a fly 0
scoreboard players add @a rpg.grav 0
scoreboard players add @a C+C 0
scoreboard players add @a rpg.bills 0
function rpg:nation/fix

advancement revoke @s only rpg:exp/bonus_boss
scoreboard players operation @s rpg.exp += #exp_boss rpg.sys

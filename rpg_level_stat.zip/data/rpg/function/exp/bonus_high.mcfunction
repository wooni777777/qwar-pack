advancement revoke @s only rpg:exp/bonus_high
scoreboard players operation @s rpg.exp += #exp_high rpg.sys

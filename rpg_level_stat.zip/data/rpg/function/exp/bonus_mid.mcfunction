advancement revoke @s only rpg:exp/bonus_mid
scoreboard players operation @s rpg.exp += #exp_mid rpg.sys

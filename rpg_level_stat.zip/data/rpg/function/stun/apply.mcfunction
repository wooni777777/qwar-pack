# 스턴 걸기 (v45 · 내부용 · as at 대상) — 관전 · 크리에이티브 · 살아 있지 않은 것은 제외
execute if entity @s[type=minecraft:player,gamemode=spectator] run return 0
execute if entity @s[type=minecraft:player,gamemode=creative] run return 0
execute unless data entity @s Health run return 0
execute if score @s rpg.bcc matches 1.. run return run particle minecraft:totem_of_undying ~ ~1 ~ 0.3 0.5 0.3 0.1 10 normal @a
scoreboard players add #snn rpg.sys 1
scoreboard players add @s rpg.snT 0
execute unless entity @s[tag=rpg_stn] run function rpg:stun/start
execute if score #snt rpg.sys > @s rpg.snT run scoreboard players operation @s rpg.snT = #snt rpg.sys

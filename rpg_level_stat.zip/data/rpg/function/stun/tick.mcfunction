# 스턴 (v45 · 매 틱)
execute as @e[tag=rpg_stn] run function rpg:stun/t1

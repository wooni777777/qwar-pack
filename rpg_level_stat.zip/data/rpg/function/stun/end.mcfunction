# 스턴 끝 (v45 · as 대상) — 직접 풀 때 : execute as @e[tag=rpg_stn] run function rpg:stun/end
tag @s remove rpg_stn
scoreboard players set @s rpg.snT 0
attribute @s minecraft:movement_speed modifier remove rpg:stn
attribute @s minecraft:jump_strength modifier remove rpg:stn
attribute @s minecraft:gravity modifier remove rpg:stn
attribute @s minecraft:knockback_resistance modifier remove rpg:stn

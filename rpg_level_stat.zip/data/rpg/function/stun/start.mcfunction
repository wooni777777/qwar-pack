# 스턴 시작 (v45 · 내부용) — 지금 자리 기억 · 이동 · 점프 · 중력 · 밀려남 0
tag @s add rpg_stn
execute store result score @s rpg.snX run data get entity @s Pos[0] 1000
execute store result score @s rpg.snY run data get entity @s Pos[1] 1000
execute store result score @s rpg.snZ run data get entity @s Pos[2] 1000
attribute @s minecraft:movement_speed modifier remove rpg:stn
attribute @s minecraft:jump_strength modifier remove rpg:stn
attribute @s minecraft:gravity modifier remove rpg:stn
attribute @s minecraft:knockback_resistance modifier remove rpg:stn
attribute @s minecraft:movement_speed modifier add rpg:stn -1 add_multiplied_total
attribute @s minecraft:jump_strength modifier add rpg:stn -1 add_multiplied_total
attribute @s minecraft:gravity modifier add rpg:stn -1 add_multiplied_total
attribute @s minecraft:knockback_resistance modifier add rpg:stn 1 add_value
particle minecraft:electric_spark ~ ~1 ~ 0.3 0.5 0.3 0.1 25 normal @a
playsound minecraft:block.anvil.land player @a ~ ~ ~ 0.6 1.9
execute if entity @s[type=minecraft:player] run title @s actionbar {"text":"스턴 — 움직일 수 없습니다 (평타 · 스킬은 가능)","color":"yellow","bold":true}

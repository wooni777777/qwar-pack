# 스턴 1틱 (v45 · 내부용) — 기억한 자리로 되돌림 (보는 방향은 그대로)
scoreboard players remove @s rpg.snT 1
execute if score @s rpg.snT matches ..0 run return run function rpg:stun/end
execute store result storage rpg:sn p.x double 0.001 run scoreboard players get @s rpg.snX
execute store result storage rpg:sn p.y double 0.001 run scoreboard players get @s rpg.snY
execute store result storage rpg:sn p.z double 0.001 run scoreboard players get @s rpg.snZ
function rpg:stun/tp with storage rpg:sn p
execute unless entity @s[type=minecraft:player] run data modify entity @s Motion set value [0.0d,0.0d,0.0d]
execute if score #timer rpg.sys matches 5 at @s run particle minecraft:crit ~ ~2.2 ~ 0.25 0.05 0.25 0.05 6 normal @a

# 스킬로 죽은 플레이어 알림 (v42 · 내부용 · @s = 죽은 플레이어 · 죽인 사람 = rpg_skw)
#   예) 철수이(가) 영희에게 불꽃 검 +5강(으)로 죽었습니다
data modify storage rpg:dm w set value {text:"맨손",color:"gray"}
scoreboard players set #dme rpg.sys 0
execute if items entity @a[tag=rpg_skw,limit=1] weapon.mainhand * run function rpg:api/dm_wpn
execute if score #dme rpg.sys matches 1.. run tellraw @a ["", {"selector": "@s", "color": "white"}, {"text": "이(가) ", "color": "gray"}, {"selector": "@a[tag=rpg_skw,limit=1]", "color": "white"}, {"text": "에게 ", "color": "gray"}, {"nbt": "w", "storage": "rpg:dm", "interpret": true}, {"text": " +", "color": "gold", "bold": true}, {"score": {"name": "#dme", "objective": "rpg.sys"}, "color": "gold", "bold": true}, {"text": "강", "color": "gold", "bold": true}, {"text": "(으)로 죽었습니다", "color": "gray"}]
execute unless score #dme rpg.sys matches 1.. run tellraw @a ["", {"selector": "@s", "color": "white"}, {"text": "이(가) ", "color": "gray"}, {"selector": "@a[tag=rpg_skw,limit=1]", "color": "white"}, {"text": "에게 ", "color": "gray"}, {"nbt": "w", "storage": "rpg:dm", "interpret": true}, {"text": "(으)로 죽었습니다", "color": "gray"}]

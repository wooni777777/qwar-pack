# (v46 · 내부용 · as 투사체)
scoreboard players add #pk rpg.sys 1
kill @s

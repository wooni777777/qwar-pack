# heal_hit 정리 (v46 · 내부용)
tag @e[tag=rpg_hhc] remove rpg_hhc
tag @a[tag=rpg_hho] remove rpg_hho
tag @s remove rpg_hlc
tag @a[tag=rpg_hlo] remove rpg_hlo
tag @a[tag=rpg_skw] remove rpg_skw
return fail

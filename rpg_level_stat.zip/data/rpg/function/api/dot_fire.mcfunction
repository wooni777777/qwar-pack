# DoT 1회 발동 (내부용)
function rpg:api/dot_go with storage rpg:sk d
execute store result score #dl rpg.sys run data get storage rpg:sk d.left
scoreboard players remove #dl rpg.sys 1
execute store result entity @s data.left int 1 run scoreboard players get #dl rpg.sys
execute store result entity @s data.t int 1 run data get storage rpg:sk d.iv
execute if score #dl rpg.sys matches ..0 run kill @s

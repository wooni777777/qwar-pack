# 플레이어면 회복 · 아니면 피해 (내부용)
execute if entity @s[type=minecraft:player] run return run function rpg:api/heal_n with storage rpg:tmp d
return run function rpg:api/deal_n with storage rpg:tmp d

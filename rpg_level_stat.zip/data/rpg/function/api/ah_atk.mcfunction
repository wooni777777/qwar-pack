# (v59 · 내부용 · as 플레이어) 총공격력 -> #atk (크리 없음 · api/atk_dmg 와 같은 합)
scoreboard players set #atk rpg.sys 0
scoreboard players operation #atk rpg.sys = @s rpg.d_atk
scoreboard players set #wp rpg.sys 0
execute store result score #wp rpg.sys run attribute @s minecraft:attack_damage get 1
scoreboard players operation #atk rpg.sys += #wp rpg.sys

# 실제 피해 한 번 (v46 · 내부용 · 매크로 n · as 맞는 대상)
$return run damage @s $(n) rpg:true

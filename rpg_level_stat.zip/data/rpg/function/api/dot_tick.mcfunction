# DoT 마커 1틱 (내부용)
data modify storage rpg:sk d set from entity @s data
execute store result score #dt rpg.sys run data get storage rpg:sk d.t
scoreboard players remove #dt rpg.sys 1
execute store result entity @s data.t int 1 run scoreboard players get #dt rpg.sys
execute if score #dt rpg.sys matches 1.. run return 0
function rpg:api/dot_fire

# ── 공격력 비례 광역 스킬 (방어구 무시 · 무적시간 무시) ──
#   execute as <시전자> at @s run function rpg:api/atk_hit {base:20,ratio:150,radius:4}
#   반환값 = 맞은 대상 수  ->  조건부 명령 블록 연쇄가 그대로 이어집니다
$function rpg:api/atk_dmg {base:$(base),ratio:$(ratio)}
execute store result storage rpg:tmp d.n int 1 run scoreboard players get #dmg rpg.sys
scoreboard players set #hitn rpg.sys 0
$execute as @e[distance=0.1..$(radius),tag=!rpg_model,tag=!rpg_mtext,tag=!rpg_auc_h,tag=!rpg_npcE,type=!minecraft:marker,type=!minecraft:armor_stand,type=!minecraft:item_display,type=!minecraft:text_display,type=!minecraft:block_display,type=!minecraft:interaction,type=!minecraft:item,type=!minecraft:experience_orb] run function rpg:api/deal_n with storage rpg:tmp d
return run scoreboard players get #hitn rpg.sys

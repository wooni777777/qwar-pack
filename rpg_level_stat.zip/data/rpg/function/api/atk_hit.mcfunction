# ── 공격력 비례 광역 스킬 (방어구 무시 · 무적시간 무시) ──
#   execute as <시전자> at @s run function rpg:api/atk_hit {base:20,ratio:150,radius:4,max:"x",inv:"x"}
#   max : 최대 몇 마리까지 맞을지. "x" 면 제한 없음. 숫자면 가까운 순으로 그 수만큼
#   inv : 맞은 적에게 거는 "잠깐 무적" 초. "x" 면 안 검 (예전과 똑같이 무한 연타)
#         0.5 면 0.5초 동안 이 스킬류에 다시 맞지 않습니다
#   반환값 = 맞은 대상 수
#   ※ 한 마리도 못 맞히면 이 명령 자체가 "실패" 로 처리됩니다.
#      -> 뒤에 붙인 조건부(Conditional) 명령 블록이 실행되지 않습니다.
$function rpg:api/atk_dmg {base:$(base),ratio:$(ratio)}
execute store result storage rpg:tmp d.n int 1 run scoreboard players get #dmg rpg.sys
tag @s add rpg_skc
scoreboard players set #hitn rpg.sys 0
scoreboard players set #ivt rpg.sys 0
$data modify storage rpg:sk a set value {radius:$(radius),max:"$(max)",inv:"$(inv)"}
$execute unless data storage rpg:sk a{inv:"x"} run function rpg:api/iv_calc {v:$(inv)}
execute if data storage rpg:sk a{max:"x"} run function rpg:api/hit_all with storage rpg:sk a
execute unless data storage rpg:sk a{max:"x"} run function rpg:api/hit_lim with storage rpg:sk a
tag @s remove rpg_skc
function rpg:api/crit_say
execute if score #hitn rpg.sys matches ..0 run return fail
return run scoreboard players get #hitn rpg.sys

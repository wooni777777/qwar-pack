# 기본 아이템 이름 (번역 키) (v42 · 내부용 · 매크로 id)
$data modify storage rpg:dm w set value {translate:"item.minecraft.$(id)",color:"white"}

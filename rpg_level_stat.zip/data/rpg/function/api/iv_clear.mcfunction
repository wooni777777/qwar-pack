# 잠깐 무적을 전부 푼다
scoreboard players reset @e[tag=rpg_iv] rpg.iv
tag @e[tag=rpg_iv] remove rpg_iv
return 1

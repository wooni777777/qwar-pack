# 크리티컬 1회 (내부용) — 여기서는 "계산만" 합니다.
#   알림(글자·소리)은 실제로 맞힌 대상이 있을 때 rpg:api/crit_say 가 냅니다.
scoreboard players add #cchain rpg.sys 1
scoreboard players add #cmul rpg.sys 40
# v49 : 2번째 크리티컬은 크리티컬 확률 -20% (200 을 뺌) · 최대 2번
execute unless score #cchain rpg.sys matches 1 run return 0
scoreboard players operation #c2c rpg.sys = @s rpg.crit
scoreboard players remove #c2c rpg.sys 200
execute if score #c2c rpg.sys matches ..0 run return 0
execute store result score #r rpg.sys run random value 1..1000
execute if score #r rpg.sys <= #c2c rpg.sys run function rpg:api/crit_go

scoreboard players add #cchain rpg.sys 1
scoreboard players add #cmul rpg.sys 40
execute if score #cchain rpg.sys matches 1 run tellraw @s [{"text":"크리티컬!","color":"red","bold":true}]
execute if score #cchain rpg.sys matches 2.. run tellraw @s ["",{"text":"크리티컬 x","color":"red","bold":true},{"score":{"name":"#cchain","objective":"rpg.sys"},"color":"gold","bold":true},{"text":" !","color":"red","bold":true}]
execute at @s run playsound minecraft:entity.player.attack.crit player @s ~ ~ ~ 1 1.4
execute if entity @s[tag=H18] if score @s rpg.h18cd matches ..0 run function rpg:hid/h18_heal
execute if score #cchain rpg.sys matches ..9 store result score #r rpg.sys run random value 1..1000
execute if score #cchain rpg.sys matches ..9 if score #r rpg.sys <= @s rpg.crit run function rpg:api/crit_go

# 크리티컬 1회 (내부용) — 여기서는 "계산만" 합니다.
#   알림(글자·소리)은 실제로 맞힌 대상이 있을 때 rpg:api/crit_say 가 냅니다.
scoreboard players add #cchain rpg.sys 1
scoreboard players add #cmul rpg.sys 40
# 같은 확률로 한 번 더 (최대 3연쇄)
execute if score #cchain rpg.sys matches ..2 store result score #r rpg.sys run random value 1..1000
execute if score #cchain rpg.sys matches ..2 if score #r rpg.sys <= @s rpg.crit run function rpg:api/crit_go

# [ac] 백어택 — 스킬 데미지 (v46 · 내부용 · as 맞는 대상)
#   스킬을 쓴 플레이어(rpg_skw)가 스코어보드 ac 1 이고, 대상이 보는 방향의 반대쪽 ±60° 에 있으면
#   이번 스킬 피해 #dln 을 (100 + #ac_pct)% 로  (기본 #ac_pct 100 -> 2배)
tag @a[tag=rpg_skw,limit=1] add rpg_acs
scoreboard players set #acb rpg.sys 0
execute at @s rotated as @s rotated ~30 0 positioned ^ ^ ^-1024 if entity @a[tag=rpg_acs,distance=..1024] at @s rotated as @s rotated ~-30 0 positioned ^ ^ ^-1024 if entity @a[tag=rpg_acs,distance=..1024] run scoreboard players set #acb rpg.sys 1
tag @a[tag=rpg_acs] remove rpg_acs
execute if score #acb rpg.sys matches 0 run return 0
scoreboard players operation #acx rpg.sys = #ac_pct rpg.sys
scoreboard players add #acx rpg.sys 100
scoreboard players operation #dln rpg.sys *= #acx rpg.sys
scoreboard players operation #dln rpg.sys /= #c100 rpg.sys
execute at @s run particle minecraft:crit ~ ~1 ~ 0.3 0.5 0.3 0.4 18 normal @a
execute at @s run particle minecraft:sweep_attack ~ ~1 ~ 0 0 0 0 1 normal @a
return 1

# 감지 표시를 지운다
tag @e[tag=rpg_pwall] remove rpg_pwall
return 1

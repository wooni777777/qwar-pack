# 초 -> 틱 (내부용)  function rpg:api/iv_calc {v:0.5}
$data modify storage rpg:sk n set value {v:$(v)}
execute store result score #ivt rpg.sys run data get storage rpg:sk n.v 20
execute if score #ivt rpg.sys matches ..0 run scoreboard players set #ivt rpg.sys 1

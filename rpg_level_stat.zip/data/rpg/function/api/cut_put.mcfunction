# 맞은 플레이어에게 치감을 건다 (v42 · 내부용 · @s = 맞은 플레이어) — 이미 더 길게 걸려 있으면 그대로
execute unless score @s rpg.cut >= #cutt rpg.sys run scoreboard players operation @s rpg.cut = #cutt rpg.sys
execute at @s run particle minecraft:smoke ~ ~1.9 ~ 0.25 0.1 0.25 0 6 normal @a

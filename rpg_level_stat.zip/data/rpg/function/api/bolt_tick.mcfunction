# rpg:api/bolt 로 부른 번개 (v46 · 내부용 · 매 틱 · as 번개) — 9틱 뒤 치움
#   v47 : 번개가 만든 불 끄기 (번쩍일 때마다 생기는 불도)
scoreboard players add @s rpg.lbt 1
execute at @s run fill ~-3 ~-3 ~-3 ~3 ~3 ~3 minecraft:air replace #minecraft:fire
execute if score @s rpg.lbt matches 9.. run kill @s

# ── 태그를 가진 플레이어가 죽으면 그 태그를 지운다 (v46) ──
#   function rpg:api/untag_dead {tag:"A"}      (반복 명령 블록에 넣어 두세요)
#   죽은 순간부터 다시 살아난 뒤 2초까지 "죽음" 으로 봅니다 (반복 블록이 한 틱 놓쳐도 지워짐)
#   반환값 = 이번에 지운 사람 수 · 없으면 "실패"
$execute store result score #udn rpg.sys if entity @a[tag=$(tag),tag=rpg_died]
$tag @a[tag=$(tag),tag=rpg_died] remove $(tag)
execute if score #udn rpg.sys matches ..0 run return fail
return run scoreboard players get #udn rpg.sys

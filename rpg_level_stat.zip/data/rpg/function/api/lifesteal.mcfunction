# ── 피흡 (v42) : 태그를 가진 플레이어를 "기본 + 공격력 비례" 만큼 회복 ──
#   execute as @p at @s run function rpg:api/lifesteal {tag:"ber",base:4,ratio:10}
#   tag   : 회복받을 플레이어의 태그 (보통 스킬 주인 태그)
#   base  : 기본 피흡 (고정 회복량 · 체력 1 = 하트 반 칸)
#   ratio : 공격력 비례 피흡 (%) — 그 플레이어 총공격력 x ratio / 100 을 더합니다
#   회복량 = base + 총공격력 x ratio / 100   (4 단위로 올림 · 포션과 같은 방식)
#   치감(스킬 데미지 명령어의 cut)이 걸린 플레이어는 회복받지 못합니다
#   반환값 = 회복받은 사람 수. 아무도 못 받으면 "실패" (조건부 명령 블록이 이어지지 않음)
#   ※ 스킬 데미지 명령 블록 뒤에 [조건부] 로 붙이면 "스킬이 맞았을 때만" 피흡합니다
$scoreboard players set #lsb rpg.sys $(base)
$scoreboard players set #lsr rpg.sys $(ratio)
scoreboard players set #lsn rpg.sys 0
$execute as @a[tag=$(tag),gamemode=!spectator] at @s run function rpg:api/ls_one
execute if score #lsn rpg.sys matches ..0 run return fail
return run scoreboard players get #lsn rpg.sys

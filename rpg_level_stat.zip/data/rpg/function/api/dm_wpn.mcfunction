# 죽인 사람이 든 무기 이름 · 강화 단계 (v42 · 내부용) — 이름표 이름 > 아이템 이름 > 기본 이름
data modify storage rpg:dm id set string entity @a[tag=rpg_skw,limit=1] SelectedItem.id 10
function rpg:api/dm_tr with storage rpg:dm
data modify storage rpg:dm w set from entity @a[tag=rpg_skw,limit=1] SelectedItem.components."minecraft:item_name"
data modify storage rpg:dm w set from entity @a[tag=rpg_skw,limit=1] SelectedItem.components."minecraft:custom_name"
execute store result score #dme rpg.sys run data get entity @a[tag=rpg_skw,limit=1] SelectedItem.components."minecraft:custom_data".enh

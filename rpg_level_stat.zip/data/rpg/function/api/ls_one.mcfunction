# 피흡 1명 (v42 · 내부용 · as 회복받을 플레이어)
execute if score @s rpg.cut matches 1.. run return run function rpg:api/ls_cut
scoreboard players operation #atk rpg.sys = @s rpg.d_atk
scoreboard players set #wp rpg.sys 0
execute store result score #wp rpg.sys run attribute @s minecraft:attack_damage get 1
scoreboard players operation #atk rpg.sys += #wp rpg.sys
scoreboard players operation #atk rpg.sys *= #lsr rpg.sys
scoreboard players operation #atk rpg.sys /= #c100 rpg.sys
scoreboard players operation #heal rpg.sys = #lsb rpg.sys
scoreboard players operation #heal rpg.sys += #atk rpg.sys
# v58 : 치감 (피흡 % 감소)
execute if score @s rpg.cuT matches 1.. run function rpg:cc/cut_heal
execute if score #heal rpg.sys matches ..0 run return 0
function rpg:util/heal
particle minecraft:damage_indicator ~ ~1.2 ~ 0.3 0.4 0.3 0.05 4 normal @a
particle minecraft:heart ~ ~2.1 ~ 0.3 0.2 0.3 0 2 normal @a
scoreboard players add #lsn rpg.sys 1
return 1

# ── 공격력 비례 "힐" 스킬 (v46) : 시전자(아머스탠드 · 투사체 등) 주위 플레이어는 회복 · 몬스터 · 다른 엔티티는 피해 ──
#   execute as <시전자> at @s run function rpg:api/heal_hit {owner:"ber",base:10,ratio:100,radius:5,max:"x",inv:"x",self:"o",tick:10}
#   owner : 사용자 태그 — 이 플레이어의 공격력 · 크리티컬로 회복량/피해량 계산 (스킬 데미지 명령어와 같은 식)
#   self  : "o" = 사용자(owner 태그 플레이어)도 회복 (범위 밖이어도) · "x" = 사용자는 회복 안 함 (범위 안이어도)
#   tick  : 같은 대상은 몇 틱마다 한 번 (20 = 1초) — v46 : 범위는 매 틱 확인하고, 간격은 "대상마다" 따로 셉니다
#           (예전엔 시전자 기준 간격이라, 빨리 날아가는 투사체가 그 사이에 몹을 지나쳐 버려 피해가 안 들어갔습니다)
#           같은 사용자(owner)의 heal_hit 시전자가 여러 개여도 한 대상은 tick 간격에 한 번만 맞습니다
#   범위 : 대상의 발 또는 몸통(발 + 0.9칸) 중 하나라도 radius 안이면 (v46)
#   시전자 자신(아머스탠드 등)은 회복 · 피해 대상에서 빠집니다
#   반환값 = 이번 틱에 회복 + 피해 받은 수 (아무도 없으면 "실패")
$execute unless entity @a[tag=$(owner),limit=1] run return fail
$execute if score @a[tag=$(owner),limit=1] noskill matches 1 run return fail
$scoreboard objectives add rpg.hh_$(owner) dummy
$scoreboard players set #hlk rpg.sys $(tick)
execute if score #hlk rpg.sys matches ..0 run scoreboard players set #hlk rpg.sys 1
tag @s add rpg_hlc
$tag @a[tag=$(owner)] add rpg_hlo
$data modify storage rpg:sk h set value {radius:$(radius),max:"$(max)",inv:"$(inv)",self:"$(self)",owner:"$(owner)"}
# 후보 고르기 : 범위 안 (발 · 몸통) + self "o" 면 사용자
function rpg:api/hh_pick with storage rpg:sk h
execute if data storage rpg:sk h{self:"o"} run tag @a[tag=rpg_hlo,scores={rpg.hp=1..}] add rpg_hho
# 이 사용자 기준 간격이 아직 안 지난 대상은 뺌
function rpg:api/hh_cd with storage rpg:sk h
execute unless entity @e[tag=rpg_hhc] unless entity @a[tag=rpg_hho] run return run function rpg:api/hh_end
# 회복/피해량
scoreboard players set #dmg rpg.sys 0
$execute as @a[tag=$(owner),limit=1] run function rpg:api/atk_dmg {base:$(base),ratio:$(ratio)}
execute store result storage rpg:tmp d.n int 1 run scoreboard players get #dmg rpg.sys
$tag @a[tag=$(owner),limit=1] add rpg_skw
scoreboard players set #hitn rpg.sys 0
scoreboard players set #ivt rpg.sys 0
scoreboard players set #cutt rpg.sys 0
$execute unless data storage rpg:sk h{inv:"x"} run function rpg:api/iv_calc {v:$(inv)}
execute as @a[tag=rpg_hho] at @s run function rpg:api/hh_one with storage rpg:sk h
execute if data storage rpg:sk h{max:"x"} as @e[tag=rpg_hhc] at @s run function rpg:api/hh_one with storage rpg:sk h
execute unless data storage rpg:sk h{max:"x"} run function rpg:api/hh_lim with storage rpg:sk h
$execute as @a[tag=$(owner),limit=1] at @s run function rpg:api/crit_say
function rpg:api/hh_end
execute if score #hitn rpg.sys matches ..0 run return fail
return run scoreboard players get #hitn rpg.sys

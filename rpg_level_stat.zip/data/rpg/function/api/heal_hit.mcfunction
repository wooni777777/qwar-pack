# ── 공격력 비례 "힐" 스킬 (v41) : 플레이어가 맞으면 피해 대신 그만큼 회복 ──
#   execute as <시전자> at @s run function rpg:api/heal_hit {base:10,ratio:100,radius:5,max:"x",inv:"x",self:"o"}
#   회복량 = atk_hit 피해와 같은 식 (base + 총공격력 x ratio / 100, 크리티컬 포함)
#   플레이어 -> 회복  /  몬스터 · 다른 엔티티 -> 피해 (atk_hit 과 같음)
#   self : "o" 면 시전자 본인도 회복 · "x" 면 본인 제외
#   반환값 = 맞은(회복 + 피해) 수. 아무도 없으면 "실패"
$function rpg:api/atk_dmg {base:$(base),ratio:$(ratio)}
execute store result storage rpg:tmp d.n int 1 run scoreboard players get #dmg rpg.sys
tag @s add rpg_skc
tag @s[type=minecraft:player] add rpg_skw
scoreboard players set #hitn rpg.sys 0
scoreboard players set #ivt rpg.sys 0
$data modify storage rpg:sk h set value {radius:$(radius),max:"$(max)",inv:"$(inv)",self:"$(self)"}
$execute unless data storage rpg:sk h{inv:"x"} run function rpg:api/iv_calc {v:$(inv)}
execute if data storage rpg:sk h{self:"o"} run function rpg:api/heal_n with storage rpg:tmp d
execute if data storage rpg:sk h{max:"x"} run function rpg:api/hhit_all with storage rpg:sk h
execute unless data storage rpg:sk h{max:"x"} run function rpg:api/hhit_lim with storage rpg:sk h
tag @s remove rpg_skc
tag @a remove rpg_skw
function rpg:api/crit_say
execute if score #hitn rpg.sys matches ..0 run return fail
return run scoreboard players get #hitn rpg.sys

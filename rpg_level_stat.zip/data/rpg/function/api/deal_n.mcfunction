# 대상 1명에게 피해를 주고 맞은 수를 #hitn 에 누적한다
# v41 : 플레이어가 맞으면 누가 때렸는지 적어 둔다 ([체력 90] 반격이 그 사람에게 돌아가도록)
# v42 : 치감(#cutt) · 스킬로 플레이어가 죽으면 "누가 무엇으로 죽였는지" 알림 (바닐라 사망 메시지 대신)
# v46 : 피해량을 점수로 (백어택이면 늘림)
$scoreboard players set #dln rpg.sys $(n)
# v51 : PVP 가 안 되는 플레이어(같은 국가 · PVP 꺼짐)는 스킬 피해 X
execute if entity @s[type=minecraft:player,tag=!rpg_skw] if entity @a[tag=rpg_skw] run function rpg:pvp/g_skw
execute if entity @s[type=minecraft:player,tag=!rpg_skw] if entity @a[tag=rpg_skw] if score #pvx rpg.sys matches 1 run return 0
execute if entity @a[tag=rpg_skw,scores={ac=1}] unless entity @s[tag=rpg_skw] run function rpg:api/ac_skill
# v58 : [정밀사격] (스킬 데미지도 정밀도 · 강화)
execute unless entity @s[tag=rpg_skw] if entity @a[tag=rpg_skw,scores={ranger-pas=1},limit=1] run function rpg:passive/prc_skill
execute store result storage rpg:tmp dn.n int 1 run scoreboard players get #dln rpg.sys
# v58 : 몬스터도 기록 (피의 균열 스킬 피흡 · 막타 · 정밀사격이 평타와 겹치지 않게)
execute if entity @a[tag=rpg_skw] run function rpg:api/mark_hit
scoreboard players set #dmh rpg.sys 0
execute if entity @s[type=minecraft:player,tag=!rpg_skw] if entity @a[tag=rpg_skw] run function rpg:api/dm_pre with storage rpg:tmp dn
execute store success score #hit1 rpg.sys run function rpg:api/deal_dmg with storage rpg:tmp dn
execute if score #dmh rpg.sys matches 1 run function rpg:api/dm_post
# v45 : ignore (공격 무시) 가 이번 스킬 한 번을 막았으면 소모
execute if score #hit1 rpg.sys matches 1.. if entity @s[type=minecraft:player,tag=rpg_ign] run function rpg:ign/use
scoreboard players operation #hitn rpg.sys += #hit1 rpg.sys
# v45 : 크리티컬로 맞았으면 데미지 숫자 빨강
execute if score #hit1 rpg.sys matches 1.. if score #cmul rpg.sys matches 101.. run function rpg:dmgn/crit_mark
# v51 · v58 : 막타 기록 (보스 · 잡몹 모두)
execute if score #hit1 rpg.sys matches 1.. if entity @s[tag=rpg_mob] if entity @a[tag=rpg_skw] run scoreboard players operation @s rpg.lhp = @a[tag=rpg_skw,limit=1] rpg.pid
# v58 : [악마의 힘] 스킬 피해를 주면 은신 풀림
execute if score #hit1 rpg.sys matches 1.. as @a[tag=rpg_skw,tag=rpg_dmn] run function rpg:skill/demon_break
# v44 : 스킬로 때려도 시전자 전투태세 한 겹
execute if score #hit1 rpg.sys matches 1.. as @a[tag=rpg_skw,limit=1] run function rpg:stance/gain
execute if score #hit1 rpg.sys matches 1.. if score #cutt rpg.sys matches 1.. if entity @s[type=minecraft:player,tag=!rpg_ignx] run function rpg:api/cut_put
# "타격 시" 패시브 (출혈 등) — 스킬 데미지에도 적용 (v35)
execute if score #hit1 rpg.sys matches 1.. if entity @a[tag=rpg_skc] unless entity @s[tag=rpg_ignx] run tag @s add rpg.tgt
execute if score #hit1 rpg.sys matches 1.. if entity @s[tag=rpg.tgt] as @a[tag=rpg_skc,limit=1] at @s run function rpg:passive/skill_hit
tag @s remove rpg.tgt
# 잠깐 무적 (#ivt 가 1 이상일 때만)
execute if score #hit1 rpg.sys matches 1.. if score #ivt rpg.sys matches 1.. run function rpg:api/iv_put
return run scoreboard players get #hit1 rpg.sys

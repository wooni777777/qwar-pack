# 대상 1명에게 피해를 주고 맞은 수를 #hitn 에 누적한다
# v41 : 플레이어가 맞으면 누가 때렸는지 적어 둔다 ([체력 90] 반격이 그 사람에게 돌아가도록)
execute if entity @s[type=minecraft:player] if entity @a[tag=rpg_skw] run function rpg:api/mark_hit
$execute store success score #hit1 rpg.sys run damage @s $(n) rpg:true
scoreboard players operation #hitn rpg.sys += #hit1 rpg.sys
# "타격 시" 패시브 (출혈 등) — 스킬 데미지에도 적용 (v35)
execute if score #hit1 rpg.sys matches 1.. if entity @a[tag=rpg_skc] run tag @s add rpg.tgt
execute if score #hit1 rpg.sys matches 1.. as @a[tag=rpg_skc,limit=1] at @s run function rpg:passive/skill_hit
tag @s remove rpg.tgt
# 잠깐 무적 (#ivt 가 1 이상일 때만)
execute if score #hit1 rpg.sys matches 1.. if score #ivt rpg.sys matches 1.. run function rpg:api/iv_put
return run scoreboard players get #hit1 rpg.sys

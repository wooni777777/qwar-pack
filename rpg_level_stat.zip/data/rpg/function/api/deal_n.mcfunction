# 대상 1명에게 피해를 주고 맞은 수를 #hitn 에 누적한다
$execute store success score #hit1 rpg.sys run damage @s $(n) rpg:true
scoreboard players operation #hitn rpg.sys += #hit1 rpg.sys
return run scoreboard players get #hit1 rpg.sys

# 시전자의 공격력을 대행 엔티티의 rpg.pow 에 새겨 둔다
#   execute as <시전자> run function rpg:api/bind_pow {tag:"ber-R"}
scoreboard players set #atk rpg.sys 0
scoreboard players operation #atk rpg.sys = @s rpg.d_atk
scoreboard players set #wp rpg.sys 0
execute store result score #wp rpg.sys run attribute @s minecraft:attack_damage get 1
scoreboard players operation #atk rpg.sys += #wp rpg.sys
$scoreboard players operation @e[tag=$(tag)] rpg.pow = #atk rpg.sys
return run scoreboard players get #atk rpg.sys

# 반경 안 전부 (내부용)
$execute as @e[distance=0.1..$(radius),tag=!god,tag=!rpg_model,tag=!rpg_mtext,tag=!rpg_auc_h,tag=!rpg_npcE,type=!minecraft:marker,type=!minecraft:armor_stand,type=!minecraft:item_display,type=!minecraft:text_display,type=!minecraft:block_display,type=!minecraft:interaction,type=!minecraft:item,type=!minecraft:experience_orb] run function rpg:api/deal_n with storage rpg:tmp d

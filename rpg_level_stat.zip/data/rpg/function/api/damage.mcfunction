$damage @s $(amount) rpg:true
execute if entity @s[type=minecraft:player,tag=rpg_ign] run function rpg:ign/use

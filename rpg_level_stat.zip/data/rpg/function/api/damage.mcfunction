$damage @s $(amount) rpg:true

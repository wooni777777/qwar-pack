# heal_hit 한 대상 (v46 · 내부용 · 매크로 owner · as 대상) — 플레이어면 회복 · 아니면 피해 · 다음 가능 틱 기록
$scoreboard players operation @s rpg.hh_$(owner) = #gtick rpg.sys
$scoreboard players operation @s rpg.hh_$(owner) += #hlk rpg.sys
function rpg:api/heal_or with storage rpg:tmp d

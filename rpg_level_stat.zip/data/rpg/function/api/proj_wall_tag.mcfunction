# ── 벽에 박힌 투사체를 찾아 "태그를 붙인다" ──
#   function rpg:api/proj_wall_tag {tag:"myarrow",give:"stuck"}
#     tag  : 찾을 투사체가 달고 있는 태그
#     give : 벽에 박힌 것에게 새로 붙일 태그 ("x" 면 안 붙이고 세기만 합니다)
#   붙인 개수를 반환합니다. 하나도 없으면 "실패" 로 처리되어 조건부 명령 블록이 멈춥니다.
#   ※ 같은 투사체에 두 번 붙지 않게 rpg_pwall 이 같이 붙습니다.
scoreboard players set #pw rpg.sys 0
$data modify storage rpg:api pw set value {g:"$(give)"}
$execute as @e[tag=$(tag),tag=!rpg_pwall] if data entity @s {inGround:1b} run function rpg:api/proj_mark_tag with storage rpg:api pw
execute if score #pw rpg.sys matches ..0 run return fail
return run scoreboard players get #pw rpg.sys

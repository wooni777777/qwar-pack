# ── 범위 힐 (v59) : 아머스탠드(태그) 주위 범위 안의 "태그 가진 플레이어" 를 회복 ──
#   function rpg:api/area_heal {stand:"siren-H",radius:5,tag:"team",mode:"n",amount:6,owner:"x"}
#   stand  : 가운데가 될 엔티티 태그 (아머스탠드 등 · 여러 개면 각각 · 겹치는 범위여도 한 사람당 한 번만)
#   radius : 범위 (칸 · 소수 OK)
#   tag    : 회복받을 플레이어 태그 (지우지 않음)
#   mode   : "n"     = 고정 힐 — amount 만큼 회복 (체력 1 = 하트 반 칸)
#            "self"  = 데미지 비례 — 회복받는 사람 각자의 공격력 x amount % 만큼
#            "owner" = 데미지 비례 — owner 태그 플레이어(1명)의 공격력 x amount % 만큼 (모두 같은 양)
#   amount : 숫자 (정수) — "n" 이면 체력 · "self" / "owner" 면 %
#   owner  : mode "owner" 일 때 공격력을 읽을 플레이어 태그 · 다른 mode 면 "x"
#   공격력 = 스킬 데미지 계산과 같은 총공격력 (크리 없음) · 관전 모드 제외 · 치감과 상관없음
#   반환값 = 회복받은 사람 수 (0 이면 "실패" -> 조건부 명령 블록 안 이어짐)
$scoreboard players set #aha rpg.sys $(amount)
$data modify storage rpg:ah a set value {mode:"$(mode)"}
scoreboard players set #ahn rpg.sys 0
scoreboard players set #aho rpg.sys 0
tag @a[tag=rpg_ahv] remove rpg_ahv
$execute if data storage rpg:ah a{mode:"owner"} as @a[tag=$(owner),limit=1] run function rpg:api/ah_atk
execute if data storage rpg:ah a{mode:"owner"} run scoreboard players operation #aho rpg.sys = #atk rpg.sys
$execute as @e[tag=$(stand)] at @s as @a[tag=$(tag),distance=..$(radius),gamemode=!spectator,tag=!rpg_ahv] at @s run function rpg:api/ah_one
tag @a[tag=rpg_ahv] remove rpg_ahv
execute if score #ahn rpg.sys matches ..0 run return fail
return run scoreboard players get #ahn rpg.sys

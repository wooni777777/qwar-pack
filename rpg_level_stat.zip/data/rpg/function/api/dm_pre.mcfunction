# 이번 스킬 피해로 죽을 것 같으면 바닐라 사망 메시지를 이번만 숨긴다 (v42 · 내부용 · @s = 맞는 플레이어 · 매크로 n)
execute store result score #dmhp rpg.sys run data get entity @s Health 100
execute store result score #dmab rpg.sys run data get entity @s AbsorptionAmount 100
scoreboard players operation #dmhp rpg.sys += #dmab rpg.sys
$scoreboard players set #dmn rpg.sys $(n)
scoreboard players operation #dmn rpg.sys *= #c100 rpg.sys
execute if score #dmn rpg.sys < #dmhp rpg.sys run return 0
scoreboard players set #dmh rpg.sys 1
execute if entity @s[team=nat1] run team modify nat1 deathMessageVisibility never
execute if entity @s[team=nat2] run team modify nat2 deathMessageVisibility never
execute if entity @s[team=nat3] run team modify nat3 deathMessageVisibility never
execute if entity @s[team=nat4] run team modify nat4 deathMessageVisibility never
execute if entity @s[team=nat5] run team modify nat5 deathMessageVisibility never
execute if entity @s[team=nat6] run team modify nat6 deathMessageVisibility never
execute if entity @s[team=nat7] run team modify nat7 deathMessageVisibility never
execute if entity @s[team=nat8] run team modify nat8 deathMessageVisibility never
execute if entity @s[team=] run team join rpg_dmh @s

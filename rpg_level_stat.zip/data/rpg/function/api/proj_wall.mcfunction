# ── 태그를 가진 투사체가 벽(블록)에 박혔는지 감지 ──
#   function rpg:api/proj_wall {tag:"myarrow"}
#   박힌 것에 rpg_pwall 태그를 붙이고, 그 개수를 반환합니다.
#   하나도 없으면 "실패" 로 처리되어 조건부 명령 블록이 멈춥니다.
#   ※ 감지만 합니다. 없애거나 튕기는 건 뒤에 직접 붙이세요.
scoreboard players set #pw rpg.sys 0
$execute as @e[tag=$(tag),tag=!rpg_pwall] if data entity @s {inGround:1b} run function rpg:api/proj_mark
execute if score #pw rpg.sys matches ..0 run return fail
return run scoreboard players get #pw rpg.sys

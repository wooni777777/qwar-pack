# 사망 메시지 숨김 되돌리기 + 진짜 죽었으면 알림 (v42 · 내부용 · @s = 맞은 플레이어)
execute if entity @s[team=nat1] run team modify nat1 deathMessageVisibility always
execute if entity @s[team=nat2] run team modify nat2 deathMessageVisibility always
execute if entity @s[team=nat3] run team modify nat3 deathMessageVisibility always
execute if entity @s[team=nat4] run team modify nat4 deathMessageVisibility always
execute if entity @s[team=nat5] run team modify nat5 deathMessageVisibility always
execute if entity @s[team=nat6] run team modify nat6 deathMessageVisibility always
execute if entity @s[team=nat7] run team modify nat7 deathMessageVisibility always
execute if entity @s[team=nat8] run team modify nat8 deathMessageVisibility always
execute if entity @s[team=rpg_dmh] run team leave @s
execute store result score #dmhp rpg.sys run data get entity @s Health 100
execute if score #dmhp rpg.sys matches ..0 run function rpg:api/dm_say

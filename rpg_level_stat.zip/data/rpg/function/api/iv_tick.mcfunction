scoreboard players remove @s rpg.iv 1
execute if score @s rpg.iv matches ..0 run tag @s remove rpg_iv

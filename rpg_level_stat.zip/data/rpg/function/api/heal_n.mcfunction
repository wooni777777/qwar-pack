# 플레이어 1명 회복 (내부용 · 매크로 n)
$scoreboard players set #heal rpg.sys $(n)
function rpg:util/heal
execute at @s run particle minecraft:heart ~ ~2.1 ~ 0.3 0.2 0.3 0 3 normal @a
execute at @s run particle minecraft:happy_villager ~ ~1 ~ 0.3 0.5 0.3 0 6 normal @a
scoreboard players add #hitn rpg.sys 1
execute if score #ivt rpg.sys matches 1.. run function rpg:api/iv_put
return 1

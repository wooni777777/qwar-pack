# ── 출혈 (v44) : 범위 안 대상에게 출혈 — 정해진 초마다 피해 · 이미 출혈 중이면 확률로 "출혈 폭발" ──
#   execute as @p at @s run function rpg:api/bleed {owner:"ber",radius:4,max:"x",dmg:3,every:1,time:5,burst:100,chance:30}
#   owner  : 때리는 주인 태그 (그 플레이어는 안 맞음 · 출혈로 죽이면 그 사람이 죽인 것)
#   radius : 범위 (칸) — 실행 위치(at) 기준
#   max    : 최대 몇 명/마리 (가까운 순) · "x" = 제한 없음
#   dmg    : 출혈 피해 1번에 얼마 (소수 한 자리까지 · 방어구 무시)
#   every  : 몇 초마다 출혈 피해 (예 1 = 1초마다 · 0.5 = 0.5초마다)
#   time   : 출혈이 몇 초 동안 가는지
#   burst  : 출혈에 출혈이 또 걸리면 "출혈 폭발" — 남은 출혈 피해의 몇 % 를 한 번에 (100 = 남은 것 전부 · 200 = 2배)
#            "x" = 안 터짐 (새 출혈로 덮어씀)
#   chance : 출혈 폭발 확률 % (1 ~ 100 · burst 가 "x" 면 아무 숫자)
#   반환값 = 출혈 걸린 대상 수 (한 명도 없거나 owner 태그 플레이어가 없으면 "실패")
$execute unless entity @a[tag=$(owner),limit=1] run return fail
# v45 : 주인이 봉인(noskill 1) 중이면 못 씀
$execute if score @a[tag=$(owner),limit=1] noskill matches 1 run return fail
$data modify storage rpg:bl a set value {radius:$(radius),max:"$(max)",owner:"$(owner)",burst:"$(burst)"}
$data modify storage rpg:bl n set value {d:$(dmg),e:$(every),t:$(time)}
execute store result score #bld rpg.sys run data get storage rpg:bl n.d 10
execute store result score #bli rpg.sys run data get storage rpg:bl n.e 20
execute store result score #blt rpg.sys run data get storage rpg:bl n.t 20
execute if score #bld rpg.sys matches ..0 run scoreboard players set #bld rpg.sys 1
execute if score #bli rpg.sys matches ..0 run scoreboard players set #bli rpg.sys 1
execute if score #blt rpg.sys matches ..0 run scoreboard players set #blt rpg.sys 1
scoreboard players set #blb rpg.sys 0
scoreboard players set #blc rpg.sys 0
$execute unless data storage rpg:bl a{burst:"x"} run function rpg:bleed/bp {b:$(burst),c:$(chance)}
scoreboard players set #blo rpg.sys 0
$scoreboard players operation #blo rpg.sys = @a[tag=$(owner),limit=1] rpg.pid
$tag @a[tag=$(owner)] add rpg_blw
$tag @a[tag=$(owner),limit=1] add rpg_blo1
scoreboard players set #bln rpg.sys 0
execute if data storage rpg:bl a{max:"x"} run function rpg:bleed/all with storage rpg:bl a
execute unless data storage rpg:bl a{max:"x"} run function rpg:bleed/lim with storage rpg:bl a
tag @a remove rpg_blw
tag @a remove rpg_blo1
execute if score #bln rpg.sys matches ..0 run return fail
return run scoreboard players get #bln rpg.sys

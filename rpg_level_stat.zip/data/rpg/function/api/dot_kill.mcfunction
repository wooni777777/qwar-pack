# DoT 마커 1개 제거 (내부용)
scoreboard players add #dstop rpg.sys 1
kill @s

# (구버전 이름 유지) 공격력 비례 계산
$return run function rpg:api/atk_dmg {base:$(base),ratio:$(ratio)}

# 치감 때문에 피흡 못 받음 (v42 · 내부용)
particle minecraft:smoke ~ ~1.9 ~ 0.25 0.1 0.25 0 8 normal @a
playsound minecraft:block.fire.extinguish player @s ~ ~ ~ 0.4 1.6
return fail

# ── 스턴 (v45) : 범위 안 대상을 그 자리에 묶음 — 공중이면 공중에 뜬 채로 · 평타 · 스킬은 쓸 수 있음 ──
#   execute as <시전자> at @s run function rpg:api/stun {owner:"ber",radius:4,time:2}
#   시전자 : execute as 로 지정 (플레이어 · 아머스탠드 등) — 시전자 자신은 안 걸림
#   owner  : 시전자 주인 태그 (그 태그 플레이어는 안 걸림 · 시전자가 플레이어 본인이면 그 사람 태그)
#   radius : 범위 (칸) — 시전자(at) 위치 기준
#   time   : 스턴 몇 초 (0.5 처럼 소수 OK) · 또 걸면 더 긴 쪽
#   CC 면역(버프) 중이면 안 걸림 · 반환값 = 걸린 수 (없으면 실패)
$execute if score @a[tag=$(owner),limit=1] noskill matches 1 run return fail
$data modify storage rpg:sn a set value {r:$(radius),t:$(time)}
execute store result score #snt rpg.sys run data get storage rpg:sn a.t 20
execute if score #snt rpg.sys matches ..0 run scoreboard players set #snt rpg.sys 1
tag @s add rpg_snc
$tag @a[tag=$(owner)] add rpg_snw
scoreboard players set #snn rpg.sys 0
function rpg:stun/area with storage rpg:sn a
tag @s remove rpg_snc
tag @a remove rpg_snw
execute if score #snn rpg.sys matches ..0 run return fail
return run scoreboard players get #snn rpg.sys

# 번개 피해 한 번 (v46 · 내부용 · 매크로 dmg · as 맞는 대상)
#   먼저 무적시간 무시 피해를 넣어 두면, 바로 뒤 바닐라 번개(5)는 무적시간에 막혀 두 번 맞지 않습니다
$damage @s $(dmg) rpg:bolt
execute if entity @s[type=minecraft:player,tag=rpg_ign] run function rpg:ign/use

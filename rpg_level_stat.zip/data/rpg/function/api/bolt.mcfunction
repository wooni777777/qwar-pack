# ── 번개 소환 (v46) : "잠깐 무적" 없이 번개마다 피해가 들어가는 번개 ──
#   execute at <위치> run function rpg:api/bolt {dmg:8,y:0}
#   dmg : 번개 한 번의 피해 (바닐라 번개는 5 · 5 이상 권장 · 7.5 처럼 소수 가능)
#   y   : 높이 (v47) — 0 = 그 자리 · 1 = 한 칸 위 · -1 = 한 칸 아래 · 0.5 처럼 소수 가능 (맞는 범위도 같이 올라감)
#   v47 : 번개가 친 자리에 불이 생기지 않습니다 (생기는 즉시 꺼짐)
#   · 같은 대상에게 번개를 연달아 떨어뜨려도 번개마다 dmg 가 들어갑니다 (무적시간 무시)
#   · 번개 한 개가 같은 대상을 여러 번 때리지는 않습니다 (번개는 9틱 뒤 치움 · 늦게 다시 번쩍이는 것 방지)
#   · 범위 = 바닐라 번개와 같음 (가로 ±3칸 · 아래 3칸 ~ 위 9칸) · 맞은 대상에 불 붙는 것은 바닐라와 같음
#   ※ 그냥 /summon minecraft:lightning_bolt 로 부른 번개는 예전처럼 바닐라 무적시간에 막힙니다 -> 이 명령어로 바꿔 쓰세요
$data modify storage rpg:tmp lb set value $(dmg)
execute store result score #lbd rpg.sys run data get storage rpg:tmp lb 100
$execute if score #lbd rpg.sys matches 1.. positioned ~-3 ~$(y) ~-3 positioned ~ ~-3 ~ as @e[dx=5,dy=11,dz=5,tag=!god,tag=!rpg_model,tag=!rpg_mtext,tag=!rpg_auc_h,tag=!rpg_npcE,type=!minecraft:lightning_bolt,type=!minecraft:marker,type=!minecraft:armor_stand,type=!minecraft:item_display,type=!minecraft:text_display,type=!minecraft:block_display,type=!minecraft:interaction,type=!minecraft:item,type=!minecraft:experience_orb,type=!#rpg:no_hit] run function rpg:api/bolt1 {dmg:$(dmg)}
$execute positioned ~ ~$(y) ~ run summon minecraft:lightning_bolt ~ ~ ~ {Tags:["rpg_bolt"]}
return 1

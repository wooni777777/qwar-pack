# ── 태그로 지정한 적에게 지속 피해 ──
#   execute as @p at @s run function rpg:api/dot {owner:"ber",target:"boss",base:10,ratio:50,interval:20,times:5,max:"x"}
#   owner    : 스킬 주인 (이 태그를 가진 플레이어의 공격력으로 매번 다시 계산합니다)
#   target   : 맞는 적 태그
#   interval : 몇 틱마다 때릴지 (20 = 1초)
#   times    : 총 몇 번 때릴지
#   max      : 한 번에 최대 몇 마리. "x" 면 제한 없음
$summon minecraft:marker ~ ~ ~ {Tags:["rpg_dot","rpg_dotN"],data:{owner:"$(owner)",target:"$(target)",base:$(base),ratio:$(ratio),iv:$(interval),t:1,left:$(times),max:"$(max)"}}
tag @e[tag=rpg_dotN] remove rpg_dotN
return 1

# 태그 전부 (내부용)
$execute as @e[tag=$(target)] run function rpg:api/deal_n with storage rpg:tmp d

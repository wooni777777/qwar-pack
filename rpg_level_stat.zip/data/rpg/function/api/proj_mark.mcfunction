tag @s add rpg_pwall
scoreboard players add #pw rpg.sys 1

# ── 버프 (v44) : 태그를 가진 대상에게 절대방어 · 받는 피해 감소 · CC 면역 ──
#   function rpg:api/buff {tag:"tank",guard:3,dr_t:5,dr_p:30,cc:4}
#   tag   : 효과를 받을 태그 — 효과를 주자마자 이 태그를 지웁니다 (태그가 없어져도 지속시간은 그대로)
#   guard : 절대방어 몇 초 (그동안 받는 피해 0)                 · "x" = 안 줌
#   dr_t  : 받는 피해 감소 몇 초                                · "x" = 안 줌
#   dr_p  : 받는 피해 감소 몇 % (1 ~ 100)                       · "x" = 안 줌
#   cc    : CC 면역 몇 초 (기절 · 느려짐 · 구속류 + 밀려남 없음) · "x" = 안 줌
#   초는 0.5 처럼 소수도 됩니다 · 플레이어 · 몬스터 둘 다 됩니다
#   반환값 = 효과 받은 대상 수 (한 명도 없으면 "실패" -> 조건부 명령 블록 안 이어짐)
scoreboard players set #bfg rpg.sys 0
scoreboard players set #bft rpg.sys 0
scoreboard players set #bfp rpg.sys 0
scoreboard players set #bfc rpg.sys 0
$data modify storage rpg:bf a set value {guard:"$(guard)",dr_t:"$(dr_t)",dr_p:"$(dr_p)",cc:"$(cc)"}
$execute unless data storage rpg:bf a{guard:"x"} run function rpg:buff/sec {k:"g",v:$(guard)}
$execute unless data storage rpg:bf a{dr_t:"x"} run function rpg:buff/sec {k:"t",v:$(dr_t)}
$execute unless data storage rpg:bf a{dr_p:"x"} run function rpg:buff/pct {v:$(dr_p)}
$execute unless data storage rpg:bf a{cc:"x"} run function rpg:buff/sec {k:"c",v:$(cc)}
scoreboard players set #bfn rpg.sys 0
$execute as @e[tag=$(tag)] at @s run function rpg:buff/one
$tag @e[tag=$(tag)] remove $(tag)
execute if score #bfn rpg.sys matches ..0 run return fail
return run scoreboard players get #bfn rpg.sys

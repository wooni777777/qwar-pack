# ── 태그를 가진 투사체가 벽(통과 못 하는 블록)에 부딪히면 바로 없앤다 (v46) ──
#   function rpg:api/proj_kill {tag:"myproj"}     (반복 명령 블록에 넣어 두세요)
#   기준은 proj_block 과 같음 (통과 못 하는 블록 안에 들어감) + 화살 · 삼지창처럼 벽에 박힌 것 (inGround)
#   눈덩이 · 엔더진주 · 아머스탠드 · 마커 · 디스플레이 등 아무 엔티티나 됩니다 (플레이어는 제외)
#   반환값 = 없앤 개수 · 하나도 없으면 "실패" (뒤의 조건부 명령 블록이 멈춤)
#   ※ proj_block (감지만) 은 그대로 있습니다
scoreboard players set #pk rpg.sys 0
$execute as @e[tag=$(tag),type=!minecraft:player] at @s unless block ~ ~ ~ #rpg:pass run function rpg:api/proj_kill1
$execute as @e[tag=$(tag),type=!minecraft:player,nbt={inGround:1b}] run function rpg:api/proj_kill1
execute if score #pk rpg.sys matches ..0 run return fail
return run scoreboard players get #pk rpg.sys

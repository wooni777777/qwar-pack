# ── 태그를 가진 플레이어가 맞으면 근처 적에게 되돌려준다 ──
#   반복 명령 블록에 넣어두세요 (매 틱 실행)
#   function rpg:api/reflect {tag:"refl",ratio:50,radius:6,max:3}
#   ratio  받은 피해의 몇 % 를 되돌릴지      radius 반사 범위(칸)
#   max    최대 몇 명에게 되돌릴지 ("x" 면 제한 없음)
#   반환값 = 이번 틱에 반사가 터진 횟수. 0 이면 "실패" 로 처리됩니다
scoreboard players set #rfn rpg.sys 0
$data modify storage rpg:api rf set value {ratio:$(ratio),radius:$(radius),max:"$(max)"}
$execute as @a[tag=$(tag),scores={rpg.lastd=1..}] at @s run function rpg:api/reflect_go with storage rpg:api rf
execute if score #rfn rpg.sys matches ..0 run return fail
return run scoreboard players get #rfn rpg.sys

# heal_hit 간격 (v46 · 내부용 · 매크로 owner) — 이 사용자에게 tick 간격 안에 이미 맞은 대상은 후보에서 뺌
$execute as @e[tag=rpg_hhc] if score @s rpg.hh_$(owner) > #gtick rpg.sys run tag @s remove rpg_hhc
$execute as @a[tag=rpg_hho] if score @s rpg.hh_$(owner) > #gtick rpg.sys run tag @s remove rpg_hho

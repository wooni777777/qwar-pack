$damage @s $(n) rpg:true

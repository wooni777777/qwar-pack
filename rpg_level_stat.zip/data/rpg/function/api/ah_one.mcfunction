# 범위 힐 1명 (v59 · 내부용 · as at 회복받을 플레이어)
tag @s add rpg_ahv
scoreboard players operation #heal rpg.sys = #aha rpg.sys
execute if data storage rpg:ah a{mode:"self"} run function rpg:api/ah_atk
execute if data storage rpg:ah a{mode:"self"} run scoreboard players operation #heal rpg.sys = #atk rpg.sys
execute if data storage rpg:ah a{mode:"owner"} run scoreboard players operation #heal rpg.sys = #aho rpg.sys
execute unless data storage rpg:ah a{mode:"n"} run scoreboard players operation #heal rpg.sys *= #aha rpg.sys
execute unless data storage rpg:ah a{mode:"n"} run scoreboard players operation #heal rpg.sys /= #c100 rpg.sys
execute if score #heal rpg.sys matches ..0 run return 0
function rpg:util/heal
scoreboard players add #ahn rpg.sys 1
particle minecraft:heart ~ ~2.1 ~ 0.3 0.2 0.3 0 3 normal @a
particle minecraft:happy_villager ~ ~1 ~ 0.35 0.5 0.35 0 8 normal @a

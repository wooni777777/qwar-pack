effect give @s minecraft:instant_health 1 8 true

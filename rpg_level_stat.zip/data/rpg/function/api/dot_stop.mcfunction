# ── 특정 적 태그에 걸린 지속 피해만 중단 ──
#   function rpg:api/dot_stop {target:"boss"}
$execute as @e[tag=rpg_dot] if data entity @s data{target:"$(target)"} run kill @s
return 1

# ── 특정 적 태그에 걸린 지속 피해만 중단 ──
#   function rpg:api/dot_stop {target:"boss"}
#   반환값 = 중단한 개수. 하나도 없으면 "실패" 로 처리됩니다
scoreboard players set #dstop rpg.sys 0
$execute as @e[tag=rpg_dot] if data entity @s data{target:"$(target)"} run function rpg:api/dot_kill
execute if score #dstop rpg.sys matches ..0 run return fail
return run scoreboard players get #dstop rpg.sys

$scoreboard players set #heal rpg.sys $(amount)
function rpg:util/heal

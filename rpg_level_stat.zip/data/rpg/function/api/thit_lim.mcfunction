# 태그 중 가까운 순 max 마리 (내부용)
$execute as @e[tag=$(target),tag=!god,sort=nearest,limit=$(max)] run function rpg:api/deal_n with storage rpg:tmp d

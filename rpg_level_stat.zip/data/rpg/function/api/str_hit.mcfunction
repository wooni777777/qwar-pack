# (구버전 이름 유지) 공격력 비례 광역
$return run function rpg:api/atk_hit {base:$(base),ratio:$(ratio),radius:$(radius)}

scoreboard players operation #cmul rpg.sys *= #c3 rpg.sys
tellraw @s [{"text":"치명적일격!","color":"dark_red","bold":true}]
execute at @s run playsound minecraft:entity.wither.break_block player @s ~ ~ ~ 0.8 1.7
execute at @s run particle minecraft:crit ~ ~1 ~ 0.4 0.5 0.4 0.8 40 normal @a

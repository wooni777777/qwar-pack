# 치명적일격 (내부용) — 계산만 합니다.
scoreboard players operation #cmul rpg.sys *= #c3 rpg.sys
scoreboard players set #cexe rpg.sys 1

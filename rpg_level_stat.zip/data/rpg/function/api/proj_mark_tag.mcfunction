tag @s add rpg_pwall
$execute unless data storage rpg:api pw{g:"x"} run tag @s add $(g)
scoreboard players add #pw rpg.sys 1

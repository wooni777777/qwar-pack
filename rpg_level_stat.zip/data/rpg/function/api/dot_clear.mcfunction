# ── 진행 중인 지속 피해 전부 중단 ──
#   반환값 = 중단한 개수. 하나도 없으면 "실패" 로 처리됩니다
scoreboard players set #dstop rpg.sys 0
execute store result score #dstop rpg.sys if entity @e[tag=rpg_dot]
kill @e[tag=rpg_dot]
execute if score #dstop rpg.sys matches ..0 run return fail
return run scoreboard players get #dstop rpg.sys

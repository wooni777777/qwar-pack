# ── 진행 중인 지속 피해 전부 중단 ──
kill @e[tag=rpg_dot]
return 1

# @s = 맞은 플레이어
scoreboard players operation #rfd rpg.sys = @s rpg.lastd
scoreboard players set @s rpg.lastd 0
$scoreboard players set #rfr rpg.sys $(ratio)
scoreboard players operation #rfd rpg.sys *= #rfr rpg.sys
scoreboard players operation #rfd rpg.sys /= #c100 rpg.sys
execute if score #rfd rpg.sys matches ..0 run return 0
execute store result storage rpg:tmp d.n int 1 run scoreboard players get #rfd rpg.sys
scoreboard players set #hitn rpg.sys 0
$data modify storage rpg:api rf2 set value {radius:$(radius),max:"$(max)"}
execute if data storage rpg:api rf2{max:"x"} run function rpg:api/reflect_all with storage rpg:api rf2
execute unless data storage rpg:api rf2{max:"x"} run function rpg:api/reflect_lim with storage rpg:api rf2
execute if score #hitn rpg.sys matches 1.. run scoreboard players add #rfn rpg.sys 1
execute if score #hitn rpg.sys matches 1.. at @s run particle minecraft:enchanted_hit ~ ~1 ~ 0.4 0.6 0.4 0.1 20 normal @a
execute if score #hitn rpg.sys matches 1.. at @s run playsound minecraft:item.shield.block player @a ~ ~ ~ 0.7 1.4

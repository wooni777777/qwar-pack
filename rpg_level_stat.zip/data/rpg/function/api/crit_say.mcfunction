# ── 크리티컬 · 치명적일격 알림 (맞힌 대상이 있을 때만) ──
#   execute as <시전자> at @s run function rpg:api/crit_say
#   스킬 데미지 함수들이 끝에서 자동으로 부릅니다.
#   직접 rpg:api/atk_dmg 만 써서 피해를 넣었다면, 맞힌 뒤에 이 줄을 붙이세요.
execute if score #hitn rpg.sys matches ..0 run return 0
execute if score #cchain rpg.sys matches 1 run tellraw @s [{"text":"크리티컬","color":"red","bold":true}]
execute if score #cchain rpg.sys matches 2.. run tellraw @s ["",{"text":"크리티컬 x","color":"red","bold":true},{"score":{"name":"#cchain","objective":"rpg.sys"},"color":"gold","bold":true}]
execute if score #cchain rpg.sys matches 1.. at @s run playsound minecraft:entity.player.attack.crit player @s ~ ~ ~ 1 1.4
execute if score #cchain rpg.sys matches 1.. if entity @s[tag=H18] if score @s rpg.h18cd matches ..0 run function rpg:hid/h18_heal
execute if score #cexe rpg.sys matches 1 run tellraw @s [{"text":"치명적일격","color":"dark_red","bold":true}]
execute if score #cexe rpg.sys matches 1 at @s run playsound minecraft:entity.wither.break_block player @s ~ ~ ~ 0.8 1.7
execute if score #cexe rpg.sys matches 1 at @s run particle minecraft:crit ~ ~1 ~ 0.4 0.5 0.4 0.8 40 normal @a
scoreboard players set #cchain rpg.sys 0
scoreboard players set #cexe rpg.sys 0
return 1

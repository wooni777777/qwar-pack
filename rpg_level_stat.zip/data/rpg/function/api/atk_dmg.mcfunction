# ── 공격력 비례 스킬 데미지 계산 (시전자로 실행) ──
#   execute as <시전자> run function rpg:api/atk_dmg {base:20,ratio:150}
#   결과 : #dmg rpg.sys = (base + 총공격력 × ratio ÷ 100) × 크리티컬 배율
$scoreboard players set #dmg rpg.sys $(base)
$scoreboard players set #ratio rpg.sys $(ratio)
scoreboard players set #atk rpg.sys 0
scoreboard players operation #atk rpg.sys = @s rpg.d_atk
scoreboard players set #wp rpg.sys 0
execute store result score #wp rpg.sys run attribute @s minecraft:attack_damage get 1
scoreboard players operation #atk rpg.sys += #wp rpg.sys
scoreboard players operation #sd rpg.sys = #atk rpg.sys
scoreboard players operation #sd rpg.sys *= #ratio rpg.sys
scoreboard players operation #sd rpg.sys /= #c100 rpg.sys
scoreboard players operation #dmg rpg.sys += #sd rpg.sys
# ── 크리티컬 (무기 주인 기준 · 중첩 가능) ──
scoreboard players set #cchain rpg.sys 0
scoreboard players set #cexe rpg.sys 0
scoreboard players set #cmul rpg.sys 100
execute if score @s rpg.crit matches 1.. run function rpg:api/crit_roll
# ── [민첩 100] 치명적일격 : 크리티컬 확률 -20%, 성공하면 x3 ──
execute if score @s rpg.dex matches 100.. run function rpg:api/exec_roll
scoreboard players operation #dmg rpg.sys *= #cmul rpg.sys
scoreboard players operation #dmg rpg.sys /= #c100 rpg.sys
execute if score #dmg rpg.sys matches ..0 run scoreboard players set #dmg rpg.sys 1
return run scoreboard players get #dmg rpg.sys

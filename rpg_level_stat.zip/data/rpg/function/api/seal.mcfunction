# ── 봉인 (v45) : 태그를 가진 플레이어 주위의 적은 스킬 사용 X · 평타 피해 X ──
#   function rpg:api/seal {tag:"A",radius:5,time:4}
#   tag    : 봉인을 두르는 플레이어 태그 (이 태그 플레이어 · 같은 국가 사람은 안 걸림 · 태그는 안 지움)
#   radius : 범위 (칸) — 그 플레이어를 따라다님
#   time   : 몇 초 동안 · "x" = 이번 한 번만 (반복 명령 블록에 넣으면 켜 둔 동안 계속)
#   범위 안 적(플레이어 · 몹) : 스코어보드 noskill = 1 (내 스킬 명령 블록이 이걸 보고 막음)
#                               평타 피해 0 · 화살 X · 스킬 데미지 명령어 X · 몹 특수 공격 X  — 범위를 벗어나면 바로 풀림
#   반환값 = 봉인을 두른 플레이어 수 (없으면 실패)
$data modify storage rpg:sl a set value {r:$(radius),t:"$(time)"}
scoreboard players set #slt rpg.sys 3
$execute unless data storage rpg:sl a{t:"x"} run function rpg:seal/sec {v:$(time)}
execute store result score #slr rpg.sys run data get storage rpg:sl a.r 10
scoreboard players set #sln rpg.sys 0
$execute as @a[tag=$(tag)] run function rpg:seal/on
execute if score #sln rpg.sys matches ..0 run return fail
return run scoreboard players get #sln rpg.sys

# ── 통과 못 하는 블록 안에 들어간 투사체에게 "태그를 붙인다" ──
#   function rpg:api/proj_block_tag {tag:"myproj",give:"stuck"}
#   화살이 아닌 투사체(눈덩이 · 엔더진주 · 커스텀 마커)에도 씁니다.
scoreboard players set #pw rpg.sys 0
$data modify storage rpg:api pw set value {g:"$(give)"}
$execute as @e[tag=$(tag),tag=!rpg_pwall] at @s unless block ~ ~ ~ #rpg:pass run function rpg:api/proj_mark_tag with storage rpg:api pw
execute if score #pw rpg.sys matches ..0 run return fail
return run scoreboard players get #pw rpg.sys

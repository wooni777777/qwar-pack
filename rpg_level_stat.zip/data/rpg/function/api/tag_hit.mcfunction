# ── 태그로 지정한 적에게 확정 타격 (거리 무관) ──
#   execute as @p at @s run function rpg:api/tag_hit {owner:"ber",target:"boss",base:20,ratio:150,max:"x"}
#   owner  : 스킬 주인 — 이 태그를 가진 플레이어의 공격력으로 계산합니다
#   target : 맞는 적 — 이 태그를 가진 엔티티 전부가 맞습니다
#   max    : 최대 몇 마리. "x" 면 제한 없음. 숫자면 가까운 순
#   반환값 = 맞은 대상 수
#   ※ 한 마리도 못 맞히면 이 명령 자체가 "실패" 로 처리됩니다.
#      -> 뒤에 붙인 조건부(Conditional) 명령 블록이 실행되지 않습니다.
scoreboard players set #dmg rpg.sys 0
$execute as @a[tag=$(owner),limit=1] run function rpg:api/atk_dmg {base:$(base),ratio:$(ratio)}
execute if score #dmg rpg.sys matches ..0 run return fail
execute store result storage rpg:tmp d.n int 1 run scoreboard players get #dmg rpg.sys
scoreboard players set #hitn rpg.sys 0
$data modify storage rpg:sk t set value {target:"$(target)",max:"$(max)"}
execute if data storage rpg:sk t{max:"x"} run function rpg:api/thit_all with storage rpg:sk t
execute unless data storage rpg:sk t{max:"x"} run function rpg:api/thit_lim with storage rpg:sk t
execute if score #hitn rpg.sys matches ..0 run return fail
return run scoreboard players get #hitn rpg.sys

# ── 태그로 지정한 적에게 확정 타격 (거리 무관) ──
#   execute as @p at @s run function rpg:api/tag_hit {owner:"ber",target:"boss",base:20,ratio:150,max:"x",inv:"x"}
#   owner  : 스킬 주인 — 이 태그를 가진 플레이어의 공격력으로 계산합니다
#   target : 맞는 적 — 이 태그를 가진 엔티티 전부가 맞습니다
#   max    : 최대 몇 마리. "x" 면 제한 없음. 숫자면 가까운 순
#   inv    : 맞은 적에게 거는 "잠깐 무적" 초. "x" 면 안 검
#   반환값 = 맞은 대상 수
#   ※ 한 마리도 못 맞히면 이 명령 자체가 "실패" 로 처리됩니다.
scoreboard players set #dmg rpg.sys 0
$execute as @a[tag=$(owner),limit=1] run function rpg:api/atk_dmg {base:$(base),ratio:$(ratio)}
execute if score #dmg rpg.sys matches ..0 run return fail
execute store result storage rpg:tmp d.n int 1 run scoreboard players get #dmg rpg.sys
tag @s add rpg_skc
scoreboard players set #hitn rpg.sys 0
scoreboard players set #ivt rpg.sys 0
$data modify storage rpg:sk t set value {target:"$(target)",max:"$(max)",inv:"$(inv)"}
$execute unless data storage rpg:sk t{inv:"x"} run function rpg:api/iv_calc {v:$(inv)}
execute if data storage rpg:sk t{max:"x"} run function rpg:api/thit_all with storage rpg:sk t
execute unless data storage rpg:sk t{max:"x"} run function rpg:api/thit_lim with storage rpg:sk t
tag @s remove rpg_skc
$execute as @a[tag=$(owner),limit=1] at @s run function rpg:api/crit_say
execute if score #hitn rpg.sys matches ..0 run return fail
return run scoreboard players get #hitn rpg.sys

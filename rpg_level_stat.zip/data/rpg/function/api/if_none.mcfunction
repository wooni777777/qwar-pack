# ── 조건 명령어 (v46) : 태그를 가진 몹 · 플레이어 · 몬스터가 "하나라도 있으면" 실패 ──
#   function rpg:api/if_none {tag:"B"}
#   B 태그 가진 게 있다  -> 실패 -> 뒤에 붙인 조건부(Conditional) 명령 블록이 실행 안 됨
#   B 태그 가진 게 없다  -> 성공 -> 뒤의 조건부 명령 블록 실행
#   (죽어서 리스폰 화면에 있는 플레이어 · 사라진 엔티티는 "없음" 으로 칩니다)
$execute if entity @e[tag=$(tag)] run return fail
return 1

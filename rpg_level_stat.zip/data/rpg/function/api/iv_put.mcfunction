# 맞은 대상에게 잠깐 무적을 건다 (내부용 · @s = 맞은 대상)
scoreboard players operation @s rpg.iv = #ivt rpg.sys
tag @s add rpg_iv

scoreboard players operation @s rpg.lskp = @a[tag=rpg_skw,limit=1] rpg.pid
scoreboard players operation @s rpg.lskt = #gtick rpg.sys

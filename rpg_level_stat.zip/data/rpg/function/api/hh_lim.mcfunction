# heal_hit 가까운 순 max (v46 · 내부용 · 매크로 max owner · at 시전자)
$execute as @e[tag=rpg_hhc,sort=nearest,limit=$(max)] at @s run function rpg:api/hh_one with storage rpg:sk h

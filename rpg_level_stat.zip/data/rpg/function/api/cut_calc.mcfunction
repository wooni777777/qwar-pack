# 치감 초 -> 틱 (내부용)  function rpg:api/cut_calc {v:3}
$data modify storage rpg:sk c set value {v:$(v)}
execute store result score #cutt rpg.sys run data get storage rpg:sk c.v 20
execute if score #cutt rpg.sys matches ..0 run scoreboard players set #cutt rpg.sys 1

# ── 아머스탠드(대행 엔티티)가 대신 때려주는 광역 스킬 ──
#   execute as @e[tag=ber-R] at @s run function rpg:api/proxy_hit {owner:"ber",base:20,ratio:150,radius:4,max:"x",inv:"x",cut:"x"}
#   owner : 시전자가 가진 태그 (공격력을 여기서 읽습니다)
#   max   : 최대 몇 마리. "x" 면 제한 없음
#   inv   : 맞은 적에게 거는 "잠깐 무적" 초. "x" 면 안 검
#   cut : 맞은 플레이어에게 거는 "치감" 초 (그동안 피흡 명령어로 회복을 못 받음). "x" 면 안 검  (v42 · 꼭 넣어야 함)
#   반환값 = 맞은 대상 수
#   ※ 한 마리도 못 맞히면 이 명령 자체가 "실패" 로 처리됩니다.
# v45 : 주인이 봉인(noskill 1) 중이면 못 씀
$execute if score @a[tag=$(owner),limit=1] noskill matches 1 run return fail
scoreboard players set #dmg rpg.sys 0
$execute as @a[tag=$(owner),limit=1] run function rpg:api/atk_dmg {base:$(base),ratio:$(ratio)}
execute if score #dmg rpg.sys matches ..0 run return fail
execute store result storage rpg:tmp d.n int 1 run scoreboard players get #dmg rpg.sys
scoreboard players set #hitn rpg.sys 0
$tag @a[tag=$(owner),limit=1] add rpg_skw
scoreboard players set #ivt rpg.sys 0
scoreboard players set #cutt rpg.sys 0
$data modify storage rpg:sk p set value {radius:$(radius),max:"$(max)",owner:"$(owner)",inv:"$(inv)",cut:"$(cut)"}
$execute unless data storage rpg:sk p{cut:"x"} run function rpg:api/cut_calc {v:$(cut)}
$execute unless data storage rpg:sk p{inv:"x"} run function rpg:api/iv_calc {v:$(inv)}
execute if data storage rpg:sk p{max:"x"} run function rpg:api/phit_all with storage rpg:sk p
execute unless data storage rpg:sk p{max:"x"} run function rpg:api/phit_lim with storage rpg:sk p
tag @a remove rpg_skw
$execute as @a[tag=$(owner),limit=1] at @s run function rpg:api/crit_say
execute if score #hitn rpg.sys matches ..0 run return fail
return run scoreboard players get #hitn rpg.sys

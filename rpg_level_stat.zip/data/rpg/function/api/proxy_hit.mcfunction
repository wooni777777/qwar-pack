# ── 아머스탠드(대행 엔티티)가 대신 때려주는 광역 스킬 ──
#   execute as @e[tag=ber-R] at @s run function rpg:api/proxy_hit {owner:"ber",base:20,ratio:150,radius:4}
#   owner 에는 시전자가 가진 태그를 넣습니다 (ber, mage, arc ...)
#   반환값 = 맞은 대상 수
scoreboard players set #dmg rpg.sys 0
$execute as @a[tag=$(owner),limit=1] run function rpg:api/atk_dmg {base:$(base),ratio:$(ratio)}
execute if score #dmg rpg.sys matches ..0 run return 0
execute store result storage rpg:tmp d.n int 1 run scoreboard players get #dmg rpg.sys
scoreboard players set #hitn rpg.sys 0
$execute as @e[distance=0.1..$(radius),tag=!$(owner),tag=!rpg_model,tag=!rpg_mtext,tag=!rpg_auc_h,tag=!rpg_npcE,type=!minecraft:marker,type=!minecraft:armor_stand,type=!minecraft:item_display,type=!minecraft:text_display,type=!minecraft:block_display,type=!minecraft:interaction,type=!minecraft:item,type=!minecraft:experience_orb] run function rpg:api/deal_n with storage rpg:tmp d
return run scoreboard players get #hitn rpg.sys

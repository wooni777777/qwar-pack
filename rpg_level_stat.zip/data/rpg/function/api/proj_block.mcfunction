# ── 태그를 가진 엔티티가 통과 못 하는 블록 안에 들어갔는지 감지 ──
#   function rpg:api/proj_block {tag:"myproj"}
#   화살이 아닌 투사체(눈덩이 · 엔더진주 · 커스텀 마커)에도 씁니다.
scoreboard players set #pw rpg.sys 0
$execute as @e[tag=$(tag),tag=!rpg_pwall] at @s unless block ~ ~ ~ #rpg:pass run function rpg:api/proj_mark
execute if score #pw rpg.sys matches ..0 run return fail
return run scoreboard players get #pw rpg.sys

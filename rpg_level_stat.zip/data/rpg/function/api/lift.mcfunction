# ── 띄우기 (v47) : 아머스탠드(태그) 주위의 몹 · 플레이어 · 몬스터를 위로 올리고, 그 높이에 잠깐 고정 ──
#   function rpg:api/lift {tag:"ber-R",owner:"ber",radius:4,power:0.6,self:"x",time:1,hold:2}
#   tag    : 가운데가 될 엔티티 태그 (아머스탠드 등 · 여러 개면 각각)
#   owner  : 태그 주인 (사용자 태그) — 기본으로 안 올라감
#   radius : 범위 (칸)
#   power  : 올리는 파워 = 1틱에 올라가는 칸 (0.6 = 1초에 12칸 · 0.05 단위)
#   self   : "o" = 태그 주인도 같이 올림 · "x" = 주인은 안 올림
#   time   : 몇 초 동안 올릴지 (소수 OK · 0.5 = 반 초)
#   hold   : 다 올라간 뒤 몇 초 동안 그 높이에 고정 (아래로 안 떨어짐 · 옆으로는 조금 움직일 수 있음) · 0 이면 바로 떨어짐
#   CC 면역(버프) 중인 대상은 안 올라감 · 이미 올라가는 중이면 새로 다시 시작
#   반환값 = 올린 수 (0 이면 실패)
$execute if entity @a[tag=$(owner),limit=1] if score @a[tag=$(owner),limit=1] noskill matches 1 run return fail
$data modify storage rpg:lf a set value {p:$(power),t:$(time),h:$(hold),self:"$(self)"}
execute store result score #lfa rpg.sys run data get storage rpg:lf a.p 20
execute if score #lfa rpg.sys matches ..0 run scoreboard players set #lfa rpg.sys 1
execute if score #lfa rpg.sys matches 128.. run scoreboard players set #lfa rpg.sys 128
scoreboard players remove #lfa rpg.sys 1
execute store result storage rpg:lf a.a int 1 run scoreboard players get #lfa rpg.sys
execute store result score #lft rpg.sys run data get storage rpg:lf a.t 20
execute store result score #lfh rpg.sys run data get storage rpg:lf a.h 20
execute if score #lft rpg.sys matches ..0 run scoreboard players set #lft rpg.sys 1
execute if score #lfh rpg.sys matches ..-1 run scoreboard players set #lfh rpg.sys 0
scoreboard players set #lfn rpg.sys 0
$tag @a[tag=$(owner)] add rpg_lfw
$tag @a[tag=$(owner)] add rpg_lfo
execute if data storage rpg:lf a{self:"o"} run tag @a[tag=rpg_lfo] remove rpg_lfo
$execute as @e[tag=$(tag)] at @s as @e[distance=..$(radius),tag=!$(tag),tag=!rpg_lfo,tag=!god,tag=!rpg_model,tag=!rpg_mtext,tag=!rpg_auc_h,tag=!rpg_npcE,type=!minecraft:marker,type=!minecraft:armor_stand,type=!minecraft:item_display,type=!minecraft:text_display,type=!minecraft:block_display,type=!minecraft:interaction,type=!minecraft:item,type=!minecraft:experience_orb,type=!#rpg:no_hit] run function rpg:lift/start with storage rpg:lf a
tag @a[tag=rpg_lfo] remove rpg_lfo
tag @a[tag=rpg_lfw] remove rpg_lfw
execute if score #lfn rpg.sys matches ..0 run return fail
return run scoreboard players get #lfn rpg.sys

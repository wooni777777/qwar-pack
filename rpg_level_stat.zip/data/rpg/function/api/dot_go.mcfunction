# DoT 피해 1회 (내부용)
$function rpg:api/tag_hit {owner:"$(owner)",target:"$(target)",base:$(base),ratio:$(ratio),max:"$(max)",inv:"$(inv)"}

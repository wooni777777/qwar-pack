# ── fly 스코어보드가 1인 플레이어에게 비행 부여 ──
#   · 중력 0  : 공중에 그대로 멈춰 있습니다
#   · 달리기  : 바라보는 방향으로 추진 (위를 보고 달리면 상승)
#   · 웅크림  : 하강
#   · 낙하 피해 면역
# 켜기 (아직 적용 안 된 사람만)
# 점수가 없는 플레이어에게 0을 만들어 준다 (없으면 selector 조건이 통째로 실패)
scoreboard players add @a fly 0
scoreboard players add @a rpg.grav 0
execute as @a[scores={fly=1,rpg.grav=0},gamemode=!creative,gamemode=!spectator] run function rpg:sys/fly_on
# 끄기 (fly 가 1 이 아닌데 적용돼 있는 사람)
execute as @a[scores={rpg.grav=1}] unless score @s fly matches 1 run function rpg:sys/fly_off
execute as @a[scores={rpg.grav=1},gamemode=creative] run function rpg:sys/fly_off
execute as @a[scores={rpg.grav=1},gamemode=spectator] run function rpg:sys/fly_off

# 조작
execute as @a[scores={fly=1,rpg.grav=1}] at @s[predicate=rpg:sprinting] run tp @s ^ ^ ^0.55
execute as @a[scores={fly=1,rpg.grav=1}] at @s[predicate=rpg:sneaking] run tp @s ~ ~-0.4 ~

# 웅크림 1회 입력
scoreboard players add @s rpg.snkN 1
scoreboard players set @s rpg.snkT 10
# 2번째 입력 + 당근 낚싯대를 들고 있으면 C+C = 1
execute if score @s rpg.snkN matches 2.. if items entity @s weapon.mainhand minecraft:carrot_on_a_stick run function rpg:sys/cc_fire
execute if score @s rpg.snkN matches 2.. run scoreboard players set @s rpg.snkN 0

scoreboard players set @s C+C 1
scoreboard players set @s rpg.cct 4
scoreboard players set @s rpg.snkT 0

scoreboard players set @s rpg.grav 1
attribute @s minecraft:gravity base set 0
attribute @s minecraft:safe_fall_distance base set 1024
attribute @s minecraft:fall_damage_multiplier base set 0
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"비행이 켜졌습니다.  달리기 = 바라보는 방향으로 추진 / 웅크리기 = 하강","color":"aqua"}]

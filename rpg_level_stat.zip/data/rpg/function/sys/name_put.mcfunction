$data modify storage rpg:names p$(p) set value "$(n)"
$scoreboard players set @a[scores={rpg.pid=$(p)}] rpg.nmok 1

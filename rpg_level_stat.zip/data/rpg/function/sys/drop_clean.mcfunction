# 바닥에 떨어진 액티브 스킬 아이템은 즉시 사라진다 (건네주기 방지)
kill @e[type=minecraft:item,nbt={Item:{components:{"minecraft:custom_data":{rpg_leap:1b}}}}]
kill @e[type=minecraft:item,nbt={Item:{components:{"minecraft:custom_data":{rpg_stun:1b}}}}]
kill @e[type=minecraft:item,nbt={Item:{components:{"minecraft:custom_data":{rpg_totem:1b}}}}]

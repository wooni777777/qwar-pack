scoreboard players add @s rpg.nmt 1
execute if data entity @s ArmorItems[3].components."minecraft:profile".name run function rpg:sys/name_save
execute if score @s rpg.nmt matches 60.. run kill @s

# ── 플레이어 닉네임 캐시 ──
# 자바 데이터팩은 플레이어 이름을 문자열로 직접 읽을 수 없습니다.
# 그래서 UUID 로 만든 플레이어 머리를 서버가 해석(resolve)할 때
# 채워 넣는 profile.name 을 받아와서 storage rpg:names 에 저장해 둡니다.
execute as @a unless score @s rpg.nmok matches 1 unless entity @e[tag=rpg_namer] run function rpg:sys/name_req
execute as @e[type=minecraft:armor_stand,tag=rpg_namer] run function rpg:sys/name_get

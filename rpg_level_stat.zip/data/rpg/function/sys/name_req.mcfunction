function rpg:vault/pid
summon minecraft:armor_stand ~ ~-64 ~ {Tags:["rpg_namer"],Marker:1b,Invisible:1b,NoGravity:1b,Invulnerable:1b,PersistenceRequired:1b,Silent:1b}
item replace entity @e[tag=rpg_namer,limit=1] armor.head with minecraft:player_head
data modify entity @e[tag=rpg_namer,limit=1] ArmorItems[3].components."minecraft:profile".id set from entity @s UUID
scoreboard players operation @e[tag=rpg_namer,limit=1] rpg.pid = @s rpg.pid

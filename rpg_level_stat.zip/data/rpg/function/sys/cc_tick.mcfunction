# ── 당근 낚싯대를 들고 웅크리기를 연속 2번 하면  C+C = 1 ──
# 지난 틱의 웅크림 상태를 보관
scoreboard players operation @a rpg.snkP = @a rpg.snkS
scoreboard players set @a rpg.snkS 0
execute as @a[predicate=rpg:sneaking] run scoreboard players set @s rpg.snkS 1

# 누르는 순간(0 -> 1)만 1회로 센다
execute as @a if score @s rpg.snkS matches 1 if score @s rpg.snkP matches 0 run function rpg:sys/cc_press

# 연타 인정 시간 창 (10틱 = 0.5초) 이 지나면 카운트 초기화
execute as @a[scores={rpg.snkT=1..}] run scoreboard players remove @s rpg.snkT 1
execute as @a[scores={rpg.snkT=0,rpg.snkN=1..}] run scoreboard players set @s rpg.snkN 0

# ── C+C 가 1 이면 4틱(0.2초) 뒤 0 으로 ──
execute as @a if score @s C+C matches 1 unless score @s rpg.cct matches 1.. run scoreboard players set @s rpg.cct 4
execute as @a[scores={rpg.cct=1..}] run scoreboard players remove @s rpg.cct 1
execute as @a[scores={rpg.cct=0}] run scoreboard players set @s C+C 0
# C+C 가 0 이면 0.2초 타이머도 0 으로 (요청대로)
execute as @a if score @s C+C matches 0 run scoreboard players set @s rpg.cct 0

scoreboard players set @s rpg.grav 0
attribute @s minecraft:gravity base set 0.08
attribute @s minecraft:safe_fall_distance base set 3
attribute @s minecraft:fall_damage_multiplier base set 1
execute if score @s fly matches 0 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"비행이 꺼졌습니다.","color":"gray"}]

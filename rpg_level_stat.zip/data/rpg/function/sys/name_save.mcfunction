data modify storage rpg:tmp nm.n set from entity @s ArmorItems[3].components."minecraft:profile".name
execute store result storage rpg:tmp nm.p int 1 run scoreboard players get @s rpg.pid
function rpg:sys/name_put with storage rpg:tmp nm
kill @s

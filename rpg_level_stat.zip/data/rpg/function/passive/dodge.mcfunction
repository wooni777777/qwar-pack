# [민첩 100] 잔상 : 20% 확률로 피해를 완전히 흘린다
execute store result score #r rpg.sys run random value 1..100
execute if score #r rpg.sys matches 1..20 run function rpg:passive/dodge_go

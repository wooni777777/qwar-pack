execute store result score #r rpg.sys run random value 1..100
execute if score #r rpg.sys matches 1..5 run function rpg:passive/bleed

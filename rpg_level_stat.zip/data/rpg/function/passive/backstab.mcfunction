tag @s add rpg.atkr
scoreboard players set #bs rpg.sys 0
execute as @e[tag=rpg.tgt,limit=1] at @s rotated as @s positioned ^ ^ ^-1.6 if entity @a[tag=rpg.atkr,distance=..2.6] run scoreboard players set #bs rpg.sys 1
tag @s remove rpg.atkr
execute if score #bs rpg.sys matches 1 run function rpg:passive/backstab_go

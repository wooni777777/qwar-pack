scoreboard players operation #x rpg.sys = #atk rpg.sys
scoreboard players operation #x rpg.sys *= #c50 rpg.sys
scoreboard players operation #x rpg.sys /= #c100 rpg.sys
function rpg:passive/deal_call
tellraw @s [{"text":"[패시브] ","color":"aqua","bold":true},{"text":"습격 - 추가 피해","color":"white"}]

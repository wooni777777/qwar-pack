scoreboard players set #cchain rpg.sys 0
execute store result score #r rpg.sys run random value 1..1000
execute if score #r rpg.sys <= @s rpg.crit run function rpg:passive/crit

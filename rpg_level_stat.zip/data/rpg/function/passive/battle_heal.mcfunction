scoreboard players set @s rpg.cd60 1800
execute if score @s rpg.str matches 60.. run function rpg:passive/battle_heal_go

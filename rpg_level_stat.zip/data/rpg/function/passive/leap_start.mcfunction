scoreboard players operation @s rpg.lcd = #leap_cd rpg.sys

# 낙하 피해 면역 (착지하거나 5초가 지나면 해제)
attribute @s minecraft:fall_damage_multiplier modifier remove rpg:leapfall
attribute @s minecraft:fall_damage_multiplier modifier add rpg:leapfall -1 add_multiplied_total
scoreboard players set @s rpg.leap 100

execute at @s run playsound minecraft:entity.breeze.charge player @a ~ ~ ~ 1.2 1.3
execute at @s run particle minecraft:gust ~ ~0.2 ~ 0 0 0 0 1 normal @a

# 돌풍구를 발 뒤쪽에 #leap_pow 개 소환 -> 폭발 넉백이 겹쳐서 강하게 날아간다
scoreboard players operation #lp rpg.sys = #leap_pow rpg.sys
execute if score #lp rpg.sys matches 1.. at @s run function rpg:passive/leap_burst

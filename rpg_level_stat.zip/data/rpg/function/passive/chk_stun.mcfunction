scoreboard players set #has rpg.sys 0
execute store result score #has rpg.sys run clear @s *[minecraft:custom_data~{rpg_stun:1b}] 0
execute if score #has rpg.sys matches ..0 run function rpg:passive/give_stun

scoreboard players operation #t rpg.sys = @s rpg.tmax
scoreboard players operation #t rpg.sys *= #c7 rpg.sys
scoreboard players operation #t rpg.sys /= #c100 rpg.sys
execute if score @s rpg.hpnow < #t rpg.sys run function rpg:passive/armorbreak_go

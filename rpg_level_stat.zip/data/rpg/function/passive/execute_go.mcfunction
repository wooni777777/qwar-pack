# 기본 타격(1배) 위에 2배를 더해 총 3배
scoreboard players operation #x rpg.sys = #atk rpg.sys
scoreboard players operation #x rpg.sys *= #c2 rpg.sys
function rpg:passive/deal_call
tellraw @s [{"text":"치명적일격!","color":"dark_red","bold":true}]
execute at @s run playsound minecraft:entity.wither.break_block player @s ~ ~ ~ 0.8 1.7
execute at @s run particle minecraft:crit ~ ~1 ~ 0.4 0.5 0.4 0.8 40 normal @a

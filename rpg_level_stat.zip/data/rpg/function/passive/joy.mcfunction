scoreboard players operation #heal rpg.sys = @s rpg.tmax
scoreboard players operation #heal rpg.sys *= #c2 rpg.sys
scoreboard players operation #heal rpg.sys /= #c100 rpg.sys
function rpg:util/heal

attribute @s minecraft:fall_damage_multiplier modifier remove rpg:leapfall
scoreboard players set @s rpg.leap 0
execute at @s run particle minecraft:cloud ~ ~0.1 ~ 0.4 0.05 0.4 0.02 12 normal @a

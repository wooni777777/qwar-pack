particle minecraft:cloud ~ ~0.1 ~ 0.25 0.05 0.25 0.01 3 normal @a
scoreboard players remove @s rpg.leap 1
# 15틱 이상 지난 뒤 땅에 닿으면 즉시 종료
execute if score @s rpg.leap matches ..85 if entity @s[nbt={OnGround:1b}] run scoreboard players set @s rpg.leap 0
execute if score @s rpg.leap matches ..0 run function rpg:passive/leap_end

scoreboard players set #red rpg.sys 100
scoreboard players set #dodge rpg.sys 1
scoreboard players set @s rpg.grace 10
effect give @s minecraft:speed 2 1 true
title @s actionbar [{"text":"잔상!","color":"aqua","bold":true}]
execute at @s run particle minecraft:cloud ~ ~1 ~ 0.35 0.6 0.35 0.02 25 normal @a
execute at @s run playsound minecraft:entity.phantom.flap player @a ~ ~ ~ 0.7 1.8

# 패시브가 교체되어 더 이상 토템을 주지 않는다. 남아 있는 토템은 회수.
clear @s *[minecraft:custom_data~{rpg_totem:1b}]

scoreboard players set @s rpg.combo 0
scoreboard players set @s rpg.cmb2 0
scoreboard players set @s rpg.cmbt -1
scoreboard players set @s rpg.war 0

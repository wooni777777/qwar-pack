# 시선 방향 뒤쪽 아래에 돌풍구를 놓고 즉시 지면으로 쏜다 (폭발 -> 앞 + 위로 밀림)
execute rotated ~ 0 positioned ^ ^0.15 ^-1.0 run summon minecraft:wind_charge ~ ~ ~ {Motion:[0.0,-2.2,0.0],Tags:["rpg_leapwind"]}
scoreboard players remove #lp rpg.sys 1
execute if score #lp rpg.sys matches 1.. run function rpg:passive/leap_burst

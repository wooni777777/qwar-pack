# 치명적일격 확률 = 크리티컬 확률 - 20%  (1000분율이므로 200 을 뺀다)
scoreboard players operation #ec rpg.sys = @s rpg.crit
scoreboard players remove #ec rpg.sys 200
execute if score #ec rpg.sys matches 1.. store result score #r rpg.sys run random value 1..1000
execute if score #ec rpg.sys matches 1.. if score #r rpg.sys <= #ec rpg.sys run function rpg:passive/execute_go

scoreboard players set @s rpg.cmb2 0
scoreboard players operation #x rpg.sys = #atk rpg.sys
scoreboard players operation #x rpg.sys *= #c60 rpg.sys
scoreboard players operation #x rpg.sys /= #c100 rpg.sys
function rpg:passive/deal_call
tellraw @s [{"text":"[패시브] ","color":"aqua","bold":true},{"text":"기습 - 추가 타격","color":"white"}]

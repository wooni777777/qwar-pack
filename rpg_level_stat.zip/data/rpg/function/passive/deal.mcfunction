$damage @e[tag=rpg.tgt,limit=1] $(amt) $(type) by @s

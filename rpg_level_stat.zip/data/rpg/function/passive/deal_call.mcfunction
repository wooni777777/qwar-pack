execute store result storage rpg:main dmg.amt int 1 run scoreboard players get #x rpg.sys
execute if score #x rpg.sys matches 1.. run function rpg:passive/deal with storage rpg:main dmg

scoreboard players operation #heal rpg.sys = @s rpg.tmax
scoreboard players operation #heal rpg.sys *= #c8 rpg.sys
scoreboard players operation #heal rpg.sys /= #c100 rpg.sys
function rpg:util/heal
tellraw @s [{"text":"[패시브] ","color":"red","bold":true},{"text":"숙련된 싸움 - 체력 회복","color":"white"}]

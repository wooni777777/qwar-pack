scoreboard players operation #x rpg.sys = #atk rpg.sys
scoreboard players operation #x rpg.sys *= #c75 rpg.sys
scoreboard players operation #x rpg.sys /= #c100 rpg.sys
function rpg:passive/deal_call
scoreboard players set @s rpg.hide 1
tellraw @s [{"text":"[패시브] ","color":"aqua","bold":true},{"text":"구사일생 - 은신 해제, 추가 피해","color":"white"}]

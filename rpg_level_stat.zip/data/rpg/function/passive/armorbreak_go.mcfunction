scoreboard players set #ar rpg.sys 0
execute store result score #ar rpg.sys run attribute @e[tag=rpg.tgt,limit=1] minecraft:armor get 1
scoreboard players operation #x rpg.sys = #atk rpg.sys
scoreboard players operation #x rpg.sys *= #ar rpg.sys
scoreboard players operation #x rpg.sys /= #c40 rpg.sys
function rpg:passive/deal_call

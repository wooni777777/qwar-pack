data modify storage rpg:main dmg.type set value "rpg:bleed"
scoreboard players operation #x rpg.sys = #atk rpg.sys
scoreboard players operation #x rpg.sys *= #c60 rpg.sys
scoreboard players operation #x rpg.sys /= #c100 rpg.sys
function rpg:passive/deal_call
data modify storage rpg:main dmg.type set value "rpg:true"
execute at @e[tag=rpg.tgt,limit=1] run particle minecraft:crit ~ ~1 ~ 0.4 0.5 0.4 0 20 normal @a
tellraw @s [{"text":"[패시브] ","color":"aqua","bold":true},{"text":"출혈 발생","color":"red"}]

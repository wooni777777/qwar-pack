effect clear @s minecraft:invisibility
scoreboard players set @s rpg.hide -1

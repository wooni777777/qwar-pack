scoreboard players add #cchain rpg.sys 1
scoreboard players operation #x rpg.sys = #atk rpg.sys
scoreboard players operation #x rpg.sys *= #c40 rpg.sys
scoreboard players operation #x rpg.sys /= #c100 rpg.sys
function rpg:passive/deal_call
execute if score #cchain rpg.sys matches 1 run tellraw @s [{"text":"크리티컬!","color":"red","bold":true}]
execute if score #cchain rpg.sys matches 2.. run tellraw @s ["",{"text":"크리티컬 x","color":"red","bold":true},{"score":{"name":"#cchain","objective":"rpg.sys"},"color":"gold","bold":true},{"text":" !","color":"red","bold":true}]
execute at @s run playsound minecraft:entity.player.attack.crit player @s ~ ~ ~ 1 1.4
execute if score #cchain rpg.sys matches 2.. at @s run particle minecraft:crit ~ ~1 ~ 0.4 0.4 0.4 0.4 20 normal @a
# 같은 확률로 한 번 더 (최대 10연쇄)
execute if score #cchain rpg.sys matches ..9 store result score #r rpg.sys run random value 1..1000
execute if score #cchain rpg.sys matches ..9 if score #r rpg.sys <= @s rpg.crit run function rpg:passive/crit

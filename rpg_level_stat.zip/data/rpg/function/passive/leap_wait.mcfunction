scoreboard players operation #sec rpg.sys = @s rpg.lcd
scoreboard players operation #sec rpg.sys /= #c20 rpg.sys
scoreboard players add #sec rpg.sys 1
tellraw @s ["",{"text":"[도약] ","color":"aqua","bold":true},{"text":"재사용까지 ","color":"gray"},{"score":{"name":"#sec","objective":"rpg.sys"},"color":"yellow"},{"text":"초 남았습니다","color":"gray"}]
execute at @s run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 0.7 0.6

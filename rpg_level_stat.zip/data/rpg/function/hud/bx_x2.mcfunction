# (v51 · 내부용 · 매크로 m a b)
$data modify storage rpg:main hud.bx set value "   [경험치 x2 $(m):$(a)$(b)]"
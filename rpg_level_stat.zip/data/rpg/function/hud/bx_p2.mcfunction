# (v51 · 내부용 · 매크로 m a b)
$data modify storage rpg:main hud.bp set value "   [PVP $(m):$(a)$(b)]"
# 경험치 % (v50 · 내부용 · as 플레이어) -> rpg.d_xp . rpg.d_xp2 (소수 한 자리)
scoreboard players operation #xpe rpg.sys = @s rpg.exp
scoreboard players operation #xpn rpg.sys = @s rpg.need
execute if score #xpe rpg.sys matches ..-1 run scoreboard players set #xpe rpg.sys 0
execute if score #xpn rpg.sys matches 2000000.. run scoreboard players operation #xpe rpg.sys /= #c1000 rpg.sys
execute if score #xpn rpg.sys matches 2000000.. run scoreboard players operation #xpn rpg.sys /= #c1000 rpg.sys
execute if score #xpn rpg.sys matches ..0 run scoreboard players set #xpn rpg.sys 1
execute if score #xpe rpg.sys > #xpn rpg.sys run scoreboard players operation #xpe rpg.sys = #xpn rpg.sys
scoreboard players operation #xpe rpg.sys *= #c1000 rpg.sys
scoreboard players operation #xpe rpg.sys /= #xpn rpg.sys
scoreboard players operation @s rpg.d_xp = #xpe rpg.sys
scoreboard players operation @s rpg.d_xp /= #c10 rpg.sys
scoreboard players operation @s rpg.d_xp2 = #xpe rpg.sys
scoreboard players operation @s rpg.d_xp2 %= #c10 rpg.sys

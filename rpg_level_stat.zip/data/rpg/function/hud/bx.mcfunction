# 액션바 끝에 PVP · 경험치 x2 남은 시간 (v51 · 내부용 · as 플레이어)
data modify storage rpg:main hud.bp set value ""
data modify storage rpg:main hud.bx set value ""
execute if score #war_run rpg.sys matches 1 run data modify storage rpg:main hud.bp set value "   [PVP 전쟁]"
execute unless score #war_run rpg.sys matches 1 if score @s rpg.pvpt matches 1.. run function rpg:hud/bx_p
execute if score @s rpg.x2t matches 1.. run function rpg:hud/bx_x
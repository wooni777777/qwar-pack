# ===== 체력 / 경험치 게이지바 (액션바) =====
# 현재 체력 / 최대 체력
scoreboard players set #cur rpg.sys 0
scoreboard players set #max rpg.sys 20
scoreboard players operation #cur rpg.sys = @s rpg.hpnow
scoreboard players operation #max rpg.sys = @s rpg.tmax
execute if score #max rpg.sys matches ..0 run scoreboard players set #max rpg.sys 20
execute if score #cur rpg.sys > #max rpg.sys run scoreboard players operation #cur rpg.sys = #max rpg.sys
execute if score #cur rpg.sys matches ..0 run scoreboard players set #cur rpg.sys 0
scoreboard players operation @s rpg.d_cur = #cur rpg.sys
scoreboard players operation @s rpg.d_max = #max rpg.sys

# 경험치
scoreboard players set #ex rpg.sys 0
scoreboard players operation #ex rpg.sys = @s rpg.exp
execute if score #ex rpg.sys > @s rpg.need run scoreboard players operation #ex rpg.sys = @s rpg.need
execute if score #ex rpg.sys matches ..0 run scoreboard players set #ex rpg.sys 0

# 0~20 단계
scoreboard players operation #hi rpg.sys = #cur rpg.sys
scoreboard players operation #hi rpg.sys *= #c20 rpg.sys
scoreboard players operation #hi rpg.sys /= #max rpg.sys
execute if score #hi rpg.sys matches 21.. run scoreboard players set #hi rpg.sys 20
execute if score #hi rpg.sys matches ..0 run scoreboard players set #hi rpg.sys 0
scoreboard players set #xi rpg.sys 0
scoreboard players operation #xi rpg.sys = #ex rpg.sys
scoreboard players operation #xi rpg.sys *= #c20 rpg.sys
scoreboard players operation #xi rpg.sys /= @s rpg.need
execute if score #xi rpg.sys matches 21.. run scoreboard players set #xi rpg.sys 20
execute if score #xi rpg.sys matches ..0 run scoreboard players set #xi rpg.sys 0

# 단계에 맞는 게이지 글자 선택 (매크로 없이)
execute if score #hi rpg.sys matches 0 run data modify storage rpg:main hud.hc set from storage rpg:main hpb[0]
execute if score #hi rpg.sys matches 1 run data modify storage rpg:main hud.hc set from storage rpg:main hpb[1]
execute if score #hi rpg.sys matches 2 run data modify storage rpg:main hud.hc set from storage rpg:main hpb[2]
execute if score #hi rpg.sys matches 3 run data modify storage rpg:main hud.hc set from storage rpg:main hpb[3]
execute if score #hi rpg.sys matches 4 run data modify storage rpg:main hud.hc set from storage rpg:main hpb[4]
execute if score #hi rpg.sys matches 5 run data modify storage rpg:main hud.hc set from storage rpg:main hpb[5]
execute if score #hi rpg.sys matches 6 run data modify storage rpg:main hud.hc set from storage rpg:main hpb[6]
execute if score #hi rpg.sys matches 7 run data modify storage rpg:main hud.hc set from storage rpg:main hpb[7]
execute if score #hi rpg.sys matches 8 run data modify storage rpg:main hud.hc set from storage rpg:main hpb[8]
execute if score #hi rpg.sys matches 9 run data modify storage rpg:main hud.hc set from storage rpg:main hpb[9]
execute if score #hi rpg.sys matches 10 run data modify storage rpg:main hud.hc set from storage rpg:main hpb[10]
execute if score #hi rpg.sys matches 11 run data modify storage rpg:main hud.hc set from storage rpg:main hpb[11]
execute if score #hi rpg.sys matches 12 run data modify storage rpg:main hud.hc set from storage rpg:main hpb[12]
execute if score #hi rpg.sys matches 13 run data modify storage rpg:main hud.hc set from storage rpg:main hpb[13]
execute if score #hi rpg.sys matches 14 run data modify storage rpg:main hud.hc set from storage rpg:main hpb[14]
execute if score #hi rpg.sys matches 15 run data modify storage rpg:main hud.hc set from storage rpg:main hpb[15]
execute if score #hi rpg.sys matches 16 run data modify storage rpg:main hud.hc set from storage rpg:main hpb[16]
execute if score #hi rpg.sys matches 17 run data modify storage rpg:main hud.hc set from storage rpg:main hpb[17]
execute if score #hi rpg.sys matches 18 run data modify storage rpg:main hud.hc set from storage rpg:main hpb[18]
execute if score #hi rpg.sys matches 19 run data modify storage rpg:main hud.hc set from storage rpg:main hpb[19]
execute if score #hi rpg.sys matches 20 run data modify storage rpg:main hud.hc set from storage rpg:main hpb[20]
execute if score #xi rpg.sys matches 0 run data modify storage rpg:main hud.xc set from storage rpg:main xpb[0]
execute if score #xi rpg.sys matches 1 run data modify storage rpg:main hud.xc set from storage rpg:main xpb[1]
execute if score #xi rpg.sys matches 2 run data modify storage rpg:main hud.xc set from storage rpg:main xpb[2]
execute if score #xi rpg.sys matches 3 run data modify storage rpg:main hud.xc set from storage rpg:main xpb[3]
execute if score #xi rpg.sys matches 4 run data modify storage rpg:main hud.xc set from storage rpg:main xpb[4]
execute if score #xi rpg.sys matches 5 run data modify storage rpg:main hud.xc set from storage rpg:main xpb[5]
execute if score #xi rpg.sys matches 6 run data modify storage rpg:main hud.xc set from storage rpg:main xpb[6]
execute if score #xi rpg.sys matches 7 run data modify storage rpg:main hud.xc set from storage rpg:main xpb[7]
execute if score #xi rpg.sys matches 8 run data modify storage rpg:main hud.xc set from storage rpg:main xpb[8]
execute if score #xi rpg.sys matches 9 run data modify storage rpg:main hud.xc set from storage rpg:main xpb[9]
execute if score #xi rpg.sys matches 10 run data modify storage rpg:main hud.xc set from storage rpg:main xpb[10]
execute if score #xi rpg.sys matches 11 run data modify storage rpg:main hud.xc set from storage rpg:main xpb[11]
execute if score #xi rpg.sys matches 12 run data modify storage rpg:main hud.xc set from storage rpg:main xpb[12]
execute if score #xi rpg.sys matches 13 run data modify storage rpg:main hud.xc set from storage rpg:main xpb[13]
execute if score #xi rpg.sys matches 14 run data modify storage rpg:main hud.xc set from storage rpg:main xpb[14]
execute if score #xi rpg.sys matches 15 run data modify storage rpg:main hud.xc set from storage rpg:main xpb[15]
execute if score #xi rpg.sys matches 16 run data modify storage rpg:main hud.xc set from storage rpg:main xpb[16]
execute if score #xi rpg.sys matches 17 run data modify storage rpg:main hud.xc set from storage rpg:main xpb[17]
execute if score #xi rpg.sys matches 18 run data modify storage rpg:main hud.xc set from storage rpg:main xpb[18]
execute if score #xi rpg.sys matches 19 run data modify storage rpg:main hud.xc set from storage rpg:main xpb[19]
execute if score #xi rpg.sys matches 20 run data modify storage rpg:main hud.xc set from storage rpg:main xpb[20]

title @s actionbar ["",{"nbt":"hud.hc","storage":"rpg:main","font":"rpg:hud","color":"white","shadow_color":0},{"text":"  ","font":"minecraft:default"},{"score":{"name":"@s","objective":"rpg.d_cur"},"color":"white","bold":true,"font":"minecraft:default"},{"text":" / ","color":"dark_gray","font":"minecraft:default"},{"score":{"name":"@s","objective":"rpg.d_max"},"color":"gray","font":"minecraft:default"},{"text":"    ","font":"minecraft:default"},{"nbt":"hud.xc","storage":"rpg:main","font":"rpg:hud","color":"white","shadow_color":0},{"text":"  ","font":"minecraft:default"},{"score":{"name":"@s","objective":"rpg.exp"},"color":"green","font":"minecraft:default"},{"text":" / ","color":"dark_gray","font":"minecraft:default"},{"score":{"name":"@s","objective":"rpg.need"},"color":"dark_green","font":"minecraft:default"},{"text":"   Lv.","color":"gold","font":"minecraft:default"},{"score":{"name":"@s","objective":"rpg.lv"},"color":"yellow","bold":true,"font":"minecraft:default"}]

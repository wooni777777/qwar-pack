# (v51 · 내부용)
scoreboard players operation #bm rpg.sys = @s rpg.pvpt
scoreboard players operation #bm rpg.sys /= #c60 rpg.sys
scoreboard players operation #bs rpg.sys = @s rpg.pvpt
scoreboard players operation #bs rpg.sys %= #c60 rpg.sys
scoreboard players operation #bs1 rpg.sys = #bs rpg.sys
scoreboard players operation #bs1 rpg.sys /= #c10 rpg.sys
scoreboard players operation #bs2 rpg.sys = #bs rpg.sys
scoreboard players operation #bs2 rpg.sys %= #c10 rpg.sys
execute store result storage rpg:tmp bx.m int 1 run scoreboard players get #bm rpg.sys
execute store result storage rpg:tmp bx.a int 1 run scoreboard players get #bs1 rpg.sys
execute store result storage rpg:tmp bx.b int 1 run scoreboard players get #bs2 rpg.sys
function rpg:hud/bx_p2 with storage rpg:tmp bx
execute as @a[gamemode=!creative,gamemode=!spectator,scores={rpg.init=1}] run function rpg:hud/tick

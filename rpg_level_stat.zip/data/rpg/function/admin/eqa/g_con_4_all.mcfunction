# [장비] 체력 4등급 세트 전부 (v49 · 관리자)
function rpg:admin/eqa/g_con_4_w
function rpg:admin/eqa/g_con_4_h
function rpg:admin/eqa/g_con_4_c
function rpg:admin/eqa/g_con_4_l
function rpg:admin/eqa/g_con_4_b

# [장비] %s %d월 %s 세트 전부 (v61 · 관리자)
function rpg:admin/eqa/g_str_3_w
function rpg:admin/eqa/g_str_3_h
function rpg:admin/eqa/g_str_3_c
function rpg:admin/eqa/g_str_3_l
function rpg:admin/eqa/g_str_3_b

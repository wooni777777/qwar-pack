# [장비] 민첩 1등급 세트 전부 (v49 · 관리자)
function rpg:admin/eqa/g_dex_1_w
function rpg:admin/eqa/g_dex_1_h
function rpg:admin/eqa/g_dex_1_c
function rpg:admin/eqa/g_dex_1_l
function rpg:admin/eqa/g_dex_1_b

# [장비] 민첩 6등급 세트 전부 (v49 · 관리자)
function rpg:admin/eqa/g_dex_6_w
function rpg:admin/eqa/g_dex_6_h
function rpg:admin/eqa/g_dex_6_c
function rpg:admin/eqa/g_dex_6_l
function rpg:admin/eqa/g_dex_6_b

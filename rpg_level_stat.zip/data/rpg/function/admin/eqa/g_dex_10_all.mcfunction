# [장비] %s %d월 %s 세트 전부 (v61 · 관리자)
function rpg:admin/eqa/g_dex_10_w
function rpg:admin/eqa/g_dex_10_h
function rpg:admin/eqa/g_dex_10_c
function rpg:admin/eqa/g_dex_10_l
function rpg:admin/eqa/g_dex_10_b

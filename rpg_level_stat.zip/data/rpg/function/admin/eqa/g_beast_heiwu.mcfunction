# [장비] 현무의 창 꺼내기 (v49 · 관리자)
function rpg:beast/give_heiwu
tellraw @s ["",{"text":"[장비] ","color":"gold"},{"text": "현무의 창", "color": "dark_green", "bold": true},{"text":" 을(를) 꺼냈습니다.","color":"white"}]

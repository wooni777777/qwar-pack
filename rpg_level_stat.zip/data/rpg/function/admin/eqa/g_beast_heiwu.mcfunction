# [장비] 현무의 창 꺼내기 (v49 · 관리자)
function rpg:beast/give_heiwu
execute if score #dlgon rpg.sys matches 1 run data modify storage rpg:dlg d.body append value {type:"minecraft:plain_message",width:400,contents:{text:"",extra:[{text:"[장비] ",color:"gold"},{text:"현무의 창",color:"dark_green",bold:true},{text:" 을(를) 꺼냈습니다.",color:"white"}]}}
execute unless score #dlgq rpg.sys matches 1 run tellraw @s ["",{"text":"[장비] ","color":"gold"},{"text": "현무의 창", "color": "dark_green", "bold": true},{"text":" 을(를) 꺼냈습니다.","color":"white"}]

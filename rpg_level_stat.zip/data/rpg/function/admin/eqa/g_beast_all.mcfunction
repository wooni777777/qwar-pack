# [장비] 사신수 무기 4종 (v49 · 관리자)
function rpg:admin/eqa/g_beast_azure
function rpg:admin/eqa/g_beast_tiger
function rpg:admin/eqa/g_beast_vermilion
function rpg:admin/eqa/g_beast_heiwu

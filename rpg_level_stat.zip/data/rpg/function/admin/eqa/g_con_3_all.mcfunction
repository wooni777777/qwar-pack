# [장비] 체력 3등급 세트 전부 (v49 · 관리자)
function rpg:admin/eqa/g_con_3_w
function rpg:admin/eqa/g_con_3_h
function rpg:admin/eqa/g_con_3_c
function rpg:admin/eqa/g_con_3_l
function rpg:admin/eqa/g_con_3_b

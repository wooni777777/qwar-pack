# [장비] 카와의 명작 4부위 (v49 · 관리자)
function rpg:kawa/give_all

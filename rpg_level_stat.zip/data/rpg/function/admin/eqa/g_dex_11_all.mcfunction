# [장비] %s %d월 %s 세트 전부 (v61 · 관리자)
function rpg:admin/eqa/g_dex_11_w
function rpg:admin/eqa/g_dex_11_h
function rpg:admin/eqa/g_dex_11_c
function rpg:admin/eqa/g_dex_11_l
function rpg:admin/eqa/g_dex_11_b

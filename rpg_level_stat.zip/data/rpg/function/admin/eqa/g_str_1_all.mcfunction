# [장비] 힘 1등급 세트 전부 (v49 · 관리자)
function rpg:admin/eqa/g_str_1_w
function rpg:admin/eqa/g_str_1_h
function rpg:admin/eqa/g_str_1_c
function rpg:admin/eqa/g_str_1_l
function rpg:admin/eqa/g_str_1_b

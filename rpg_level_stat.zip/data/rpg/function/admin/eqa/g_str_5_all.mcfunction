# [장비] 힘 5등급 세트 전부 (v49 · 관리자)
function rpg:admin/eqa/g_str_5_w
function rpg:admin/eqa/g_str_5_h
function rpg:admin/eqa/g_str_5_c
function rpg:admin/eqa/g_str_5_l
function rpg:admin/eqa/g_str_5_b

# [장비] 백호의 도끼 꺼내기 (v49 · 관리자)
function rpg:beast/give_tiger
tellraw @s ["",{"text":"[장비] ","color":"gold"},{"text": "백호의 도끼", "color": "white", "bold": true},{"text":" 을(를) 꺼냈습니다.","color":"white"}]

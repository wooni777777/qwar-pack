# [장비] 카와의 명작 [바르만] 꺼내기 (v49 · 관리자 · 부위당 세상에 1개라 이미 있으면 안 나옴)
function rpg:kawa/give_l

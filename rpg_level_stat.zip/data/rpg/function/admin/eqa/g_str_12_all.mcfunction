# [장비] %s %d월 %s 세트 전부 (v61 · 관리자)
function rpg:admin/eqa/g_str_12_w
function rpg:admin/eqa/g_str_12_h
function rpg:admin/eqa/g_str_12_c
function rpg:admin/eqa/g_str_12_l
function rpg:admin/eqa/g_str_12_b

# [장비] 힘 2등급 세트 전부 (v49 · 관리자)
function rpg:admin/eqa/g_str_2_w
function rpg:admin/eqa/g_str_2_h
function rpg:admin/eqa/g_str_2_c
function rpg:admin/eqa/g_str_2_l
function rpg:admin/eqa/g_str_2_b

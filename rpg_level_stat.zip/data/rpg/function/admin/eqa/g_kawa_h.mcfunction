# [장비] 카와의 명작 [디라프시] 꺼내기 (v49 · 관리자 · v57 : 여러 개 꺼낼 수 있음)
function rpg:kawa/give_h

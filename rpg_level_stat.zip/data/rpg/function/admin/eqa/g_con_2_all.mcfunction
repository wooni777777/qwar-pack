# [장비] %s %d월 %s 세트 전부 (v61 · 관리자)
function rpg:admin/eqa/g_con_2_w
function rpg:admin/eqa/g_con_2_h
function rpg:admin/eqa/g_con_2_c
function rpg:admin/eqa/g_con_2_l
function rpg:admin/eqa/g_con_2_b

# [장비] 체력 2등급 세트 전부 (v49 · 관리자)
function rpg:admin/eqa/g_con_2_w
function rpg:admin/eqa/g_con_2_h
function rpg:admin/eqa/g_con_2_c
function rpg:admin/eqa/g_con_2_l
function rpg:admin/eqa/g_con_2_b

# [장비] %s %d월 %s 세트 전부 (v61 · 관리자)
function rpg:admin/eqa/g_dex_5_w
function rpg:admin/eqa/g_dex_5_h
function rpg:admin/eqa/g_dex_5_c
function rpg:admin/eqa/g_dex_5_l
function rpg:admin/eqa/g_dex_5_b

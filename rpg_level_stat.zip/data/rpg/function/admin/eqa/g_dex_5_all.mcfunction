# [장비] 민첩 5등급 세트 전부 (v49 · 관리자)
function rpg:admin/eqa/g_dex_5_w
function rpg:admin/eqa/g_dex_5_h
function rpg:admin/eqa/g_dex_5_c
function rpg:admin/eqa/g_dex_5_l
function rpg:admin/eqa/g_dex_5_b

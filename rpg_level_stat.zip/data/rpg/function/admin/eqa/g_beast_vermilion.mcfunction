# [장비] 주작의 단검 꺼내기 (v49 · 관리자)
function rpg:beast/give_vermilion
tellraw @s ["",{"text":"[장비] ","color":"gold"},{"text": "주작의 단검", "color": "red", "bold": true},{"text":" 을(를) 꺼냈습니다.","color":"white"}]

# [장비] 체력 5등급 세트 전부 (v49 · 관리자)
function rpg:admin/eqa/g_con_5_w
function rpg:admin/eqa/g_con_5_h
function rpg:admin/eqa/g_con_5_c
function rpg:admin/eqa/g_con_5_l
function rpg:admin/eqa/g_con_5_b

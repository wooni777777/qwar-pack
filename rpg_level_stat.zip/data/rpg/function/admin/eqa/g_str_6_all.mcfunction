# [장비] %s %d월 %s 세트 전부 (v61 · 관리자)
function rpg:admin/eqa/g_str_6_w
function rpg:admin/eqa/g_str_6_h
function rpg:admin/eqa/g_str_6_c
function rpg:admin/eqa/g_str_6_l
function rpg:admin/eqa/g_str_6_b

# [장비] 민첩 2등급 세트 전부 (v49 · 관리자)
function rpg:admin/eqa/g_dex_2_w
function rpg:admin/eqa/g_dex_2_h
function rpg:admin/eqa/g_dex_2_c
function rpg:admin/eqa/g_dex_2_l
function rpg:admin/eqa/g_dex_2_b

# [장비] 관리자 메뉴 첫 페이지 (v49 · v51 : [아이템] 안으로) — 책 메뉴 [ 아이템 ] > [ 장비 ] (op 만)
scoreboard players enable @s rpg.eqa
playsound minecraft:item.book.page_turn player @s ~ ~ ~ 1 1.2
tellraw @s " "
tellraw @s {"text": "━━━━━━━  장비 (관리자)  ━━━━━━━", "color": "dark_gray"}
tellraw @s {"text": "   무기와 갑옷을 조건 · 크리스탈 없이 꺼냅니다.", "color": "gray"}
tellraw @s " "
tellraw @s ["", {"text": "   "}, {"text": "[ 힘 ]", "color": "red", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.eqa set 101"}, "hover_event": {"action": "show_text", "value": {"text": "힘 무기 · 갑옷 (1월 ~ 6월)", "color": "gray"}}}, {"text": "   "}, {"text": "[ 민첩 ]", "color": "aqua", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.eqa set 201"}, "hover_event": {"action": "show_text", "value": {"text": "민첩 무기 · 갑옷 (1월 ~ 6월)", "color": "gray"}}}, {"text": "   "}, {"text": "[ 체력 ]", "color": "dark_green", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.eqa set 301"}, "hover_event": {"action": "show_text", "value": {"text": "체력 무기 · 갑옷 (1월 ~ 6월)", "color": "gray"}}}, {"text": "   "}, {"text": "[ 히든 ]", "color": "light_purple", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.eqa set 400"}, "hover_event": {"action": "show_text", "value": {"text": "사신수 무기 · 카와의 명작", "color": "gray"}}}]
tellraw @s " "
tellraw @s ["", {"text": "   "}, {"text": "[ 뒤로 ]", "color": "gray", "click_event": {"action": "run_command", "command": "trigger rpg.ita set 1"}}]
tellraw @s {"text": "━━━━━━━━━━━━━━━━━━━━━━━━━━", "color": "dark_gray"}

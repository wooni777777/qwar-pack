# [장비] 체력 6등급 세트 전부 (v49 · 관리자)
function rpg:admin/eqa/g_con_6_w
function rpg:admin/eqa/g_con_6_h
function rpg:admin/eqa/g_con_6_c
function rpg:admin/eqa/g_con_6_l
function rpg:admin/eqa/g_con_6_b

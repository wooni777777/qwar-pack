# [장비] %s %d월 %s 세트 전부 (v61 · 관리자)
function rpg:admin/eqa/g_dex_9_w
function rpg:admin/eqa/g_dex_9_h
function rpg:admin/eqa/g_dex_9_c
function rpg:admin/eqa/g_dex_9_l
function rpg:admin/eqa/g_dex_9_b

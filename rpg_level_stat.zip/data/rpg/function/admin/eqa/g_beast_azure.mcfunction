# [장비] 청룡의 검 꺼내기 (v49 · 관리자)
function rpg:beast/give_azure
tellraw @s ["",{"text":"[장비] ","color":"gold"},{"text": "청룡의 검", "color": "aqua", "bold": true},{"text":" 을(를) 꺼냈습니다.","color":"white"}]

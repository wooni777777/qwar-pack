# [장비] 체력 1등급 세트 전부 (v49 · 관리자)
function rpg:admin/eqa/g_con_1_w
function rpg:admin/eqa/g_con_1_h
function rpg:admin/eqa/g_con_1_c
function rpg:admin/eqa/g_con_1_l
function rpg:admin/eqa/g_con_1_b

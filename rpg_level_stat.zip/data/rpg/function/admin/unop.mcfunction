tag @s remove op
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"제작자 권한(op 태그)을 해제했습니다.","color":"gray"}]

# 운영자용: /function rpg:admin/give_book
execute as @s run function rpg:menu/give_book

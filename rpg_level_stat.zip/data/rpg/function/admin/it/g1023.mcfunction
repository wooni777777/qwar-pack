# 수표 1,000만원 64개 (v51 · 관리자)
function rpg:admin/it/leaf {f:"dsp_bill8",n:64}
tellraw @s ["", {"text": "[아이템] ", "color": "gold", "bold": true}, {"text": "수표 1,000만원", "color": "gold", "bold": true}, {"text": " 64개를 꺼냈습니다.", "color": "white"}]
execute at @s run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 0.6 1.4
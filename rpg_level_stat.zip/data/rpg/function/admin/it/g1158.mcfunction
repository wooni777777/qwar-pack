# 경험치 x2 (10분) (v51 · 관리자)
function rpg:exp/x2_give
tellraw @s ["", {"text": "[아이템] ", "color": "gold", "bold": true}, {"text": "경험치 x2 (10분)", "color": "green", "bold": true}, {"text": " 을(를) 꺼냈습니다.", "color": "white"}]
execute at @s run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 0.6 1.4
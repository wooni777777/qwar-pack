# 수표 100원 1개 (v51 · 관리자)
function rpg:admin/it/leaf {f:"dsp_bill3",n:1}
tellraw @s ["", {"text": "[아이템] ", "color": "gold", "bold": true}, {"text": "수표 100원", "color": "gold", "bold": true}, {"text": " 1개를 꺼냈습니다.", "color": "white"}]
execute at @s run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 0.6 1.4
# 슬라임 킹의 핵 64개 (v51 · 관리자)
function rpg:mob/core_give_slime_k {n:64}
tellraw @s ["", {"text": "[아이템] ", "color": "gold", "bold": true}, {"text": "슬라임 킹의 핵", "color": "gold", "bold": true}, {"text": " 64개를 꺼냈습니다.", "color": "white"}]
execute at @s run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 0.6 1.4
# 10분 PVP 활성화 (v51 · 관리자)
function rpg:war/pvp_give
tellraw @s ["", {"text": "[아이템] ", "color": "gold", "bold": true}, {"text": "10분 PVP 활성화", "color": "red", "bold": true}, {"text": " 을(를) 꺼냈습니다.", "color": "white"}]
execute at @s run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 0.6 1.4
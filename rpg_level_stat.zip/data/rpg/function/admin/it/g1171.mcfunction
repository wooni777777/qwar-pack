# [악마의 힘] (v58 · 관리자)
function rpg:skill/give_demon
tellraw @s ["", {"text": "[아이템] ", "color": "gold", "bold": true}, {"text": "[악마의 힘]", "color": "dark_red", "bold": true}, {"text": " 을(를) 꺼냈습니다.", "color": "white"}]
execute at @s run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 0.6 1.4

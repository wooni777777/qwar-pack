# [아이템] 관리자 메뉴 (v51 · as 플레이어 · 트리거 rpg.ita) — op 만
execute unless entity @s[tag=op] run function rpg:menu/noperm
execute unless entity @s[tag=op] run return run function rpg:admin/it/reset
execute if score @s rpg.ita matches 1 run function rpg:admin/it/open
execute if score @s rpg.ita matches 2 run function rpg:admin/it/p2
execute if score @s rpg.ita matches 3 run function rpg:admin/it/p3
execute if score @s rpg.ita matches 4 run function rpg:admin/it/p4
execute if score @s rpg.ita matches 5 run function rpg:admin/it/p5
execute if score @s rpg.ita matches 6 run function rpg:admin/it/p6
execute if score @s rpg.ita matches 7 run function rpg:admin/it/p7
execute if score @s rpg.ita matches 1000 run function rpg:admin/it/g1000
execute if score @s rpg.ita matches 1001 run function rpg:admin/it/g1001
execute if score @s rpg.ita matches 1002 run function rpg:admin/it/g1002
execute if score @s rpg.ita matches 1003 run function rpg:admin/it/g1003
execute if score @s rpg.ita matches 1004 run function rpg:admin/it/g1004
execute if score @s rpg.ita matches 1005 run function rpg:admin/it/g1005
execute if score @s rpg.ita matches 1006 run function rpg:admin/it/g1006
execute if score @s rpg.ita matches 1007 run function rpg:admin/it/g1007
execute if score @s rpg.ita matches 1008 run function rpg:admin/it/g1008
execute if score @s rpg.ita matches 1009 run function rpg:admin/it/g1009
execute if score @s rpg.ita matches 1010 run function rpg:admin/it/g1010
execute if score @s rpg.ita matches 1011 run function rpg:admin/it/g1011
execute if score @s rpg.ita matches 1012 run function rpg:admin/it/g1012
execute if score @s rpg.ita matches 1013 run function rpg:admin/it/g1013
execute if score @s rpg.ita matches 1014 run function rpg:admin/it/g1014
execute if score @s rpg.ita matches 1015 run function rpg:admin/it/g1015
execute if score @s rpg.ita matches 1016 run function rpg:admin/it/g1016
execute if score @s rpg.ita matches 1017 run function rpg:admin/it/g1017
execute if score @s rpg.ita matches 1018 run function rpg:admin/it/g1018
execute if score @s rpg.ita matches 1019 run function rpg:admin/it/g1019
execute if score @s rpg.ita matches 1020 run function rpg:admin/it/g1020
execute if score @s rpg.ita matches 1021 run function rpg:admin/it/g1021
execute if score @s rpg.ita matches 1022 run function rpg:admin/it/g1022
execute if score @s rpg.ita matches 1023 run function rpg:admin/it/g1023
execute if score @s rpg.ita matches 1024 run function rpg:admin/it/g1024
execute if score @s rpg.ita matches 1025 run function rpg:admin/it/g1025
execute if score @s rpg.ita matches 1026 run function rpg:admin/it/g1026
execute if score @s rpg.ita matches 1027 run function rpg:admin/it/g1027
execute if score @s rpg.ita matches 1028 run function rpg:admin/it/g1028
execute if score @s rpg.ita matches 1029 run function rpg:admin/it/g1029
execute if score @s rpg.ita matches 1030 run function rpg:admin/it/g1030
execute if score @s rpg.ita matches 1031 run function rpg:admin/it/g1031
execute if score @s rpg.ita matches 1032 run function rpg:admin/it/g1032
execute if score @s rpg.ita matches 1033 run function rpg:admin/it/g1033
execute if score @s rpg.ita matches 1034 run function rpg:admin/it/g1034
execute if score @s rpg.ita matches 1035 run function rpg:admin/it/g1035
execute if score @s rpg.ita matches 1036 run function rpg:admin/it/g1036
execute if score @s rpg.ita matches 1037 run function rpg:admin/it/g1037
execute if score @s rpg.ita matches 1038 run function rpg:admin/it/g1038
execute if score @s rpg.ita matches 1039 run function rpg:admin/it/g1039
execute if score @s rpg.ita matches 1040 run function rpg:admin/it/g1040
execute if score @s rpg.ita matches 1041 run function rpg:admin/it/g1041
execute if score @s rpg.ita matches 1042 run function rpg:admin/it/g1042
execute if score @s rpg.ita matches 1043 run function rpg:admin/it/g1043
execute if score @s rpg.ita matches 1044 run function rpg:admin/it/g1044
execute if score @s rpg.ita matches 1045 run function rpg:admin/it/g1045
execute if score @s rpg.ita matches 1046 run function rpg:admin/it/g1046
execute if score @s rpg.ita matches 1047 run function rpg:admin/it/g1047
execute if score @s rpg.ita matches 1048 run function rpg:admin/it/g1048
execute if score @s rpg.ita matches 1049 run function rpg:admin/it/g1049
execute if score @s rpg.ita matches 1050 run function rpg:admin/it/g1050
execute if score @s rpg.ita matches 1051 run function rpg:admin/it/g1051
execute if score @s rpg.ita matches 1052 run function rpg:admin/it/g1052
execute if score @s rpg.ita matches 1053 run function rpg:admin/it/g1053
execute if score @s rpg.ita matches 1054 run function rpg:admin/it/g1054
execute if score @s rpg.ita matches 1055 run function rpg:admin/it/g1055
execute if score @s rpg.ita matches 1056 run function rpg:admin/it/g1056
execute if score @s rpg.ita matches 1057 run function rpg:admin/it/g1057
execute if score @s rpg.ita matches 1058 run function rpg:admin/it/g1058
execute if score @s rpg.ita matches 1059 run function rpg:admin/it/g1059
execute if score @s rpg.ita matches 1060 run function rpg:admin/it/g1060
execute if score @s rpg.ita matches 1061 run function rpg:admin/it/g1061
execute if score @s rpg.ita matches 1062 run function rpg:admin/it/g1062
execute if score @s rpg.ita matches 1063 run function rpg:admin/it/g1063
execute if score @s rpg.ita matches 1064 run function rpg:admin/it/g1064
execute if score @s rpg.ita matches 1065 run function rpg:admin/it/g1065
execute if score @s rpg.ita matches 1066 run function rpg:admin/it/g1066
execute if score @s rpg.ita matches 1067 run function rpg:admin/it/g1067
execute if score @s rpg.ita matches 1068 run function rpg:admin/it/g1068
execute if score @s rpg.ita matches 1069 run function rpg:admin/it/g1069
execute if score @s rpg.ita matches 1070 run function rpg:admin/it/g1070
execute if score @s rpg.ita matches 1071 run function rpg:admin/it/g1071
execute if score @s rpg.ita matches 1072 run function rpg:admin/it/g1072
execute if score @s rpg.ita matches 1073 run function rpg:admin/it/g1073
execute if score @s rpg.ita matches 1074 run function rpg:admin/it/g1074
execute if score @s rpg.ita matches 1075 run function rpg:admin/it/g1075
execute if score @s rpg.ita matches 1076 run function rpg:admin/it/g1076
execute if score @s rpg.ita matches 1077 run function rpg:admin/it/g1077
execute if score @s rpg.ita matches 1078 run function rpg:admin/it/g1078
execute if score @s rpg.ita matches 1079 run function rpg:admin/it/g1079
execute if score @s rpg.ita matches 1080 run function rpg:admin/it/g1080
execute if score @s rpg.ita matches 1081 run function rpg:admin/it/g1081
execute if score @s rpg.ita matches 1082 run function rpg:admin/it/g1082
execute if score @s rpg.ita matches 1083 run function rpg:admin/it/g1083
execute if score @s rpg.ita matches 1084 run function rpg:admin/it/g1084
execute if score @s rpg.ita matches 1085 run function rpg:admin/it/g1085
execute if score @s rpg.ita matches 1086 run function rpg:admin/it/g1086
execute if score @s rpg.ita matches 1087 run function rpg:admin/it/g1087
execute if score @s rpg.ita matches 1088 run function rpg:admin/it/g1088
execute if score @s rpg.ita matches 1089 run function rpg:admin/it/g1089
execute if score @s rpg.ita matches 1090 run function rpg:admin/it/g1090
execute if score @s rpg.ita matches 1091 run function rpg:admin/it/g1091
execute if score @s rpg.ita matches 1092 run function rpg:admin/it/g1092
execute if score @s rpg.ita matches 1093 run function rpg:admin/it/g1093
execute if score @s rpg.ita matches 1094 run function rpg:admin/it/g1094
execute if score @s rpg.ita matches 1095 run function rpg:admin/it/g1095
execute if score @s rpg.ita matches 1096 run function rpg:admin/it/g1096
execute if score @s rpg.ita matches 1097 run function rpg:admin/it/g1097
execute if score @s rpg.ita matches 1098 run function rpg:admin/it/g1098
execute if score @s rpg.ita matches 1099 run function rpg:admin/it/g1099
execute if score @s rpg.ita matches 1100 run function rpg:admin/it/g1100
execute if score @s rpg.ita matches 1101 run function rpg:admin/it/g1101
execute if score @s rpg.ita matches 1102 run function rpg:admin/it/g1102
execute if score @s rpg.ita matches 1103 run function rpg:admin/it/g1103
execute if score @s rpg.ita matches 1104 run function rpg:admin/it/g1104
execute if score @s rpg.ita matches 1105 run function rpg:admin/it/g1105
execute if score @s rpg.ita matches 1106 run function rpg:admin/it/g1106
execute if score @s rpg.ita matches 1107 run function rpg:admin/it/g1107
execute if score @s rpg.ita matches 1108 run function rpg:admin/it/g1108
execute if score @s rpg.ita matches 1109 run function rpg:admin/it/g1109
execute if score @s rpg.ita matches 1110 run function rpg:admin/it/g1110
execute if score @s rpg.ita matches 1111 run function rpg:admin/it/g1111
execute if score @s rpg.ita matches 1112 run function rpg:admin/it/g1112
execute if score @s rpg.ita matches 1113 run function rpg:admin/it/g1113
execute if score @s rpg.ita matches 1114 run function rpg:admin/it/g1114
execute if score @s rpg.ita matches 1115 run function rpg:admin/it/g1115
execute if score @s rpg.ita matches 1116 run function rpg:admin/it/g1116
execute if score @s rpg.ita matches 1117 run function rpg:admin/it/g1117
execute if score @s rpg.ita matches 1118 run function rpg:admin/it/g1118
execute if score @s rpg.ita matches 1119 run function rpg:admin/it/g1119
execute if score @s rpg.ita matches 1120 run function rpg:admin/it/g1120
execute if score @s rpg.ita matches 1121 run function rpg:admin/it/g1121
execute if score @s rpg.ita matches 1122 run function rpg:admin/it/g1122
execute if score @s rpg.ita matches 1123 run function rpg:admin/it/g1123
execute if score @s rpg.ita matches 1124 run function rpg:admin/it/g1124
execute if score @s rpg.ita matches 1125 run function rpg:admin/it/g1125
execute if score @s rpg.ita matches 1126 run function rpg:admin/it/g1126
execute if score @s rpg.ita matches 1127 run function rpg:admin/it/g1127
execute if score @s rpg.ita matches 1128 run function rpg:admin/it/g1128
execute if score @s rpg.ita matches 1129 run function rpg:admin/it/g1129
execute if score @s rpg.ita matches 1130 run function rpg:admin/it/g1130
execute if score @s rpg.ita matches 1131 run function rpg:admin/it/g1131
execute if score @s rpg.ita matches 1132 run function rpg:admin/it/g1132
execute if score @s rpg.ita matches 1133 run function rpg:admin/it/g1133
execute if score @s rpg.ita matches 1134 run function rpg:admin/it/g1134
execute if score @s rpg.ita matches 1135 run function rpg:admin/it/g1135
execute if score @s rpg.ita matches 1136 run function rpg:admin/it/g1136
execute if score @s rpg.ita matches 1137 run function rpg:admin/it/g1137
execute if score @s rpg.ita matches 1138 run function rpg:admin/it/g1138
execute if score @s rpg.ita matches 1139 run function rpg:admin/it/g1139
execute if score @s rpg.ita matches 1140 run function rpg:admin/it/g1140
execute if score @s rpg.ita matches 1141 run function rpg:admin/it/g1141
execute if score @s rpg.ita matches 1142 run function rpg:admin/it/g1142
execute if score @s rpg.ita matches 1143 run function rpg:admin/it/g1143
execute if score @s rpg.ita matches 1144 run function rpg:admin/it/g1144
execute if score @s rpg.ita matches 1145 run function rpg:admin/it/g1145
execute if score @s rpg.ita matches 1146 run function rpg:admin/it/g1146
execute if score @s rpg.ita matches 1147 run function rpg:admin/it/g1147
execute if score @s rpg.ita matches 1148 run function rpg:admin/it/g1148
execute if score @s rpg.ita matches 1149 run function rpg:admin/it/g1149
execute if score @s rpg.ita matches 1150 run function rpg:admin/it/g1150
execute if score @s rpg.ita matches 1151 run function rpg:admin/it/g1151
execute if score @s rpg.ita matches 1152 run function rpg:admin/it/g1152
execute if score @s rpg.ita matches 1153 run function rpg:admin/it/g1153
execute if score @s rpg.ita matches 1154 run function rpg:admin/it/g1154
execute if score @s rpg.ita matches 1155 run function rpg:admin/it/g1155
execute if score @s rpg.ita matches 1156 run function rpg:admin/it/g1156
execute if score @s rpg.ita matches 1969 run function rpg:admin/it/g1969
execute if score @s rpg.ita matches 1157 run function rpg:admin/it/g1157
execute if score @s rpg.ita matches 1158 run function rpg:admin/it/g1158
execute if score @s rpg.ita matches 1159 run function rpg:admin/it/g1159
execute if score @s rpg.ita matches 1160 run function rpg:admin/it/g1160
execute if score @s rpg.ita matches 1161 run function rpg:admin/it/g1161
execute if score @s rpg.ita matches 1162 run function rpg:admin/it/g1162
execute if score @s rpg.ita matches 1163 run function rpg:admin/it/g1163
execute if score @s rpg.ita matches 1164 run function rpg:admin/it/g1164
execute if score @s rpg.ita matches 1165 run function rpg:admin/it/g1165
execute if score @s rpg.ita matches 1166 run function rpg:admin/it/g1166
execute if score @s rpg.ita matches 1169 run function rpg:admin/it/g1169
execute if score @s rpg.ita matches 1170 run function rpg:admin/it/g1170
execute if score @s rpg.ita matches 1901 run function rpg:hid/give {n:1}
execute if score @s rpg.ita matches 1951 run function rpg:hid/take {n:1}
execute if score @s rpg.ita matches 1902 run function rpg:hid/give {n:2}
execute if score @s rpg.ita matches 1952 run function rpg:hid/take {n:2}
execute if score @s rpg.ita matches 1903 run function rpg:hid/give {n:3}
execute if score @s rpg.ita matches 1953 run function rpg:hid/take {n:3}
execute if score @s rpg.ita matches 1904 run function rpg:hid/give {n:4}
execute if score @s rpg.ita matches 1954 run function rpg:hid/take {n:4}
execute if score @s rpg.ita matches 1905 run function rpg:hid/give {n:5}
execute if score @s rpg.ita matches 1955 run function rpg:hid/take {n:5}
execute if score @s rpg.ita matches 1906 run function rpg:hid/give {n:6}
execute if score @s rpg.ita matches 1956 run function rpg:hid/take {n:6}
execute if score @s rpg.ita matches 1907 run function rpg:hid/give {n:7}
execute if score @s rpg.ita matches 1957 run function rpg:hid/take {n:7}
execute if score @s rpg.ita matches 1908 run function rpg:hid/give {n:8}
execute if score @s rpg.ita matches 1958 run function rpg:hid/take {n:8}
execute if score @s rpg.ita matches 1909 run function rpg:hid/give {n:9}
execute if score @s rpg.ita matches 1959 run function rpg:hid/take {n:9}
execute if score @s rpg.ita matches 1910 run function rpg:hid/give {n:10}
execute if score @s rpg.ita matches 1960 run function rpg:hid/take {n:10}
execute if score @s rpg.ita matches 1911 run function rpg:hid/give {n:11}
execute if score @s rpg.ita matches 1961 run function rpg:hid/take {n:11}
execute if score @s rpg.ita matches 1912 run function rpg:hid/give {n:12}
execute if score @s rpg.ita matches 1962 run function rpg:hid/take {n:12}
execute if score @s rpg.ita matches 1913 run function rpg:hid/give {n:13}
execute if score @s rpg.ita matches 1963 run function rpg:hid/take {n:13}
execute if score @s rpg.ita matches 1914 run function rpg:hid/give {n:14}
execute if score @s rpg.ita matches 1964 run function rpg:hid/take {n:14}
execute if score @s rpg.ita matches 1915 run function rpg:hid/give {n:15}
execute if score @s rpg.ita matches 1965 run function rpg:hid/take {n:15}
execute if score @s rpg.ita matches 1916 run function rpg:hid/give {n:16}
execute if score @s rpg.ita matches 1966 run function rpg:hid/take {n:16}
execute if score @s rpg.ita matches 1917 run function rpg:hid/give {n:17}
execute if score @s rpg.ita matches 1967 run function rpg:hid/take {n:17}
execute if score @s rpg.ita matches 1918 run function rpg:hid/give {n:18}
execute if score @s rpg.ita matches 1968 run function rpg:hid/take {n:18}
scoreboard players set @s rpg.ita 0
scoreboard players enable @s rpg.ita
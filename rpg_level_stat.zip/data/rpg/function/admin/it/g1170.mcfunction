# 훈련용 검 (v51 · 관리자)
function rpg:quest/give_train
tellraw @s ["", {"text": "[아이템] ", "color": "gold", "bold": true}, {"text": "훈련용 검", "color": "white", "bold": true}, {"text": " 을(를) 꺼냈습니다.", "color": "white"}]
execute at @s run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 0.6 1.4
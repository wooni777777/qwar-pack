# 합성서 【방어력】 +10 (v51 · 관리자)
function rpg:synth/give_d10
tellraw @s ["", {"text": "[아이템] ", "color": "gold", "bold": true}, {"text": "합성서 【방어력】 +10", "color": "red", "bold": true}, {"text": " 을(를) 꺼냈습니다.", "color": "white"}]
execute at @s run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 0.6 1.4
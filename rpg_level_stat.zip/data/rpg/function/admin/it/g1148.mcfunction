# 해적 왕 소환 나팔 (v51 · 관리자)
function rpg:mob/bsum_give2
tellraw @s ["", {"text": "[아이템] ", "color": "gold", "bold": true}, {"text": "해적 왕 소환 나팔", "color": "dark_red", "bold": true}, {"text": " 을(를) 꺼냈습니다.", "color": "white"}]
execute at @s run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 0.6 1.4
# 국가 신호기 (성 건축) (v51 · 관리자)
function rpg:war/cs_give
tellraw @s ["", {"text": "[아이템] ", "color": "gold", "bold": true}, {"text": "국가 신호기 (성 건축)", "color": "aqua", "bold": true}, {"text": " 을(를) 꺼냈습니다.", "color": "white"}]
execute at @s run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 0.6 1.4
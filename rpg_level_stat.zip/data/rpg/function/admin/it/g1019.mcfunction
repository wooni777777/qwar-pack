# 수표 100만원 10개 (v51 · 관리자)
function rpg:admin/it/leaf {f:"dsp_bill7",n:10}
tellraw @s ["", {"text": "[아이템] ", "color": "gold", "bold": true}, {"text": "수표 100만원", "color": "gold", "bold": true}, {"text": " 10개를 꺼냈습니다.", "color": "white"}]
execute at @s run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 0.6 1.4
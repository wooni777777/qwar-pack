# 스탯 초기화 종이 (v51 · 관리자)
function rpg:war/sreset_give
tellraw @s ["", {"text": "[아이템] ", "color": "gold", "bold": true}, {"text": "스탯 초기화 종이", "color": "light_purple", "bold": true}, {"text": " 을(를) 꺼냈습니다.", "color": "white"}]
execute at @s run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 0.6 1.4
# [아이템] > 무기 (v51 · 관리자 · 자동 생성)
scoreboard players enable @s rpg.ita
scoreboard players enable @s rpg.eqa
playsound minecraft:item.book.page_turn player @s ~ ~ ~ 1 1.2
tellraw @s " "
tellraw @s {"text": "━━━━━━  아이템 · 무기  ━━━━━━", "color": "dark_gray"}
tellraw @s ["", {"text": "   "}, {"text": "베르세르크의 도끼", "color": "red", "bold": true, "hover_event": {"action": "show_text", "value": {"text": "직업 무기", "color": "gray"}}}, {"text": "  "}, {"text": "[꺼내기]", "color": "green", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.ita set 1167"}, "hover_event": {"action": "show_text", "value": {"text": "베르세르크의 도끼 꺼내기", "color": "gray"}}}, {"text": " "}]
tellraw @s ["", {"text": "   "}, {"text": "혈궁의 활", "color": "dark_red", "bold": true, "hover_event": {"action": "show_text", "value": {"text": "직업 무기", "color": "gray"}}}, {"text": "  "}, {"text": "[꺼내기]", "color": "green", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.ita set 1168"}, "hover_event": {"action": "show_text", "value": {"text": "혈궁의 활 꺼내기", "color": "gray"}}}, {"text": " "}]
tellraw @s ["", {"text": "   "}, {"text": "진검", "color": "aqua", "bold": true, "hover_event": {"action": "show_text", "value": {"text": "퀘스트용 - 마을 어른에게", "color": "gray"}}}, {"text": "  "}, {"text": "[꺼내기]", "color": "green", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.ita set 1169"}, "hover_event": {"action": "show_text", "value": {"text": "진검 꺼내기", "color": "gray"}}}, {"text": " "}]
tellraw @s ["", {"text": "   "}, {"text": "훈련용 검", "color": "white", "bold": true, "hover_event": {"action": "show_text", "value": {"text": "마을 어른이 준 낡은 검", "color": "gray"}}}, {"text": "  "}, {"text": "[꺼내기]", "color": "green", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.ita set 1170"}, "hover_event": {"action": "show_text", "value": {"text": "훈련용 검 꺼내기", "color": "gray"}}}, {"text": " "}]
tellraw @s {"text": "  -- 직업 무기 (힘 · 민첩 · 체력 / 1월 ~ 6월) 은 [장비] 에서 --", "color": "dark_gray"}
tellraw @s " "
tellraw @s ["", {"text": "   "}, {"text": "[ ◀ 아이템 ]", "color": "aqua", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.ita set 1"}}, {"text": "   "}, {"text": "[ 메뉴 ]", "color": "gray", "click_event": {"action": "run_command", "command": "trigger rpg.menu set 1"}}]
tellraw @s {"text": "━━━━━━━━━━━━━━━━━━━━━━━━━━", "color": "dark_gray"}
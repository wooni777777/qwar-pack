# 균열 랜덤박스 1개 (v58 · 관리자)
function rpg:rift/box {n:1}
execute if score #dlgon rpg.sys matches 1 run data modify storage rpg:dlg d.body append value {type:"minecraft:plain_message",width:400,contents:{text:"",extra:[{text:"[아이템] ",color:"gold",bold:true},{text:"균열 랜덤박스",color:"light_purple",bold:true},{text:" 1개를 꺼냈습니다.",color:"white"}]}}
execute unless score #dlgq rpg.sys matches 1 run tellraw @s ["", {"text": "[아이템] ", "color": "gold", "bold": true}, {"text": "균열 랜덤박스", "color": "light_purple", "bold": true}, {"text": " 1개를 꺼냈습니다.", "color": "white"}]
execute at @s run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 0.6 1.4

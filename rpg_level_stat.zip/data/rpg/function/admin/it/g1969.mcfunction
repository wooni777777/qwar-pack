# 부서진 철문 (v56 · 관리자)
function rpg:war/bdoor_give
tellraw @s ["", {"text": "[아이템] ", "color": "gold", "bold": true}, {"text": "부서진 철문", "color": "gray", "bold": true}, {"text": " 을(를) 꺼냈습니다.", "color": "white"}]
execute at @s run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 0.6 1.41966

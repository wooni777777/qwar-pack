scoreboard players set @s rpg.ita 0
scoreboard players enable @s rpg.ita
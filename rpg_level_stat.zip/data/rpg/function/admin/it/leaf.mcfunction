# 보스 드롭 알맹이로 꺼내기 (v51 · 관리자 · 매크로 f n) — 수표 · 경험치 닭 (돈 · 조건 없이)
tag @a[tag=rpg_rwd] remove rpg_rwd
tag @s add rpg_rwd
scoreboard players set #bdsc rpg.sys 0
$function rpg:mob/$(f) {n:$(n)}
tag @s remove rpg_rwd
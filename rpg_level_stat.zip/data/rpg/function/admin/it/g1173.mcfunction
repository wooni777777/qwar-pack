# 균열 랜덤박스 10개 (v58 · 관리자)
function rpg:rift/box {n:10}
tellraw @s ["", {"text": "[아이템] ", "color": "gold", "bold": true}, {"text": "균열 랜덤박스", "color": "light_purple", "bold": true}, {"text": " 10개를 꺼냈습니다.", "color": "white"}]
execute at @s run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 0.6 1.4

# [아이템] > 갑옷 (v51 · 관리자 · 자동 생성)
scoreboard players enable @s rpg.ita
scoreboard players enable @s rpg.eqa
playsound minecraft:item.book.page_turn player @s ~ ~ ~ 1 1.2
tellraw @s " "
tellraw @s {"text": "━━━━━━  아이템 · 갑옷  ━━━━━━", "color": "dark_gray"}
tellraw @s ["", {"text": "   "}, {"text": "구명조끼", "color": "gold", "bold": true, "hover_event": {"action": "show_text", "value": {"text": "흉갑 · 최대 체력 +500 만 (다른 능력 없음) · 3D 모델", "color": "gray"}}}, {"text": "  "}, {"text": "[꺼내기]", "color": "green", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.ita set 1166"}, "hover_event": {"action": "show_text", "value": {"text": "구명조끼 꺼내기", "color": "gray"}}}, {"text": " "}]
tellraw @s {"text": "  -- 직업 갑옷 (힘 · 민첩 · 체력 / 1월 ~ 6월) 은 [장비] 에서 --", "color": "dark_gray"}
tellraw @s " "
tellraw @s ["", {"text": "   "}, {"text": "[ ◀ 아이템 ]", "color": "aqua", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.ita set 1"}}, {"text": "   "}, {"text": "[ 메뉴 ]", "color": "gray", "click_event": {"action": "run_command", "command": "trigger rpg.menu set 1"}}]
tellraw @s {"text": "━━━━━━━━━━━━━━━━━━━━━━━━━━", "color": "dark_gray"}
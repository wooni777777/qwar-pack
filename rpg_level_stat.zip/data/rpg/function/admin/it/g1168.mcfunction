# 혈궁의 활 (v51 · 관리자)
function rpg:weapon/give_vr
tellraw @s ["", {"text": "[아이템] ", "color": "gold", "bold": true}, {"text": "혈궁의 활", "color": "dark_red", "bold": true}, {"text": " 을(를) 꺼냈습니다.", "color": "white"}]
execute at @s run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 0.6 1.4
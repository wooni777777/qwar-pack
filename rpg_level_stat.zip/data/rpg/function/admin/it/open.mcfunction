# [아이템] 관리자 메뉴 첫 페이지 (v51) — 책 메뉴 [ 아이템 ] (op 만)
scoreboard players enable @s rpg.ita
scoreboard players enable @s rpg.eqa
playsound minecraft:item.book.page_turn player @s ~ ~ ~ 1 1.2
tellraw @s " "
tellraw @s {"text": "━━━━━━━━  아이템 (관리자)  ━━━━━━━━", "color": "dark_gray"}
tellraw @s {"text": "   모든 아이템을 조건 · 돈 · 재료 없이 꺼냅니다.", "color": "gray"}
tellraw @s " "
tellraw @s ["", {"text": "   "}, {"text": "[ 장비 ]", "color": "gold", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.eqa set 1"}, "hover_event": {"action": "show_text", "value": {"text": "직업 무기 · 갑옷 (힘 · 민첩 · 체력 / 1월 ~ 6월) · 히든 장비", "color": "gray"}}}]
tellraw @s ["", {"text": "   "}, {"text": "[ 소모 아이템 ① ]", "color": "yellow", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.ita set 2"}, "hover_event": {"action": "show_text", "value": {"text": "돈(수표) · 크리스탈 · 네더별 · 경험치 닭 · 경험치 책 · 보스 핵", "color": "gray"}}}]
tellraw @s ["", {"text": "   "}, {"text": "[ 소모 아이템 ② ]", "color": "yellow", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.ita set 3"}, "hover_event": {"action": "show_text", "value": {"text": "포션 · 강화 · 합성 · 균열 · 보스 소환 · 전쟁(성 건축 · 철문 · 폭탄 …) · 스탯 초기화 · 경험치 x2 · PVP", "color": "gray"}}}]
tellraw @s ["", {"text": "   "}, {"text": "[ 스킬 아이템 ]", "color": "aqua", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.ita set 4"}, "hover_event": {"action": "show_text", "value": {"text": "도약 · 기절시키기 · 그림자이동 · 영웅의 힘", "color": "gray"}}}]
tellraw @s ["", {"text": "   "}, {"text": "[ 갑옷 ]", "color": "green", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.ita set 5"}, "hover_event": {"action": "show_text", "value": {"text": "구명조끼", "color": "gray"}}}]
tellraw @s ["", {"text": "   "}, {"text": "[ 무기 ]", "color": "red", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.ita set 6"}, "hover_event": {"action": "show_text", "value": {"text": "진검 · 훈련용 검", "color": "gray"}}}]
tellraw @s ["", {"text": "   "}, {"text": "[ 히든 요소 ]", "color": "dark_red", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.ita set 7"}, "hover_event": {"action": "show_text", "value": {"text": "사신수 무기 · 카와의 명작 · 히든 패시브 H1 ~ H18 해금/회수", "color": "gray"}}}]
tellraw @s " "
tellraw @s ["", {"text": "   "}, {"text": "[ 뒤로 ]", "color": "gray", "click_event": {"action": "run_command", "command": "trigger rpg.menu set 1"}}]
tellraw @s {"text": "━━━━━━━━━━━━━━━━━━━━━━━━━━", "color": "dark_gray"}
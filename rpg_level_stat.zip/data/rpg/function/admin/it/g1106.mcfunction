# 회복 포션 (중급) 10개 (v51 · 관리자)
function rpg:shop/buy3 {n:10}
tellraw @s ["", {"text": "[아이템] ", "color": "gold", "bold": true}, {"text": "회복 포션 (중급)", "color": "white", "bold": true}, {"text": " 10개를 꺼냈습니다.", "color": "white"}]
execute at @s run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 0.6 1.4
# 운영자용: 실행한 사람의 레벨/스탯을 완전히 초기화
# /execute as <플레이어> run function rpg:admin/reset
attribute @s minecraft:attack_damage modifier remove rpg:stat_a
attribute @s minecraft:attack_damage modifier remove rpg:stat_b
attribute @s minecraft:max_health modifier remove rpg:stat_a
attribute @s minecraft:max_health modifier remove rpg:stat_b
attribute @s minecraft:movement_speed modifier remove rpg:stat_a
attribute @s minecraft:movement_speed modifier remove rpg:stat_b
scoreboard players set @s rpg.init 0
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"스탯이 초기화되었습니다.","color":"white"}]
scoreboard players set @s rpg.q_tuto 0
scoreboard players set @s rpg.q_main 0
scoreboard players set @s rpg.qc 0

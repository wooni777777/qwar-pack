execute if score #cb rpg.sys matches 1.. run function rpg:admin/clear_one

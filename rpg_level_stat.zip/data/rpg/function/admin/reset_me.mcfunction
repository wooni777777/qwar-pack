# 자기 자신만 초기화
scoreboard players set @s rpg.lv 0
scoreboard players set @s rpg.exp 0
scoreboard players set @s rpg.sp 0
scoreboard players set @s rpg.str 0
scoreboard players set @s rpg.dex 0
scoreboard players set @s rpg.con 0
scoreboard players set @s money 0
scoreboard players set @s rpg.q_tuto 0
scoreboard players set @s rpg.q_main 0
scoreboard players set @s rpg.qc 0
scoreboard players set @s rpg.abid1 0
scoreboard players set @s rpg.abid2 0
scoreboard players set @s rpg.abid3 0
scoreboard players set @s rpg.abid4 0
scoreboard players set @s rpg.abidv 0
scoreboard players set @s rpg.aminv 0
scoreboard players set @s rpg.abidi 0
scoreboard players set @s rpg.bills 0
scoreboard players set @s rpg.init 0
scoreboard players set @s rpg.mig 0
scoreboard players set @s fly 0
scoreboard players set @s C+C 0
scoreboard players set @s rpg.lv 1
tag @s remove vil1
tag @s remove vil2
tag @s remove vil3
tag @s remove vil4
tag @s remove hg1
tag @s remove hg2
tag @s remove hg3
tag @s remove hg4
tag @s remove bos1
tag @s remove war1
tag @s remove auc_win1
tag @s remove auc_win2
tag @s remove auc_win3
tag @s remove auc_win4
team leave @s
scoreboard players set @s rpg.nat 0
clear @s *[minecraft:custom_data~{rpg_pouch:1}]
function rpg:stat/apply
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"초기화되었습니다.","color":"gray"}]
scoreboard players set @s rpg.abidL 0
scoreboard players set @s rpg.qcat 1
scoreboard players set @s rpg.qord 0
scoreboard players set @s rpg.qo1 0
scoreboard players set @s rpg.qo2 0

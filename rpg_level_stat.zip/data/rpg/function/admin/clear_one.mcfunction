execute store result storage rpg:main cb.i int 1 run scoreboard players get #cb rpg.sys
function rpg:admin/clear_macro with storage rpg:main cb
scoreboard players remove #cb rpg.sys 1
function rpg:admin/clear_loop

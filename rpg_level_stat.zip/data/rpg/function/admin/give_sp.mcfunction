# 특수 아이템 지급 : /function rpg:admin/give_sp
scoreboard players add @s rpg.spD 1
scoreboard players add @s rpg.spL 1
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"특수 파괴무시 · 특수 성공확률을 1개씩 지급했습니다.","color":"green"}]

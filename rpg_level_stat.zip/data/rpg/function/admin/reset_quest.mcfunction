scoreboard players set @s rpg.q_tuto 0
scoreboard players set @s rpg.q_main 0
scoreboard players set @s rpg.qc 0
scoreboard players set @s rpg.qord 0
scoreboard players set @s rpg.qo1 0
scoreboard players set @s rpg.qo2 0
scoreboard players set @s rpg.qcat 1
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"퀘스트 진행도를 초기화했습니다.","color":"white"}]

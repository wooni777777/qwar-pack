# ── 모든 플레이어 전체 초기화 ──
#   스탯 / 소지금 / 퀘스트 / 경매 / 창고 / 텔포 를 한 번에 되돌립니다
tellraw @a [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"서버 전체 초기화가 실행되었습니다.","color":"red","bold":true}]
scoreboard players set @a rpg.lv 0
scoreboard players set @a rpg.exp 0
scoreboard players set @a rpg.sp 0
scoreboard players set @a rpg.str 0
scoreboard players set @a rpg.dex 0
scoreboard players set @a rpg.con 0
scoreboard players set @a money 0
scoreboard players set @a rpg.q_tuto 0
scoreboard players set @a rpg.q_main 0
scoreboard players set @a rpg.qc 0
scoreboard players set @a rpg.abid1 0
scoreboard players set @a rpg.abid2 0
scoreboard players set @a rpg.abid3 0
scoreboard players set @a rpg.abid4 0
scoreboard players set @a rpg.abidv 0
scoreboard players set @a rpg.aminv 0
scoreboard players set @a rpg.abidi 0
scoreboard players set @a rpg.abidL 0
scoreboard players set @a rpg.def 0
scoreboard players set @a rpg.dsh 0
scoreboard players set @a rpg.spD 0
scoreboard players set @a rpg.spL 0
scoreboard players set @a rpg.spDu 0
scoreboard players set @a rpg.spLu 0
scoreboard players set @a rpg.enhM 0
scoreboard players set @a rpg.dshf 0
attribute @a minecraft:fall_damage_multiplier modifier remove rpg:dashfall
attribute @a minecraft:armor modifier remove rpg:p_armor
scoreboard players set @a rpg.asort 0
scoreboard players set @a rpg.qcat 1
scoreboard players set @a rpg.qord 0
scoreboard players set @a rpg.qo1 0
scoreboard players set @a rpg.qo2 0
scoreboard players set @a rpg.bills 0
scoreboard players set @a rpg.init 0
scoreboard players set @a rpg.mig 0
scoreboard players set @a fly 0
scoreboard players set @a C+C 0
scoreboard players set @a rpg.lv 1
tag @a remove vil1
tag @a remove vil2
tag @a remove vil3
tag @a remove vil4
tag @a remove hg1
tag @a remove hg2
tag @a remove hg3
tag @a remove hg4
tag @a remove bos1
tag @a remove war1
tag @a remove auc_win1
tag @a remove auc_win2
tag @a remove auc_win3
tag @a remove auc_win4
team leave @a
scoreboard players set @a rpg.nat 0
# 창고 비우기
data remove storage rpg:vault v
kill @e[tag=rpg_vbar]
# 경매 초기화
scoreboard players set #auc_run rpg.sys 0
scoreboard players set #auc_pause rpg.sys 0
scoreboard players set #auc_n rpg.sys 0
scoreboard players set #auc_time rpg.sys 0
execute if score #auc_bb rpg.sys matches 1 run bossbar remove rpg:auction
scoreboard players set #auc_bb rpg.sys 0
kill @e[tag=rpg_auc_h]
data remove storage rpg:auc i1
data remove storage rpg:auc i2
data remove storage rpg:auc i3
data remove storage rpg:auc i4
scoreboard players set #auc_min1 rpg.sys 0
scoreboard players set #auc_min2 rpg.sys 0
scoreboard players set #auc_min3 rpg.sys 0
scoreboard players set #auc_min4 rpg.sys 0
scoreboard players set #auc_top1 rpg.sys 0
scoreboard players set #auc_top2 rpg.sys 0
scoreboard players set #auc_top3 rpg.sys 0
scoreboard players set #auc_top4 rpg.sys 0
# 소지금 아이템 정리
clear @a *[minecraft:custom_data~{rpg_pouch:1}]
effect clear @a
execute as @a run function rpg:stat/apply
tellraw @a [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"초기화 완료. 다시 시작하세요.","color":"gray"}]
scoreboard players set #rnd_run rpg.sys 0
scoreboard players set #rnd_pause rpg.sys 0
scoreboard players set #rnd_time rpg.sys 0
execute if score #rnd_bb rpg.sys matches 1 run bossbar remove rpg:round
scoreboard players set #rnd_bb rpg.sys 0

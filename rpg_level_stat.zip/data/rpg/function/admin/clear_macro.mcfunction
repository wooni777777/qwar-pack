$bossbar remove rpg:hp$(i)
$bossbar remove rpg:xp$(i)

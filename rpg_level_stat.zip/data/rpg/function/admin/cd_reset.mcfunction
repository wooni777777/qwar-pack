# 모든 쿨타임 초기화 (v45 · op · 메뉴 [쿨타임 초기화] · trigger rpg.menu set 28)
#   패시브 쿨 (숙련된 싸움 · 구사일생 · 전사 · 복수 · 히든) · 도약 / 기절 아이템 · 폭탄 · 아이템 우클릭 · 전투태세 쌓기 + 스킬 쿨 (레드스톤)
scoreboard players set @a rpg.cd60 0
scoreboard players set @a rpg.cd900 0
scoreboard players set @a rpg.cdw 0
scoreboard players set @a rpg.revcd 0
scoreboard players set @a rpg.lcd 0
scoreboard players set @a rpg.scd 0
scoreboard players set @a rpg.cd 0
scoreboard players set @a rpg.h7cd 0
scoreboard players set @a rpg.h18cd 0
scoreboard players set @a rpg.ucd 0
scoreboard players set @a rpg.bcd 0
scoreboard players set @a rpg.sgc 0
# 스킬 쿨 초기화 (제작자가 쓰는 레드스톤 신호)
setblock 118 -58 -57 minecraft:redstone_block
tellraw @a ["", {"text": "[q후계자 전쟁] ", "color": "gray"}, {"text": "모든 쿨타임(패시브 · 스킬)이 초기화되었습니다.", "color": "aqua", "bold": true}, {"text": "  (", "color": "dark_gray"}, {"selector": "@s", "color": "dark_gray"}, {"text": ")", "color": "dark_gray"}]
execute as @a at @s run playsound minecraft:block.beacon.power_select player @s ~ ~ ~ 0.8 1.8

# 자신에게 제작자 태그(op)를 부여/해제합니다
execute unless entity @s[tag=op] run tag @s add op
execute unless entity @s[tag=op] run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"제작자 권한(op 태그)을 얻었습니다.","color":"green"}]

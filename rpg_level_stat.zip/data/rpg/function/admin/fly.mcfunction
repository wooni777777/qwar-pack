# 자신의 비행을 켜고 끕니다 (fly 스코어보드 토글)
execute unless score @s fly matches 1 run scoreboard players set @s fly 1
execute if score @s fly matches 1 if score @s rpg.grav matches 1 run scoreboard players set @s fly 0

scoreboard players operation #cb rpg.sys = #bid rpg.sys
function rpg:admin/clear_loop

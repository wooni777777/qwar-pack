# 17~31 레벨 : (5L^2 - 81L + 720) / 2
scoreboard players operation #xt rpg.sys = #xl rpg.sys
scoreboard players operation #xt rpg.sys *= #xl rpg.sys
scoreboard players operation #xt rpg.sys *= #c5 rpg.sys
scoreboard players operation #x2 rpg.sys = #xl rpg.sys
scoreboard players operation #x2 rpg.sys *= #c81 rpg.sys
scoreboard players operation #xt rpg.sys -= #x2 rpg.sys
scoreboard players operation #xt rpg.sys += #c720 rpg.sys
scoreboard players operation #xt rpg.sys /= #c2 rpg.sys

# 바닥에 떨어진 전용 아이템은 즉시 소멸 (버려서 복사하는 것 방지)
execute as @e[type=minecraft:item] if items entity @s contents *[minecraft:custom_data~{rpg_stun:1b}] run kill @s
execute as @e[type=minecraft:item] if items entity @s contents *[minecraft:custom_data~{rpg_leap:1b}] run kill @s
execute as @e[type=minecraft:item] if items entity @s contents *[minecraft:custom_data~{rpg_menu:1b}] run kill @s
execute as @e[type=minecraft:item] if items entity @s contents *[minecraft:custom_data~{rpg_totem:1b}] run kill @s

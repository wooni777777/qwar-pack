scoreboard players operation #xd rpg.sys *= #xp_rate rpg.sys
execute if score #xd rpg.sys matches 1.. run scoreboard players operation @s rpg.exp += #xd rpg.sys
execute if score #xd rpg.sys matches 1.. run function rpg:exp/check

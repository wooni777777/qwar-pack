execute unless score @s rpg.xpo matches 1.. run scoreboard players set @s rpg.xpo 0
experience set @s 0 levels
experience set @s 0 points
scoreboard players set @s rpg.xpo 0

# 32 레벨 이상 : (9L^2 - 325L + 4440) / 2
scoreboard players operation #xt rpg.sys = #xl rpg.sys
scoreboard players operation #xt rpg.sys *= #xl rpg.sys
scoreboard players operation #xt rpg.sys *= #c9 rpg.sys
scoreboard players operation #x2 rpg.sys = #xl rpg.sys
scoreboard players operation #x2 rpg.sys *= #c325 rpg.sys
scoreboard players operation #xt rpg.sys -= #x2 rpg.sys
scoreboard players operation #xt rpg.sys += #c4440 rpg.sys
scoreboard players operation #xt rpg.sys /= #c2 rpg.sys

# 0~16 레벨 : L^2 + 6L
scoreboard players operation #xt rpg.sys = #xl rpg.sys
scoreboard players operation #xt rpg.sys *= #xl rpg.sys
scoreboard players operation #x2 rpg.sys = #xl rpg.sys
scoreboard players operation #x2 rpg.sys *= #c6 rpg.sys
scoreboard players operation #xt rpg.sys += #x2 rpg.sys

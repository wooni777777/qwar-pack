function rpg:core/xp_total
scoreboard players operation #xd rpg.sys = #xt rpg.sys
scoreboard players operation #xd rpg.sys -= @s rpg.xpo
scoreboard players operation @s rpg.xpo = #xt rpg.sys
execute if score #xd rpg.sys matches 1.. run function rpg:core/xp_gain
execute if score #xp_zero rpg.sys matches 1 run function rpg:core/xp_reset

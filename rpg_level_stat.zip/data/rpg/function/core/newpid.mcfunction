scoreboard players add #pid rpg.sys 1
scoreboard players operation @s rpg.pid = #pid rpg.sys

execute unless score @s rpg.pid matches 1.. run function rpg:core/newpid
execute unless score @s rpg.php matches 0.. run scoreboard players set @s rpg.php 20
execute unless score @s rpg.cbt matches 0.. run scoreboard players set @s rpg.cbt 0
execute unless score @s rpg.hcd matches -1.. run scoreboard players set @s rpg.hcd -1
execute unless score @s rpg.busy matches 0.. run scoreboard players set @s rpg.busy 0
execute unless score @s rpg.grace matches 0.. run scoreboard players set @s rpg.grace 0
scoreboard players enable @s rpg.chk
execute unless score @s money matches -2147483648.. run scoreboard players set @s money 0
execute unless score @s rpg.combo matches 0.. run scoreboard players set @s rpg.combo 0
execute unless score @s rpg.cmb2 matches 0.. run scoreboard players set @s rpg.cmb2 0
execute unless score @s rpg.war matches 0.. run scoreboard players set @s rpg.war 0
execute unless score @s rpg.stun matches 0.. run scoreboard players set @s rpg.stun 0
execute unless score @s rpg.rage matches -1.. run scoreboard players set @s rpg.rage -1
execute unless score @s rpg.hide matches -1.. run scoreboard players set @s rpg.hide -1
execute unless score @s rpg.will matches -1.. run scoreboard players set @s rpg.will -1
execute unless score @s rpg.leap matches 0.. run scoreboard players set @s rpg.leap 0
execute unless score @s rpg.dshb matches -1.. run scoreboard players set @s rpg.dshb 1
execute if score @s rpg.dshb matches 0 run scoreboard players set @s rpg.dshb 1
execute unless score @s rpg.rev matches 0.. run scoreboard players set @s rpg.rev 0
execute unless score @s rpg.revcd matches 0.. run scoreboard players set @s rpg.revcd 0
execute unless score @s rpg.cd900 matches 0.. run scoreboard players set @s rpg.cd900 0
execute unless score @s rpg.cdw matches 0.. run scoreboard players set @s rpg.cdw 0
execute unless score @s rpg.cd60 matches 0.. run scoreboard players set @s rpg.cd60 1200
execute unless score @s rpg.tmax matches 0.. run scoreboard players set @s rpg.tmax 20
execute unless score @s rpg.hpsc matches 1.. run scoreboard players set @s rpg.hpsc 1000
execute unless score @s rpg.hpnow matches -2147483648.. run scoreboard players set @s rpg.hpnow 20
execute unless score @s rpg.absorb matches 0.. run scoreboard players set @s rpg.absorb 0
execute unless score @s rpg.lastdmg matches 0.. run scoreboard players set @s rpg.lastdmg 0
execute unless score @s rpg.q_tuto matches 0.. run scoreboard players set @s rpg.q_tuto 0
execute unless score @s rpg.q_main matches 0.. run scoreboard players set @s rpg.q_main 0
execute unless score @s rpg.qc matches 0.. run scoreboard players set @s rpg.qc 0
execute unless score @s rpg.lcd matches 0.. run scoreboard players set @s rpg.lcd 0
execute unless score @s rpg.scd matches 0.. run scoreboard players set @s rpg.scd 0
execute unless score @s rpg.uleap matches 0.. run scoreboard players set @s rpg.uleap 0
execute unless score @s rpg.ustun matches 0.. run scoreboard players set @s rpg.ustun 0
scoreboard players enable @s rpg.q
scoreboard players enable @s rpg.cry
scoreboard players enable @s rpg.eq
execute unless score @s rpg.eqs matches 1.. run scoreboard players set @s rpg.eqs 1
execute unless score @s rpg.shopt matches 1.. run scoreboard players set @s rpg.shopt 2
scoreboard players set @s rpg.mig 7

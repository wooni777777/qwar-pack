# 플레이어의 "총 획득 경험치"를 #xt 에 계산해 넣는다
execute store result score #xl rpg.sys run experience query @s levels
execute store result score #xp rpg.sys run experience query @s points
execute if score #xl rpg.sys matches ..16 run function rpg:core/xp_a
execute if score #xl rpg.sys matches 17..31 run function rpg:core/xp_b
execute if score #xl rpg.sys matches 32.. run function rpg:core/xp_c
scoreboard players operation #xt rpg.sys += #xp rpg.sys

scoreboard players set @s rpg.resp 0
scoreboard players set @s rpg.a_atk -999999
scoreboard players set @s rpg.a_hp -999999
scoreboard players set @s rpg.a_spd -999999
scoreboard players operation @s rpg.php = @s rpg.hp
scoreboard players set @s rpg.grace 60
function rpg:stat/refresh
scoreboard players operation @s rpg.hpnow = @s rpg.tmax
scoreboard players operation @s rpg.d_cur = @s rpg.hpnow
execute store result score @s rpg.php run attribute @s minecraft:max_health get 1
effect give @s minecraft:instant_health 1 10 true

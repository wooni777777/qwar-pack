scoreboard players set @s rpg.init 1
scoreboard players set @s rpg.lv 1
scoreboard players set @s rpg.exp 0
scoreboard players set @s rpg.sp 0
scoreboard players set @s rpg.str 0
scoreboard players set @s rpg.dex 0
scoreboard players set @s rpg.con 0
scoreboard players set @s rpg.kill 0
scoreboard players set @s rpg.resp 0
scoreboard players set @s rpg.slot 0
scoreboard players set @s rpg.php 20
scoreboard players set @s rpg.cbt 0
scoreboard players set @s rpg.hcd -1
scoreboard players set @s rpg.combo 0
scoreboard players set @s rpg.cmb2 0
scoreboard players set @s rpg.war 0
scoreboard players set @s rpg.busy 0
scoreboard players set @s rpg.grace 0
scoreboard players set @s rpg.tmax 20
scoreboard players set @s rpg.hpnow 20
scoreboard players set @s rpg.absorb 0
scoreboard players set @s rpg.lastdmg 0
scoreboard players set @s rpg.php 20
scoreboard players set @s rpg.hpsc 1000
scoreboard players set @s rpg.stun 0
scoreboard players set @s rpg.rage -1
scoreboard players set @s rpg.hide -1
scoreboard players set @s rpg.will -1
scoreboard players set @s rpg.leap 0
scoreboard players set @s rpg.dshb 1
scoreboard players set @s rpg.q_tuto 0
scoreboard players set @s rpg.q_main 0
scoreboard players set @s rpg.qc 0
scoreboard players set @s rpg.lcd 0
scoreboard players set @s rpg.scd 0
scoreboard players set @s rpg.shopt 2
scoreboard players set @s rpg.mig 5
scoreboard players set @s rpg.rev 0
scoreboard players set @s rpg.revcd 0
scoreboard players set @s rpg.cd900 0
scoreboard players set @s rpg.cdw 0
scoreboard players set @s rpg.cd60 1200
execute unless score @s rpg.pid matches 1.. run function rpg:core/newpid
scoreboard players set @s rpg.a_atk -999999
scoreboard players set @s rpg.a_hp -999999
scoreboard players set @s rpg.a_spd -999999
scoreboard players set @s rpg.a_cur -999999
scoreboard players set @s rpg.a_max -999999
scoreboard players set @s rpg.a_exp -999999
scoreboard players set @s rpg.a_sp -999999
scoreboard players enable @s rpg.menu
scoreboard players enable @s rpg.up
scoreboard players enable @s menu
scoreboard players enable @s rpg.tp
scoreboard players enable @s rpg.chk
scoreboard players enable @s rpg.shop
scoreboard players enable @s rpg.cry
scoreboard players enable @s rpg.eq
scoreboard players enable @s rpg.q
scoreboard players enable @s rpg.fsh
scoreboard players enable @s rpg.wcs
scoreboard players enable @s rpg.wsh
execute unless score @s money matches -2147483648.. run scoreboard players set @s money 0

# 이미 가지고 있던 바닐라 경험치는 전환하지 않는다
function rpg:core/xp_total
scoreboard players operation @s rpg.xpo = #xt rpg.sys

function rpg:menu/give_book
function rpg:stat/refresh
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"메뉴 열기 : ","color":"white"},{"text":"[메뉴]","color":"gold"},{"text":" 책 우클릭  /  채팅에 ","color":"white"},{"text":"/trigger menu","color":"green","click_event":{"action":"suggest_command","command":"/trigger menu"},"hover_event":{"action":"show_text","value":{"text":"클릭하면 채팅창에 입력됩니다","color":"gray"}}},{"text":"  /  ESC 메뉴","color":"white"}]

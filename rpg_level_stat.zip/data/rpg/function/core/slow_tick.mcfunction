scoreboard players set #timer rpg.sys 0
function rpg:nation/sync
# v40 성 : 성문 · 가짜 신호기 유지 · 예전 아이템 바꾸기
execute as @e[type=minecraft:marker,tag=rpg_cag] at @s run function rpg:war/ca_gate
execute as @e[type=minecraft:marker,tag=rpg_cab] at @s run function rpg:war/ca_keep
execute as @a if items entity @s container.* minecraft:fire_charge[minecraft:custom_data~{rpg_bomb:1}] run function rpg:war/mig_items
execute as @a if items entity @s container.* minecraft:beacon[minecraft:custom_data~{rpg_nbeacon:1}] run function rpg:war/mig_items
function rpg:npc/v39fix
# v40 낚시 : 예전 물고기 바꾸기 / 혹시 남은 미끼(대구) 치우기 / 세트 다시 계산(한 번)
execute as @a if items entity @s container.* #minecraft:fishes[minecraft:custom_data~{fishy:1}] run function rpg:fish/mig
execute as @a if items entity @s container.* *[minecraft:custom_data~{rpg_bait:1}] run clear @s *[minecraft:custom_data~{rpg_bait:1}]
execute as @a unless score @s rpg.fsv matches 40 run function rpg:fish/set_mig
execute as @a unless score @s rpg.init matches 1 run function rpg:core/join
scoreboard players enable @a rpg.menu
scoreboard players enable @a rpg.up
scoreboard players enable @a menu
scoreboard players enable @a rpg.tp
scoreboard players enable @a rpg.fsh
scoreboard players enable @a rpg.wcs
scoreboard players enable @a rpg.wsh
scoreboard players enable @a rpg.chk
scoreboard players enable @a rpg.shop
scoreboard players enable @a rpg.cry
scoreboard players enable @a rpg.eq
scoreboard players enable @a rpg.q
function rpg:core/cleanup
execute as @a[scores={rpg.init=1}] unless score @s rpg.mig matches 7 run function rpg:core/migrate
execute as @a[scores={rpg.init=1}] run function rpg:stat/refresh
# 바닐라 경험치 -> RPG 경험치
execute as @a[scores={rpg.init=1}] at @s run function rpg:core/xp_calc
# 레벨업 확인 (경험치가 쌓여 있으면 반드시 레벨업되도록 하는 안전장치)
execute as @a[scores={rpg.init=1}] at @s run function rpg:exp/check
# 패시브 주기 처리
execute as @a[scores={rpg.init=1}] at @s run function rpg:passive/slow
execute as @a[scores={rpg.init=1}] run function rpg:exp/shard_inv
execute as @a[scores={rpg.init=1}] run function rpg:money/hud
function rpg:hud/all
function rpg:sys/drop_clean

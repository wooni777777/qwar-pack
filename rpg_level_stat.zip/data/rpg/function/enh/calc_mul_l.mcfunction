# 배율 1회 적용 (재귀)
execute if score #emn rpg.sys matches ..0 run return 0
scoreboard players set #emk rpg.sys 1000
scoreboard players operation #emk rpg.sys -= #e_mul rpg.sys
scoreboard players operation #esucc rpg.sys *= #emk rpg.sys
scoreboard players operation #esucc rpg.sys /= #c1000 rpg.sys
scoreboard players remove #emn rpg.sys 1
function rpg:enh/calc_mul_l

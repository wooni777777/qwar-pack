$tellraw @s ["",{"text":"      └ ","color":"dark_gray"},{"text":"[ 재료 ]","color":"white",hover_event:{action:"show_item",id:"$(mid)",count:$(mcnt)}},{"text":"  x$(mcnt)","color":"white"}]

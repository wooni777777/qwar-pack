scoreboard players operation #enh rpg.sys = #enhnext rpg.sys
data modify storage rpg:enh it2 set from entity @s SelectedItem
execute unless score @s rpg.erod matches 1 if entity @s[tag=H11] run function rpg:hid/h11_skill
execute unless score @s rpg.erod matches 1 run function rpg:enh/apply
execute if score @s rpg.erod matches 1 run function rpg:enh/apply_rod
tellraw @s " "
execute unless score @s rpg.erod matches 1 run tellraw @s ["",{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"강화 성공! ","color":"green","bold":true},{"text":"+","color":"gold","bold":true},{"score":{"name":"#enh","objective":"rpg.sys"},"color":"gold","bold":true},{"text":"  (공격력 1.2배)","color":"gray"}]
execute if score @s rpg.erod matches 1 run tellraw @s ["",{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"낚싯대 강화 성공! ","color":"green","bold":true},{"text":"+","color":"gold","bold":true},{"score":{"name":"#enh","objective":"rpg.sys"},"color":"gold","bold":true},{"text":"  (낚시 운 +2)","color":"aqua"}]
tellraw @s " "
execute at @s run playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 0.35 1.4
execute at @s run particle minecraft:end_rod ~ ~1 ~ 0.4 0.8 0.4 0.05 60 normal @a
function rpg:enh/open

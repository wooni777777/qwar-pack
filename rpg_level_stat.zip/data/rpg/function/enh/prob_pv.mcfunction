# #pvn 단계에서의 성공확률을 #vv 에 넣는다 (미리보기용)
function rpg:enh/mode
execute if score #emode rpg.sys matches 0 run function rpg:enh/prob_pv_sub
execute if score #emode rpg.sys matches 1 run function rpg:enh/prob_pv_mul
execute if score #vv rpg.sys matches ..50 run scoreboard players set #vv rpg.sys 50
execute if score #vv rpg.sys matches 1000.. run scoreboard players set #vv rpg.sys 1000

$execute if data storage rpg:enh cfg.req.l$(n) run data modify storage rpg:enh cur set from storage rpg:enh cfg.req.l$(n)
$execute if data storage rpg:enh cfg.req.l$(n) run scoreboard players set #rfound rpg.sys 1

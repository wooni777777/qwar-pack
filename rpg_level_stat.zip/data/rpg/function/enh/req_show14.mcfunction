scoreboard players add #rlcnt rpg.sys 1
data modify storage rpg:enh r set from storage rpg:enh cfg.req.l14
data modify storage rpg:enh r.n set value 14
data modify storage rpg:enh r.del set value 84
scoreboard players set #mc rpg.sys 0
execute store result score #mc rpg.sys run data get storage rpg:enh cfg.req.l14.mats
execute store result storage rpg:enh r.cnt int 1 run scoreboard players get #mc rpg.sys
function rpg:enh/req_show with storage rpg:enh r

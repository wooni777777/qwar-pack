$execute if data storage rpg:enh cfg.req.l$(n) run scoreboard players add #rlcnt rpg.sys 1
$execute if data storage rpg:enh cfg.req.l$(n) run data modify storage rpg:enh r set from storage rpg:enh cfg.req.l$(n)
$execute if data storage rpg:enh cfg.req.l$(n) run data modify storage rpg:enh r.n set value $(n)
$execute if data storage rpg:enh cfg.req.l$(n) run function rpg:enh/req_show with storage rpg:enh r

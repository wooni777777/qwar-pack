scoreboard players enable @s rpg.enh
playsound minecraft:block.anvil.land player @s ~ ~ ~ 0.6 1.6
tellraw @s " "
execute unless score @s rpg.erod matches 1 run tellraw @s {"text": "━━━━━━━━━  강  화  ━━━━━━━━━", "color": "dark_gray"}
execute if score @s rpg.erod matches 1 run tellraw @s {"text": "━━━━━━━  낚 싯 대  강 화  ━━━━━━━", "color": "dark_gray"}
function rpg:enh/itemok
execute if score #ok rpg.sys matches 0 unless score @s rpg.erod matches 1 unless items entity @s weapon.mainhand minecraft:fishing_rod run tellraw @s ["", {"text": "   손에 강화할 무기를 들어주세요", "color": "red"}]
execute if score #ok rpg.sys matches 0 unless score @s rpg.erod matches 1 if items entity @s weapon.mainhand minecraft:fishing_rod run tellraw @s ["", {"text": "   낚싯대는 강화해 드리지 않습니다. ", "color": "red"}, {"text": "[낚싯대 강화] NPC 에게 가세요", "color": "yellow"}]
execute if score #ok rpg.sys matches 0 if score @s rpg.erod matches 1 run tellraw @s ["", {"text": "   손에 강화할 낚싯대를 들어주세요 ", "color": "red"}, {"text": "(낚싯대만 강화합니다)", "color": "dark_gray"}]
execute if score #ok rpg.sys matches 0 run tellraw @s {"text": "━━━━━━━━━━━━━━━━━━━━━━━━━━", "color": "dark_gray"}
execute if score #ok rpg.sys matches 0 run return 0
function rpg:enh/load
function rpg:enh/head with storage rpg:enh m
tellraw @s " "
function rpg:enh/moneyline with storage rpg:enh cur
function rpg:enh/mat_list
tellraw @s " "
function rpg:enh/btns with storage rpg:enh cur
execute if score @s rpg.spDu matches 1 run tellraw @s ["", {"text": "   ✔ 특수 파괴무시 예약됨 (이번 1회)", "color": "green"}]
execute if score @s rpg.spLu matches 1 run tellraw @s ["", {"text": "   ✔ 특수 성공확률 예약됨 (이번 1회)", "color": "green"}]
tellraw @s {"text": "━━━━━━━━━━━━━━━━━━━━━━━━━━", "color": "dark_gray"}

execute if score #vmn rpg.sys matches ..0 run return 0
scoreboard players set #vmk rpg.sys 1000
scoreboard players operation #vmk rpg.sys -= #e_mul rpg.sys
scoreboard players operation #vv rpg.sys *= #vmk rpg.sys
scoreboard players operation #vv rpg.sys /= #c1000 rpg.sys
scoreboard players remove #vmn rpg.sys 1
function rpg:enh/prob_pv_mul_l

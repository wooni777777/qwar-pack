$clear @s $(mid) $(mcnt)

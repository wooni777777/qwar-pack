scoreboard players enable @s rpg.enh
tellraw @s " "
tellraw @s {"text": "━━━━━━━  강화 대장장이 설정  ━━━━━━━", "color": "dark_gray"}
tellraw @s ["", {"text": "   설정은 서버 전체 공용입니다. 저장해 두면 설치할 때 그대로 적용됩니다.", "color": "dark_gray"}]
tellraw @s " "
tellraw @s ["", {"text": "   "}, {"text": "[ 요구량(재료) ]", "color": "gold", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.enh set 11"}, "hover_event": {"action": "show_text", "value": {"text": "강화 단계별 돈 / 부재료를 정합니다", "color": "gray"}}}, {"text": "   "}, {"text": "[ 확률조절 ]", "color": "aqua", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.enh set 12"}, "hover_event": {"action": "show_text", "value": {"text": "성공 / 실패 / 파괴 확률을 정합니다", "color": "gray"}}}]
tellraw @s " "
tellraw @s ["", {"text": "   "}, {"text": "[ 저 장 ]", "color": "green", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.enh set 13"}}, {"text": "   "}, {"text": "[ NPC 창 ]", "color": "dark_gray", "click_event": {"action": "run_command", "command": "trigger rpg.npc set 1"}}]
tellraw @s {"text": "━━━━━━━━━━━━━━━━━━━━━━━━━━", "color": "dark_gray"}

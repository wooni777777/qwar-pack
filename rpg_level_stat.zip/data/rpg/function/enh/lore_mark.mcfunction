# 방금 덧붙인 【공격력】 줄의 위치를 custom_data.atki 에 남긴다
scoreboard players set #aln rpg.sys 0
execute store result score #aln rpg.sys run data get storage rpg:enh it.components."minecraft:lore"
scoreboard players remove #aln rpg.sys 1
execute store result storage rpg:enh it.components."minecraft:custom_data".atki int 1 run scoreboard players get #aln rpg.sys

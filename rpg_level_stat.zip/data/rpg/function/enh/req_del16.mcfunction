data remove storage rpg:enh cfg.req.l16
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"16강 요구량을 지웠습니다.","color":"red"}]
function rpg:enh/req_menu

execute unless data storage rpg:enh cfg.req.l15 run data modify storage rpg:enh cfg.req.l15 set value {money:0,mats:[]}
execute unless data storage rpg:enh cfg.req.l15.mats run data modify storage rpg:enh cfg.req.l15.mats set value []
execute store result storage rpg:enh cfg.req.l15.money int 1 run scoreboard players get @s rpg.enhM
scoreboard players set #mn rpg.sys 0
execute store result score #mn rpg.sys run data get storage rpg:enh cfg.req.l15.mats
execute if items entity @s weapon.mainhand * if score #mn rpg.sys matches 5.. run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"재료는 최대 5종류까지입니다. [지우기] 후 다시 등록하세요.","color":"red"}]
execute if items entity @s weapon.mainhand * if score #mn rpg.sys matches ..4 run function rpg:enh/mat_add15
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"15강 요구량을 저장했습니다.","color":"green"}]
function rpg:enh/req_menu

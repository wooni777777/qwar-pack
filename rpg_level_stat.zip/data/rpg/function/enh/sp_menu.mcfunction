scoreboard players enable @s rpg.enh
tellraw @s " "
tellraw @s {"text": "━━━━━━━  특수 아이템  ━━━━━━━", "color": "dark_gray"}
execute if score @s rpg.spD matches ..0 if score @s rpg.spL matches ..0 run tellraw @s ["", {"text": "   가지고 있는 특수 아이템이 없습니다", "color": "gray"}]
execute if score @s rpg.spD matches 1.. run tellraw @s ["", {"text": "   특수 파괴무시  ", "color": "white"}, {"score": {"name": "@s", "objective": "rpg.spD"}, "color": "yellow", "bold": true}, {"text": "개   ", "color": "dark_gray"}, {"text": "[사용]", "color": "green", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.enh set 4"}, "hover_event": {"action": "show_text", "value": {"text": "다음 강화 1번에 한해 파괴되지 않습니다", "color": "gray"}}}, {"text": " "}, {"text": "[빼기]", "color": "gold", "click_event": {"action": "run_command", "command": "trigger rpg.enh set 6"}, "hover_event": {"action": "show_text", "value": {"text": "아이템으로 꺼냅니다 (거래용)", "color": "gray"}}}]
execute if score @s rpg.spL matches 1.. run tellraw @s ["", {"text": "   특수 성공확률  ", "color": "white"}, {"score": {"name": "@s", "objective": "rpg.spL"}, "color": "yellow", "bold": true}, {"text": "개   ", "color": "dark_gray"}, {"text": "[사용]", "color": "green", "bold": true, "click_event": {"action": "run_command", "command": "trigger rpg.enh set 5"}, "hover_event": {"action": "show_text", "value": {"text": "다음 강화 1번에 한해 성공확률 +10% / 실패확률 -10%", "color": "gray"}}}, {"text": " "}, {"text": "[빼기]", "color": "gold", "click_event": {"action": "run_command", "command": "trigger rpg.enh set 7"}, "hover_event": {"action": "show_text", "value": {"text": "아이템으로 꺼냅니다 (거래용)", "color": "gray"}}}]
tellraw @s " "
execute if score @s rpg.spDu matches 1 run tellraw @s ["", {"text": "   ✔ 파괴무시 사용 예약됨", "color": "green"}]
execute if score @s rpg.spLu matches 1 run tellraw @s ["", {"text": "   ✔ 성공확률 사용 예약됨", "color": "green"}]
tellraw @s ["", {"text": "   "}, {"text": "[ 돌아가기 ]", "color": "dark_gray", "click_event": {"action": "run_command", "command": "trigger rpg.enh set 1"}}]
tellraw @s {"text": "━━━━━━━━━━━━━━━━━━━━━━━━━━", "color": "dark_gray"}

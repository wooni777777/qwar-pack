# 같은 틱 안에서 만들고 지우므로 화면에는 보이지 않습니다
execute at @s run summon minecraft:item ~ ~ ~ {Tags:["rpg_enhtmp"],Item:{id:"minecraft:stone",count:1},PickupDelay:32767s,Age:-32768s,NoGravity:1b,Invulnerable:1b}
data modify entity @e[tag=rpg_enhtmp,limit=1] Item set from storage rpg:enh it
item replace entity @s weapon.mainhand from entity @e[tag=rpg_enhtmp,limit=1] contents
kill @e[tag=rpg_enhtmp]

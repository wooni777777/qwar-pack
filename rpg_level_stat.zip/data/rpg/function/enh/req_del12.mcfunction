data remove storage rpg:enh cfg.req.l12
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"12강 요구량을 지웠습니다.","color":"red"}]
function rpg:enh/req_menu

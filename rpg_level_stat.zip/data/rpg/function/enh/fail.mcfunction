execute unless score @s rpg.erod matches 1 run function rpg:enh/apply
execute if score @s rpg.erod matches 1 run function rpg:enh/apply_rod
tellraw @s ["",{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"강화 실패","color":"red","bold":true},{"text":"   남은 시도 ","color":"dark_gray"},{"score":{"name":"#etry","objective":"rpg.sys"},"color":"white"},{"text":"회","color":"dark_gray"}]
execute at @s run playsound minecraft:block.anvil.land player @s ~ ~ ~ 0.8 0.7
execute at @s run particle minecraft:smoke ~ ~1 ~ 0.3 0.5 0.3 0.02 30 normal @a
function rpg:enh/open

# 파괴 : 성공 연출은 절대 나오지 않는다 (불꽃 튀는 연출만)
item replace entity @s weapon.mainhand with minecraft:air
tellraw @s " "
execute unless score @s rpg.erod matches 1 run tellraw @s ["",{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"무기가 파괴되었습니다...","color":"dark_red","bold":true}]
execute if score @s rpg.erod matches 1 run tellraw @s ["",{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"낚싯대가 파괴되었습니다...","color":"dark_red","bold":true}]
tellraw @s " "
execute at @s run playsound minecraft:entity.blaze.shoot player @s ~ ~ ~ 1 0.7
execute at @s run playsound minecraft:entity.generic.extinguish_fire player @s ~ ~ ~ 1 0.8
execute at @s run playsound minecraft:block.anvil.destroy player @s ~ ~ ~ 1 0.6
execute at @s run particle minecraft:lava ~ ~1.1 ~ 0.3 0.4 0.3 0 40 force @a
execute at @s run particle minecraft:flame ~ ~1.1 ~ 0.25 0.35 0.25 0.08 50 force @a
execute at @s run particle minecraft:large_smoke ~ ~1.1 ~ 0.3 0.4 0.3 0.02 25 force @a
execute at @s run particle minecraft:crit ~ ~1.1 ~ 0.3 0.4 0.3 0.4 30 force @a

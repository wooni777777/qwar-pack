scoreboard players operation #vv rpg.sys = #e_base rpg.sys
scoreboard players operation #vmn rpg.sys = #pvn rpg.sys
function rpg:enh/prob_pv_mul_l

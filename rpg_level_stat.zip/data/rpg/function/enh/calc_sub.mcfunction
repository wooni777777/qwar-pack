# 성공확률 = 시작확률 - (현재 강화 x 단계당 감소)
scoreboard players operation #esucc rpg.sys = #e_dec rpg.sys
scoreboard players operation #esucc rpg.sys *= #enh rpg.sys
scoreboard players operation #et rpg.sys = #e_base rpg.sys
scoreboard players operation #et rpg.sys -= #esucc rpg.sys
scoreboard players operation #esucc rpg.sys = #et rpg.sys

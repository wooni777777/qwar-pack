data modify storage rpg:enh mt set from storage rpg:enh cur.mats[4]
function rpg:enh/mpay with storage rpg:enh mt

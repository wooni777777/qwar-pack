# 강화 가능한 아이템인가 (내부용 · #ok) — rpg.erod 1 = 낚싯대 강화 NPC , 0 = 대장장이
scoreboard players set #ok rpg.sys 0
execute unless score @s rpg.erod matches 1 unless items entity @s weapon.mainhand minecraft:fishing_rod if data entity @s SelectedItem.components."minecraft:attribute_modifiers"[{type:"minecraft:attack_damage"}] run scoreboard players set #ok rpg.sys 1
execute if score @s rpg.erod matches 1 if items entity @s weapon.mainhand minecraft:fishing_rod run scoreboard players set #ok rpg.sys 1

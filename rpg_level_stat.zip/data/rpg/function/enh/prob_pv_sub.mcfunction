scoreboard players operation #vt rpg.sys = #pvn rpg.sys
scoreboard players operation #vt rpg.sys *= #e_dec rpg.sys
scoreboard players operation #vv rpg.sys = #e_base rpg.sys
scoreboard players operation #vv rpg.sys -= #vt rpg.sys

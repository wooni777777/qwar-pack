$data modify storage rpg:enh it.components."minecraft:lore" prepend value {"text":"【낚시 운】 +$(rl)  (좋은 물고기가 잘 잡힘)","color":"aqua","italic":false}
$data modify storage rpg:enh it.components."minecraft:lore" prepend value {"text":"강화 +$(lv)","color":"gold","bold":true,"italic":false}
data modify storage rpg:enh it.components."minecraft:custom_data".rodk set value 1

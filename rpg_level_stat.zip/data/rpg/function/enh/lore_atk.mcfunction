$data modify storage rpg:enh it.components."minecraft:lore"[-1] set value {"text":"","italic":false,"extra":[{"text":"【공격력】 ","color":"red"},{"text":"+$(ai).$(af)","color":"white"}]}

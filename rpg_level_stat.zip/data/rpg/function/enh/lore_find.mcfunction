# 【공격력】 줄 위치를 #alx 에 넣는다
#   ① 글자로 먼저 찾습니다 (띄어쓰기 있든 없든 · 줄 통째로든 조각이든)
#   ② 못 찾으면 아이템이 기억하고 있는 줄 번호(custom_data.atki) 를 씁니다
scoreboard players set #alx rpg.sys -1
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[0].extra[0]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 0
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[0].extra[0]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 0
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[0]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 0
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[0]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 0
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[1].extra[0]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 1
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[1].extra[0]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 1
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[1]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 1
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[1]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 1
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[2].extra[0]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 2
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[2].extra[0]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 2
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[2]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 2
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[2]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 2
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[3].extra[0]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 3
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[3].extra[0]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 3
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[3]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 3
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[3]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 3
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[4].extra[0]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 4
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[4].extra[0]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 4
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[4]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 4
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[4]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 4
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[5].extra[0]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 5
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[5].extra[0]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 5
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[5]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 5
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[5]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 5
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[6].extra[0]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 6
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[6].extra[0]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 6
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[6]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 6
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[6]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 6
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[7].extra[0]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 7
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[7].extra[0]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 7
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[7]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 7
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[7]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 7
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[8].extra[0]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 8
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[8].extra[0]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 8
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[8]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 8
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[8]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 8
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[9].extra[0]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 9
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[9].extra[0]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 9
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[9]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 9
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[9]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 9
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[10].extra[0]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 10
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[10].extra[0]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 10
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[10]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 10
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[10]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 10
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[11].extra[0]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 11
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[11].extra[0]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 11
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[11]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 11
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[11]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 11
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[12].extra[0]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 12
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[12].extra[0]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 12
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[12]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 12
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[12]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 12
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[13].extra[0]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 13
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[13].extra[0]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 13
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[13]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 13
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[13]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 13
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[14].extra[0]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 14
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[14].extra[0]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 14
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[14]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 14
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[14]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 14
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[15].extra[0]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 15
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[15].extra[0]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 15
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[15]{text:"【공격력】 "} run scoreboard players set #alx rpg.sys 15
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:lore"[15]{text:"【공격력】"} run scoreboard players set #alx rpg.sys 15
execute if score #alx rpg.sys matches -1 if data storage rpg:enh it.components."minecraft:custom_data".atki store result score #alx rpg.sys run data get storage rpg:enh it.components."minecraft:custom_data".atki
# 그래도 못 찾으면 -1 (새 줄을 덧붙입니다)

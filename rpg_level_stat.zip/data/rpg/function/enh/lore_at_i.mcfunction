$data modify storage rpg:enh it.components."minecraft:lore"[$(i)] set value {"text":"","italic":false,"extra":[{"text":"【공격력】","color":"red"},{"text":"+$(ai)","color":"white"}]}

advancement revoke @s only rpg:enh/sp2
scoreboard players add @s rpg.spL 1
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"특수 성공확률 +10% 을(를) 얻었습니다.","color":"green"}]
execute at @s run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 1 1.6

data modify storage rpg:enh mt set value {mid:"minecraft:air",mcnt:1}
data modify storage rpg:enh mt.mid set from entity @s SelectedItem.id
data modify storage rpg:enh mt.mcnt set from entity @s SelectedItem.count
data modify storage rpg:enh cfg.req.l14.mats append from storage rpg:enh mt

$tellraw @s ["",{"text":"   필요 : ","color":"gray"},{"text":"$(money)원","color":"gold"},{"text":"   부재료 $(cnt)종","color":"dark_gray"}]

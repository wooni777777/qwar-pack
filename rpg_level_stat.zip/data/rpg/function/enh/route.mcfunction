# 플레이어
execute if score @s rpg.enh matches 1 run function rpg:enh/open
execute if score @s rpg.enh matches 2 run function rpg:enh/do
execute if score @s rpg.enh matches 3 run function rpg:enh/sp_menu
execute if score @s rpg.enh matches 4 run function rpg:enh/sp_on1
execute if score @s rpg.enh matches 5 run function rpg:enh/sp_on2
execute if score @s rpg.enh matches 6 run function rpg:enh/sp_out1
execute if score @s rpg.enh matches 7 run function rpg:enh/sp_out2
# 제작자 설정
execute if score @s rpg.enh matches 10 if entity @s[tag=op] run function rpg:enh/cfg_menu
execute if score @s rpg.enh matches 11 if entity @s[tag=op] run function rpg:enh/req_menu
execute if score @s rpg.enh matches 12 if entity @s[tag=op] run function rpg:enh/prob_menu
execute if score @s rpg.enh matches 13 if entity @s[tag=op] run function rpg:enh/save
execute if score @s rpg.enh matches 21 if entity @s[tag=op] run scoreboard players add @s rpg.enhM 1000
execute if score @s rpg.enh matches 22 if entity @s[tag=op] run scoreboard players add @s rpg.enhM 10000
execute if score @s rpg.enh matches 23 if entity @s[tag=op] run scoreboard players add @s rpg.enhM 100000
execute if score @s rpg.enh matches 24 if entity @s[tag=op] run scoreboard players set @s rpg.enhM 0
execute if score @s rpg.enh matches 21..24 if entity @s[tag=op] run function rpg:enh/req_menu
execute if score @s rpg.enh matches 31 if entity @s[tag=op] run function rpg:enh/req_set1
execute if score @s rpg.enh matches 32 if entity @s[tag=op] run function rpg:enh/req_set2
execute if score @s rpg.enh matches 33 if entity @s[tag=op] run function rpg:enh/req_set3
execute if score @s rpg.enh matches 34 if entity @s[tag=op] run function rpg:enh/req_set4
execute if score @s rpg.enh matches 35 if entity @s[tag=op] run function rpg:enh/req_set5
execute if score @s rpg.enh matches 36 if entity @s[tag=op] run function rpg:enh/req_set6
execute if score @s rpg.enh matches 37 if entity @s[tag=op] run function rpg:enh/req_set7
execute if score @s rpg.enh matches 38 if entity @s[tag=op] run function rpg:enh/req_set8
execute if score @s rpg.enh matches 39 if entity @s[tag=op] run function rpg:enh/req_set9
execute if score @s rpg.enh matches 40 if entity @s[tag=op] run function rpg:enh/req_set10
execute if score @s rpg.enh matches 41 if entity @s[tag=op] run function rpg:enh/req_set11
execute if score @s rpg.enh matches 42 if entity @s[tag=op] run function rpg:enh/req_set12
execute if score @s rpg.enh matches 43 if entity @s[tag=op] run function rpg:enh/req_set13
execute if score @s rpg.enh matches 44 if entity @s[tag=op] run function rpg:enh/req_set14
execute if score @s rpg.enh matches 45 if entity @s[tag=op] run function rpg:enh/req_set15
execute if score @s rpg.enh matches 46 if entity @s[tag=op] run function rpg:enh/req_set16
execute if score @s rpg.enh matches 47 if entity @s[tag=op] run function rpg:enh/req_set17
execute if score @s rpg.enh matches 48 if entity @s[tag=op] run function rpg:enh/req_set18
execute if score @s rpg.enh matches 49 if entity @s[tag=op] run function rpg:enh/req_set19
execute if score @s rpg.enh matches 50 if entity @s[tag=op] run function rpg:enh/req_set20
execute if score @s rpg.enh matches 71 if entity @s[tag=op] run function rpg:enh/req_del1
execute if score @s rpg.enh matches 72 if entity @s[tag=op] run function rpg:enh/req_del2
execute if score @s rpg.enh matches 73 if entity @s[tag=op] run function rpg:enh/req_del3
execute if score @s rpg.enh matches 74 if entity @s[tag=op] run function rpg:enh/req_del4
execute if score @s rpg.enh matches 75 if entity @s[tag=op] run function rpg:enh/req_del5
execute if score @s rpg.enh matches 76 if entity @s[tag=op] run function rpg:enh/req_del6
execute if score @s rpg.enh matches 77 if entity @s[tag=op] run function rpg:enh/req_del7
execute if score @s rpg.enh matches 78 if entity @s[tag=op] run function rpg:enh/req_del8
execute if score @s rpg.enh matches 79 if entity @s[tag=op] run function rpg:enh/req_del9
execute if score @s rpg.enh matches 80 if entity @s[tag=op] run function rpg:enh/req_del10
execute if score @s rpg.enh matches 81 if entity @s[tag=op] run function rpg:enh/req_del11
execute if score @s rpg.enh matches 82 if entity @s[tag=op] run function rpg:enh/req_del12
execute if score @s rpg.enh matches 83 if entity @s[tag=op] run function rpg:enh/req_del13
execute if score @s rpg.enh matches 84 if entity @s[tag=op] run function rpg:enh/req_del14
execute if score @s rpg.enh matches 85 if entity @s[tag=op] run function rpg:enh/req_del15
execute if score @s rpg.enh matches 86 if entity @s[tag=op] run function rpg:enh/req_del16
execute if score @s rpg.enh matches 87 if entity @s[tag=op] run function rpg:enh/req_del17
execute if score @s rpg.enh matches 88 if entity @s[tag=op] run function rpg:enh/req_del18
execute if score @s rpg.enh matches 89 if entity @s[tag=op] run function rpg:enh/req_del19
execute if score @s rpg.enh matches 90 if entity @s[tag=op] run function rpg:enh/req_del20
execute if score @s rpg.enh matches 61 if entity @s[tag=op] run scoreboard players remove #e_base rpg.sys 10
execute if score @s rpg.enh matches 62 if entity @s[tag=op] run scoreboard players add #e_base rpg.sys 10
execute if score @s rpg.enh matches 63 if entity @s[tag=op] run scoreboard players remove #e_dec rpg.sys 5
execute if score @s rpg.enh matches 64 if entity @s[tag=op] run scoreboard players add #e_dec rpg.sys 5
execute if score @s rpg.enh matches 65 if entity @s[tag=op] run scoreboard players remove #e_dfrom rpg.sys 1
execute if score @s rpg.enh matches 66 if entity @s[tag=op] run scoreboard players add #e_dfrom rpg.sys 1
execute if score @s rpg.enh matches 67 if entity @s[tag=op] run scoreboard players remove #e_dinc rpg.sys 5
execute if score @s rpg.enh matches 68 if entity @s[tag=op] run scoreboard players add #e_dinc rpg.sys 5
execute if score @s rpg.enh matches 91 if entity @s[tag=op] run scoreboard players add #e_mul rpg.sys 10
execute if score @s rpg.enh matches 92 if entity @s[tag=op] run scoreboard players add #e_mul rpg.sys 50
execute if score @s rpg.enh matches 93 if entity @s[tag=op] run scoreboard players add #e_mul rpg.sys 100
execute if score @s rpg.enh matches 94 if entity @s[tag=op] run scoreboard players set #e_mul rpg.sys 0
# 범위 보정
execute if score #e_base rpg.sys matches ..50 run scoreboard players set #e_base rpg.sys 50
execute if score #e_base rpg.sys matches 1000.. run scoreboard players set #e_base rpg.sys 1000
execute if score #e_dec rpg.sys matches ..0 run scoreboard players set #e_dec rpg.sys 0
execute if score #e_dec rpg.sys matches 300.. run scoreboard players set #e_dec rpg.sys 300
execute if score #e_dfrom rpg.sys matches ..1 run scoreboard players set #e_dfrom rpg.sys 1
execute if score #e_dfrom rpg.sys matches 21.. run scoreboard players set #e_dfrom rpg.sys 21
execute if score #e_dinc rpg.sys matches ..0 run scoreboard players set #e_dinc rpg.sys 0
execute if score #e_dinc rpg.sys matches 200.. run scoreboard players set #e_dinc rpg.sys 200
execute if score #e_mul rpg.sys matches ..0 run scoreboard players set #e_mul rpg.sys 0
execute if score #e_mul rpg.sys matches 900.. run scoreboard players set #e_mul rpg.sys 900
execute if score @s rpg.enh matches 95 if entity @s[tag=op] run function rpg:enh/save
execute if score @s rpg.enh matches 61..68 if entity @s[tag=op] run function rpg:enh/prob_menu
execute if score @s rpg.enh matches 91..95 if entity @s[tag=op] run function rpg:enh/prob_menu
scoreboard players set @s rpg.enh 0
scoreboard players enable @s rpg.enh

$data modify storage rpg:enh it.components."minecraft:lore" prepend value {"text":"강화 +$(lv)","color":"gold","bold":true,"italic":false}

execute if score #rn rpg.sys matches ..0 run return 0
execute store result storage rpg:enh q.n int 1 run scoreboard players get #rn rpg.sys
function rpg:enh/req_try with storage rpg:enh q
execute if score #rfound rpg.sys matches 1 run return 1
scoreboard players remove #rn rpg.sys 1
function rpg:enh/req_find

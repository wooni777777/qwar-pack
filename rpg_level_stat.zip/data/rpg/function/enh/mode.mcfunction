# 어떤 방식으로 확률을 깎을지 정한다
#   #emode 0 = 단계마다 빼기 (기존)   1 = 배율로 곱하기
#   '단계마다 감소' 를 0 으로 둔 경우에만 배율을 씁니다
scoreboard players set #emode rpg.sys 0
execute if score #e_mul rpg.sys matches 1.. if score #e_dec rpg.sys matches ..0 run scoreboard players set #emode rpg.sys 1

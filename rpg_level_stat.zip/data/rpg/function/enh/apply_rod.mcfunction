# 낚싯대 강화 결과 적용 (v40 · 내부용) — 강화 단계 / 남은 시도 / 【낚시 운】(= 단계 x 2) / 부서지지 않음
data modify storage rpg:enh it set from entity @s SelectedItem
execute store result storage rpg:enh it.components."minecraft:custom_data".enh int 1 run scoreboard players get #enh rpg.sys
execute store result storage rpg:enh it.components."minecraft:custom_data".etry int 1 run scoreboard players get #etry rpg.sys
scoreboard players operation #rl rpg.sys = #enh rpg.sys
scoreboard players operation #rl rpg.sys *= #k2 rpg.sys
execute store result storage rpg:enh it.components."minecraft:custom_data".rodl int 1 run scoreboard players get #rl rpg.sys
execute store result storage rpg:enh t.lv int 1 run scoreboard players get #enh rpg.sys
execute store result storage rpg:enh t.rl int 1 run scoreboard players get #rl rpg.sys
execute unless data storage rpg:enh it.components."minecraft:lore"[0] run data modify storage rpg:enh it.components."minecraft:lore" set value []
execute if score #enh rpg.sys matches 1.. unless data storage rpg:enh it.components."minecraft:custom_data".rodk run function rpg:enh/rod_new with storage rpg:enh t
execute if score #enh rpg.sys matches 1.. if data storage rpg:enh it.components."minecraft:custom_data".rodk run function rpg:enh/rod_upd with storage rpg:enh t
execute if score #enh rpg.sys matches 1.. run data modify storage rpg:enh it.components."minecraft:unbreakable" set value {}
function rpg:enh/put

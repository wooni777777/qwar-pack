# 성공확률 = 시작확률 x (100 - 배율)% 를 강화 횟수만큼 곱한다
scoreboard players operation #esucc rpg.sys = #e_base rpg.sys
scoreboard players operation #emn rpg.sys = #enh rpg.sys
function rpg:enh/calc_mul_l

scoreboard players set #rfound rpg.sys 0
data remove storage rpg:enh cur
scoreboard players operation #rn rpg.sys = #enhnext rpg.sys
function rpg:enh/req_find
execute if score #rfound rpg.sys matches 0 run data modify storage rpg:enh cur set value {money:1000,mats:[]}
execute unless data storage rpg:enh cur.mats run data modify storage rpg:enh cur.mats set value []

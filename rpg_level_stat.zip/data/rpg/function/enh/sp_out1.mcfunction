execute if score @s rpg.spD matches ..0 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"꺼낼 것이 없습니다.","color":"red"}]
execute if score @s rpg.spD matches ..0 run return 0
scoreboard players remove @s rpg.spD 1
scoreboard players set @s rpg.spDu 0
function rpg:enh/sp_give1
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"특수 파괴무시 을(를) 아이템으로 꺼냈습니다.","color":"gold"}]
function rpg:enh/sp_menu

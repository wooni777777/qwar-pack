# 손에 든 무기의 강화 단계 / 남은 시도횟수 / 다음 단계 요구량·확률을 읽어 온다
scoreboard players set #enh rpg.sys 0
execute store result score #enh rpg.sys run data get entity @s SelectedItem.components."minecraft:custom_data".enh
scoreboard players set #etry rpg.sys 30
execute if data entity @s SelectedItem.components."minecraft:custom_data".etry store result score #etry rpg.sys run data get entity @s SelectedItem.components."minecraft:custom_data".etry
scoreboard players operation #enhnext rpg.sys = #enh rpg.sys
scoreboard players add #enhnext rpg.sys 1
function rpg:enh/req_load
function rpg:enh/calc
data modify storage rpg:enh m set value {}
data modify storage rpg:enh m.id set from entity @s SelectedItem.id
data modify storage rpg:enh m.count set from entity @s SelectedItem.count
data modify storage rpg:enh m.components set value {}
execute if data entity @s SelectedItem.components run data modify storage rpg:enh m.components set from entity @s SelectedItem.components
execute store result storage rpg:enh m.enh int 1 run scoreboard players get #enh rpg.sys
execute store result storage rpg:enh m.next int 1 run scoreboard players get #enhnext rpg.sys
execute store result storage rpg:enh m.try int 1 run scoreboard players get #etry rpg.sys
execute store result storage rpg:enh cur.money2 int 1 run data get storage rpg:enh cur.money
execute store result storage rpg:enh cur.try2 int 1 run scoreboard players get #etry rpg.sys
execute store result storage rpg:enh cur.next2 int 1 run scoreboard players get #enhnext rpg.sys
scoreboard players set #mc2 rpg.sys 1
execute store result score #mc2 rpg.sys run data get storage rpg:enh cur.mcnt
execute if score #mc2 rpg.sys matches ..0 run scoreboard players set #mc2 rpg.sys 1
execute store result storage rpg:enh cur.mcnt2 int 1 run scoreboard players get #mc2 rpg.sys
scoreboard players set #mc rpg.sys 0
execute store result score #mc rpg.sys run data get storage rpg:enh cur.mats
execute store result storage rpg:enh cur.cnt int 1 run scoreboard players get #mc rpg.sys

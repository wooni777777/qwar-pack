# 성공확률 [하한 5%]  — 빼기 방식 / 배율 방식 중 하나
function rpg:enh/mode
execute if score #emode rpg.sys matches 0 run function rpg:enh/calc_sub
execute if score #emode rpg.sys matches 1 run function rpg:enh/calc_mul
execute if score @s rpg.spLu matches 1 run scoreboard players add #esucc rpg.sys 100
execute if entity @s[tag=H14] run scoreboard players add #esucc rpg.sys 30
execute if score #esucc rpg.sys matches ..50 run scoreboard players set #esucc rpg.sys 50
execute if score #esucc rpg.sys matches 1000.. run scoreboard players set #esucc rpg.sys 1000
# 파괴확률 : 지정한 강화 단계부터 단계마다 증가   [상한 50%]
scoreboard players set #edest rpg.sys 0
execute if score #enhnext rpg.sys >= #e_dfrom rpg.sys run function rpg:enh/calc_dest
execute if score @s rpg.spDu matches 1 run scoreboard players set #edest rpg.sys 0
# 실패확률 = 나머지
scoreboard players set #efail rpg.sys 1000
scoreboard players operation #efail rpg.sys -= #esucc rpg.sys
scoreboard players operation #efail rpg.sys -= #edest rpg.sys
execute if score #efail rpg.sys matches ..0 run scoreboard players set #efail rpg.sys 0
function rpg:enh/calc_disp

# 표시용 : 1000분율을 정수부/소수부로 나눈다
scoreboard players operation #psi rpg.sys = #esucc rpg.sys
scoreboard players operation #psi rpg.sys /= #c10 rpg.sys
scoreboard players operation #psf rpg.sys = #esucc rpg.sys
scoreboard players operation #psf rpg.sys %= #c10 rpg.sys
scoreboard players operation #pfi rpg.sys = #efail rpg.sys
scoreboard players operation #pfi rpg.sys /= #c10 rpg.sys
scoreboard players operation #pff rpg.sys = #efail rpg.sys
scoreboard players operation #pff rpg.sys %= #c10 rpg.sys
scoreboard players operation #pdi rpg.sys = #edest rpg.sys
scoreboard players operation #pdi rpg.sys /= #c10 rpg.sys
scoreboard players operation #pdf rpg.sys = #edest rpg.sys
scoreboard players operation #pdf rpg.sys %= #c10 rpg.sys

$execute store result score #mhave rpg.sys run clear @s $(mid) 0
$scoreboard players set #mneed rpg.sys $(mcnt)
execute unless score #mhave rpg.sys >= #mneed rpg.sys run scoreboard players set #matok rpg.sys 0

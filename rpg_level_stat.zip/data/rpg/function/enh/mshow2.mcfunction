data modify storage rpg:enh mt set from storage rpg:enh cur.mats[2]
function rpg:enh/mshow with storage rpg:enh mt

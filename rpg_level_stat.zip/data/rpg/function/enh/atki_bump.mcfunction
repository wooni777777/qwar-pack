# "강화 +N" 줄을 맨 위에 끼웠으므로 기억해 둔 줄 번호를 1 올린다 (내부용)
scoreboard players set #ab rpg.sys 0
execute store result score #ab rpg.sys run data get storage rpg:enh it.components."minecraft:custom_data".atki
scoreboard players add #ab rpg.sys 1
execute store result storage rpg:enh it.components."minecraft:custom_data".atki int 1 run scoreboard players get #ab rpg.sys

# 낚싯대 강화 NPC 클릭 (v40) — 창과 설정은 대장장이와 같고, 낚싯대만 받습니다
execute on target run scoreboard players set @s rpg.erod 1
execute on target run function rpg:enh/open
data remove entity @s interaction

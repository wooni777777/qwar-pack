execute if data storage rpg:enh cur.mats[0] run function rpg:enh/mshow0
execute if data storage rpg:enh cur.mats[1] run function rpg:enh/mshow1
execute if data storage rpg:enh cur.mats[2] run function rpg:enh/mshow2
execute if data storage rpg:enh cur.mats[3] run function rpg:enh/mshow3
execute if data storage rpg:enh cur.mats[4] run function rpg:enh/mshow4

scoreboard players operation #edest rpg.sys = #enhnext rpg.sys
scoreboard players operation #edest rpg.sys -= #e_dfrom rpg.sys
scoreboard players add #edest rpg.sys 1
scoreboard players operation #edest rpg.sys *= #e_dinc rpg.sys
execute if score #edest rpg.sys matches 500.. run scoreboard players set #edest rpg.sys 500

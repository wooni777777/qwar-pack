# 강화 대장장이 클릭 — 누른 사람에게 강화 창 (v40 : 낚싯대는 안 받음)
execute on target run scoreboard players set @s rpg.erod 0
execute on target run function rpg:enh/open
data remove entity @s interaction

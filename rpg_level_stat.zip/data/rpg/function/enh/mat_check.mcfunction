scoreboard players set #matok rpg.sys 1
execute if data storage rpg:enh cur.mats[0] run function rpg:enh/mchk0
execute if data storage rpg:enh cur.mats[1] run function rpg:enh/mchk1
execute if data storage rpg:enh cur.mats[2] run function rpg:enh/mchk2
execute if data storage rpg:enh cur.mats[3] run function rpg:enh/mchk3
execute if data storage rpg:enh cur.mats[4] run function rpg:enh/mchk4

# 표시용 : 1000분율 -> 정수부 / 소수부
scoreboard players operation #cbi rpg.sys = #e_base rpg.sys
scoreboard players operation #cbi rpg.sys /= #c10 rpg.sys
scoreboard players operation #cbf rpg.sys = #e_base rpg.sys
scoreboard players operation #cbf rpg.sys %= #c10 rpg.sys
scoreboard players operation #cdi rpg.sys = #e_dec rpg.sys
scoreboard players operation #cdi rpg.sys /= #c10 rpg.sys
scoreboard players operation #cdf rpg.sys = #e_dec rpg.sys
scoreboard players operation #cdf rpg.sys %= #c10 rpg.sys
scoreboard players operation #cii rpg.sys = #e_dinc rpg.sys
scoreboard players operation #cii rpg.sys /= #c10 rpg.sys
scoreboard players operation #cif rpg.sys = #e_dinc rpg.sys
scoreboard players operation #cif rpg.sys %= #c10 rpg.sys
scoreboard players operation #cmi rpg.sys = #e_mul rpg.sys
scoreboard players operation #cmi rpg.sys /= #c10 rpg.sys
scoreboard players operation #cmf rpg.sys = #e_mul rpg.sys
scoreboard players operation #cmf rpg.sys %= #c10 rpg.sys
scoreboard players set #pvn rpg.sys 0
function rpg:enh/prob_pv
scoreboard players operation #v1i rpg.sys = #vv rpg.sys
scoreboard players operation #v1i rpg.sys /= #c10 rpg.sys
scoreboard players operation #v1f rpg.sys = #vv rpg.sys
scoreboard players operation #v1f rpg.sys %= #c10 rpg.sys
scoreboard players set #pvn rpg.sys 4
function rpg:enh/prob_pv
scoreboard players operation #v5i rpg.sys = #vv rpg.sys
scoreboard players operation #v5i rpg.sys /= #c10 rpg.sys
scoreboard players operation #v5f rpg.sys = #vv rpg.sys
scoreboard players operation #v5f rpg.sys %= #c10 rpg.sys
scoreboard players set #pvn rpg.sys 9
function rpg:enh/prob_pv
scoreboard players operation #v10i rpg.sys = #vv rpg.sys
scoreboard players operation #v10i rpg.sys /= #c10 rpg.sys
scoreboard players operation #v10f rpg.sys = #vv rpg.sys
scoreboard players operation #v10f rpg.sys %= #c10 rpg.sys
scoreboard players set #pvn rpg.sys 19
function rpg:enh/prob_pv
scoreboard players operation #v20i rpg.sys = #vv rpg.sys
scoreboard players operation #v20i rpg.sys /= #c10 rpg.sys
scoreboard players operation #v20f rpg.sys = #vv rpg.sys
scoreboard players operation #v20f rpg.sys %= #c10 rpg.sys

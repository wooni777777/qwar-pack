$execute store result score #mhave rpg.sys run clear @s $(mid) 0

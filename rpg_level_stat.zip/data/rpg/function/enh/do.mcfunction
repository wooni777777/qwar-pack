function rpg:enh/itemok
execute if score #ok rpg.sys matches 0 unless score @s rpg.erod matches 1 unless items entity @s weapon.mainhand minecraft:fishing_rod run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"손에 강화할 무기를 들어주세요.","color":"red"}]
execute if score #ok rpg.sys matches 0 unless score @s rpg.erod matches 1 if items entity @s weapon.mainhand minecraft:fishing_rod run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"대장장이는 낚싯대를 강화하지 않습니다. [낚싯대 강화] NPC 에게 가세요.","color":"red"}]
execute if score #ok rpg.sys matches 0 if score @s rpg.erod matches 1 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"손에 강화할 낚싯대를 들어주세요.","color":"red"}]
execute if score #ok rpg.sys matches 0 run return 0
function rpg:enh/load
execute if score #enh rpg.sys matches 20.. run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"이미 최대 강화(+20)입니다.","color":"red"}]
execute if score #enh rpg.sys matches 20.. run return 0
execute if score #etry rpg.sys matches ..0 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"이 아이템은 강화 시도 횟수를 모두 썼습니다.","color":"red"}]
execute if score #etry rpg.sys matches ..0 run return 0
# ── 재료 확인 ──
scoreboard players set #ereq rpg.sys 0
execute store result score #ereq rpg.sys run data get storage rpg:enh cur.money
function rpg:enh/mat_check
scoreboard players set #ok rpg.sys 1
execute unless score @s money >= #ereq rpg.sys run scoreboard players set #ok rpg.sys 0
execute unless score @s money >= #ereq rpg.sys run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"돈이 부족합니다.","color":"red"}]
execute if score #matok rpg.sys matches 0 run scoreboard players set #ok rpg.sys 0
execute if score #matok rpg.sys matches 0 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"부재료가 부족합니다.","color":"red"}]
execute if score #ok rpg.sys matches 0 at @s run playsound minecraft:entity.villager.no player @s ~ ~ ~ 1 1
execute if score #ok rpg.sys matches 0 run return 0
# ── 지불 ──
scoreboard players operation @s money -= #ereq rpg.sys
function rpg:enh/mat_pay
scoreboard players remove #etry rpg.sys 1
# ── 판정 (1 성공 / 2 실패 / 3 파괴) ──
execute store result score #r rpg.sys run random value 1..1000
scoreboard players operation #sd2 rpg.sys = #esucc rpg.sys
scoreboard players operation #sd2 rpg.sys += #edest rpg.sys
scoreboard players set #eres rpg.sys 2
execute if score #r rpg.sys <= #esucc rpg.sys run scoreboard players set #eres rpg.sys 1
execute if score #eres rpg.sys matches 2 if score #r rpg.sys <= #sd2 rpg.sys run scoreboard players set #eres rpg.sys 3
# 특수 아이템은 [사용] 누를 때 이미 1개 소모됐으므로 예약만 해제한다
scoreboard players set @s rpg.spDu 0
scoreboard players set @s rpg.spLu 0
execute if score #eres rpg.sys matches 1 run function rpg:enh/succ
execute if score #eres rpg.sys matches 2 run function rpg:enh/fail
execute if score #eres rpg.sys matches 3 run function rpg:enh/dest

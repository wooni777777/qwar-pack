data modify storage rpg:enh saved set from storage rpg:enh cfg
execute store result storage rpg:enh saved.p.base int 1 run scoreboard players get #e_base rpg.sys
execute store result storage rpg:enh saved.p.dec int 1 run scoreboard players get #e_dec rpg.sys
execute store result storage rpg:enh saved.p.dfrom int 1 run scoreboard players get #e_dfrom rpg.sys
execute store result storage rpg:enh saved.p.dinc int 1 run scoreboard players get #e_dinc rpg.sys
execute store result storage rpg:enh saved.p.mul int 1 run scoreboard players get #e_mul rpg.sys
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"강화 설정(요구량 + 확률)을 저장했습니다. 설치하면 그대로 적용됩니다.","color":"green"}]
execute at @s run playsound minecraft:block.beacon.power_select player @s ~ ~ ~ 1 1.4

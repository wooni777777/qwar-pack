execute if score @s rpg.spL matches ..0 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"꺼낼 것이 없습니다.","color":"red"}]
execute if score @s rpg.spL matches ..0 run return 0
scoreboard players remove @s rpg.spL 1
scoreboard players set @s rpg.spLu 0
function rpg:enh/sp_give2
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"특수 성공확률 을(를) 아이템으로 꺼냈습니다.","color":"gold"}]
function rpg:enh/sp_menu

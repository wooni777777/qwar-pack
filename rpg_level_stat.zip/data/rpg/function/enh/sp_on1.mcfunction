execute if score @s rpg.spDu matches 1 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"이미 예약되어 있습니다. 다음 강화 1회에 적용됩니다.","color":"gray"}]
execute if score @s rpg.spDu matches 1 run return 0
execute if score @s rpg.spD matches ..0 run tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"가지고 있지 않습니다.","color":"red"}]
execute if score @s rpg.spD matches ..0 run return 0
scoreboard players remove @s rpg.spD 1
scoreboard players set @s rpg.spDu 1
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"특수 파괴무시 1개를 사용합니다. (다음 강화 1회만 적용)","color":"green"}]
function rpg:enh/open

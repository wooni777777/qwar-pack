# 플레이어 인벤 NBT 는 /data 로 못 고치므로
#   손에 든 무기 -> 스토리지 -> 수정 -> 임시 아이템 엔티티 -> 손에 되돌려주기
data modify storage rpg:enh it set from entity @s SelectedItem
# 강화 단계 / 남은 시도횟수
execute store result storage rpg:enh it.components."minecraft:custom_data".enh int 1 run scoreboard players get #enh rpg.sys
execute store result storage rpg:enh it.components."minecraft:custom_data".etry int 1 run scoreboard players get #etry rpg.sys
# 실제 공격력 1.2배 (0.1 단위)
scoreboard players set #ea rpg.sys 0
execute store result score #ea rpg.sys run data get storage rpg:enh it.components."minecraft:attribute_modifiers"[{type:"minecraft:attack_damage"}].amount 10
execute if score #ea rpg.sys matches ..0 store result score #ea rpg.sys run data get storage rpg:enh it.components."minecraft:attribute_modifiers".modifiers[{type:"minecraft:attack_damage"}].amount 10
scoreboard players operation #ea rpg.sys *= #c12 rpg.sys
scoreboard players operation #ea rpg.sys /= #c10 rpg.sys
execute if score #ea rpg.sys matches ..0 run scoreboard players set #ea rpg.sys 10
execute store result storage rpg:enh it.components."minecraft:attribute_modifiers"[{type:"minecraft:attack_damage"}].amount double 0.1 run scoreboard players get #ea rpg.sys
execute store result storage rpg:enh it.components."minecraft:attribute_modifiers".modifiers[{type:"minecraft:attack_damage"}].amount double 0.1 run scoreboard players get #ea rpg.sys
# 부설명용 숫자 (정수부 . 소수부)
scoreboard players operation #eai rpg.sys = #ea rpg.sys
scoreboard players operation #eai rpg.sys /= #c10 rpg.sys
scoreboard players operation #eaf rpg.sys = #ea rpg.sys
scoreboard players operation #eaf rpg.sys %= #c10 rpg.sys
execute store result storage rpg:enh t.ai int 1 run scoreboard players get #eai rpg.sys
execute store result storage rpg:enh t.af int 1 run scoreboard players get #eaf rpg.sys
execute store result storage rpg:enh t.lv int 1 run scoreboard players get #enh rpg.sys
execute unless data storage rpg:enh it.components."minecraft:lore"[0] run data modify storage rpg:enh it.components."minecraft:lore" set value []
# ── ① 먼저 "강화 +N" 줄 ──
#    +1 일 때는 맨 위에 새 줄이 생기므로 아래 줄 번호가 한 칸씩 밀립니다.
execute if score #enh rpg.sys matches 1 run function rpg:enh/lore_new with storage rpg:enh t
execute if score #enh rpg.sys matches 1 if data storage rpg:enh it.components."minecraft:custom_data".atki run function rpg:enh/atki_bump
execute if score #enh rpg.sys matches 2.. run function rpg:enh/lore_upd with storage rpg:enh t
# ── ② 그 다음에 【공격력】 줄 (밀린 뒤의 위치를 다시 찾습니다) ──
function rpg:enh/lore_find
execute store result storage rpg:enh t.i int 1 run scoreboard players get #alx rpg.sys
execute if score #alx rpg.sys matches 0.. if score #eaf rpg.sys matches 0 run function rpg:enh/lore_at_i with storage rpg:enh t
execute if score #alx rpg.sys matches 0.. unless score #eaf rpg.sys matches 0 run function rpg:enh/lore_at_d with storage rpg:enh t
execute if score #alx rpg.sys matches ..-1 if score #eaf rpg.sys matches 0 run function rpg:enh/lore_add_i with storage rpg:enh t
execute if score #alx rpg.sys matches ..-1 unless score #eaf rpg.sys matches 0 run function rpg:enh/lore_add_d with storage rpg:enh t
data modify storage rpg:enh it.components."minecraft:custom_data".atkl set value 1
# 줄을 새로 덧붙였으면 그 위치를 아이템에 기억시킨다
execute if score #alx rpg.sys matches ..-1 run function rpg:enh/lore_mark
function rpg:enh/put

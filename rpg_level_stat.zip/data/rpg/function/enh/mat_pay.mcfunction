execute if data storage rpg:enh cur.mats[0] run function rpg:enh/mpay0
execute if data storage rpg:enh cur.mats[1] run function rpg:enh/mpay1
execute if data storage rpg:enh cur.mats[2] run function rpg:enh/mpay2
execute if data storage rpg:enh cur.mats[3] run function rpg:enh/mpay3
execute if data storage rpg:enh cur.mats[4] run function rpg:enh/mpay4

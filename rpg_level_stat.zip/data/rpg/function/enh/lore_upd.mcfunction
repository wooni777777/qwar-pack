$data modify storage rpg:enh it.components."minecraft:lore"[0] set value {"text":"강화 +$(lv)","color":"gold","bold":true,"italic":false}

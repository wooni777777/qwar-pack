scoreboard players set #ok rpg.sys 0
execute if score @s rpg.eq matches 201 run scoreboard players set @s rpg.eqt 1
execute if score @s rpg.eq matches 201 run function rpg:equip/tier
execute if score @s rpg.eq matches 201 run scoreboard players set #ok rpg.sys 1
execute if score @s rpg.eq matches 202 run scoreboard players set @s rpg.eqt 2
execute if score @s rpg.eq matches 202 run function rpg:equip/tier
execute if score @s rpg.eq matches 202 run scoreboard players set #ok rpg.sys 1
execute if score @s rpg.eq matches 203 run scoreboard players set @s rpg.eqt 3
execute if score @s rpg.eq matches 203 run function rpg:equip/tier
execute if score @s rpg.eq matches 203 run scoreboard players set #ok rpg.sys 1
execute if score @s rpg.eq matches 204 run scoreboard players set @s rpg.eqt 4
execute if score @s rpg.eq matches 204 run function rpg:equip/tier
execute if score @s rpg.eq matches 204 run scoreboard players set #ok rpg.sys 1
execute if score @s rpg.eq matches 205 run scoreboard players set @s rpg.eqt 5
execute if score @s rpg.eq matches 205 run function rpg:equip/tier
execute if score @s rpg.eq matches 205 run scoreboard players set #ok rpg.sys 1
execute if score @s rpg.eq matches 206 run scoreboard players set @s rpg.eqt 6
execute if score @s rpg.eq matches 206 run function rpg:equip/tier
execute if score @s rpg.eq matches 206 run scoreboard players set #ok rpg.sys 1
execute if score @s rpg.eq matches 1 run function rpg:equip/menu
execute if score @s rpg.eq matches 1 run scoreboard players set #ok rpg.sys 1
execute if score @s rpg.eq matches 11..399 unless score @s rpg.eq matches 201..206 if score @s rpg.eqs matches 1 run function rpg:equip/buy_str
execute if score @s rpg.eq matches 11..399 unless score @s rpg.eq matches 201..206 if score @s rpg.eqs matches 2 run function rpg:equip/buy_dex
execute if score @s rpg.eq matches 11..399 unless score @s rpg.eq matches 201..206 if score @s rpg.eqs matches 3 run function rpg:equip/buy_con
execute if score #ok rpg.sys matches 0 run function rpg:equip/fail
scoreboard players set @s rpg.eq 0
scoreboard players enable @s rpg.eq

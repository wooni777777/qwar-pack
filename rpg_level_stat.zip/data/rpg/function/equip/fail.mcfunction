tellraw @s ["", {"text": "[장비] ", "color": "gold", "bold": true}, {"text": "크리스탈이 부족하거나 조건(레벨 / 스탯)을 만족하지 못했습니다.", "color": "red"}]
execute at @s run playsound minecraft:entity.villager.no player @s ~ ~ ~ 1 1

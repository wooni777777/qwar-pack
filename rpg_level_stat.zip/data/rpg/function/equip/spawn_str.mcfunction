# 주민 대신 직접 만든 NPC 캐릭터를 세웁니다
execute at @s run function rpg:npc/place3
return 1

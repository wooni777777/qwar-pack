scoreboard players set @s rpg.eqs 3
function rpg:equip/menu

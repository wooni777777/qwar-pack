data remove entity @s interaction
execute as @p[distance=..6] run function rpg:equip/open_str

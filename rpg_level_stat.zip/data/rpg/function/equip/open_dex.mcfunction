scoreboard players set @s rpg.eqs 2
function rpg:equip/menu

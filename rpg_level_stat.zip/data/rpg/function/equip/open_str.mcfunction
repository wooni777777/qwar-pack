scoreboard players set @s rpg.eqs 1
function rpg:equip/menu

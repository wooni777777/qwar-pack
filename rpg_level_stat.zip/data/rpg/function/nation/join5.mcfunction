team join nat5 @s
scoreboard players set @s rpg.nat 5
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"","font":"rpg:icons","color":"blue"},{"text":" 파랑 국가","color":"blue","bold":true},{"text":" 에 들어갔습니다.","color":"white"}]
tellraw @a[team=nat5] [{"text":"[q후계자 전쟁] ","color":"gray"},{"selector":"@s","color":"blue"},{"text":" 님이 파랑 국가에 합류했습니다.","color":"gray"}]
execute at @s run playsound minecraft:block.beacon.power_select player @s ~ ~ ~ 1 1.2
function rpg:nation/open

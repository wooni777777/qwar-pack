team join nat6 @s
scoreboard players set @s rpg.nat 6
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"","font":"rpg:icons","color":"dark_purple"},{"text":" 보라 국가","color":"dark_purple","bold":true},{"text":" 에 들어갔습니다.","color":"white"}]
tellraw @a[team=nat6] [{"text":"[q후계자 전쟁] ","color":"gray"},{"selector":"@s","color":"dark_purple"},{"text":" 님이 보라 국가에 합류했습니다.","color":"gray"}]
execute at @s run playsound minecraft:block.beacon.power_select player @s ~ ~ ~ 1 1.2
function rpg:nation/open

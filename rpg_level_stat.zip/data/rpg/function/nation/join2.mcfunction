team join nat2 @s
scoreboard players set @s rpg.nat 2
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"","font":"rpg:icons","color":"gold"},{"text":" 주황 국가","color":"gold","bold":true},{"text":" 에 들어갔습니다.","color":"white"}]
tellraw @a[team=nat2] [{"text":"[q후계자 전쟁] ","color":"gray"},{"selector":"@s","color":"gold"},{"text":" 님이 주황 국가에 합류했습니다.","color":"gray"}]
execute at @s run playsound minecraft:block.beacon.power_select player @s ~ ~ ~ 1 1.2
function rpg:nation/open

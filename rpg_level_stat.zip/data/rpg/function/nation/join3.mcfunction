team join nat3 @s
scoreboard players set @s rpg.nat 3
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"","font":"rpg:icons","color":"yellow"},{"text":" 노랑 국가","color":"yellow","bold":true},{"text":" 에 들어갔습니다.","color":"white"}]
tellraw @a[team=nat3] [{"text":"[q후계자 전쟁] ","color":"gray"},{"selector":"@s","color":"yellow"},{"text":" 님이 노랑 국가에 합류했습니다.","color":"gray"}]
execute at @s run playsound minecraft:block.beacon.power_select player @s ~ ~ ~ 1 1.2
function rpg:nation/open

# 국가 팀 (friendlyFire false → 같은 국가끼리 때릴 수 없음)
team add nat1 {"text":"빨강","color":"red"}
team modify nat1 color red
team modify nat1 friendlyFire false
team modify nat1 seeFriendlyInvisibles true
team modify nat1 prefix {"text":""}
team add nat2 {"text":"주황","color":"gold"}
team modify nat2 color gold
team modify nat2 friendlyFire false
team modify nat2 seeFriendlyInvisibles true
team modify nat2 prefix {"text":""}
team add nat3 {"text":"노랑","color":"yellow"}
team modify nat3 color yellow
team modify nat3 friendlyFire false
team modify nat3 seeFriendlyInvisibles true
team modify nat3 prefix {"text":""}
team add nat4 {"text":"초록","color":"green"}
team modify nat4 color green
team modify nat4 friendlyFire false
team modify nat4 seeFriendlyInvisibles true
team modify nat4 prefix {"text":""}
team add nat5 {"text":"파랑","color":"blue"}
team modify nat5 color blue
team modify nat5 friendlyFire false
team modify nat5 seeFriendlyInvisibles true
team modify nat5 prefix {"text":""}
team add nat6 {"text":"보라","color":"dark_purple"}
team modify nat6 color dark_purple
team modify nat6 friendlyFire false
team modify nat6 seeFriendlyInvisibles true
team modify nat6 prefix {"text":""}
team add nat7 {"text":"분홍","color":"light_purple"}
team modify nat7 color light_purple
team modify nat7 friendlyFire false
team modify nat7 seeFriendlyInvisibles true
team modify nat7 prefix {"text":""}
team add nat8 {"text":"하양","color":"white"}
team modify nat8 color white
team modify nat8 friendlyFire false
team modify nat8 seeFriendlyInvisibles true
team modify nat8 prefix {"text":""}

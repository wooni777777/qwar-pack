team join nat8 @s
scoreboard players set @s rpg.nat 8
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"","font":"rpg:icons","color":"white"},{"text":" 하양 국가","color":"white","bold":true},{"text":" 에 들어갔습니다.","color":"white"}]
tellraw @a[team=nat8] [{"text":"[q후계자 전쟁] ","color":"gray"},{"selector":"@s","color":"white"},{"text":" 님이 하양 국가에 합류했습니다.","color":"gray"}]
execute at @s run playsound minecraft:block.beacon.power_select player @s ~ ~ ~ 1 1.2
function rpg:nation/open

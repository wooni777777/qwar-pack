# 이미 붙어 있던 팀 접두어를 지웁니다
team modify nat1 prefix {"text":""}
team modify nat2 prefix {"text":""}
team modify nat3 prefix {"text":""}
team modify nat4 prefix {"text":""}
team modify nat5 prefix {"text":""}
team modify nat6 prefix {"text":""}
team modify nat7 prefix {"text":""}
team modify nat8 prefix {"text":""}

team join nat1 @s
scoreboard players set @s rpg.nat 1
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"","font":"rpg:icons","color":"red"},{"text":" 빨강 국가","color":"red","bold":true},{"text":" 에 들어갔습니다.","color":"white"}]
tellraw @a[team=nat1] [{"text":"[q후계자 전쟁] ","color":"gray"},{"selector":"@s","color":"red"},{"text":" 님이 빨강 국가에 합류했습니다.","color":"gray"}]
execute at @s run playsound minecraft:block.beacon.power_select player @s ~ ~ ~ 1 1.2
function rpg:nation/open

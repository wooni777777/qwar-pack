team join nat4 @s
scoreboard players set @s rpg.nat 4
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"","font":"rpg:icons","color":"green"},{"text":" 초록 국가","color":"green","bold":true},{"text":" 에 들어갔습니다.","color":"white"}]
tellraw @a[team=nat4] [{"text":"[q후계자 전쟁] ","color":"gray"},{"selector":"@s","color":"green"},{"text":" 님이 초록 국가에 합류했습니다.","color":"gray"}]
execute at @s run playsound minecraft:block.beacon.power_select player @s ~ ~ ~ 1 1.2
function rpg:nation/open

team join nat7 @s
scoreboard players set @s rpg.nat 7
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"","font":"rpg:icons","color":"light_purple"},{"text":" 분홍 국가","color":"light_purple","bold":true},{"text":" 에 들어갔습니다.","color":"white"}]
tellraw @a[team=nat7] [{"text":"[q후계자 전쟁] ","color":"gray"},{"selector":"@s","color":"light_purple"},{"text":" 님이 분홍 국가에 합류했습니다.","color":"gray"}]
execute at @s run playsound minecraft:block.beacon.power_select player @s ~ ~ ~ 1 1.2
function rpg:nation/open

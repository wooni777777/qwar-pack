team leave @s
scoreboard players set @s rpg.nat 0
tellraw @s [{"text":"[q후계자 전쟁] ","color":"gray"},{"text":"국가에서 탈퇴했습니다.","color":"red"}]
function rpg:nation/open

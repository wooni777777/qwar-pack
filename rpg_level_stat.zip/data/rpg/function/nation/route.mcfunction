execute if score @s rpg.nat matches 1 run function rpg:nation/join1
execute if score @s rpg.nat matches 2 run function rpg:nation/join2
execute if score @s rpg.nat matches 3 run function rpg:nation/join3
execute if score @s rpg.nat matches 4 run function rpg:nation/join4
execute if score @s rpg.nat matches 5 run function rpg:nation/join5
execute if score @s rpg.nat matches 6 run function rpg:nation/join6
execute if score @s rpg.nat matches 7 run function rpg:nation/join7
execute if score @s rpg.nat matches 8 run function rpg:nation/join8
execute if score @s rpg.nat matches 9 run function rpg:nation/leave
scoreboard players set @s rpg.nat 0
scoreboard players enable @s rpg.nat

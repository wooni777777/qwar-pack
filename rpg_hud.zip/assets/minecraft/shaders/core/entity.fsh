#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <rpg:armor3d.glsl>

uniform sampler2D Sampler0;

#ifdef DISSOLVE
uniform sampler2D DissolveMaskSampler;
#endif

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
in vec4 vertexPerFaceColorBack;
in vec4 vertexPerFaceColorFront;
#else
in vec4 vertexColor;
#endif

#ifndef EMISSIVE
in vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
in vec4 overlayColor;
#endif

in vec2 texCoord0;

// rpg:armor3d
in vec3 a3Po;
in vec3 a3Pe;
flat in vec4 a3E;
flat in vec4 a3R2;
flat in vec4 a3R3;
flat in vec4 a3L0N;
flat in vec4 a3L1N;
flat in vec4 a3M;

out vec4 fragColor;

void main() {
    int kind = int(a3M.y + 0.5);
    if (kind == A3_K_FALLBACK) {
        discard;
    }
    if (kind == A3_K_DATA) {
        // ---- rpg:armor3d : 3D 갑옷 ----
        vec2 uv = texCoord0;   // (UV - north 면 중심), 정밀도용
        vec2 sv = vec2(sphericalVertexDistance, cylindricalVertexDistance);
        vec3 dPx = dFdx(a3Po);
        vec3 dPy = dFdy(a3Po);
        vec2 dUx = dFdx(uv);
        vec2 dUy = dFdy(uv);
        vec2 dSx = dFdx(sv);
        vec2 dSy = dFdy(sv);
        int id = int(floor(a3M.z + 0.5));
        if (id < 0) {
            discard;
        }
        int part = id & 3;
        bool mir = (id & 4) != 0;
        mat2 MS = mat2(dSx, dSy);
        mat2 MU = mat2(dUx, dUy);
        float detS = determinant(MS);
        float detU = determinant(MU);
        if (abs(detS) < 1e-3 * length(dSx) * length(dSy) || abs(detS) < 1e-20) {
            discard;
        }
        if (abs(detU) < 1e-3 * length(dUx) * length(dUy) || abs(detU) < 1e-20) {
            discard;
        }
        mat2 J = MU * inverse(MS);
        vec4 rq = vec4(a3_rect(part));
        vec2 hw = 0.5 * vec2(rq.y - rq.x, rq.w - rq.z);
        vec2 cen = 0.5 * vec2(rq.x + rq.y, rq.z + rq.w);
        float jy = mir ? -hw.y : hw.y;
        if (abs(J[0][0] - hw.x) > 0.05 * hw.x || abs(J[1][1] - jy) > 0.05 * hw.y
            || abs(J[1][0]) > 0.05 * hw.x || abs(J[0][1]) > 0.05 * hw.y) {
            discard;
        }
        vec2 C = uv - vec2(hw.x, jy) * sv;
        if (any(greaterThan(abs(C), vec2(0.15)))) {
            discard;
        }

        // 뼈 좌표계 복원 (화면 미분)
        mat2 MUi = inverse(MU);
        vec3 eu = dPx * MUi[0][0] + dPy * MUi[0][1];
        vec3 ev = dPx * MUi[1][0] + dPy * MUi[1][1];
        float la = length(eu);
        float lb = length(ev);
        if (la < 1e-12 || lb < 1e-12) {
            discard;
        }
        vec3 X = eu / la;
        vec3 Y = ev / lb;
        vec3 Zc = normalize(cross(X, Y));
        vec3 Nf = vec3(a3L0N.w, a3L1N.w, a3M.x);
        vec3 Z = dot(Zc, Nf) > 0.0 ? -Zc : Zc;
        float dxp = 2.0 * hw.x;
        float dyp = 2.0 * hw.y;
        float sc;
        float g;
        if (part == 0) {
            g = float(a3_pair(Sampler0, ivec2(4, 0)).y) / 16.0;
            sc = la * dxp / (dxp + 2.0 * g);
        } else {
            sc = (la * dxp - lb * dyp) / (dxp - dyp);
            if (sc <= 0.0) {
                discard;
            }
            g = clamp(0.5 * (la * dxp / sc - dxp), 0.0, 3.0);
        }
        vec3 Pmin = a3Po - eu * (uv.x + hw.x) - ev * (uv.y + hw.y);
        vec3 O = Pmin + sc * g * (X + Y + Z);

        // 광선
        vec3 ro;
        vec3 rd;
        if (abs(a3E.w) > 1e-7 * length(a3E.xyz)) {
            ro = a3E.xyz / a3E.w;
            rd = normalize(a3Pe - ro);
        } else {
            rd = -normalize(vec3(ModelViewMat[0][2], ModelViewMat[1][2], ModelViewMat[2][2]));
            if (dot(a3R2.xyz, rd) < 0.0) {
                rd = -rd;
            }
            ro = a3Pe - rd * (96.0 * sc);
        }
        vec3 rl = ro - O;
        vec3 lo = vec3(dot(rl, X), dot(rl, Y), dot(rl, Z)) / sc;
        vec3 ld = vec3(dot(rd, X), dot(rd, Y), dot(rd, Z)) / sc;

        A3Hit hit = a3_trace(Sampler0, part, lo, ld);
        if (hit.t > 1e29) {
            discard;
        }
        vec3 W = ro + rd * hit.t;
        vec3 nw = normalize(hit.n.x * X + hit.n.y * Y + hit.n.z * Z);
        bool emissive = (hit.flags & 1) != 0;

        vec4 color = hit.col;
        if (!emissive) {
            color.rgb *= a3_light(nw, a3L0N.xyz, a3L1N.xyz);
        }
#ifdef PER_FACE_LIGHTING
        vec4 faceVertexColor = vertexPerFaceColorFront;
#else
        vec4 faceVertexColor = vertexColor;
#endif
#ifdef DISSOLVE
        if (faceVertexColor.a < texture(DissolveMaskSampler, (uv + cen) / vec2(64.0, 32.0)).a) {
            discard;
        }
        faceVertexColor.a = 1.0;
#endif
        color *= faceVertexColor * ColorModulator;
#ifndef NO_OVERLAY
        color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
#endif
#ifndef EMISSIVE
        if (!emissive) {
            color *= lightMapColor;
        }
#endif
        fragColor = apply_fog(color, fog_spherical_distance(W), fog_cylindrical_distance(W), FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);

        // 깊이 (GL [-1,1] / [0,1] 규약 자동 판별)
        float zb = dot(a3R2, vec4(a3Pe, 1.0)) / dot(a3R3, vec4(a3Pe, 1.0));
        float zh = dot(a3R2, vec4(W, 1.0)) / dot(a3R3, vec4(W, 1.0));
        bool halfRange = abs(gl_FragCoord.z - (zb * 0.5 + 0.5)) <= abs(gl_FragCoord.z - zb);
        gl_FragDepth = clamp(halfRange ? zh * 0.5 + 0.5 : zh, 0.0, 1.0);
        return;
    }

    // ---- 바닐라 경로 (변경 없음) ----
    gl_FragDepth = gl_FragCoord.z;
    vec4 color = texture(Sampler0, texCoord0);
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#endif

#ifdef PER_FACE_LIGHTING
    vec4 faceVertexColor = gl_FrontFacing ? vertexPerFaceColorFront : vertexPerFaceColorBack;
#else
    vec4 faceVertexColor = vertexColor;
#endif

#ifdef DISSOLVE
    if (faceVertexColor.a < texture(DissolveMaskSampler, texCoord0).a) {
        discard;
    }
    // The dissolve effect entirely replaces translucency
    faceVertexColor.a = 1.0;
#endif

    color *= faceVertexColor * ColorModulator;
#ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
#endif
#ifndef EMISSIVE
    color *= lightMapColor;
#endif

    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}

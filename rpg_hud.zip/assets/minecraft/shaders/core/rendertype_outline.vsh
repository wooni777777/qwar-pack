#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <rpg:armor3d.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;

uniform sampler2D Sampler0;

out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexColor = Color;
    texCoord0 = UV0;

    // rpg:armor3d : 발광 윤곽선에 2D 대체 갑옷 상자가 나오지 않게
    if (a3_kind(Sampler0) == A3_K_FALLBACK) {
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
    }
}

#version 330

#if defined(PER_FACE_LIGHTING) || !defined(NO_CARDINAL_LIGHTING)
#moj_import <minecraft:light.glsl>
#endif
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#moj_import <rpg:armor3d.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler0;

#ifndef NO_OVERLAY
uniform sampler2D Sampler1;
#endif

#ifndef EMISSIVE
uniform sampler2D Sampler2;
#endif

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

#ifdef PER_FACE_LIGHTING
out vec4 vertexPerFaceColorBack;
out vec4 vertexPerFaceColorFront;
#else
out vec4 vertexColor;
#endif

#ifndef EMISSIVE
out vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
out vec4 overlayColor;
#endif

out vec2 texCoord0;

// rpg:armor3d
out vec3 a3Po;
out vec3 a3Pe;
flat out vec4 a3E;
flat out vec4 a3R2;
flat out vec4 a3R3;
flat out vec4 a3L0N;
flat out vec4 a3L1N;
flat out vec4 a3M;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

#ifdef PER_FACE_LIGHTING
    vec2 light = minecraft_compute_light(Light0_Direction, Light1_Direction, Normal);
    vertexPerFaceColorBack = minecraft_mix_light_separate(-light, Color);
    vertexPerFaceColorFront = minecraft_mix_light_separate(light, Color);
#elif defined(NO_CARDINAL_LIGHTING)
    vertexColor = Color;
#else
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
#endif

#ifndef EMISSIVE
    lightMapColor = sample_lightmap(Sampler2, UV2);
#endif

#ifndef NO_OVERLAY
    overlayColor = texelFetch(Sampler1, UV1, 0);
#endif

    texCoord0 = UV0;

#ifdef APPLY_TEXTURE_MATRIX
    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif

    // ---- rpg:armor3d ----
    a3Po = Position;
    a3Pe = Position;
    a3E = vec4(0.0);
    a3R2 = vec4(0.0);
    a3R3 = vec4(0.0);
    a3L0N = vec4(0.0);
    a3L1N = vec4(0.0);
    a3M = vec4(0.0, 0.0, -1.0, 0.0);

    int kind = a3_kind(Sampler0);
    a3M.y = float(kind);
    if (kind == A3_K_FALLBACK) {
        // 셰이더가 켜져 있으면 2D 대체 레이어는 그리지 않음
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
    } else if (kind == A3_K_DATA) {
        texCoord0 = UV0;
#ifdef PER_FACE_LIGHTING
        vertexPerFaceColorBack = Color;
        vertexPerFaceColorFront = Color;
#else
        vertexColor = Color;
#endif
#if defined(PER_FACE_LIGHTING) || !defined(NO_CARDINAL_LIGHTING)
        a3L0N.xyz = Light0_Direction;
        a3L1N.xyz = Light1_Direction;
#endif
        vec3 nn = normalize(Normal);
        a3L0N.w = nn.x;
        a3L1N.w = nn.y;
        a3M.x = nn.z;

        mat4 pmv = ProjMat * ModelViewMat;
        a3R2 = vec4(pmv[0][2], pmv[1][2], pmv[2][2], pmv[3][2]);
        a3R3 = vec4(pmv[0][3], pmv[1][3], pmv[2][3], pmv[3][3]);
        a3E = inverse(pmv) * vec4(0.0, 0.0, 1.0, 0.0);

        int k = gl_VertexID & 3;
        int id = a3_ident(UV0 * vec2(64.0, 32.0), k);
        vec2 sv = vec2(0.0);
        if (id >= 0) {
            int part = id & 3;
            float rpx = a3_spair(Sampler0, ivec2(9 + 5 * part, 0)).x;
            if (rpx > 0.0) {
                a3M.z = float(id);
                sv = vec2((k == 0 || k == 3) ? 1.0 : -1.0, (k >= 2) ? 1.0 : -1.0);
                vec3 camR = normalize(vec3(ModelViewMat[0][0], ModelViewMat[1][0], ModelViewMat[2][0]));
                vec3 camU = normalize(vec3(ModelViewMat[0][1], ModelViewMat[1][1], ModelViewMat[2][1]));
                bool ortho = abs(a3E.w) <= 1e-7 * length(a3E.xyz);
                if (ortho) {
                    // GUI 등 직교 투영: 화면 전체를 덮는 판
                    float lx = length(vec3(pmv[0][0], pmv[1][0], pmv[2][0]));
                    float ly = length(vec3(pmv[0][1], pmv[1][1], pmv[2][1]));
                    a3Pe = Position + (sv.x * camR + sv.y * camU) * (2.2 / max(min(lx, ly), 1e-6));
                } else {
                    // 원근: 뼈를 감싸는 구(반지름 Dw)의 앞쪽 평면에 원뿔을 덮는 판
                    vec3 eye = a3E.xyz / a3E.w;
                    vec3 fwd = -normalize(vec3(ModelViewMat[0][2], ModelViewMat[1][2], ModelViewMat[2][2]));
                    float zv = max(dot(Position - eye, fwd), 0.02);
                    float Dw = rpx / 16.0 * 1.3;
                    float tanS = 2.0 / max(min(abs(ProjMat[0][0]), abs(ProjMat[1][1])), 1e-3);
                    float zb;
                    float H;
                    if (zv > Dw * 1.02) {
                        zb = zv - Dw;
                        H = zb * min(1.15 * Dw / sqrt(zv * zv - Dw * Dw), tanS);
                    } else {
                        zb = 0.5 * zv;
                        H = zb * tanS;
                    }
                    if (zb < 0.06) {
                        H *= 0.06 / zb;
                        zb = 0.06;
                    }
                    a3Pe = eye + (Position - eye) * (zb / zv) + (sv.x * camR + sv.y * camU) * H;
                }
                texCoord0 = UV0 * vec2(64.0, 32.0) - 0.5 * vec2(a3_rect(part).xz + a3_rect(part).yw);
                gl_Position = pmv * vec4(a3Pe, 1.0);
            }
        }
        // 미분 복원용 (데이터 레이어에서는 안개 값을 프래그먼트에서 다시 계산)
        sphericalVertexDistance = sv.x;
        cylindricalVertexDistance = sv.y;
    }
}

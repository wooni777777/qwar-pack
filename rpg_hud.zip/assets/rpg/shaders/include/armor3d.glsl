#version 330

// ---------------------------------------------------------------------------
// q후계자 전쟁 · 3D 착용 갑옷 (rpg:armor3d)  v52 · v57 (둥근 모서리)
// 직접 작성한 코드입니다 (외부 코드 복사 없음).
//
// v56 : north 면 꼭짓점을 gl_VertexID 순서 없이 UV 만으로 찾음
//       (게임이 꼭짓점 버퍼를 4의 배수가 아닌 자리부터 그리면 갑옷이 통째로 사라져 깜빡이던 문제)
//
// 장비 에셋 1개 = 레이어 2장
//   ① 대체 레이어 (머리 (0,0)~(2,0) = 'RPF' 표식) : 셰이더가 있으면 숨김,
//      코어 셰이더가 꺼진 환경(OptiFine/Iris 등)에서만 바닐라 2D 갑옷으로 보임
//   ② 데이터 레이어 (모든 픽셀 알파 0, 'RPA' 표식) : 상자 목록 + 면 텍스처.
//      바닐라 갑옷 상자의 '앞면(north)' 4꼭짓점을 카메라를 향한 판으로 넓히고,
//      프래그먼트에서 화면 미분으로 뼈(머리·몸통·팔·다리)의 좌표계를 복원한 뒤
//      상자들을 광선 추적해 그립니다. 깊이(gl_FragDepth)도 실제 위치로 씁니다.
//
// 데이터 레이어 텍스처 (RGB 24비트 = 12비트 값 2개, 좌표 단위 1/16 px)
//   행 0 : [0]'RPA' [1](51,68,33) [2](90,165,60) [3](버전,레이어종류) [4](밀도 D,머리 팽창*16)
//          [5+5b .. 9+5b] 뼈 b(0 머리,1 몸통,2 팔,3 다리): (시작,개수) min.xy min.z|max.x max.yz (반지름,예비)
//   행 1~ : 상자 12텍셀 = min.xy | min.z,max.x | max.yz | (축,각도*10) | 피벗.xy | 피벗.z,플래그 | 면 6개 (u0,v0)
//   플래그 : 1 발광 · 2 외곽선을 오린 얇은 판 · (v57) 4~16 = 둥근 모서리 반지름 ((fl>>2)&7) x 0.25px
//   면 순서 : -x, +x, -y(위), +y(아래), -z(앞), +z(뒤)   숨김 면 u0 = 4095
//   색 (255,0,255) = 투명
// ---------------------------------------------------------------------------

#define A3_K_NONE 0
#define A3_K_FALLBACK 1
#define A3_K_DATA 2

ivec3 a3_px(sampler2D s, ivec2 p) {
    return ivec3(texelFetch(s, p, 0).rgb * 255.0 + 0.5);
}

int a3_u24(sampler2D s, ivec2 p) {
    ivec3 c = a3_px(s, p);
    return c.r | (c.g << 8) | (c.b << 16);
}

ivec2 a3_pair(sampler2D s, ivec2 p) {
    int u = a3_u24(s, p);
    return ivec2(u & 4095, (u >> 12) & 4095);
}

vec2 a3_spair(sampler2D s, ivec2 p) {
    ivec2 v = a3_pair(s, p);
    v -= 4096 * (v >> 11);
    return vec2(v) / 16.0;
}

int a3_kind(sampler2D s) {
    ivec2 sz = textureSize(s, 0);
    if (sz.x < 32 || sz.y < 2) return A3_K_NONE;
    ivec3 m0 = a3_px(s, ivec2(0, 0));
    if (m0.r != 82 || m0.g != 80) return A3_K_NONE;
    if (a3_px(s, ivec2(1, 0)) != ivec3(51, 68, 33)) return A3_K_NONE;
    if (a3_px(s, ivec2(2, 0)) != ivec3(90, 165, 60)) return A3_K_NONE;
    if (m0.b == 70) return A3_K_FALLBACK;
    if (m0.b == 65) return A3_K_DATA;
    return A3_K_NONE;
}

// 바닐라 갑옷 모델(64x32)의 north 면 UV 사각형 (u1,u2,v1,v2)
ivec4 a3_rect(int part) {
    if (part == 0) return ivec4(8, 16, 8, 16);    // head  texOffs(0,0)   8x8x8
    if (part == 1) return ivec4(20, 28, 20, 32);  // body  texOffs(16,16) 8x12x4
    if (part == 2) return ivec4(44, 48, 20, 32);  // arm   texOffs(40,16) 4x12x4
    return ivec4(4, 8, 20, 32);                   // leg   texOffs(0,16)  4x12x4
}

// 꼭짓점 k(사각형 안 순서)와 UV로 north 면 꼭짓점인지 판별
// 반환: 부위 | (거울<<2), 아니면 -1
int a3_ident(vec2 uv64, int k) {
    vec2 r = floor(uv64 + 0.5);
    if (any(greaterThan(abs(uv64 - r), vec2(0.02)))) return -1;
    ivec2 iu = ivec2(r);
    for (int p = 0; p < 4; p++) {
        ivec4 q = a3_rect(p);
        ivec2 n = (k == 0) ? ivec2(q.y, q.z) : (k == 1) ? ivec2(q.x, q.z) : (k == 2) ? ivec2(q.x, q.w) : ivec2(q.y, q.w);
        if (iu == n) return p;
        if (p >= 2) {
            ivec2 m = (k == 0) ? ivec2(q.y, q.w) : (k == 1) ? ivec2(q.x, q.w) : (k == 2) ? ivec2(q.x, q.z) : ivec2(q.y, q.z);
            if (iu == m) return p | 4;
        }
    }
    return -1;
}

// v56 : UV 만으로 north 면 꼭짓점인지 판별 (꼭짓점 순서 k 를 쓰지 않음)
//   반환 : 부위 (0 머리 1 몸통 2 팔 3 다리) · sv = 판 모서리 방향 (u 최대 +1 / v 최대 +1)
//   다른 면의 꼭짓점이 같은 UV 를 가지면 잘못 넓혀지지만, 그 삼각형은 프래그먼트 미분 검사에서 버려짐
int a3_ident_uv(vec2 uv64, out vec2 sv) {
    sv = vec2(0.0);
    vec2 r = floor(uv64 + 0.5);
    if (any(greaterThan(abs(uv64 - r), vec2(0.02)))) return -1;
    ivec2 iu = ivec2(r);
    for (int p = 0; p < 4; p++) {
        ivec4 q = a3_rect(p);
        if ((iu.x == q.x || iu.x == q.y) && (iu.y == q.z || iu.y == q.w)) {
            sv = vec2(iu.x == q.y ? 1.0 : -1.0, iu.y == q.w ? 1.0 : -1.0);
            return p;
        }
    }
    return -1;
}

float a3_light(vec3 n, vec3 l0, vec3 l1) {
    if (dot(l0, l0) < 1e-6) return 1.0;
    float a = max(0.0, dot(l0, n)) + max(0.0, dot(l1, n));
    return min(1.0, a * 0.6 + 0.4);
}

vec3 a3_rot(vec3 v, int axis, float c, float s) {
    if (axis == 1) return vec3(v.x, c * v.y - s * v.z, s * v.y + c * v.z);
    if (axis == 2) return vec3(c * v.x + s * v.z, v.y, -s * v.x + c * v.z);
    if (axis == 3) return vec3(c * v.x - s * v.y, s * v.x + c * v.y, v.z);
    return v;
}

// 면 좌표 (px) : 면 f 위의 점 p (상자 좌표)
vec2 a3_face_st(int f, vec3 p, vec3 mn, vec3 mx) {
    if (f == 0) return vec2(mx.z - p.z, p.y - mn.y);
    if (f == 1) return vec2(p.z - mn.z, p.y - mn.y);
    if (f == 2) return vec2(p.x - mn.x, p.z - mn.z);
    if (f == 3) return vec2(p.x - mn.x, mx.z - p.z);
    if (f == 4) return vec2(p.x - mn.x, p.y - mn.y);
    return vec2(mx.x - p.x, p.y - mn.y);
}

vec2 a3_face_wh(int f, vec3 sz) {
    if (f <= 1) return sz.zy;
    if (f <= 3) return sz.xz;
    return sz.xy;
}

vec3 a3_face_n(int f) {
    if (f == 0) return vec3(-1.0, 0.0, 0.0);
    if (f == 1) return vec3(1.0, 0.0, 0.0);
    if (f == 2) return vec3(0.0, -1.0, 0.0);
    if (f == 3) return vec3(0.0, 1.0, 0.0);
    if (f == 4) return vec3(0.0, 0.0, -1.0);
    return vec3(0.0, 0.0, 1.0);
}

// 면 텍셀 (투명/숨김이면 a = 0)
vec4 a3_face_col(sampler2D s, ivec2 base, int f, vec3 p, vec3 mn, vec3 mx, float D) {
    ivec2 o = a3_pair(s, base + ivec2(6 + f, 0));
    if (o.x == 4095) return vec4(0.0);
    vec2 wh = a3_face_wh(f, mx - mn);
    ivec2 n = max(ivec2(wh * D + 0.5), ivec2(1));
    ivec2 t = clamp(ivec2(floor(a3_face_st(f, p, mn, mx) * D)), ivec2(0), n - 1);
    ivec3 c = a3_px(s, o + t);
    if (c == ivec3(255, 0, 255)) return vec4(0.0);
    return vec4(vec3(c) / 255.0, 1.0);
}

// 결과
struct A3Hit {
    float t;      // 월드 광선 거리
    vec3 n;       // 뼈 좌표계 법선
    vec4 col;
    int flags;
};

// v57 : 둥근 모서리 상자와 광선 (직접 작성)
//   상자 = 안쪽 상자(반 크기 hs) 를 반지름 r 공으로 부풀린 모양. ro · rd 는 상자 가운데 기준.
//   t0 = 바깥 상자(hs + r)에 들어가는 거리, t1 = 나가는 거리. 맞으면 거리 th 와 바깥쪽 법선 nn.
bool a3_rbox(vec3 ro, vec3 rd, vec3 hs, float r, float t0, float t1, out float th, out vec3 nn) {
    th = 1e30;
    nn = vec3(0.0, 0.0, -1.0);
    vec3 p = ro + rd * t0;
    vec3 q = abs(p) - hs;
    float e = 1e-4;
    int cnt = (q.x > e ? 1 : 0) + (q.y > e ? 1 : 0) + (q.z > e ? 1 : 0);
    vec3 sg = vec3(p.x < 0.0 ? -1.0 : 1.0, p.y < 0.0 ? -1.0 : 1.0, p.z < 0.0 ? -1.0 : 1.0);
    if (cnt <= 1) {
        // 평평한 면 구역으로 바로 들어옴
        th = t0;
        if (q.x >= q.y && q.x >= q.z) nn = vec3(sg.x, 0.0, 0.0);
        else if (q.y >= q.z) nn = vec3(0.0, sg.y, 0.0);
        else nn = vec3(0.0, 0.0, sg.z);
        return true;
    }
    // 모서리 · 꼭짓점 구역 : 모서리 원기둥 12개 + 꼭짓점 공 8개 중 가장 가까운 것 (스치는 광선도 빠짐없이)
    float best = 1e30;
    float rr = r * r;
    float a0 = dot(rd, rd);
    for (int c = 0; c < 8; c++) {
        vec3 cs = vec3((c & 1) != 0 ? 1.0 : -1.0, (c & 2) != 0 ? 1.0 : -1.0, (c & 4) != 0 ? 1.0 : -1.0);
        vec3 oc = ro - cs * hs;
        float b = dot(oc, rd);
        float cc = dot(oc, oc) - rr;
        float h = b * b - a0 * cc;
        if (h <= 0.0 || a0 < 1e-20) continue;
        float t = (-b - sqrt(h)) / a0;
        if (t < t0 - e || t > t1 + e || t >= best) continue;
        vec3 w = (ro + rd * t) * cs - hs;
        if (all(greaterThanEqual(w, vec3(-e)))) best = t;
    }
    for (int k = 0; k < 3; k++) {
        int i = (k + 1) % 3;
        int j = (k + 2) % 3;
        float a = rd[i] * rd[i] + rd[j] * rd[j];
        if (a < 1e-20) continue;
        for (int c = 0; c < 4; c++) {
            float si = (c & 1) != 0 ? 1.0 : -1.0;
            float sj = (c & 2) != 0 ? 1.0 : -1.0;
            float oi = ro[i] - si * hs[i];
            float oj = ro[j] - sj * hs[j];
            float b = oi * rd[i] + oj * rd[j];
            float cc = oi * oi + oj * oj - rr;
            float h = b * b - a * cc;
            if (h <= 0.0) continue;
            float t = (-b - sqrt(h)) / a;
            if (t < t0 - e || t > t1 + e || t >= best) continue;
            vec3 w = ro + rd * t;
            if ((w[i] - si * hs[i]) * si < -e || (w[j] - sj * hs[j]) * sj < -e) continue;
            if (abs(w[k]) > hs[k] + e) continue;
            best = t;
        }
    }
    if (best > 1e29) return false;
    th = best;
    vec3 ph = ro + rd * th;
    vec3 m = max(abs(ph) - hs, vec3(0.0));
    float lm = length(m);
    nn = lm > 1e-6 ? sign(ph) * m / lm : nn;
    return true;
}

// 뼈 하나의 상자들을 광선 추적 (lo, ld : 뼈 좌표 px, t는 월드 단위)
A3Hit a3_trace(sampler2D s, int part, vec3 lo, vec3 ld) {
    A3Hit h;
    h.t = 1e30;
    h.n = vec3(0.0, 0.0, -1.0);
    h.col = vec4(0.0);
    h.flags = 0;
    int W = textureSize(s, 0).x;
    int perRow = W / 12;
    float D = float(a3_pair(s, ivec2(4, 0)).x);
    ivec2 b0 = ivec2(5 + 5 * part, 0);
    ivec2 sc = a3_pair(s, b0);
    if (sc.y <= 0) return h;
    // 뼈 전체 상자 (AABB) 먼저
    vec2 q0 = a3_spair(s, b0 + ivec2(1, 0));
    vec2 q1 = a3_spair(s, b0 + ivec2(2, 0));
    vec2 q2 = a3_spair(s, b0 + ivec2(3, 0));
    vec3 amn = vec3(q0.x, q0.y, q1.x);
    vec3 amx = vec3(q1.y, q2.x, q2.y);
    vec3 dd = ld;
    dd.x = abs(dd.x) < 1e-9 ? 1e-9 : dd.x;
    dd.y = abs(dd.y) < 1e-9 ? 1e-9 : dd.y;
    dd.z = abs(dd.z) < 1e-9 ? 1e-9 : dd.z;
    vec3 inv = 1.0 / dd;
    vec3 ta = (amn - lo) * inv;
    vec3 tb = (amx - lo) * inv;
    vec3 tmn = min(ta, tb);
    vec3 tmx = max(ta, tb);
    float tN = max(max(tmn.x, tmn.y), tmn.z);
    float tF = min(min(tmx.x, tmx.y), tmx.z);
    if (tF <= max(tN, 0.0)) return h;

    for (int i = 0; i < 160; i++) {
        if (i >= sc.y) break;
        int bi = sc.x + i;
        ivec2 base = ivec2((bi % perRow) * 12, 1 + bi / perRow);
        vec2 r0 = a3_spair(s, base);
        vec2 r1 = a3_spair(s, base + ivec2(1, 0));
        vec2 r2 = a3_spair(s, base + ivec2(2, 0));
        vec3 mn = vec3(r0.x, r0.y, r1.x);
        vec3 mx = vec3(r1.y, r2.x, r2.y);
        ivec2 ra = a3_pair(s, base + ivec2(3, 0));
        int axis = ra.x & 3;
        vec3 o = lo;
        vec3 d = ld;
        vec3 piv = vec3(0.0);
        float cs = 1.0;
        float sn = 0.0;
        if (axis != 0) {
            int ang = ra.y - 4096 * (ra.y >> 11);
            float a = radians(float(ang) / 10.0);
            cs = cos(a);
            sn = sin(a);
            vec2 p0 = a3_spair(s, base + ivec2(4, 0));
            vec2 p1 = a3_spair(s, base + ivec2(5, 0));
            piv = vec3(p0.x, p0.y, p1.x);
            // 상자 좌표로 (역회전)
            o = a3_rot(o - piv, axis, cs, -sn) + piv;
            d = a3_rot(d, axis, cs, -sn);
        }
        vec3 d2 = d;
        d2.x = abs(d2.x) < 1e-9 ? 1e-9 : d2.x;
        d2.y = abs(d2.y) < 1e-9 ? 1e-9 : d2.y;
        d2.z = abs(d2.z) < 1e-9 ? 1e-9 : d2.z;
        vec3 iv = 1.0 / d2;
        vec3 ea = (mn - o) * iv;
        vec3 eb = (mx - o) * iv;
        vec3 emn = min(ea, eb);
        vec3 emx = max(ea, eb);
        float n0 = max(max(emn.x, emn.y), emn.z);
        float f0 = min(min(emx.x, emx.y), emx.z);
        if (f0 <= max(n0, 0.0) || n0 >= h.t) continue;
        int fl = a3_pair(s, base + ivec2(5, 0)).y;
        // v57 : 둥근 모서리
        float rr = float((fl >> 2) & 7) * 0.25;
        if (rr > 0.0) {
            vec3 hz = 0.5 * (mx - mn);
            rr = min(rr, min(hz.x, min(hz.y, hz.z)));
            if (n0 > 0.0) {
                float tr;
                vec3 nr;
                if (!a3_rbox(o - 0.5 * (mn + mx), d, hz - rr, rr, n0, f0, tr, nr)) continue;
                if (tr < h.t) {
                    vec3 pr = o + d * tr;
                    vec3 an = abs(nr);
                    int rx = (an.x >= an.y && an.x >= an.z) ? 0 : ((an.y >= an.z) ? 1 : 2);
                    int rf = rx * 2 + ((rx == 0 ? nr.x : (rx == 1 ? nr.y : nr.z)) > 0.0 ? 1 : 0);
                    vec4 cr = a3_face_col(s, base, rf, clamp(pr, mn, mx), mn, mx, D);
                    if (cr.a > 0.5) {
                        h.t = tr;
                        h.col = cr;
                        h.n = a3_rot(nr, axis, cs, sn);
                        h.flags = fl;
                        continue;
                    }
                }
            }
        }
        // 들어가는 면
        int ax = (n0 == emn.x) ? 0 : ((n0 == emn.y) ? 1 : 2);
        int fi = ax * 2 + ((ax == 0 ? d2.x : (ax == 1 ? d2.y : d2.z)) > 0.0 ? 0 : 1);
        if (n0 > 0.0 && rr <= 0.0) {
            vec3 p = o + d * n0;
            vec4 c = a3_face_col(s, base, fi, p, mn, mx, D);
            if (c.a > 0.5) {
                h.t = n0;
                h.col = c;
                h.n = a3_rot(a3_face_n(fi), axis, cs, sn);
                h.flags = fl;
                continue;
            }
        }
        // 투명하면 나가는 면 (안쪽에서 봄) — 외곽선을 오려 낸 얇은 판(플래그 2)은 건너뜀
        if ((fl & 2) == 0 && f0 < h.t) {
            int bx = (f0 == emx.x) ? 0 : ((f0 == emx.y) ? 1 : 2);
            int fo = bx * 2 + ((bx == 0 ? d2.x : (bx == 1 ? d2.y : d2.z)) > 0.0 ? 1 : 0);
            vec3 p = o + d * f0;
            vec4 c = a3_face_col(s, base, fo, p, mn, mx, D);
            if (c.a > 0.5) {
                h.t = f0;
                h.col = c * vec4(vec3(0.72), 1.0);
                h.n = -a3_rot(a3_face_n(fo), axis, cs, sn);
                h.flags = fl;
            }
        }
    }
    return h;
}
